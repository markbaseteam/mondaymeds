[[Ephes-01#v5]]

Ephesians 1:3-6
![[Drawing EPH0104 Diagram.excalidraw]]

---
> *4 even as he chose us in him before the foundation of the world, that we should be holy and blameless before him. In love 5 <u>he predestined us for adoption to himself as sons through Jesus Christ, according to the purpose of his will</u>, 6 to the praise of his glorious grace, with which he has blessed us in the Beloved.*

Adoption |Sonship |Legal Heirs
G5206 υἱοθεσία huiothesia (hwiy-yo-the-siy'-a) n.
1. the placing as a son.
2. (concretely) adoption.
3. (figuratively) Christian sonship in respect to God.

The Greek word huiothesia [ὑιοθεσια] (G5206 [υἱοθεσία]) is made up of two words, '*huios'* which means "son" and *'thesis'* which means placing.   It literally means “son-placing.” 

The word "adoption" or "huiothesia" in unique to Paul in the New Testament. Judaism did not use adoption in their culture. However, it was a common practice in the Roman culture in which Paul grew up in. Paul uses the Roman practice of adoption as a key metaphor  for the new status that the believers have obtained. 

The Roman culture held a special public ceremony when a child was a teenager that was called "son-placing". It was a coming of age ceremony that declared the child who had no rights previously and who owned nothing, was now officially a son, with all it's privileges and responsibilities that came with being an official family member.  Nothing had changed in relationship, but the child's position had changed from that of being a child to being recognized as a son.

The Roman culture also had the practice of adoption more familiar with us today of adopting a child that was born outside the family by birth. This was often done when a heir was needed. Augustus Caesar was adopted. His adopted father was assassinated and he became the Roman ruler at the time of Christ. 

One thing common with adoptions was that a child who was adopted became a new person, receiving a new name, new position, a new future, all their previous debts were cancelled.  They received all the benefits of an actual son who was born and sometimes even stronger benefits ensuring they were treated as son. 

This would have been the metaphor and picture that Paul was drawing upon to help us to understand our new position, new future, new relationship to God as Father as an adopted child.  The devil was our father. [[John-08#v44|John 8:44]], [[1 John-03#v8|[[1 John 3:8,]][[1 John-03#v9|9,]][[1 John-03#v10|10,]] All our debts have been cancelled as we are members of God's family in Christ.

One of the greatest blessings and privileges of the Christian life is that we now get to call God our Father.  Every time we pray the Lord's prayer we should be reminded what a blessing it is for us to pray" Our Father which art in heaven..."which is a result of our adoption, our sonship status to God himself through Jesus Christ.

The doctrine of adoption is important because it helps us understand how God relates to us, as Father, and how we relate to God as children and to others in the church as 'brothers'.

### Relating to God as Father

> *"You sum up the whole of the New Testament teaching a single phrase, if you speak of it as a revelation of the Fatherhood of the holy Creator. In the same way, you sum up the whole of New Testament religion if you describe it as the knowledge of God as one's holy Father. If you want to judge how well a person understands Christianity, find out how much he makes of the thought of being God's child, and having God as his Father. If this is not the thought that prompts and controls his worship and prayers and his whole outlook on life, it means that he does not understand Christianity very well at all" - JI Packer*

Claiming God as our Father is unique and critical to Christianity.  In Judaism, men rarely if ever prayed to God as "Father".  They certainly did not refer to him as "Abba Father" in the manner that Jesus addressed God. [[Mark-14#v36|Mark 14:36]], [[Rom-08#v15|Rom 8:15]], [[Gal-04#v6|Gal 4:6]]

As children of God, we are able to call God Father, not just Father in a stern manner but in a loving manner, "Abba" which would correspond with our more intimate English word "Daddy. "

God would have us relate to him in no other way.  This is how God relates to us and how we must learn to relate to God.  Not as a servant. Not as an authoritative dictator, but as a loving Father. To relate to God in any other manner is disrespectful and dishonoring to his role. 

In practice, if we did not have a good relationship with our earthly fathers, and have a marred image of what genuine fatherhood looks like, relating to God as Father can be difficult for us.  If our fathers were absent, abusive, neglectful, angry, we could project that false image onto God the Father and have great difficulty realty to God as Father.  Our earthly fathers are but dim shadows of the heavenly reality of God the Father. Some of us have good images of fatherhood. Some of us not so much. If this is the case, we need to pray and seek God to understand and truly appreciate what true fatherhood looks like. A good bible study for this is:

[In My Father's House: Finding Your Hearts True Home - Mary Kassian](https://amzn.to/449NimX)

### Special Access
God relates to us as a Father. [[Ps-103#v13|Psa 103:13]], [[Hos-11#v1|Hosea 11:1,]][[Hos-11#v2|2,]][[Hos-11#v8|8]]  This should be very comforting to us because since God is our Father we have special access to him at all times and can boldly come to the throne of grace in our time of need.

Remember story of John F Kennedy Jr entering his father's office in the Oval office?

![[Pasted image 20230618215613.png]]
John F Kennedy Jr.

### Put off the Old Nature & Put On the New
Our adoption does not change our nature but it changes our status. This is important to realize because our adoption is not based on our works or good behavior.  This is important for any adoptive child to understand.

Our adoption will cause conflict with our old family. Just as our adoption changes our status in new family, it changes our status in the old family. We no longer belong to old family legally. They have no authority over us. We are no longer children of wrath, servants and slaves in the kingdom of darkness. We are now members of God's household [[Ephes-02#v3|Eph 2:3]] [[Ephes-02#v12|Eph 2:12]], [[Ephes-02#v19|Eph 2:19]] We are given a new name. All our previous debts are cancelled. Sometimes the old family has a hard time letting go. Satan will try to say we are still his.  He may continue to torment us and draw us back to "Dear old Dad" but torment is all he can do. He can't touch his. We no longer are his slaves. We no longer wish to imitate him as we once did.  At times we may doubt because of our behavior. It takes a long time for the truth of our adoption to sink into our hearts.

Our adoption is final, we are sealed with the holy spirit, however, it is not fully complete in this world. There is an aspect from 1 John 3:1-3 that is waiting for the sons of God to be revealed. There is still more to come.

Jesus Christ made this relationship possible to us. He restored us to sonship. Our sonship in Christ was always a part of God's will and eternal plan. 

### Relating to God as Children - Our Sonship
Our adoption as children of the Living God, brothers to Jesus Christ, is at the very heart of the gospel and Christian doctrine. The doctrine of adoption does not always receive the emphasis it deserves.

> *Our sonship to God is the apex of Creation and the goal of redemption. - Sinclair Ferguson.*

> *"Adoption is ... the apex of redemptive grace & privilege" - John Murray*

> *"Adoption is the highest privilege that the gospel offers: higher even than justification." - J.I. Packer*

 J.I. Packer made this comment because the doctrine of adoption is sometimes listed as a subcategory of justification or as the subcategory of another doctrine, instead of being listed among the top doctrine headings of regeneration, justification, sanctification and glorification. He is by no means lowering the importance of the doctrine of our justification but raising up the doctrine of our adoption. They are two very distinct doctrines and are not synonymous.
  
>  "The Scriptures make a difference between [justification and adoption] They treat adoption as something over and beyond justification... justification... introduces the...sinner into the society of the righteous...adoption...introduces the sinner into the society of God's family" - J.L. Girardeau.

 Justification alone is hard to wrap our minds around, to have all our sins forgiven before God, to not face his wrath and our due penalty, what a marvelous, marvelous mercy. God could have stopped there and any one of us would be glad to be his subjects, his bond servants.  <span style="background:rgba(240, 200, 0, 0.2)">Justification was fueled by mercy, us not getting what we deserved, adoption, however, is fueled by grace,  pure unmerited favor.</span>  
 
 "*It was to the praise of his glorious grace."* God did not just wipe our slates clean, he elevated us. He restored us, "*he restored the image that he created of Himself and of His glory in the life of man.*" - (Sinclair Ferguson, Children of the Living God) God restored his purpose of Sonship for us in Christ Jesus. God restored his role of Fatherhood that was broken by the fall.
[[2 Cor-06#v18|2 Cor 6:18]]
![[2 Cor-06#v18|2 Cor 6:18]]
This restoring us goes right to the heart of God choosing and predestining us before the foundation of the world that we talked about last week.

**Predestinate/Foreordained**
> Proorizō [Προοριζω] (G4309 [προορίζω]) is a fascinating word. Its simple meaning is “to designate before,” but we see the real depth of it in the fact that it’s a compound word. Pro [Προ] (G4253 [πρό]), of course, means “beforehand,” but horizō [ὁριζω] (G3724 [ὁρίζω]) speaks of a “boundary or limit,” and is actually where our English word horizon comes from. So, just as the horizon marks a limit between what we can and can’t see, God has placed us within a certain limit, a certain “horizon.” He has put us in a place where we can see and comprehend many things but where many other things are hidden from our sight and understanding, many things that are beyond our horizon. Further, even if we walk closer to the horizon, and understand things we never understood before, a new horizon appears. We will never understand it all this side of heaven. - Word of the Day


Last week we saw that it should be no surprise that God did not hap-hazardly create us or the world. He created us according to his own will, with a purpose and an intentional plan before the foundation of the world.  We saw that God declares the end from the beginning. What he says, his word *will* accomplish, it will come to pass.  This is in accordance with his power and his sovereignty. If his word was not accomplished even one time, then God would not be sovereign or he would not be all wise, there would have been something he had not considered. We saw that God is immutable, and that God's plans do not change.  He does not have a plan b. He does not have to adjust course.  Everything that happens, occurs according to his providence and he uses sin as his slave in this world to accomplish his ultimate purposes.

This is important to keep in mind as we look at God's purposes in creating mankind:

**Genesis 1:26:**
*"Then God said, “Let us make man in our image, after our likeness. And let them have dominion over the fish of the sea and over the birds of the heavens and over the livestock and over all the earth and over every creeping thing that creeps on the earth.*"

Why did God create mankind?
1.  To reflect God's own image. [[Gen-01#v26|Gen 1:26]]
2.  To tend and rule over the earth. [[Gen-01#v26|Gen 1:26]]
3.  To praise God [[Isa-43#v21|Isa 43:21]] [[Ps-150#v6|Psa 150:6]]
4. Glorify God and Enjoy him forever. [[Isa-43#v7|Isa 43:7]]
5. Good works [[Ephes-02#v10|Eph 2:10]]

What does it mean to be the image and likeness of God?

Sinclair Ferguson attempts to answer this question in his book 'Children of the Living God.'' by looking at Jesus Christ and the roles he filled. 

**Luke 3:38**
*"the son of Enos, the son of Seth, the son of Adam, the son of God."*

> *"If we wish to understand what man was intended to be, we need to think of him as a son of God.  If in turn, we ask what it means to be a son of God,  the answer must be found in terms of being God's image and likeness."
> 
> What does it mean to be the image and likeness of God? One clue is to be found in the fact that Christ Himself, the Son of God incarnate, is described as being the image of God. By understanding what that means, we can begin to unravel what it means for us also to be God's image, since Christ came to restore to us the image that was marred through sin.
> 
> When Christ came as the last Adam, the second Man, he took on three tasks, He was Prophet, Priest and King. As the Christ, He fulfilled in His life the roles that God had appointed in the Old Testament in order to give His people glimpses of what life in His Kingdom was really all about. But, by fulfilling these roles, Christ was also demonstrating to us what God intended all His children to be. 
> 
> God's sons were intended to be *prophets*. In the sense that they would speak God's word and reveal God's will to the created order. There is a hint of this in the Creation narrative when Adam names the animal kingdom, *"and whatever the man called each  living creature, that was its name".* His word was God's word to his environment.
> 
> God's sons were also intended to be *priests,* expressing the praises and worship of the whole creation. At Creation, all nature was made to unite in a magnificent symphony of worship to the Lord. But rational, articulate praise was expressed supremely by man as God's son. Man's voice and sacrifice of worship was significant to God because he was made as His image. Moreover, as God's son, in a special sense man was able to appreciate the Sabbath day in which he could rest in the presence of his Father and enjoy worshipful contemplation of all the glories of creation. (Gen 2:2-3). 
> 
> Then, thirdly, God's sons were created to be *kings* on the earth. In the complementary descriptions of Creation in Genesis 1 and 2 man is presented as both the apex of Creation (Gen 1) and the center of Creation (Gen 2). God gave him everything in the world as a gift ("I give you every seed bearing plant on the face of the whole earth and every tree that has fruit with seed in it") He gave him dominion over the whole earth. He was to be God's vice-regent!
> 
> Man's life was that of a royal prince in the realm of his heavenly Father. The world was his principality - but one in which he was to demonstrate his loyalty in order to show himself capable of richer decree of privilege and responsibility. Hence the command of God: "You are f****ree to eat from any tree in the garden but you must not eat from the tree of the knowledge of good and evil, for when you eat of it you shall surely die." (Gen 2:16-17)
> 
> From this high dignity and these privileges, man fell. The image of God was fractured the offices God gave to man were brought into disrepute as he disqualified himself from exercising them. True sonship to God thus became a memory of the past, a lost and unrecoverable privilege forfeited by sin."*


Our salvation, our justification and redemption and glorification is very much foreordained/predestined from the foundation of the world when God created us in his image, when he chose us before the foundation of the world to be holy and blameless before him in Christ to predestine us to adoption to himself through Christ.   

Nothing is going to interfere with that. Nothing is going to snatch us out of his hand. Nothing thwarts the will of God. God makes sin his slave to accomplish his purposes.  

Why did God create mankind?
1.  To reflect God's own image. [[Gen-01#v26|Gen 1:26]]
2.  To tend and rule over the earth. [[Gen-01#v26|Gen 1:26]]
3.  To praise God [[Isa-43#v21|Isa 43:21]] [[Ps-150#v6|Psa 150:6]]
4. Glorify God and Enjoy him forever. [[Isa-43#v7|Isa 43:7]]
5. Good works [[Ephes-02#v10|Eph 2:10]]

**Peace & Joy**
That should bring us great peace and joy and boldness that we are children of God! **Security**
It brings us increased security knowing that God loves and cares for us deeply. *It gives us stability in an unstable world.*  
**Direction**
It also provides us with direction. Belonging to God does influence the general direction of our lives.  Our family has meaning and purpose.
**Moral Fiber**
We are no longer shaped by others and this world, we are given courage to stand strong for Gods purposes and his kingdom to come.


READ 1 John 1:1-3:
> *See what kind of love the Father has given to us, that we should be called children of God; and so we are. The reason why the world does not know us is that it did not know him. 2 Beloved, we are God's children now, and what we will be has not yet appeared; but we know that when he appears we shall be like him, because we shall see him as he is. 3 And everyone who thus hopes in him purifies himself as he is pure.*

[[Children of God]]

God has truly lavished his love on us when he blessed us with every spiritual blessing in the heavenly realms in Christ!  

**Lavish** - to bestow something in generous or extravagant quantities on. 

*"<span style="background:rgba(5, 117, 197, 0.2)">What we will be has not yet been revealed; </span>but we know that <span style="background:#d2cbff">when he appears we shall be like him</span>, <span style="background:#d2cbff">because we shall see him as he is</span>. A<span style="background:rgba(205, 244, 105, 0.55)">nd everyone who thus hopes in him purifies himself as he is pure."*</span>

1. <span style="background:rgba(5, 117, 197, 0.2)">Creation waits in anticipation</span>. [[Rom-08#V18|Rom 8:18,]][[Rom-08#v19|19]] For I consider that the sufferings of this present time are not worth comparing with the glory that is to be revealed to us. For the creation waits with eager longing for the revealing of the sons of God. 

2. <span style="background:#d2cbff">We WILL be like Christ</span>. End promise We were created after the image of God. God chose us before the foundation of the world that we would be holy and blameless in his sight.  Blameless before the eyes of God who looks at the heart. This is internal and real humility and purity of heart.    We are God's workmanship, he who began a good work in us will bring it to completion in the day of Jesus Christ. [[Phil-01#v6|Phil 1:6]]  

	<span style="background:#d2cbff">**Romans 8:29**</span>
	"For those whom he foreknew he also <u>predestined to be conformed to the image of his Son,</u> <span style="background:rgba(240, 200, 0, 0.2)">in order that he might be the firstborn among many brothers</span>.  
	
	<span style="background:#d2cbff">**Galatians 4:4-7**</span>
	 But when the fullness of time had come, <u>God sent forth his Son</u>, born of woman, born under the law,  to redeem those who were under the law, <span style="background:rgba(240, 200, 0, 0.2)"><u>so that we might receive adoption as sons.</u></span>  And because you are sons, God has sent the Spirit of his Son into our hearts, crying, “Abba! Father!” So you are no longer a slave, but a son, and if a son, then an heir through God.
	
	<span style="background:#d2cbff">**Hebrews 2:17**</span>
	"Therefore he had to be <u><span style="background:rgba(240, 200, 0, 0.2)">made like his brothers in every respect</span>,</u> so that he might become a merciful and faithful high priest in the service of God, to make propitiation for the sins of the people.""
	

3.  Current hope of being like Christ <span style="background:rgba(205, 244, 105, 0.55)">causes us purify ourselves</span> as he is pure. We want to be like our brother. We begin to imitate. 

### Our New Walk
 As God’s adopted children, we begin to walk somewhat clumsily at first, according to this new spirit within us, to this new nature and our old nature is slowly being put to death as our new nature is growing as we look to God as our Father, as we seek to imitate Him, to imitate Christ, making Jesus our idol in a big brother, hero worship way as small children do. They imitate that which they are around, love and admire. This is what it means to practice righteousness since he is righteous.

> “_We are built to imitate. If we don’t place ourselves in front of God, we will imitate that which we are in front of. Your boss at work, friends that you look up to. You will imitate what you are in front of_.”
> 
> _“We don’t just hear from God one time at salvation and then in obedience walk in it forever. We are consistently shined on by God to shine on others. We consistently need to receive from God, let it take root, and give to others. That is a daily, hourly routine. To the end we stop seeking revelation, we will cut off the source for everything else. That is why we press the scriptures so hard. It is the fuel for the rest of your Christian life_.” – Barry Keldie, Sermon, _Breadth, Width, Height & Depth__._

### Our New Lifestyle
In the family of God, there are some family traits. A new lifestyle is learned in the household of God. For new children it takes time to watch and get use to. But eventually we all start to exhibit the same family traits of our Father as the effects of our new birth.

1. Changed relationship to sin. [[1 John-03#v6|1 John 3:6, ]][[1 John-03#v9|1 John 3:9, ]][[1 John-05#v18|1 John 5:18, ]]
2. Changed relationship to the Church. Church is our family . [[1 John-04#v7|1 John 4:7]], [[1 John-02#v10|1 John 2:10]]  [[1 John-04#v20|1 John 4:20]]
3. Changed relationship to Christ. [[1 John-05#v1|1John 5:1]]
4. Changed relationship to the world   [[1 John-05#v4|1 John 5:4]],  [[1 John-05#v19|1 John 5:19]]

We walk in love
We walk in the light [[1 Thess-05#v5|1 Thess 5:5]]
We walk as imitators of God [[Ephes-05#v1|Eph 5:1]]
The Father's Word is rule.  [[Ps-119#v11|Psa 119:11]]


### Relating to Our Brothers & Sisters
Read: 1 John 3:11-18
> _11 For this is the message you heard from the beginning: We should love one another._ _12 Do not be like Cain, who belonged to the evil one and murdered his brother. And why did he murder him? Because his own actions were evil and his brother’s were righteous. 13 Do not be surprised, my brothers and sisters, if the world hates you. 14 We know that we have passed from death to life, because we love each other. Anyone who does not love remains in death. 15 Anyone who hates a brother or sister is a murderer, and you know that no murderer has eternal life residing in him.
> 
> _16 This is how we know what love is: Jesus Christ laid down his life for us. And we ought to lay down our lives for our brothers and sisters._ _17 If anyone has material possessions and sees a brother or sister in need but has no pity on them, how can the love of God be in that person? 18 Dear children, let us not love with words or speech but with actions and in truth._

Most of us have a brother or sister or have children with a brother and or sister if we were an only child, or have a parent with a brother or sister. We can attest to the unique relationship that exists between brothers and sisters or should exist. Many times, when it does not exist and brothers and sisters are estranged from one another, we know that something is seriously wrong. It’s not supposed to be this way. It’s not normal for brothers and sisters not to talk. As they grow older and begin to build their own families, move away, get busy they may not talk as much or be as close as they once were, however, there is a bond between them that no matter how long it has been they can pick right up where they left off just like it was yesterday. Sometimes this is a good thing and sometimes it’s a bad thing when we pick up right where we left off with our quarrels.

Siblings have unique and intimate insider relationship with one another. A unique bond coming from the same roots, the same parents and experiencing the same upbringing and shared experiences and challenges.  If you have a sibling then you can understand the unique pain that comes with interacting with a sibling, there are unique stresses. Though you can pick your friends you cannot pick your siblings, they are assigned to you by God and sometimes you have to wonder how you two ended up as siblings. Sometimes you share nothing in common despite sharing the same bloodlines, the same background and heritage. Sometimes you have or meet siblings and they have everything in common, so much so that it is eerie how much they are alike. They have the same habits, tastes, gifts, temperament, sense of humor, hobbies, etc…

God's family is very diverse.  It is international being made up of people of all nations, times, ages, giftings, positions...

This picture of siblings is a wonderful picture of us as church members and how we are called to love one another. We too have a unique relationship, a unique binding together through the sharing of God as our Father, through sharing his Spirit, through sharing the blood of Christ, through sharing the experience of salvation and sanctification and pains of spiritual grown and upbringing. God calls us to love one another and to relate to one another with the attachment of siblings. Yes, sometimes we fight and disagree, (_Siblings that say they never fight are most definitely hiding something”)_ but instead of breaking up and leaving the family we forgive and bear with one another.” (_We’re family, right? We foul up and say we’re sorry and let it go.”)_ Sometimes we wonder at our siblings who we share nothing in common with. We wonder how we can be part of the same family. That’s normal too. Sometimes we run into a brother or sister in Christ that we connect with and have so much in common with as our spirits are united that it is eerie but wonderful. In such cases, a sibling can understand you better in an instant having shared the same mind of Christ, the same struggles that you can communicate a thousand words with just a glance of the eyes. The world may not understand, but your sibling understands. Siblings are often a blessing from God.

One of my favorite verses is Psa. 68:6, “_God sets the lonely in families_.” So God has set us in families by giving us the church. In this church body, we protect one another, we provide for one another, we look out for one another, we rejoice with one another, we bear with one another, we confront one another, we annoy one another, we enjoy the delicate joys of sibling abuse as we tease one another. We are familiar with one anthers greatest weaknesses and strengths. We are one another’s greatest champions. The church is designed to be a place of rest, to be the place to receive all the spiritual support, emotional support, physical support of a healthy, functional family. In a time when so many families are broken and dysfunctional this world needs the church. You and I need the church. Saying one does not need the church or attend the church is like saying you do not need a family. It’s nonsense. God designed the family unit and he designed us to grow in families not only physically but also spiritually.

Many people see their relationship with God as a one way relationship. As long as they see themselves as good with God then they have no need to be good with everyone else. This is their idea of a “_personal relationship with Jesus Christ_.” It’s a private relationship. Although God does relate to each one of us individually and personally, he also relates to us corporately as a body, with him as a head. There are no living unattached body parts. If a body part is unattached it is dead. If a tree branch is unattached it is dead. In order to be alive, to be fully functioning member of a body you must be attached to the body. This is what it means to abide.

_I am the true vine, and my Father is the gardener._ _2 He cuts off every branch in me that bears no fruit, while every branch that does bear fruit he prunes so that it will be even more fruitful. 3 You are already clean because of the word I have spoken to you. 4 Remain in me, as I also remain in you. No branch can bear fruit by itself; it must remain in the vine. Neither can you bear fruit unless you remain in me._

_5 “I am the vine; you are the branches. If you remain in me and I in you, you will bear much fruit; apart from me you can do nothing._ _6 If you do not remain in me, you are like a branch that is thrown away and withers; such branches are picked up, thrown into the fire and burned. 7 If you remain in me and my words remain in you, ask whatever you wish, and it will be done for you. 8 This is to my Father’s glory, that you bear much fruit, showing yourselves to be my disciples. (John 15:1-8)_

Apart from staying attached to Christ’s body, we cannot bear fruit. Unattached Christians are fruitless Christians. No one can be the body to themselves. We are all individual parts placed in the body according to the spirit and God’s will. (1 Cor. 12)

We can only grow as we remain attached to the body. We can only bear fruit as we remain attached to the body. Being part of a body, we naturally, look out for the welfare and benefit of the entire body because if one part hurts we all hurt. If one part is missing, we all get overworked to cover for it. 

A body does not attack itself…yet this is what we see happens. This is where illnesses come from. Autoimmune diseases. Cancer.

> _Many chronic diseases are the result of the body’s immune system mistakenly perceiving that the body is under attack from foreign bodies. A counterattack is then launched — an inflammatory response meant to vanquish the intruder. In reality, the immune system has misinterpreted the threat and is actually attacking the body’s own cells and tissue_. –[Science Daily](http://www.sciencedaily.com/releases/2011/03/110324104412.htm)

This same happens within the church body. “Normal” disagreements happen between members, between siblings and we as a body forget this essential truth from Eph. 6:12:

_“For our struggle is not against flesh and blood, but against the rulers, against the powers, against the world forces of this darkness, against the spiritual forces of wickedness in the heavenly places._” – Eph. 6:12

Instead of fighting the foreign enemy, Satan, turning to God in prayer, seeking reconciliation, we turn against our own body and attack our own members as foreigners to be rejected from the body. The church body immune system misinterprets the threat and attacks itself.

Love one another. Love your siblings. Hang on. Stay attached. Remember who our enemy is and that we do not struggle against flesh and blood. The body should never attack itself but should always be looking out for the good and benefit of the body.  

_Rejoice with those who rejoice; mourn with those who mourn. Live in harmony with one another_. – Romans 12:15-16

It’s abnormal to attack the body, to attack your own family and sibling. It’s the worse situation that any parent can imagine when one sibling harms another sibling. Yet it happens and Cain and Abel were the start of it back in Genesis 4.

===What God has joined together in the body of Christ to not be separated. We need to be very cautious about causing division within the family ourselves. God calls for unity.===

God, our Father, command his children to love one another. It is the family emblem. How we are known. See how they love one another!!

> *"The family of God is like a man going into the forest to gather wood for his fire. He collects the branches he sees lying around him. But as he does so he realizes he has a problem. How is he going to get them home? One branch is thick, another thin; one is long, another short; one is straight, another crooked. So he binds them together with a cord, and in this way he is able to carry them home in one bundle. This is the way Christ works in the Church.  How can different people possibly live together as one family? Only if they are bound together by the cord of love" - John Owen*

Being part of the same "international" family we have to learn to accept and appreciate one another. God choose us and placed us all together. We don't get to pick our siblings. God has made some rich, some poor, [[James-02#v5|James 2:5-]][[James-02#v6|6]] Some weak and some strong members. [[1 Cor-12#v22|1`Cor 12:22]], [[1 Cor-12#v23|1`Cor 2:23]],[[1 Cor-12#v24|1`Cor 2:24]], [[1 Cor-12#v25|1`Cor 2:25]]. God calls us to bear with those who are weaker in faith and in conscience then what we are, as an elder brother or sister we are to sacrifice our comfort for their benefit.

So strong is the bond of brotherly unity in Christ that to speak against a brother is to speak against the law. [[James-04#v11|James 4:11]] We should be very careful about guarding our tongues and slandering a brother and sister in Christ, speaking lightly or making any false accusation to their character. God will not stand for it. As parents we don't stand for it between our children, how much less so, God our Father who hears every word we say and don't say. There is no fibbing or justifying ourselves and our positions before him. He knows.

One of the most important elements of the household of God is the unity of God. God does not take it lightly anyone who would cause division and stir the children up against one another. It must not be so among us.  Instead we are called to be peace makers in the family. To not be like Cain and Abel.




| Ref                | Verses Children of God                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| ------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1 John 3:1-2       | See what kind of love the Father has given to us, that we should be called children of God; and so we are. The reason why the world does not know us is that it did not know him. 2 Beloved, we are God's children now, and what we will be has not yet appeared; but we know that when he appears we shall be like him, because we shall see him as he is.                                                                                                                                                                                                                                                                                                                                                                                                 |
| John 1:12-13       | But to all who did receive him, who believed in his name, he gave the right to become children of God, who were born, not of blood nor of the will of the flesh nor of the will of man, but of God.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| John 11:51-52      | 51 He did not say this of his own accord, but being high priest that year he prophesied that Jesus would die for the nation, 52 and not for the nation only, but also to gather into one the children of God who are scattered abroad.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| John 20:17         | Jesus said to her, “Do not cling to me, for I have not yet ascended to the Father; but go to my brothers and say to them, ‘I am ascending to my Father and your Father, to my God and your God.’”                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| John 8:38,42-44,47 | 38... I speak of what I have seen with my Father, and you do what you have heard from your father.”...42 42 Jesus said to them, “If God were your Father, you would love me, for I came from God and I am here. I came not of my own accord, but he sent me. 43 Why do you not understand what I say? It is because you cannot bear to hear my word. 44 You are of your father the devil, and your will is to do your father's desires. He was a murderer from the beginning, and does not stand in the truth, because there is no truth in him. When he lies, he speaks out of his own character, for he is a liar and the father of lies....47 Whoever is of God hears the words of God. The reason why you do not hear them is that you are not of God.” |
| Gal 3:26           | for in Christ Jesus you are all sons of God, through faith.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Heb 2:17           | Therefore he had to be made like his brothers in every respect, so that he might become a merciful and faithful high priest in the service of God, to make propitiation for the sins of the people.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Rom 8:29           | For those whom he foreknew he also predestined to be conformed to the image of his Son, in order that he might be the firstborn among many brothers.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Eph 1:5            | he predestined us for adoption to himself as sons through Jesus Christ, according to the purpose of his will,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| Eph 2:18           | For through him we both have access in one Spirit to the Father.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| Gal 4:4-7          |4 But when the fullness of time had come, God sent forth his Son, born of woman, born under the law, 5 to redeem those who were under the law, so that we might receive adoption as sons. 6 And because you are sons, God has sent the Spirit of his Son into our hearts, crying, “Abba! Father!” 7 So you are no longer a slave, but a son, and if a son, then an heir through God.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |






Further Reading:
Recommended Books
[Chosen by God](https://amzn.to/43NhVyB)
[Ferguson, Sinclair - Children of the Living God](https://amzn.to/3JmdfaV)
[Beeke, Joel - Heirs with Christ: The Puritans on Adoption](https://amzn.to/3qTVida)
[Adopted into God's Family: Exploring the Pauline Metaphor - Trevor Burke](https://amzn.to/3p9mUuq)
[In My Father's House: Finding Your Hearts True Home - Mary Kassian](https://amzn.to/449NimX)
