
<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->

---

![[Pasted image 20230710165632.png]]
---
Ephesians 1:13-14 ESV
<font size="6">  
<p align= "left">
13 In him you also, when you heard the word of truth, the gospel of your salvation, and believed in him, were sealed with the promised Holy Spirit, 14 who is the guarantee of our inheritance until we acquire possession of it, to the praise of his glory.
---
Every Spiritual Blessing 
<font size="6">  <p align= "left">
Eph 1:4 He chose us in Christ<br>
Eph 1:5 He predestined us to adoption as sons<br>
Eph 1:6 He richly bestowed His grace on us<br>
Eph 1:7 He redeemed us through Christ's blood<br>
Eph 1:9 He has made known to us the mystery of his will<br>
Eph 1:11 He has  made us an inheritance<br>
Eph 1:12 He has sealed us with His Spirit<br>
---
<center><strong><em>Recap & Review</strong></em></center>
<font size="6">  <p align= "left">
Last week we looked at verses 11 and 12. We saw that we have obtained an inheritance and that we are an inheritance to Christ, the Father gave us to him, we are not our own.  We saw that we are to the praise of His glory. 
<p align= "left">
This week we are going to further examine our position in Christ and the spiritual blessing and gift of the Holy Spirit, given to us by God the Father as a deposit, a guarantee of our future inheritance and as a mark of his possession of us, we are not our own.
---

### In Him
<font size="6">  
<strong>Acts 17:28 </strong>- For in him we live, and move, and have our being;

"I am in my Father, and you in me, and I in you." - <strong> John 14:20</strong><br><br>

---
<font size="6">  
<p align= "justify">
The believer’s position “in Christ,” is one of the most important distinctives between the old and new covenants.

<p align= "justify">
We have seen this 11x already in these first 14 verses of Ephesians.  This same expression is used 172 times in New Testament. It is the central idea of the Christian experience.  Once we were in Adam, in sin,  now we are in Christ,  in his righteousness. Since this new position, this new possession is central to our identity now found in Him, in Christ. We are going to take a few minutes and look at what being "in Christ" means,  so that we can perhaps comprehend this life change that has taken place for us and strengthen our faith. 
---
What does it mean that we are *in Christ*?
---

New Position in New Family Line
<font size="5">  
|In Adam (Old Creation)|In Christ (New Creation)|
|---|---|
|Sinful by nature (Romans 5:12)|Righteous by faith (2 Corinthians 5:21)|
|Condemned to death (Romans 5:18)|Gifted eternal life (Romans 6:23)|
|Separated from God (Isaiah 59:2)|Reconciled to God (2 Corinthians 5:18-19)|
|Spiritually blind (2 Corinthians 4:4)|Spiritually enlightened (Ephesians 1:18)|
|Under the law's curse (Galatians 3:10)|Freed from the law's curse (Galatians 3:13)|
|Slave to sin (Romans 6:16)|Set free from sin (Romans 6:22)|
|Lives in fear of death (Hebrews 2:15)|Lives with hope of resurrection (1 Corinthians 15:22)|
|Has a heart of stone (Ezekiel 36:26)|Has a heart of flesh (Ezekiel 36:26)|
|Walks according to the flesh (Romans 8:5)|Walks according to the Spirit (Romans 8:5)|
|Dead in trespasses (Ephesians 2:1)|Alive with Christ (Ephesians 2:5)|
|Alienated from the community of God (Ephesians 2:12)|Brought near to God's community (Ephesians 2:13)| Self Willed | God's Will|

--
<font size="6.">  
<p align= "justify">
<!-- slide bg="[[BabyinWomb2.jpg]]" data-background-opacity="0.25" -->
<br><br><br><br><P>
<p align= "justify">
This expression "in him" speaks of our unique intimate union with Jesus Christ himself.  As a child exists in their mothers womb  separate from her individually and yet sharing in her life and very much a part of her life,  so we are united to Christ,  drawing our very life from him as a branch draws life from the vine and is sustained by the vine.  Christ is our source of life who sustains us.  Nothing can any longer separate us from Him. 
<P>
<p align= "justify">
God looks at us and sees us joined to Christ and his righteousness
--
How can we remind ourselves of our position and new identity in Christ?
--
<font size="6">
<p align= "left">
In "Concerning Christian Liberty," Martin Luther employs a compelling analogy to depict the concept of union. He likens it to a king who decides to marry a harlot. As they unite in marriage, the harlot is elevated to the status of a queen, inheriting everything that belongs to the king. Instantly, she becomes royalty, her squalid rags replaced with regal robes. Moreover, the king willingly shoulders all her transgressions and debts, assuming them as his own.  Luther writes:,
<font size="5">
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
 <em>Christ, that rich and pious Husband, takes as a wife a needy and impious harlot, redeeming her from all her evils and supplying her with all his good things. It is impossible now that her sins should destroy her, since they have been laid upon Christ and swallowed up in him, and since she has in her Husband Christ a righteousness which she may claim as her own, and which she can set up with confidence against all her sins, against death and hell, saying, “If I have sinned, my Christ, in whom I believe, has not sinned; all mine is his, and all his is mine.” </em>- ["Concerning Christian Liberty"](https://www.gutenberg.org/files/1911/1911-h/1911-h.htm
---
 In him<strong> you also, </strong>when you heard the word of truth believed. 
<font size="6">
<p align= "left">
NLT - 13 <em>"And now you Gentiles have also heard the truth, the Good News that God saves you. And when you believed in Christ, he identified you as his own  by giving you the Holy Spirit, whom he promised long ago.""</em><p>
<font size="6">
<p align= "left">
Paul is now addressing the Gentile, Ephesian audience. In previous verse, he spoke of the Jews who were the first to have hoped in Jesus Christ, but now he turns to the Gentiles and says, "In him you also.... believed"<br><br>

<p align= "left">
Here we begin seeing the work of Salvation...<br> 
---
The Work of Salvation
<font size="6">

<p align= "left">
How does one come to be in Christ?<br>
<p align= "left">
---
Long Answer
<font size="4">
<p align= "left">
1.<strong>Election</strong>: Before the foundation of the world, God chose and set apart a people for himself.  This is called "election". It is not based on any foreseen faith or good works of the person, but solely on God's merciful will.<br><p align= "left">
2. <strong>The Call</strong>: God calls all people to come to Him through the preaching of the Gospel. This is often referred to as the "external call". However, for the elect, God issues an "internal" or "effective call", which is performed by the Holy Spirit and cannot be resisted.<br><p align= "left">
3. <strong>Regeneration</strong>: In this step, the Holy Spirit changes the person's heart. This is what Jesus referred to as being "born again" in John 3:3. The person is given a new nature that loves God and desires to follow His commands. This is often called "being made alive" or "quickened".<br><p align= "left">
4. <strong>Faith and Repentance</strong>: As a result of regeneration, the person responds to the Gospel with faith (believing the truth about Jesus and trusting in Him for salvation) and repentance (turning away from sin and towards God). Both faith and repentance are gifts given by God.<br><p align= "left">
5. <strong>Justification</strong>: God declares the person righteous because of their faith in Jesus. This is not because of any good works they have done, but because of Jesus' righteousness credited to them.<br><p align= "left">
6. <strong>Sanctification</strong>: After justification, the person begins the lifelong process of becoming more like Jesus, empowered by the Holy Spirit. This involves growing in holiness, turning away from sin, and seeking to live according to God's will. <br><p align= "left">
7. <strong>Glorification</strong>: This is the final step when, at the resurrection, believers will be fully and finally freed from sin and made perfect in Christ.<br>
---
Short Answer:<br>

Hear the Gospel<br>
Believe the Gospel <br>
Sealed by Holy Spirit <br>

---
  In him you also, <strong><font color="#4f81bd">when you heard the word of truth, (the gospel of your salvation)</font>, </strong>and believed in him, were sealed with the promised Holy Spirit, 
 
<font size="5">
<p align= "left">
<em>"hearing the word of truth"</em>  and <em>"the gospel of your salvation" </em> are synonymous.  The gospel of our salvation is the word of truth.  Salvation first comes through hearing the word.
<p align= "left">
<strong>Word</strong> [**logos**]means intelligence, word as the expression of that intelligence. Both act of speaking and thing spoken. Here the Good news that God has provided a way of salvation through the atoning work of His Son, Jesus Christ, The Word of God.
<p align= "left">
 It is the <strong>"Word of truth</strong>”—not cunningly devised fables or illusory dreams of men; for it comes from the God of truth, it has Christ the very Truth for its substance, and the Spirit of truth applies it by imparting a true spiritual discernment of its meaning. - Pulpit Commentary
---
The Word of Truth/The Gospel of Your Salvation
<font size="6">  
<p align= "left">
![[Pasted image 20230720215108.png]]
---
Hear the Gospel | Hear the Truth
-<font size="6">  
<p align= "left">
<strong>Romans 10:11-15</strong> - <em>For the Scripture says, “Everyone who believes in him will not be put to shame.” For there is no distinction between Jew and Greek; for the same Lord is Lord of all, bestowing his riches on all who call on him. For “everyone who calls on the name of the Lord will be saved.”
<p align= "left">
How then will they call on him in whom they have not believed? And how are they to believe in him of whom they have never heard? Or  him whom they have never heard  And how are they to hear without someone preaching? And how are they to preach unless they are sent? As it is written, “How beautiful are the feet of those who preach the good news!” </em>
---
Hearing G191 akouō "to Hear"
<font size="5">  
<p align= "left">
<strong>Listening</strong>**  (**akouo**) means to hear with attention, hear with the "ear of the mind". The idea is to hear effectually as to perform or grant what is spoken. Listen or pay attention to a person with resulting conformity to what is advised or commanded. The context often implies to hear and obey (the old word "_heed_" conveys this sense)
<font size="5">  <br><br>
Matthew 11:15 -  <br>
- "He who has ears to hear, let him hear."- NASB<br>
- "The one who has ears had better listen!"" (NET)<br>

"He that hath an ear, let him hear what the Spirit saith unto the churches” (Revelations 2:7, 11, 17, 29; 3:6, 13, 22). 7x
<p align= "left">
Faith comes from hearing. However, hearing alone is not enough. We must intentionally combine what we hear with faith, believing, trusting and obeying God's word.  <br><br>
<Strong>Hebrews 4:2 KJV </strong>- <em> For unto us was the gospel preached, as well as unto them: but the word preached did not profit them, not being mixed with faith in them that heard it.</em>
---
<font size="6">  
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
Throughout scripture, listening is equated with obeying. In many passages, a direct connection is clearly made between listening and obeying. They are like two sides of the same coin. They are synonymous terms. In fact, there is a direct lexical link between the words "hear" and 'obey' in both the Old and the New Testament. The Old Testament word for "hear" is sama. This is the same word used for "obey". There is no seperate word for "obey" in the Old Testament. In the New Testament, the Greek word is "hear" is <em>akouw</em>.  The word for "obey", <em>hupakoun</em> which literally means "to hear under", is a derivative of the word "hear". The implication is that, in God's mind, hearing and obeying are one in the same. - Ken Ramey, Expository Listening
--
<font size="6">  
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
If you are honest, you have to admit that you know far more than you are presently putting into practice. If you never heard another sermon, you would have enough biblical truth to work on applying for the rest of your life. You may feel spiritually satisfied by the fact that you go to church every Sunday, that you have your devotions every day, and that you go to Bible Study every week. But if you are not applying what you are reading and hearing, then you are only kidding yourself. You are forgetting the whole point of looking into God's Word in the first place. - Ken Ramey, Expository Listening
---
When you hear the word of truth...
<font size="5
	  ">
<p align= "left">
Some are saved immediately upon hearing the word of God. In a twinkling of an eye, they hear and they believe.  Others may hear multiple times before they believe or experience great internal wrestlings in their spirit with the truth.<br><br>
	In Scriptures we have:<br>
		- Pentecost Outpouring 3,000 saved. Acts 2:41<br>
		- Peter & John's preaching w/5,000 saved Acts 4:4<br>
		- Paul on Damascus Road Acts <br><br>
	In Christian History we have:<br>
	- Charles Spurgeon <br>
	- John Calvin<br>
	- Jonathan Edwards<br>
--
Charles Spurgeon's Instantaneous Salvation
<font size="6">
<p align= "left">
Spurgeon's conversion took place on a snowy January 6, 1850. At the age of 15, he sought refuge from a snowstorm in a small Primitive Methodist chapel in Colchester, England. The preacher for that day did not arrive, and a stand-in layman stepped forward to deliver the message. His text was Isaiah 45:22: "Look unto me, and be ye saved, all the ends of the earth." Spurgeon recounted that it was at that moment when the simple message of salvation through faith in Christ struck him with great force. He described the experience as feeling the burden of sin being lifted from his shoulders, and he surrendered his life to Jesus Christ as his Lord and Savior. This event marked the beginning of his remarkable ministry.
--
John Calvin's Gradual Transformation
<font size="6">
<p align= "left">
John Calvin was born on July 10, 1509, in Noyon, France, into a Roman Catholic family. He studied law and theology and, from an early age, demonstrated a deep interest in religious matters. It is important to note that Calvin's spiritual journey was marked by a gradual process of change and transformation, rather than a dramatic and instantaneous conversion.<br>
Calvin mentioned having undergone a gradual and inward transformation in his understanding of the gospel and the Scriptures. Initially, he resisted the doctrines of the Reformation, but through his studies and reflections on God's Word, he came to accept the biblical teachings concerning salvation by grace through faith. Calvin's encounter with the Gospel led him to become a passionate advocate for the doctrines of grace and the sovereignty of God in salvation.
--
Jonathan Edwards - Spiritual Wrestling
<font size="5">
<p align= "left">
During his youth, Edwards was intellectually gifted and displayed a remarkable interest in religious matters. He was well-read in theology and philosophy, even at a young age. However, despite his academic knowledge and religious environment, Edwards initially described himself as spiritually indifferent and lacking true faith.
<p align= "left">
It was in his late teens, around the age of 17 or 18, that Edwards experienced what he later referred to as his "conversion." Edwards mentioned that he felt a growing awareness of the immense holiness and sovereignty of God, as well as a deeper understanding of the gravity of human sinfulness. He began to see the stark contrast between his own unworthiness and God's perfect righteousness.
<p align= "left">
However, amidst this spiritual struggle, Edwards experienced a profound revelation of God's grace and mercy through Jesus Christ. It was in this moment of grappling with the reality of sin and the justice of God that he felt an overwhelming sense of God's love and forgiveness offered through Christ's atoning sacrifice on the cross.
---
Word of **Truth** [**aletheia**]
<font size="5">  
<p align= "left">
 Truth refers to the: body of real things, events, facts. Obviously whatever God says is truth. Truth, reality; the unveiled reality lying at the basis of and agreeing with an appearance; the manifested, the veritable essence of matter. Truth is revealed to disciples. Truth sets a person free from bondage to the law, the flesh, the devil [Jn 8:32]
![[Pasted image 20230720220007.png]]
---
Truth  alētheia [αληθεια]<br>
<font size="5">  
<p align= "left">
Word of the Day
<font size="5">  
<p align= "left">
We live in a day when the concept of truth is more and more challenged. Never before has there been such a redefining of truth. Many, in fact, deny that there is any truth at all. In stark contrast, however, the Word of God, in no uncertain terms, makes it clear that there is truth and that truth is to be found only in God and His Word.<br><p align= "left">
The English words truth and true speak of what is real, what really is, what is factual. It’s not opinion, it’s not conjecture, it’s not hypothesis or theory. Rather, it is, like the old expression, “telling it like it is.” If something is true, it is absolutely reliable, totally secure. It cannot change because to do so would mean it’s not true, not reliable.<br><br>
The Greek alētheia [αληθεια] (G225 [ἀλήθεια]) means basically the same thing as the English. As one Greek authority puts it: etymologically alētheia [αληθεια] means <strong>“nonconcealment.” </strong>
<p align= "left">
The fundamental concept to understand about truth is that it is that which is absolute, that which is incontrovertible, irrefutable, incontestable, unarguable, and unchanging. If something is true, it’s always true and can never be untrue, no matter what the circumstances.
---
<font size="5">  
<p align= "left">
In John 18:37–38, Pontius Pilate asked the Lord Jesus, <em>“Art thou a king?” </em>Our Lord responded, <em> “Thou sayest that I am a king. To this end was I born, and for this cause came I into the world, that I should bear witness unto the truth. Every one that is of the truth heareth my voice.” </em> What a powerful statement!<em> “If you would have truth,”</em> He was saying, <em>“you will listen to Me.”</em>To that Pilate spoke three words—probably in at least a cynical if not contemptuous tone—that have echoed through the millennia: <em>“What is truth?”</em><br><br>
The most noteworthy thing about that scene is that while Pilate asked a legitimate and pivotal question, he did not wait for an answer, rather “when he had said this, he went out again.” Think of it—he was standing in front of Truth Incarnate but walked away. And people have been walking away from the truth ever since.<br>
---
<font size="5">  
<p align= "left">

Ponder these two wonderful verses: <em>“Then said Jesus to those Jews which believed on him, If you continue in my word, then are you are my disciples indeed; And you will  know the truth, and the truth will make you free” </em> (John 8:31–32). <br>
<p align= "left">Will science make us free? <br>No, we’re ever learning but never discovering. <br>
Will philosophy make us free? <br>No, it drove Nietzsche mad. <br>Will even religion make us free? <br>
No, the Law keeps us in bondage.<br><br>
It is only the Gospel of Christ that makes us free, and it is only in His Word that we find truth.<br>
No matter what the question, no matter what the issue, let our motto ever be, <em>“What saith the Scripture?”</em> (Rom. 4:3; Gal. 4:30). Why? Because only it is truth.
---
How is one saved? 
<font size="6">
<p align= "left">
First by hearing the Word of Truth.  Hearing the Gospel is critical and this is something we should pray for the lost, and for neighbors.  Pray that they will encounter the gospel message and that they will <em>truly</em> hear it. There is something about hearing the gospel message, encountering the Word of Truth, the "logos", Word of God, that is powerful in and of itself. It is encountering God Himself, his authority and a holy fear and conviction can arise just from encountering truth.
<p align= "left">
---
History of the word Gospel
<font size="6">
<p align= "left">
The Anglo-Saxon word "gospel" originally meant "good news" or "message." Long ago, the term "spell" was used to refer to news or a message. When someone captivates an audience with their message, they may be called a "spellbinder." So, the gospel is like the ultimate "good spell" or "good message." It's God's wonderful news for lost sinners and tells us about His blessed Son. It's crucial to understand that the gospel isn't just good advice to follow; it's good news to believe in. When we believe in this message, we are saved.
<p align= "left">
<strong>Romans 1:16</strong> - For I am not ashamed of the gospel of Christ: for it is the power of God unto salvation to every one that believeth; to the Jew first, and also to the Greek."
---
![[Screenshot_20230722_150052_Chrome.jpg]]
---
<font size="6">  
<p align= "left">
Note the living and active aspect of the Gospel - bearing fruit, growing, opening blind eyes to understand the grace of God in truth. Beloved, does not this truth "take the pressure off" somewhat? In other words, if we are faithful to present the pure Gospel, not a "watered down" version, the Gospel is "alive" and it bears fruit bringing about regeneration and new birth. These effects are not dependent on how clever or eloquent we are in our presentation but on how faithful we are to speak forth the truth Gospel. We do that remembering that this Word of Truth, the Gospel, is the [power (dunamis)]. - Preach the Word
---
Good News!!
<font size="6">  
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
"The Gospel tells rebellious men that God is reconciled, that justice is satisfied, that sin has been atoned for, that the judgment of the guilty may be revoked, the condemnation of the sinner cancelled, the curse of the Law blotted out, the gates of hell closed, the portals of heaven opened wide, the power of sin subdued, the guilty conscience healed, the broken heart comforted, the sorrow and misery of the Fall undone." - A.B. Simpson <!-- .element: style="font-size: 24px" align="justify" --><br>
---
The Gospel
<font size="5">  
<p align= "left">

1. <strong>The Problem:</strong> The gospel starts by addressing the issue of sin and separation from God. It acknowledges that all humans have sinned and fall short of God's perfect standard and the entire world lies under the wrath of God.
    
2. <strong>The Solution:</strong> Jesus Christ is presented as the solution to the problem of sin. Through his substitutional death on the cross, he paid the price for our sin, making it possible for those who trust in him, to be reconciled with God and have eternal life.
    
3. <strong>Faith and Repentance:</strong> The gospel calls people to respond in faith and repentance. Faith involves believing in Jesus Christ as Lord and Savior, while repentance means turning away from sin and turning toward God.
    
4. <strong>Grace:</strong> The gospel emphasizes that salvation is a gift of God's grace and cannot be earned through good works or personal merit. It is freely offered to all who accept it through faith.
---
...the gospel of your <strong>salvation</strong>
<font size="5">  
<p align= "left">
What are we saved from?<br><br>
<strong>Salvation</strong>([4991] ([<em>soteria</em>] pictures one's preservation from danger/destruction. Restore the state of well being or health. Salvation can be described as:<br><br>
<strong>Past</strong> = justified =declared righteous. From penalty of sin <br><strong>Present</strong>= sanctified. from power of sin. <br>
<strong>Future</strong> = glorified From presence of sin <br><br>This is the only use of <strong>Soteria</strong> in Ephesians.
---
And <strong><font color="#4f81bd">believed, trusted</font></strong> in him
<font size="6">  
<p align= "left">
Believed - pisteuō<br>
Thayer Definition:<br>
1) to think to be true, to be persuaded of, to credit, place confidence in<br>
1a) of the thing believed<br>
1a1) to credit, have confidence<br>
1b) in a moral or religious reference<br>
1b1) used in the NT of the conviction and trust to which a man is impelled by a certain inner and higher prerogative and law of soul<br>
1b2) to trust in Jesus or God as able to aid either in obtaining or in doing something: saving faith<br>
2) to entrust a thing to one, i.e. his fidelity<br>
---
You were sealed with the promised Holy Spirit

<font size="5"> 
<p align= "left">
Sealed σφραγίζω  sphragizō<br>
Thayer Definition:<br>
Part of Speech: verb<br>
Total KJV Occurrences: 27<br>
1) to set a seal upon, mark with a seal, to seal<br>
1a) for security: from Satan<br>
1b) since things sealed up are concealed (as the contents of a letter), to hide, keep in silence, keep secret<br>
1c) in order to mark a person or a thing<br>
1c1) to set a mark upon by the impress of a seal or a stamp<br>
1c2) angels are said to be sealed by God<br>
1d) in order to prove, confirm, or attest a thing<br>
1d1) to confirm authenticate, place beyond doubt<br>
1d1a) of a written document<br>
1d1b) to prove one’s testimony to a person that he is what he professes to be<br>
---
<font size="6"> 
<p align= "left">
Three times in the New Testament we read of the believer being sealed with the Spirit. We find it here Eph 1:13 , and in 2Co 1:22 , <em> “Who hath also sealed us, and given the earnest of the Spirit in our hearts,”</em> and then again in Ephesians 4.30, <em>“Grieve not the holy Spirit of God, whereby ye are sealed unto the day of redemption.” </em>These are the only 3 direct references to the sealing of the Holy Spirit in connection with the believer.
---

![[Pasted image 20230724091008.png]]
---
![[Pasted image 20230724090835.png]]
---
![[Pasted image 20230724090805.png]]
---
![[Pasted image 20230724091050.png]]
Seal document and ancient bullae display at Hecht Museum, University of Haifa. Photo by Ferrell Jenkins
---
![[Pasted image 20230724091321.png]]
The Scroll & Seven Seals of Revelation
---
<font size="6"> 
<p align= "left">
A seal was a stamp, a mark of ownership, a mark of approval. Letters or decrees were often sealed with a signet ring. A seal then is much like our county courthouse seal we use to show authenticity of a court document or a company seal showing originality of a corporate document, or even a notary seal.
<p align= "left">
These seals show authenticity and origination.  However, seals also showed ownership and possession in NT times. Today we have stamps that show ownership. Perhaps a logo stamp, name brand symbol. <br>
---
<font size="5"> 
<p align= "left">
Ironside shares a story demonstrating seals in NT era:<br>
Corinth and Ephesus were both  great centers of the lumber industry in ancient times. A raft of logs would be brought from the Black Sea and notice sent to the different lumber firms that the raft was in the harbor. These firms would send their men out and they would look over the logs and make their selection. One would say, “I will take those logs,” another, “I will take these,” and they would give a down payment and then cut a certain wedge on each log that the firm had agreed to take. This was called the seal. The logs might not be drawn out of the water for many weeks, but each was sealed by the mark of the firm that had pledged to purchase them.
<p align= "left">
I was standing on a high bridge at St. Cloud, Minnesota, watching a lumber jam, and as I saw the men working I said to my friend, “Do all these logs belong to one firm?” “Oh no,” he said, “there are representatives of many different firms working here in the Minnesota woods.” “Well,” I asked, “How on earth can they distinguish between the logs?” He showed me from the bridge how they were marked, so that when they reached their destination down the river, the various firms would be able to select their own logs. Though you and I are still tossed about in the waters of this poor world we have been sealed by the Holy Spirit of promise. When the appointed day comes and the Lord takes His own to be with Himself, that will be the day of the redemption of His purchased possession. Then He will take out of this world all who have been sealed with His Spirit. We will go to be with Him in glory.
---
<font size="5"> 
<p align= "left">
 I mentioned the lumber dealer paying down a small sum as a pledge, the rest to be paid in full when the logs were drawn out of the water. God has given us the Holy Spirit as the pledge that eventually we are to be taken out of this world and fully conformed to the image of His Son. Now we are privileged to appropriate in a small measure what we will have in all its fullness when we get home to Heaven.
---
The seal is the Holy Spirit Himself, and His presence in the believer denotes ownership and security. The sealing with the Spirit is not an emotional feeling or some mysterious inward experience.” (Gaebelein)
---
<font size="6"> 
<p align= "left">
It is God's Holy Spirit in us that distinguishes us as Christians, as his possession.<br><br>
<strong>Romans 9:9-11 KJV </strong>- But ye are not in the flesh, but in the Spirit, if so be that the Spirit of God dwell in you. Now if any man have not the Spirit of Christ, he is none of his.<br>
10 And if Christ be in you, the body is dead because of sin; but the Spirit is life because of righteousness.<br>
<p align= "left">
11 But if the Spirit of him that raised up Jesus from the dead dwell in you, he that raised up Christ from the dead shall also quicken your mortal bodies by his Spirit that dwelleth in you.
---
<font size="6"> 
<p align= "left">
By His presence, believers are recognized as belonging to God and as set apart. 
<font size="6"> 
<p align= "left">
When the Gentiles first began to hear the gospel back in Acts 11:19-30, it was noticed that many believed, the Holy Spirit was poured out on them as well as the Jews. It was this that indicated to the early Apostles that the Gentiles were included and Paul was specially set a part to bring the gospel message to the Gentles.  The presence of the Holy Spirit was a key indicator of their salvation.
---
The promised Holy Spirit
<font size="5"> 
<p align= "left">
The Holy Spirit was promised in both OT and NT and because of this is called the Spirit of promise.
<p align= "left">
1. Old Testament: <br>
- <Strong>Ezekiel 36:26-27:</Strong> "And I will give you a new heart, and a new spirit I will put within you. And I will remove the heart of stone from your flesh and give you a heart of flesh. And I will put my Spirit within you, and cause you to walk in my statutes and be careful to obey my rules."<br><br>
New Testament:<br>
- <Strong>John 14:15-17, 26:</Strong> "If you love me, you will keep my commandments. And I will ask the Father, and he will give you another Helper, to be with you forever, even the Spirit of truth, whom the world cannot receive because it neither sees him nor knows him. You know him, for he dwells with you and will be in you."..."But the Helper, the Holy Spirit, whom the Father will send in my name, he will teach you all things and bring to your remembrance all that I have said to you."<br>
- <Strong>John 15:26:</Strong> "But when the Helper comes, whom I will send to you from the Father, the Spirit of truth, who proceeds from the Father, he will bear witness about me."<br>
- <Strong>Acts 1:8: </Strong>"But you will receive power when the Holy Spirit has come upon you, and you will be my witnesses in Jerusalem and in all Judea and Samaria, and to the end of the earth."
---

		What is the work of the Holy Spirit?<br>

---

The Work of the <strong><font color="#4f81bd">Holy Spirit</font></strong>
<font size="5">  <p align= "left">
1. **Conviction of Sin:** The Holy Spirit convicts people of sin, righteousness, and judgment (John 16:8). He brings awareness to our need for a Savior and leads us to repentance.
    
2. **Regeneration:** The Holy Spirit regenerates the hearts of believers, making them new creations in Christ (Titus 3:5). Through the Spirit's work, we are born again and become partakers of the divine nature (2 Peter 1:4).
    
3. **Indwelling:** The Holy Spirit takes up residence in the hearts of believers upon their faith in Jesus Christ (1 Corinthians 6:19). He dwells within believers, guiding, empowering, and sanctifying them.
    
4. **Empowerment and Spiritual Gifts:** The Holy Spirit bestows spiritual gifts upon believers for the edification of the Church and the advancement of God's Kingdom (1 Corinthians 12:7-11). He empowers believers to serve and witness effectively.
---
<font size="5">  <p align= "left">

5. **Sanctification:** The Holy Spirit is actively involved in the process of sanctification, transforming believers into the likeness of Christ (2 Thessalonians 2:13). He empowers believers to live holy lives and resist sin.
    
6. **Teaching and Remembrance:** The Holy Spirit teaches and reminds believers of Jesus' words and teachings (John 14:26). He brings to remembrance the truths of God's Word, guiding believers into all truth.
    
7. **Comfort and Counsel:** The Holy Spirit is called the Comforter or Counselor (John 14:16). He provides comfort, encouragement, and guidance during times of difficulty and confusion.
    
8. **Prayer Intercession:** The Holy Spirit intercedes for believers in prayer when they may not know how to pray (Romans 8:26-27). He helps believers communicate with God effectively.
---
<font size="5">  <p align= "left">

9. **Fruit-Bearing:** The Holy Spirit produces fruit in the lives of believers, such as love, joy, peace, patience, kindness, goodness, faithfulness, gentleness, and self-control (Galatians 5:22-23).
    
10. **Unity in the Body of Christ:** The Holy Spirit unifies believers into one body, the Church, regardless of their backgrounds or differences (1 Corinthians 12:13). He fosters a sense of community and mutual care among believers.
---
"Are ye so foolish? having begun in the Spirit, are ye now made perfect by the flesh?"- Gal 3:3
<p align= "left">
<font size="5">  
Yes, we are.<br>
The Holy Spirit is a critical part of the means of our salvation and continued sanctification. 
---
 Luke 11:13
 
<em>If you then, being evil, know how to give good gifts to your children, how much more will your heavenly Father give the Holy Spirit to those who ask Him?” </em>
---
Who is the <strong>guarantee</strong> of our inheritance, until we acquire possession of it, to the praise of His glory.
<font size="5"> 
<p align= "left">
Other words for guarantee may be, earnest, down payment, deposit, etc...
<font size="5"> 
<p align= "left">
<strong><font color="#4f81bd">Guarantee</font></strong>  ἀῤῥαβών  arrhabōn [G728]<br>
Thayer Definition:<br>
1) an earnest<br>
1a) money which in purchases is given as a pledge or downpayment that the full amount will subsequently be paid<br>
<p align= "left">
<strong>2 Cor 1:22 KJV </strong>- "Who hath also sealed us, and given the earnest of the Spirit in our hearts."
<p align= "left">
<strong>2 Cor. 5:5 ESV</strong> - 5 He who has prepared us for this very thing is God, who has given us the Spirit as a guarantee.
<p align= "left">
If we purchase a house, we may be required to put down earnest money. This a portion of the entire sum to be paid, not a portion to be returned to us.
---
Who is the guarantee of our inheritance, <strong> until we acquire possession of it</strong> , to the praise of His glory.
<font size="5"> 
<p align= "left">
In Ironside's story of the log mill, it was common for the logs to be marked to show ownership before the owner returned to claim them.  In a similiar, God has sealed us and set his mark upon us in this world, showing that we belong to him.
<p align= "left">
He is said to be the earnest, <em>"until we acquire possession of it" </em>or  <em> "until the redemption of the purchased possession" </em>  KJV, NET  It may be called here the possession, because this earnest makes it as sure to the heirs as though they were already possessed of it,
<p align= "left">
Not the pawn, but the earnest, _saith Jerome. A pawn is to be returned again, but an earnest is part of the whole sum, and assures it.
---
Who is the guarantee of our inheritance, until we acquire possession of it , <strong>to the praise of His glory.</strong>
<p align= "Left">
<font size="5">
All things have this end, the praise of God's glory! 
---

END READING
## Ephesians 1:13-14 ESV
<p align= "Left">
<font size="6"> 
 <em> <p align="justify">13 In him you also, when you heard the word of truth, the gospel of your salvation, and believed in him, were sealed with the promised Holy Spirit, 14 who is the guarantee of our inheritance until we acquire possession of it, to the praise of his glory.</em>   
---

![[Image Closing Prayer Pink.png]]

---