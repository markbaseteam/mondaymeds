
<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->

---

![[Pasted image 20230710165632.png]]
---

<center><strong><em>Review</strong></em></center>
<p align= "left"><font size="6">  
Last week we looked at prayer life of Paul and the responsibility of prayer in the life of every believer to be among those who "call upon the name of the Lord." We also shared various methods and tips to really discipline ourselves in the area of prayer.  <br>
<p align= "left">
This week we are going to begin looking into more detail at Paul's prayer found in Ephesians 1:15-17 and examine it more closely. In it we are going to see what authentic Christian faith looks like. Today, there is a lot of what  Dietrich Bohoeffer would call "Cheap Grace". If you have never read his book "The Cost of Discipleship" this is another classic book to add to your reading list. <br>

<p align= "left">

---
Cheap Grace
<font size="5"> 
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
“Cheap grace means grace sold on the market like cheapjacks' wares. The sacraments, the forgiveness of sin, and the consolations of religion are thrown away at cut prices. Grace is represented as the Church's inexhaustible treasury, from which she showers blessings with generous hands, without asking questions or fixing limits. Grace without price; grace without cost! The essence of grace, we suppose, is that the account has been paid in advance; and, because it has been paid, everything can be had for nothing. Since the cost was infinite, the possibilities of using and spending it are infinite. What would grace be if it were not cheap?...  
<p align= "left">  
Cheap grace is the preaching of forgiveness without requiring repentance, baptism without church discipline, Communion without confession, absolution without personal confession. Cheap grace is grace without discipleship, grace without the cross, grace without Jesus Christ, living and incarnate.  
<p align= "left">  
Costly grace is the treasure hidden in the field; for the sake of it a man will go and sell all that he has. It is the pearl of great price to buy which the merchant will sell all his goods. It is the kingly rule of Christ, for whose sake a man will pluck out the eye which causes him to stumble; it is the call of Jesus Christ at which the disciple leaves his nets and follows him.  
---
<font size="5"> 
  <p align= "left">
Costly grace is the gospel which must be sought again and again, the gift which must be asked for, the door at which a man must knock.  
  <p align= "left">
Such grace is costly because it calls us to follow, and it is grace because it calls us to follow Jesus Christ. It is costly because it costs a man his life, and it is grace because it gives a man the only true life. It is costly because it condemns sin, and grace because it justifies the sinner. Above all, it is costly because it cost God the life of his Son: "ye were bought at a price," and what has cost God much cannot be cheap for us. Above all, it is grace because God did not reckon his Son too dear a price to pay for our life, but delivered him up for us. Costly grace is the Incarnation of God.”
  <p align= "left">
...<strong>“When Christ calls a man, he bids him come and die.”</strong><br><Br>
-Dietrich Bonhoeffer, The Cost of Discipleship
---
<b>Ephesians 1:15-17</b>
<p align= "left">
<font size="6">  
15 For this reason, because I have heard of your faith in the Lord Jesus and your love toward all the saints, 16 I do not cease to give thanks for you, remembering you in my prayers, 17 that the God of our Lord Jesus Christ, the Father of glory, may give you the Spirit of wisdom and of revelation in the knowledge of him,
---
<font size="6">  
<p align= "left">
There is a lot in these 3 verses that shows us what an authentic faith looks like just below the surface. I kept trying to focus on the last 3 words, "knowledge of him" for  I know that little phrase is a bottomless pit of marvelous wonder in the meditation of beholding God but my spirit seemed to keep getting redirected to beholding the saints and the authenticity of their faith. So that is going to be our focus for tonight. There are three primary areas that we can always look for authenticity in, in our lives and in the lives of those around us, in a world that is filled with faux Christianity. We are to quick to invite others in to be members of the church, leadership and even friendship without proper examination.  John encourages us to "test the spirits" since many false spirits have gone out in the world.  1 John 4:1.
---
... because I have heard of your faith in the Lord<!-- element style="background: floralwhite" -->
<font size="6">  
<p align= "left">
News of the Ephesians faith in the Lord and of their love for the saints has reached Paul. 
<p align= "left">
Remember, Paul is writing this letter to the Ephesians from Rome, while being under house arrest. News from his previous mission trips and the welfare of the new converts was very important to Paul. Paul truly cared about their well being and prayed continuously for their growth and establishment in the faith. He viewed those church plants as his beloved children and related to them as a father in Christ Jesus.
<p align= "left">
 <strong>1 Cor 4:14-15: </strong> - <em>" I do not write these things to make you ashamed, but to admonish you as my beloved children. For though you have countless guides in Christ, you do not have many father's. For I became your father in Christ Jesus through the gospel.</em>
 
---
...because I have heard of your faith in the Lord and your love toward all the saints<!-- element style="background: floralwhite" -->
<font size="5">  
<p align= "left">
Note Paul's love and concern for the Ephesian believers.  You will see this genuine love and concern for the well being of the saints in all of Paul's letters. He sparkles as he is writing the Corinthians, Galatians, Colossians...every letter of encouragement and admonishment is written with a sincere love and desire for their well being and sanctification. That's authentic, mature faith displayed in Paul.
<p align= "left">
 Paul's letters often requested prayers and hopes that by God's grace he would be permitted to return to various city church plants again to see these churches face to face. To refresh their faith and he fully expected his own faith to be refreshed as well. Notice that it is mutual love. A mature relationship is not lopsided. A mature Christian relationship gives and pours out their life to others but also expects to be refreshed and have life poured back into them.  We are responsible for refreshing our leaders as much as they are responsible for refreshing us. It keeps them from feeling draining and discouraged. Who can you strengthen?
<p align= "left">
This is an important reminder of how the church body needs the church body, how we refresh, encourage and stir up one another's faith with simply living our own faith and acting in love towards other believers. There us strength in numbers and power in accountability to each other. Every part of the body needs to be connected.

---
...because I have heard of your faith in the Lord and your love toward all the saints<!-- element style="background: floralwhite" -->
<font size="6">  
<p align= "left">

<!-- slide bg="[[pexels-gelgas-airlangga-401213 1.jpg]]" data-background-opacity="0.20" -->
<p align= "left">
When Paul heard about the Ephesians' faith in the Lord and their love for all the saints, he was filled with joy, just like someone witnessing the first signs of growth in their plants in the spring. <br>
<p align= "left">
My mother has planted a garden this year using Tim's heirloom tomato seeds. For the first couple of weeks she would go out and water those seeds and look earnestly for signs of life. We had about given up when the first green shoots broke the ground. The ears appeared and the stalks began thickening and growing taller and we began to watch next for the first signs of an actual tomato. 
<p align = "left">
The Gospel message is often pictured as a seed planted in the heart of man. Remember the parable of the sower from Matthew 13?
---
Parable of the Sower
<font size="6">  

<!-- slide bg="[[pexels-gelgas-airlangga-401213 1.jpg]]" data-background-opacity="0.20" -->
<p align= "left">
<strong>Matthew 13:3-9</strong>, <em>" And he told them many things in parables, saying: “A sower went out to sow.  And as he sowed, some seeds fell along the path, and the birds came and devoured them.  Other seeds fell on rocky ground, where they did not have much soil, and immediately they sprang up, since they had no depth of soil,  but when the sun rose they were scorched. And since they had no root, they withered away. Other seeds fell among thorns, and the thorns grew up and choked them.  Other seeds fell on good soil and produced grain, some a hundredfold, some sixty, some thirty.  He who has ears, let him hear.”</em>
---
Parable of Sower Explained
<font size="5">  

<!-- slide bg="[[pexels-gelgas-airlangga-401213 1.jpg]]" data-background-opacity="0.20" -->
<p align= "left">
<strong>Matthew - 13:18-23 </strong> <em> “Hear then the parable of the sower:  When anyone hears the word of the kingdom and does not understand it, the evil one comes and snatches away what has been sown in his heart. This is what was sown along the path. 
<p align= "left">
As for what was sown on rocky ground, this is the one who hears the word and immediately receives it with joy, yet he has no root in himself, but endures for a while, and when tribulation or persecution arises on account of the word, immediately he falls away. 
<p align= "left">
As for what was sown among thorns, this is the one who hears the word, but the cares of the world and the deceitfulness of riches choke the word, and it proves unfruitful. 
<p align= "left">
As for what was sown on good soil, this is the one who hears the word and understands it. He indeed bears fruit and yields, in one case a hundredfold, in another sixty, and in another thirty.”</em>
---
<font size="5">  

<!-- slide bg="[[pexels-gelgas-airlangga-401213 1.jpg]]" data-background-opacity="0.20" -->
<p align = "left">
When planting a garden, proper soil preparation is crucial. This involves tilling and choosing the right soil type. Similarly, the soil symbolizes the human heart. In a parable, Jesus highlights four types of heart conditions, but only one fosters growth:

1. **Calloused Heart** - Resistant to God's Word.
2. **Shallow Heart** - Lacks depth, making it hard for God's teachings to firmly root.
3. **Distracted Heart** - Easily diverted from God's Word due to various desires or concerns.
4. **Open Heart** - Welcoming and responsive to God's Word.

<p align = "left">
It's essential to regularly assess our heart's state, ensuring it remains open to God's Word, so God's word can take deep root, and both faith and love can grow in our own hearts.  We can also pray for others to possess open hearts, making them receptive to His teachings.
<p align = "left">
A mature faith guards the condition of their heart. John Flavel says <em>" The keeping, and right managing of the heart in every condition, is the great business of a Christian’s life... The greatest difficulty in conversion, is, to win the heart to God; and the greatest difficulty after conversion, is, to keep the heart with God. "</em>

We need to guard our hearts from coldness, from distraction and lack of discipline.
---
<font size="5">  

<!-- slide bg="[[pexels-gelgas-airlangga-401213 1.jpg]]" data-background-opacity="0.15" -->
<p align = "left">
A few weeks ago, we studied Ephesians 1:13-14, how we become one with Christ, for "in Him" is where all  spiritual blessings dwell.
<p align = "left">
- Hearing the Gospel<br>
- Believing the Gospel<br>
- Being sealed with the Holy Spirit.<br>
<p align = "left">
We saw the sharing of the gospel is a necessity because it is through hearing the "word of truth" that the Holy Spirit works to bring about faith and belief. Our job is to simply to share the gospel, to share the word of truth. Sow the seed. In doing so, we are working with the Trinity in fulfilling our responsibility in God's great work. God the Father, allows and assigns us a role in the family business. How amazing is that? God could bring about salvation apart from our cooperation, we saw election take place before the foundation of the world, but God planned the means to bring about that salvation within time using all members of the Trinity, he choices and calls, Christ comes and atones, the Holy Spirit sanctifies and protects, and then there is us, positioned in Christ, spreading the good news of the gospel, witnessing God's glory and excellencies to the world. That is our role and our responsibility that God uses. Every role is crucial, even man's.
---
<font size="5">  
<p align = "left">
<!-- slide bg="[[pexels-gelgas-airlangga-401213 1.jpg]]" data-background-opacity="0.15" -->
<p align = "left">Faith in the Lord  is the first sign of new life joined with love, love for God and for the saints. They cannot be separated from each other. Faith works through love. They are the first external indicators of God's transforming power at work. Life!
<p align = "left">
<strong>Galatians 5:6 -</strong><em>For in Christ Jesus neither circumcision nor uncircumcision counts for anything, but only faith working through love.</em>
<p align = "left">
<strong>2 Thess 1:3</strong> - <em> We ought always to give thanks to God for you, brothers, as is right, because your faith is growing abundantly, and the love of every one of you for one another is increasing.</em>
<p align = "left">
<strong>1 Timothy 1:5</strong> - <em> " The aim of our charge is love that issues from a pure heart and a good conscience and a sincere faith."</em>
<p align = "left">
  <strong>Titus 2:2 - </strong><em>Older men are to be sober-minded, dignified, self-controlled, sound in faith, in love, and in steadfastness.

---
Faith  "pistis"
<font size="5">  
<p align= "left">
Faith means to trust or believe. Once we hear the gospel, we respond by the grace of God by believing and trusting in the gospel. atonement for their sins. 
<p align= "left">
"Pistis" also means fidelity or faithfulness. Faithfulness is a requirement in Christianity just like it is in a marriage relationship.  "Constancy". God is known for his faithfulness to us, so we are called to be known by our faithfulness to Christ.   <em>"The righteous shall live by faith."</em>
<p align= "left">
Ephesians 1:1 is addressed to the saints who are in Ephesus and who are <i>"faithful"</i> in Jesus Christ.  They are constant. 
![[Pasted image 20230806144522.png]]

---
Our Faith is a Conduit for the Work of God.
<font size="5">  
<p align= "left">
Jesus marveled at the faith displayed by the centurion in Matthew 8:10.  To many making requests to him for healing, He would  respond, "let it be done according to your faith."  In Matthew 13:58 Jesus was unable to perform miracles in Nazareth his hometown because of their lack of faith.
"<em> And he did not do many mighty works there, because of their unbelief."</em>
<p align= "left">Our faith is a conduit for the work of God. We are to do all things by faith.<p align= "left" >
<strong>Hebrews 11:6,</strong> "Without faith, it is impossible to please him" 
<p align= "left">
<strong>Romans 14:23 </strong> "Whatever does not proceed from faith is sin."
<p align= "left">
We share the gospel in faith, knowing the word of God does not return to him void.  We pray in faith, knowing God hears our prayers and will answer according to his word.
---
Authentic Faith
<font size="5">  
<p align= "left">
<strong>1 Peter 1 6:7</strong><em> 6 In this you rejoice, though now for a little while, if necessary, you have been grieved by various trials, so that the tested genuineness of your faith—more precious than gold that perishes though it is tested by fire—may be found to result in praise and glory and honor at the revelation of Jesus Christ.</em>
<p align= "left">
Unfaithfulness reveals those who do not belong to Christ. They may receive the gospel and walk for a time with the church but when their faith is tested by trials and by time, since it is by effort and not transformation, they eventually go back to their old nature and desert the faith. These are the shallow ground. They are found to have no root in trials or storms.

<p align= "left">
<strong>1 John 2:19 </strong>- <em> 19 They went out from us, but they were not of us; for if they had been of us, they would have continued with us. But they went out, that it might become plain that they all are not of us.</em>
<p align= "left">
Shallow faith is often a cheap faith. Anything of any value is always imitated. Cheap faith is appealing and mass marketed but unsustainable through afflictions which try it. Cheap faith is brief and temporary. It lacks the holy spirit seal of authenticity.
---
Genuine Faith vs Faux Faith
<font size="5">
<p align= "left">
Faith is belief and a trust, but it always has an object. That object should never be faith itself, but in God's word.
<p align= "left">

| Genuine Faith         | Faux Faith          |
| ------- | ---------- |
| Includes whole person, Head, Heart & Spirit           | Merely intellectual or emotional, not of the Spirit |
| Produces fruitfulness, spiritual growth, good works that glorify God       | Unfruitful , lack of spiritual growth in self or others, works are flesh driven,                            |
| Persistent, deep rooted, during trials, the righteous shall never be moved  | Fickle, like chaff, unrooted, easily swayed and persuaded                    |
| Based on trust in God's character, will, word and ways | Based on desire for personal benefits or gain       |
| Leads to a life of obedience, sanctification, sacrifice, self-control.  Pursuit of holiness.  |        No real change in lifestyle or behavior despite professed belief. No pursuit of holiness.          |


---
The Ephesians Demonstration of a Genuine Faith
<font size="5">
<p align= "left">

1. **Faith in the Lord Jesus**: In Ephesians 1:15, Paul says, "For this reason, ever since I heard about your faith in the Lord Jesus..." This indicates that the Ephesian believers had a genuine trust and reliance on Jesus Christ for salvation and daily living.
    
2. **Love for All the Saints**: Alongside their faith in the Lord Jesus, Paul also notes their "love toward all the saints" (Ephesians 1:15). Genuine faith is often accompanied by genuine love for fellow believers, and this was evident in the Ephesian church.
    
3. **Public Repentance Displayed**: The Ephesians received Paul's message positively during his ministry in the city (Acts 19). They believed the gospel, and many turned away from idolatry and magic, publicly burning their scrolls and turning from their former practices.
    
4. **Eagerness to Maintain Unity**: In Ephesians 4:1-3, Paul urges the Ephesians to live in a manner worthy of their calling and to be eager to maintain the unity of the Spirit in the bond of peace. The fact that Paul emphasizes this suggests that they were already engaged in efforts to maintain unity and harmony within the church. Genuine faith seeks reconciliation, forgiveness, whenever possible.
---
<font size="5">
<p align= "left">

5. **Stand Against Darkness**: In Ephesians 6, Paul instructs the believers to put on the full armor of God to stand against the schemes of the devil. The fact that they needed such protection suggests that they were active in their faith and facing opposition, yet they remained steadfast.
    
6. **Local Impact**: As recorded in Acts 19:23-41, the gospel had such a significant impact in Ephesus that local craftsmen, who made idols of the goddess Artemis, rioted because their trade was being threatened. This societal impact is a testament to the genuine faith and transformative effect of the Ephesian believers.

7.  **Spiritual Growth and Maturity**: Throughout the letter, Paul instructs the Ephesians in deeper theological truths, indicating that they were not just superficial believers but were growing in their understanding and maturity.  In Revelations 2, the letter to the church in Ephesus, Jesus commends the Ephesians  for their toil, perseverance, their lack of tolerance for those who work evil, their ability to recognize a false teacher by putting them to the test, they knew doctrine, they endured and did not grow weary, they hated the deeds of the Nicolaitans, who promoted compromise to practice sexual immorality and to eat food sacrificed to idols. The church at Ephesus was a well grounded, doctrinally sound church with a  much commendation from Christ, but despite all this they had lost sight of their primary purpose, they had neglected their first love, and Christ commands them to repent or despite all their remaining "good works" he would remove their lamp stand. How serious! 
---
When Faith Forsakes Love
<font size="5">
<p align= "left">
We said they could not be separated, they should not be separated, but Satan would cause division between our faith and our love that we must guard against. 

1. **Diminished Passion**: Over time, it's possible for the initial fervor and zeal of their faith began to diminish. The Ephesian church might have been going through the motions of their faith without the same passion and love they once had for God Himself.  They neglected their personal relationship and worship of God.  

2. **Routine and Ritual**: Over time, vibrant faith can become routine. What was once done out of love can become mere ritual or tradition. This can lead to spiritual stagnation.
    
3. **Misplaced Priorities**: While the church at Ephesus was commended for their deeds, hard work, and perseverance, it's possible that their focus on orthodoxy and correct doctrine overshadowed their primary love relationship with Jesus and worship. They might have become more focused on "doing" rather than "being" in a loving relationship with Christ. Their passion for sound doctrine could have easily replaced their passion for God and their love for him.
---
<font size="5">
<p align= "left">

4. **Neglect of Basic Christian Virtues**: Their focus on discerning and resisting false teachers might have led to a neglect of basic Christian virtues like love, grace, and compassion, mercy, patience, hope in God for people's transformation. Here in Ephesians 1:15-16 see that Ephesians were once well known for their love for all the saints. Yet their is no commendation from Christ for that love as their is from Paul years before.
    
5. **Reliance on Works**: The church was commended for its deeds, but it's possible they started to rely more on their works than on their relationship with Jesus. Doing things for God began to replace their intimate relationship with Him. Perhaps they stopped praying, expressing their dependence on God and waiting on God and began unintentionally operating on their own works vs the Holy Spirits leading. This is what they would have done at first.

Jesus gives them a solution in Revelation 2:5: _"Consider how far you have fallen! Repent and do the things you did at first."_
---
What did we do at first?

Tarry with Me
---

... and your love toward all the saints <!-- element style="background: floralwhite" -->
<font size="5">  
<p align= "left">
Andrew Murray wrote: “Our love to God is measured by our everyday fellowship with others and the love it displays.” 
<p align= "left">
An indicator of genuine faith in God is a sincere love shown by Christians for one another.  It is easy to say we love God, who we can't see but...
<p align= "left">
Jesus stated in <strong>John 13:35</strong><em> By this all people will know that you are my disciples, if you have love for one another.”</em>
<p align= "left">
Sincere love is next to impossible for false religions to imitate since a sincere love seeks not its own interest as false love does and genuine love originates only from God himself. We would not know what true love is if it were not for Christ dying for sinners. In a world filled with cheap imitations, there is nothing more cheaply and more often imitated then "love". 
---
<font size="5"> 
<p align= "left">
If you want to know how important love for the saints is, read the book of 1 John.  Over and over again again, John calls his readers to remember what they heard in the beginning. Very similar to Jesus telling the church of Ephesus to repent and to do the things they did at first.
<p align= "left">
<strong>1 John 3:11</strong> <em> "This is the message which you have heard from the beginning, that we should love one another"</em>
<p align= "left">
<strong>1 John 3:23</strong> - <em>And this is his commandment, that we believe in the name of His Son Jesus Christ, and love one another, just as He gave a commandment to us."</em>"
<p align= "left">
<strong>Gospel of John 6:29 "  </strong><em>Jesus answered them, “This is the work of God, that you believe in him whom he has sent.”</em>
<p align= "left">
Earlier in 1 John 2:5 John writes:
"But whoever keeps his His word, truly in him, the love of God has been perfected ..

Obedience to God, necessarily grows us in love. If we want to measure our "spiritual maturity" or our "love for God" we must self examine our relationships and our love for others.
---
Brotherly Love
<font size="5"> 
<p align= "left">
<strong>1 John 4:7-8, 20-21 </strong><em> "Beloved, let us love one another, for love is from God; and everyone who loves has been born of God and knows God. The one who does not love does not know God, because God is love....If someone says, "I love God," and hates his brother, he is a liar, for the one who does not love his brother whom he has seen, cannot love God whom he has not seen. And this commandment we have from Him, that the one who loves God should love his brother also."</em>
<p align= "left">
Genuine faith, always displays itself by love to all the saints, not just a specific, local church body, but for the saints born in the family of God, spread all over the world. It's an unselfish love and concern that inspires genuine intercessory prayer for their behalf and seeks unity and reconciliation within the body of Christ.  
<p align= "left">
We see this brotherly love in this very prayer from Paul as he displays his love for the Ephesians.
---
<font size="6">  
<p align= "left">

| **Genuine Love**                       | **False Love**         |
| -------------------- | ---------------------- |
| Selfless (1 Cor 13:5)                  | Selfish                |
| Patient  (1 Cor 13:4)                  | Impatient              |
| Kind (1 Cor 13:4)                      | Cruel                  |
| Rejoices in truth (1 Cor 13:6)         | Rejoices in wrongdoing |
| Always protects (1 Cor 13:7)           | Easily Abandons        |
| Endures All Things (1 Cor 13:7)        | Gives Up Easily        |
| Unconditional (Romans 5:8)             | Conditional            |
| Seeks the best for others (1 Cor 13:4) | Envious or begruding   |
| Honest (Eph 4:15)                      | Deceptive              |
| Always Hopes (1 Cor 13:7)                                       | Quick to Despair                       |

---
The Early Church was known for their  Peculiar Brotherly Love
<font size="6">  
<p align= "left">
Acts 4:32-35 - <em>Now the full number of those who believed were of one heart and soul, and no one said that any of the things that belonged to him was his own, but they had everything in common. And with great power the apostles were giving their testimony to the resurrection of the Lord Jesus, and great grace was upon them all. There was not a needy person among them, for as many as were owners of lands or houses sold them and brought the proceeds of what was sold  and laid it at the apostles' feet, and it was distributed to each as any had need.</em>
---
<font size="5">  
<p align= "left">
In response to much suspicion regarding Christian meetings, practices and peculiar ways of living <strong>Tertullian</strong>(c160-c220) wrote: <em>“It is mainly the deeds of a love so noble that lead many to put a brand upon us. See how they love one another, they say, for they themselves are animated by mutual hatred; how they are ready even to die for one another, they say, for they themselves will sooner put to death (The Apology, ch. 39).”</em>
<p align= "left">
<strong>Justin Martyr</strong>(c100-c165) described early Christian love by stating: <em>“We who used to value the acquisition of wealth and possessions more than anything else now bring what we have into a common fund and share it with anyone who needs it. We used to hate and destroy one another and refused to associate with people of another race or country. Now, because of Christ, we live together with such people and pray for our enemies.”</em>
<p align= "left">
<strong>Clement of Alexandria </strong> (c150 -215 AD), describing the person who has come to know God, wrote, “He impoverishes himself out of love, so that he is certain he may never overlook a brother in need, especially if he knows he can bear poverty better than his brother. He likewise considers the pain of another as his own pain. And if he suffers any hardship because of having given out of his own poverty, he does not complain.”
--
<font size="5">  
<p align= "left">
<strong>The Apology of Aristides</strong>, as translated by D. M. Kay. (c125)
<p align= "left">
XV: But the Christians, O King, while they went about and made search, have found the truth; and as we learned from their writings, they have come nearer to truth and genuine knowledge than the rest of the nations. For they know and trust in God, the Creator of heaven and of earth, in whom and from whom are all things, to whom there is no other god as companion, from whom they received commandments which they engraved upon their minds and observe in hope and expectation of the world which is to come. Wherefore they do not commit adultery nor fornication, nor bear false witness, nor embezzle what is held in pledge, nor covet what is not theirs. They honour father and mother, and show kindness to those near to them; and whenever they are judges, they judge uprightly. They do not worship idols (made) in the image of man; and whatsoever they would not that others should do unto them, they do not to others; and of the food which is consecrated to idols they do not eat, for they are pure. And their oppressors they appease (lit: comfort) and make them their friends; they do good to their enemies; and their women, 
--
<font size="5">  
<p align= "left">
O King, are pure as virgins, and their daughters are modest; and their men keep themselves from every unlawful union and from all uncleanness, in the hope of a recompense to come in the other world. Further, if one or other of them have bondmen and bondwomen or children, through love towards them they persuade them to become Christians, and when they have done so, they call them brethren without distinction. They do not worship strange gods, and they go their way in all modesty and cheerfulness. Falsehood is not found among them; and they love one another, and from widows they do not turn away their esteem; and they deliver the orphan from him who treats him harshly. And he, who has, gives to him who has not, without boasting. And when they see a stranger, they take him in to their homes and rejoice over him as a very brother; for they do not call them brethren after the flesh, but brethren after the spirit and in God. And whenever one of their poor passes from the world, each one of them according to his ability gives heed to him and carefully sees to his burial. And if they hear that one of their number is imprisoned or afflicted on account of the name of their Messiah, all of them anxiously minister to his necessity, and if it is possible to redeem him they set him free.
--
<font size="5">  
<p align= "left">
==And if there is among them any that is poor and needy, and if they have no spare food, they fast two or three days in order to supply to the needy their lack of food.== They observe the precepts of their Messiah with much care, living justly and soberly as the Lord their God commanded them. Every morning and every hour they give thanks and praise to God for His loving-kindnesses toward them; and for their food and their drink they offer thanksgiving to Him. And if any righteous man among them passes from the world, they rejoice and offer thanks to God; and they escort his body as if he were setting out from one place to another near. And when a child has been born to one of them, they give thanks to God; and if moreover it happen to die in childhood, they give thanks to God the more, as for one who has passed through the world without sins. And further if they see that any one of them dies in his ungodliness or in his sins, for him they grieve bitterly, and sorrow as for one who goes to meet his doom.
--
<font size="5">  
<p align= "left">
XVI. Such, O King, is the commandment of the law of the Christians, and such is their manner of life. As men who know God, they ask from Him petitions which are fitting for Him to grant and for them to receive. And thus they employ their whole lifetime. And since they know the loving-kindnesses of God toward them, behold! for their sake the glorious things which are in the world flow forth to view. And verily, they are those who found the truth when they went about and made search for it; and from what we considered, we learned that they alone come near to a knowledge of the truth. And they do not proclaim in the ears of the multitude the kind deeds they do, but are careful that no one should notice them; and they conceal their giving just as he who finds a treasure and conceals it. And they strive to be righteous as those who expect to behold their Messiah, and to receive from Him with great glory the promises made concerning them. And as for their words and their precepts, O King, and their glorying in their worship, and the hope of earning according to the work of each one of them their recompense which they look for in another world,-you may learn about these from their writings. It is enough for us to have shortly informed your Majesty concerning the conduct and the truth of the Christians. For great indeed, and wonderful is their doctrine to him who will search into it and reflect upon it. And verily, this is a new people, and there is something divine (lit: “a divine admixture”) in the midst of them.
http://www.earlychristianwritings.com/text/aristides-kay.html

---
<font size="5"> 
<p align= "left">

Teach me to love deeply<br>
Beyond the surface of what I see<br>
Teach me to love enthusiastically<br>
Emphasizing all the freedom that true love brings.<br>

 Teach me to love unconditionally<br>
When rejection is all I see<br>
Teach me to love purely<br>
Allowing you to meet all my needs<br>

 Teach me to love willfully<br>
by softening my heart while bending my knees<br>
Teach me to love obediently<br>
Even those I would call my enemies<br>

Teach me to love sacrificially<br>
When only your eyes will see<br>
Teach me to love generously<br>
Out of the abundance that flows from thee<br>
---
<font size="5"> 
<p align= "left">

Teach me to love wisely<br>
When temptation would bring me to my knees<br>
Teach me to love righteously<br>
Because not all love flows from thee<br>

Teach me to recognize love<br>
When it’s not what I expected to see<br>
Far too often I have seen love<br>
And fought him as my enemy<br>

Teach me to love<br>
by captivating and refining my taste.<br>
Sin no longer can hold or seduce me<br>
when my heart is satisfied in your embrace<br>

Teach me to love others<br>
by helping me abide in you<br>
Allowing your love to move me<br>
as I commit my heart to love you.<br>
---
Self Examination Questions for Faith & Love
<font size="6">  
<p align= "left">

- Do I genuinely exhibit faith in the Lord Jesus in my daily life, and how does this faith manifest? 
- How is my faith currently being tested?
- Am I expressing love toward fellow believers, and in what ways can I improve in this aspect?
- Am I concerned with the spiritual welfare of the universal church?
- Does my heart rejoice with news of faith in the Lord and love for the saints?
- Do I pray for the saints and Gods grace to be displayed in their lives?
- Do I look expectantly for signs of God's grace in their lives to praise and thank God for?
---
Expressing Love Towards Others
<font size="5">  
<p align= "left">

1. **Patience (v. 4a)**
        - Was I patient with others today, even when they tested my limits?
    - Were there moments when I acted out of impatience or frustration?
2. **Kindness (v. 4b)**
     - Did I show genuine kindness in my interactions with others?
    - Were there opportunities to be kind that I overlooked or ignored?
3. **Envy (v. 4c)**
    - Did I feel envious of others' successes, possessions, or relationships?
    - How did I handle feelings of jealousy or comparison?
4. **Boasting and Pride & Arrogance (v. 4d)**
    - Did I boast about my achievements or seek validation from others?
    - Were there moments when pride influenced my decisions or reactions?
5. **Rude, Dishonoring and Self-seeking (v. 5a)**
     - Did I act in ways that dishonored others or put my interests above theirs?
    - Were there times when I was self-centered or insensitive to others' needs?
    - Did I insist on my own way?
6. **Irritable or Easily Angered (v. 5b)**
    - How did I handle situations that provoked anger or annoyance?
    - Did I react hastily or take time to respond with love and understanding?
---
<font size="5">  
<p align= "left">

7. **Resentful,  Keeping Record of Wrongs (v. 5c)**
    - Did I hold onto grudges or resentments from past offenses?
    - How can I work towards forgiveness and letting go of past hurts?
8. **Rejoicing in Truth (v. 6)**
    - Did I rejoice in the truth, even when it was challenging or uncomfortable?
    - Were there moments when I was tempted to compromise my integrity?
9. **Always Protects (v. 7a)**
      - Did I seek to protect and uphold the dignity of others?
    - Were there times when I failed to stand up for someone in need?
10. **Always Trusts (v. 7b)**
    - Did I trust in the goodness of others and give them the benefit of the doubt?
    - Were there situations where I was quick to judge or make assumptions?
11. **Always Hopes (v. 7c)**
	- Did I remain hopeful in challenging situations, believing the best in others?
	- How did I encourage hope in those around me?
12. **Always Perseveres (v. 7d)**
	- Did I persevere in love, even when faced with obstacles or discouragements?
	- Were there moments when I felt like giving up on loving someone?
---

I do not cease to give thanks for you remembering you in my prayers that the God of our Lord Jesus Christ, the Father of glory, may give you the Spirit of wisdom and of revelation in the knowledge of him. <!-- element style="background: floralwhite" -->

<font size="6">  
<p align= "left">
Paul prays for the Ephesians to know God.

- Why is the knowledge of God important?
- How does one come gain the knowledge of God?
---
Knowledge of God is important because Jesus Christ came to make God the Father known to Us. It was worth dying for.
<font size="6">  
<p align= "left">
<strong>1 John 5:20 </strong> And we know that the Son of God has come and has given us understanding, so that we may know him who is true; and we are in him who is true, in his Son Jesus Christ. He is the true God and eternal life.
<p align= "left">
<strong>John 17:3 - </strong>"And this is eternal life, that they know you, the only true God, and Jesus Christ whom you have sent."



---
Christ came so we would know God.
<font size="5">  
<p align= "left">

| Reference           | Verse                      |
|----------------|-----------------|
| **John 1:18 (ESV)** | "No one has ever seen God; the only God, who is at the Father's side, he has made him known."                              |
| **John 14:7 (ESV)** | "If you had known me, you would have known my Father also. From now on you do know him and have seen him."                 |
| **John 14:9 (ESV)** | "Jesus said to him, 'Have I been with you so long, and you still do not know me, Philip? Whoever has seen me has seen the Father. How can you say, 'Show us the Father'?" |
| **Matthew 11:27 (ESV)** | "All things have been handed over to me by my Father, and no one knows the Son except the Father, and no one knows the Father except the Son and anyone to whom the Son chooses to reveal him." |
| **Colossians 1:15 (ESV)** | "He is the image of the invisible God, the firstborn of all creation."                                                     |
| **Hebrews 1:3 (ESV)** | "He is the radiance of the glory of God and the exact imprint of his nature, and he upholds the universe by the word of his power." |


---
Christianity is about a genuine knowledge of God.  The gospel is a proclamation that we know God. The God that we know, as revealed by Jesus Christ is different than the God of our modern imaginations.
---
<font size="6">  
<p align= "left">
<strong>A.W. Tozer</strong> - "What comes into our minds when we think about God is the most important thing about us."<p>
---
<font size="5">  
<p align= "left">
<strong>J.I Packer</strong> - "Once you become aware that the main business that you are here for is to know God, most of life's problems fall into place of their own accord."<p>
<p align= "left">
<strong>J.I Packer</strong>  - "The world becomes a strange, mad, painful place, and life in it a disappointing and unpleasant business, for those who do not know about God. Disregard the study of God, and you sentence yourself to stumble and blunder through life blindfolded, as it were, with no sense of direction and no understanding of what surrounds you."
---
 <font size="6">  
<p align= "left">
<strong>Jeremiah 9:23-24 </strong> - <em>Thus says the Lord: “Let not the wise man boast in his wisdom, let not the mighty man boast in his might, let not the rich man boast in his riches but let him who boast's boast in this, that he understands and knows me, that I am the Lord who practices steadfast love, justice, and righteousness in the earth. For in these things I delight, declares the Lord.” </em>
---
<font size="5">  
<p align= "left">

| Aspect      | Genuine Knowledge of God                                | False Knowledge of God                             |
|----------------|-------------|----------------|
| **Source**           | Directly from Scripture and the Holy Spirit's guidance | Human interpretations, traditions, or misconceptions|
| **Relationship**     | Personal, intimate relationship with God                | Distant, ritualistic, or merely intellectual       |
| **Fruit**            | Produces love, joy, peace, patience, kindness, etc.     | Leads to pride, hypocrisy, or legalism              |
| **Motivation**       | Love for God and others                                 | Self-gain, reputation, pride, or fear                     |
| **Obedience**        | Obeys God out of love and gratitude                     | Obeys out of obligation, for show, or pride                 |
| **Understanding**    | Seeks to align one's life with God's will               | Takes scripture out of context or twists it         |
| **Response to Sin**  | Repentance and seeking God's forgiveness                | Self-Justification, denial, or indifference              |

---
<font size="6">  
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
"One of the foundational steps in knowing God, and one of the basic demonstrations that we do know God, is prayer - spiritual, persistent, biblically minded prayer." - <strong>D.A. Carson - Praying with Paul.</strong>
---
<font size="5">  
<p align= "left">
<strong>Henry Montagu Butler</strong> an english academic and clergyman at Cambridge in 1860-1885 wrote:<br>
<em>"If I mistake not, our first instinct is to suppose that to know God must be some result of hard thinking, something to be got by books, or something which is granted to intellectual power. Whatever truth there may be in this, there is no allusion to it all through Scripture which does not lead us to connect the thought of knowing God with the study, or the library, or the laboratory. It carries us into another region; it speaks of a knowledge which is open to the poor, the uneducated, the young. It speaks of a state of mind rather than of a degree of attainment; something which leads you to say and to feel as you see it in others, not “how wonderful!” but “how beautiful!”–not “how did he amass all those stores of learning?” but, “how did he become so noble and so like Christ?” He that loveth not, knoweth not God. Is that a hard saying to any of us? What, we ask, the mightiest intellect of modern times, rich with the spoils of time, does not that intellect know God? No, is the Divine answer, not if the man be selfish. It is one thing to know about God, to know what has been said of Him and written and thought of Him, and what science has revealed to us as to the modes of the operations of His hands. This is one thing; but to know God is another. To know God in any true sense is to be unselfish, to be loving, to have towards others the heart of a brother. 
---
<font size="6">  
<p align= "left">
How does one come gain the knowledge of God?
<p align= "left">
Through God's word, absolutely. But there are many a heretic that knows the bible better then you and I, who do not know God.
<p align= "left">
Paul prays for the Spirit of wisdom and of revelation in the knowledge of God. Apart from God revealing himself to us through his spirit of wisdom and revelation, we would not know him.
---
Wisdom

![[Pasted image 20230807012016.png]]
---
<font size="5">  
<p align= "left">
The Greek word "Sophia" (σοφία) means "wisdom." In classical and Hellenistic Greek contexts, "sophia" referred to wisdom in the sense of practical skill or expertise in various fields, but also, and more broadly, to intellectual and moral wisdom.

In the New Testament, "sophia" is used in various ways:

1. **Divine Wisdom**: Refers to the wisdom of God, which is supreme and surpasses human understanding (1 Corinthians 1:21, 24).
    
2. **Contrast with Human Wisdom**: Paul, in his letters, often contrasts divine wisdom with human wisdom, emphasizing the superiority of God's wisdom over the wisdom of this world (1 Corinthians 1:20, 2:6).
    
3. **Spiritual Wisdom**: Paul often prays or expresses the desire that believers may grow in spiritual wisdom, which leads to a deeper understanding of God's will and purposes (Colossians 1:9; Ephesians 1:17).
---
Revelation

![[Pasted image 20230807012057.png]]
---

<font size="5">  
<p align= "left">
"Apokalupsis" (ἀποκάλυψις) is a Greek word that primarily means "revelation" or "unveiling." It comes from the verb "apokalupto," which means "to reveal" or "to uncover." In the context of the New Testament, "apokalupsis" often refers to the revelation or manifestation of God's truth, mysteries, or His divine will to humanity.

Several important points related to "apokalupsis" in the New Testament:

1. **Revelation of God's Mysteries**: In various epistles, Paul uses "apokalupsis" to refer to God's revealing of previously hidden mysteries, especially the mystery of the gospel of Jesus Christ (e.g., Romans 16:25).
    
2. **Revelation of Jesus Christ**: The term is notably used in the title of the last book of the New Testament: The Book of Revelation. In Greek, the title is "Apokalupsis Iesou Christou," which can be translated as "The Revelation of Jesus Christ." This book contains visions and prophecies revealed to the Apostle John concerning the end times and the final victory of Christ.
    
3. **Spiritual Understanding**: In places like Ephesians 1:17, Paul prays that believers might receive a "spirit of wisdom and of revelation (apokalupsis) in the knowledge of Him." Here, the term emphasizes a deeper, spiritual understanding of God's character and will.
    
"Apokalupsis" primarily refers to an unveiling or revealing, especially in the context of divine truths or prophecies being made known to man.
---


<font size="5">  
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>"The people that do know their God shall be strong."
Every believer understands that to know God is the highest and best form of knowledge; and this spiritual knowledge is a source of strength to the Christian. It strengthens his faith. Believers are constantly spoken of in the Scriptures as being persons who are enlightened and taught of the Lord; they are said to "have an unction from the Holy One," and it is the Spirit's peculiar office to lead them into all truth, and all this for the increase and the fostering of their faith. Knowledge strengthens love, as well as faith. Knowledge opens the door, and then through that door we see our Saviour. Or, to use another similitude, knowledge paints the portrait of Jesus, and when we see that portrait then we love him, we cannot love a Christ whom we do not know, at least, in some degree. If we know but little of the excellences of Jesus, what he has done for us, and what he is doing now, we cannot love him much; but the more we know him, the more we shall love him. Knowledge also strengthens hope. How can we hope for a thing if we do not know of its existence? Hope may be the telescope, but till we receive instruction, our ignorance stands in the front of the glass, and we can see nothing whatever; knowledge removes the interposing object, and when we look through the bright optic glass we discern the glory to be revealed, and anticipate it with joyous confidence. Knowledge supplies us reasons for patience. How shall we have patience unless we know something of the sympathy of Christ, and understand the good which is to come out of the correction which our heavenly Father sends us? Nor is there one single grace of the Christian which, under God, will not be fostered and brought to perfection by holy knowledge. How important, then, is it that we should grow not only in grace, but in the "knowledge" of our Lord and Saviour Jesus Christ. -  <strong>Daniel 11:32 - Morning Devotional for Aug. 4th</strong>
---
Ways we can grow in our knowledge of God
<font size="6">  
<p align= "left">
- Read the Bible <br>
-  Prayer<br>
- Spirit of Wisdom & Revelation<br>
- Meditation on God's Word <br>
- Shared Sufferings with Christ<br>
- Obedience<br>
- Worship<br>
-  Fellowship with other believers<br>
-  Examining God's Creation & works<br>
- Serving Others<br>
---

END READING
## Ephesians 1:15-16 ESV
<p align= "Left">
<font size="6"> 
 <em> <p align="justify">15 For this reason, because I have heard of your faith in the Lord Jesus and your love toward all the saints, 16 I do not cease to give thanks for you, remembering you in my prayers, 17 that the God of our Lord Jesus Christ, the Father of glory, may give you the Spirit of wisdom and of revelation in the knowledge of him,</em>   
---

![[Image Closing Prayer Pink.png]]

---
### 1 Thessalonians 3:11-13

"Now may God our Father himself and our Lord Jesus direct our way to you. And may the Lord cause you to increase and abound in love for one another and for all, just as we do for you, so that your hearts are strengthened in holiness to be blameless before our God and Father at the coming of our Lord Jesus with all his saints."
---