
## Ephesians 3:4-6

<p align= "Justify">
3 For this reason  I, Paul, a prisoner of Christ Jesus on behalf of you Gentiles— 2 assuming that you have heard of the stewardship of God's grace that was given to me for you, 3 how the mystery was made known to me by revelation, as I have written briefly. <font color="#548dd4"> 4 When you read this, you can perceive my insight into the mystery of Christ, 5 which was not made known to the sons of men in other generations as it has now been revealed to his holy apostles and prophets by the Spirit. 6 This mystery is that the Gentiles are fellow heirs, members of the same body, and partakers of the promise in Christ Jesus through the gospel.
<p align= "Justify">
7 Of this gospel I was made a minister according to the gift of God's grace, which was given me by the working of his power. 8 To me, though I am the very least of all the saints, this grace was given, to preach to the Gentiles the unsearchable riches of Christ, 9 and to bring to light for everyone what is the plan of the mystery hidden for ages in God, who created all things, 10 so that through the church the manifold wisdom of God might now be made known to the rulers and authorities in the heavenly places. 11 This was according to the eternal purpose that he has realized in Christ Jesus our Lord, 12 in whom we have boldness and access with confidence through our faith in him. 13 So I ask you not to lose heart over what I am suffering for you, which is your glory. </font>
<p align= "Justify">


### Review Last Week

<p align= "left">
Last time we were together, we covered Ephesians 3:1-3 where Paul draws attention to the special stewardship and revelation of the gospel to him by God. Paul was a prison when he wrote this letter to the Ephesians and he spoke both literally and metaphorically of being a prisoner for Christ.
<p align= "left">
We also discussed how Paul structures his letters can be challenging for those who don’t read Greek, especially in certain passages. Paul begins with "For this reason..." but doesn't immediately explain the reason, which he only mentions later in verse 13 or 14. Paul’s train of thought often shifts—he starts with one idea but gets so caught up in another important truth that he starts discussing it prematurely. William Barclay and Wayne Barber both speak of Paul's reputation and habit of <em> “_going off at a word_.” </em> what we would call today as "Squirrel!" or chasing a rabbit trail. A single word or idea can send his thoughts off at a tangent. Consequently, Paul weaves through different concepts before circling back to his initial point. Ray Stedman suggests that if you jump from "For this reason..." and go directly to verse 13, where Paul requests that the Ephesians not be discouraged by his sufferings since they serve to their benefit, the message he's conveying in the surrounding text becomes clearer. William Barclay would say verses 2-13 should all be in parenthesis, For verse 14 starts off with "For this reason" and he believes this is where Paul gets back on track. Paul wanted to share with them a mystery that was revealed to his heart and he is going to pray that what has been revealed to him, will also be revealed to them.</em>
<p align= "left">
Ephesians 3:4-7 highlights the revelation of the mystery of Christ, which is the inclusion of Gentiles in God's plan of salvation through faith in Jesus. Paul, as an apostle, was entrusted with the ministry of spreading this gospel among the Gentiles, and it is all by the grace and power of God. This passage underscores the sacred unity and equality of believers in Christ, regardless of their nationality.

### 4. When you read this, you can perceive my insight into the mystery of Christ,

<strong>When you read this </strong>- Paul is referring to this letter to the Ephesians. He wants the Ephesian Christians to pay attention to what he's about to say.

<strong>you can perceive [understand] my insight [knowledge]</strong>  We gain understanding and insight into the doctrine by <em>reading</em> God's word. As we read and study God's word God's Holy Spirit will use His word to help us to grow in knowledge of Him. We cannot gain deep understanding apart from reading the word of God for ourselves. Others really can't do it for us.  Paul is indicating that through reading his letter, the Ephesians themselves will perceive his insight into God's word. Paul is simply expounding on what is already in Scripture. Connecting the dots between prophecy and OT and NT.  They will see the truth of his words. Paul sees his responsibility before God as a steward of this revelation to pass it on to others as he is doing now, in this letter.

<strong>2 Cor. 11:6 </strong> -<em> Even if I am unskilled in speaking, I am not so in knowledge; indeed, in every way we have made this plain to you in all things." </em>
<strong>"To make plain" </strong> the revelation and insight from God's word was Paul's goal. It should be the goal of every teacher and preacher who expounds the word of God, not to complicate it, not to make it sound academic, unless you are in an academic setting with an academic audience, there is a place for it. But even the greatest theologians are known for their clarity and simplicity in their preaching, writing and expounding the gospel because they, like Paul, want to pass forward the insights, they too have received from the Word of God so that others might grasp them and enjoy  and marvel in them and in the knowledge of God.

<strong>the mystery </strong> refers to a "mystery" or "secret." In the New Testament, a mystery often denotes a divine truth that was previously hidden but has now been revealed by God. It's not something that can be known by human reasoning alone but is known through divine revelation.

	Stott - . “In English a ‘mystery’ is something dark, obscure, secret, puzzling. What is ‘mysterious’ is inexplicable, even incomprehensible. The Greek word mysterion is different, however. Although still a ‘secret’, it is no longer closely guarded but open . . . <u>More simply, mysterion is a truth hitherto hidden from human knowledge or understanding but now disclosed by the revelation of God.” </u>

<strong>of Christ </strong>- The central theme here is the "mystery of Christ." In this context, it's the mystery of God's plan of salvation through Jesus Christ.

But what is the "mystery" Paul wants the Ephesians to know that was previously kept secret? <em>"This mystery is that the Gentiles are sharers in the promise in Christ Jesus, heirs alongside Israel through the gospel, and members of one body together" </em>(Eph. 3:6). Paul elaborates on his earlier writings regarding how Christ's sacrifice eliminated the boundaries between Jews and non-Jews. All believers have equal access to the Father because of the atonement made for all believers' sins by the blood of Jesus. We are now "sharers together in the promise," according to Paul. The apostle is stating that everyone who is in Christ Jesus is now covered by God's covenant, which was made with Israel to be their God and they to be his people.

**Colossians 1:24-29**

	24 Now I rejoice in my sufferings for your sake, and in my flesh I am filling up what is lacking in Christ's afflictions for the sake of his body, that is, the church, 25 of which I became a minister according to the stewardship from God that was given to me for you, to make the word of God fully known, 26 the mystery hidden for ages and generations but now revealed to his saints. 27 To them God chose to make known how great among the Gentiles are the riches of the glory of this mystery, which is Christ in you, the hope of glory. 28 Him we proclaim, warning everyone and teaching everyone with all wisdom, that we may present everyone mature in Christ. 29 For this I toil, struggling with all his energy that he powerfully works within me.


| Mystery Category                        | Bible Verse Reference    | Bible Verse Text                               |
|-----------|--------------|--------------------|
| The Mystery of the Kingdom of God      | Mark 4:11               | "And he said to them, 'To you has been given the secret of the kingdom of God, but for those outside everything is in parables...'"  |
| The Mystery of Christ                   |  Colossians 2:2          | "that their hearts may be encouraged, being knit together in love, to reach all the riches of full assurance of understanding and the knowledge of God's mystery, which is Christ,"  |
| The Mystery of the Gospel               | Ephesians 6:19          | "and also for me, that words may be given to me in opening my mouth boldly to proclaim the mystery of the gospel," (Ephesians 6:19, ESV) |
| The Mystery of God's Will              | Ephesians 1:9           | "making known to us the mystery of his will, according to his purpose, which he set forth in Christ"  |
| The Mystery of the Church as the Body of Christ | 1 Cor. 12:12-27 | "For just as the body is one and has many members, and all the members of the body, though many, are one body, so it is with Christ."  |
|                                                  | Ephesians 5:32          | "This mystery is profound, and I am saying that it refers to Christ and the church."  |
| The Mystery of Iniquity (Lawlessness)  | 2 Thess. 2:7     | "For the mystery of lawlessness is already at work. Only he who now restrains it will do so until he is out of the way."  |
| The Mystery of Faith                    | 1 Timothy 3:9           | "They must hold the mystery of the faith with a clear conscience."  |
| The Mystery of the Resurrection         | 1 Cor 15:51     | "Behold! I tell you a mystery. We shall not all sleep, but we shall all be changed,"  |
| The Mystery of the Gentiles' Inclusion in Salvation | Ephesians 3:6   | "This mystery is that the Gentiles are fellow heirs, members of the same body, and partakers of the promise in Christ Jesus through the gospel."  |
| The Mystery of the Rapture (Catching Away of Believers) | 1 Cori. 15:51-52 | "Behold! I tell you a mystery. We shall not all sleep, but we shall all be changed, in a moment, in the twinkling of an eye, at the last trumpet. For the trumpet will sound, and the dead will be raised imperishable, and we shall be changed."  |


### 5 which was not made known to the sons of men in other generations as it has now been revealed to his holy apostles and prophets by the Spirit. 

The revelation that Paul shared, was not "new truth" it was "hidden" truth. It was <em> concealed</em> in the Old Testament and <em>revealed</em> in the New Testament.

Jesus Himself made references to the fulfillment of Old Testament scriptures in His ministry. In the Gospel of Luke 24:27, for instance, it is said that <em><font color="#548dd4"> "beginning with Moses and all the Prophets, he interpreted to them in all the Scriptures the things concerning himself."</font>  </em>The truth was there, but Christ needed to come and connect the dots for us concerning himself and to give us the Holy Spirit who enables us to understand spiritual truths.

The relationship between the Testaments is not one of replacement but of fulfillment and expansion. The New Testament does not discard the Old but builds upon it, revealing the fuller meaning of what was previously seen only in part.


5 which was not made known to the sons of men in other generations as it has now been revealed to his holy apostles and prophets by the Spirit. <!-- element style="background: floralwhite" --></font>

Paul had received revelation from God about a mystery or purpose that had not yet been made clear to the apostles. See Galatians 1:11-12 

Jesus himself on the road to Emmaus in Luke 24:27,  <em>"beginning with Moses and all the Prophets, he interpreted to them in all the Scriptures the things concerning himself."</em>

<strong>1 Cor 2:7</strong>  But we impart a secret and hidden wisdom of God, which God decreed before the ages for our glory

<strong>1 Cor 2:10</strong> these things God has revealed to us through the Spirit. For the Spirit searches everything, even the depths of God.

The key Greek word in this verse is "apokalupto" (ἀποκαλύπτω), which means "to reveal" or "to uncover." In this context, it indicates that something hidden has been unveiled or disclosed. The tense of this verb indicates a completed action.

Note also, the Holy Spirit is the one who has made this revelation known to the apostles and prophets. This revelation is made, <strong> "by the Spirit." </strong> We cannot understand spiritual truths apart from the Holy Spirit. 1 Cor. 2:14. It's foolishness.

Not Made Known to Previous Generations
<font size="6">  
<p align= "left">
Here, Paul states that the world was allowed to enter an extended period of darkness and ignorance, during which the gentile population was kept completely in the dark about the existence of the real God.
The Jews at this time believed that all nations except Israel were destined for permanent alienation and would eventually perish because they had access to the light of their Creator and the prophetic words of His servants. They had never considered the possibility that a banished heathen could ever find favor with God, be called to His service, and experience His love. However, the Lord had plans of kindness for them during this prolonged night of spiritual darkness, and now, at His own allotted time, He revealed these to the holy Apostles and Prophets through the Spirit.


### 6 This mystery is that the Gentiles are fellow heirs, members of the same body, and partakers of the promise in Christ Jesus through the gospel

 ![[Pasted image 20231126193239.png]]

The ESV does not quite capture the emphasize in verse 6 as some of the other versions do like the LSB, NET or ASV.   The ESV and KJV avoided the use of the repetition of the same word "fellow" or "joint" which is a good practice for a writer, you should always use variety and it does help comprehension by using synonyms.  However, you loose the poetic parallelism that I think is more important in this verse as Paul's repetition  makes a strong point of emphasis.

> <strong>Bryan Chappell </strong> - Paul must know how difficult it is for Jew and Gentile to allow each other equal status before God, so he plays with the word “together” in Greek to create a triple echo of special emphasis. When the Hebrews wanted to emphasize a word, they doubled it; and when they wanted to thunder a word, they tripled it, as in the phrase “Holy, holy, holy is the Lord God Almighty” (see Isa. 6:3). In a similar way Paul now shakes the foundations
> of traditional prejudices and long-standing antipathies between the races by tripling the word (actually a prefix) “together.”  Both Gentile and Jew—one pagan and the other orthodox, one a new people and the other an ancient
> nation—are “heirs together.” This means they are part of the same family and will get the same blessings of the kingdom in the future. They are also “members together,” meaning that they are part of the same body now and,
> finally, they are also “sharers together” of the eternal covenant that extends from the past into the forever future.

Paul even makes up a Greek word to make his point when he says Fellow-members of the body.   The Greek word <strong>"sussōmos" (σύσσωμος)</strong> did not exist but it essentially means <em>"belonging to the same body". </em> The picture image,  illustration was in Paul's mind but there was no word in the Greek for it so Paul essentially coins one. "sussōmos". 

Remember Ephesians 2:13-18:

13. But now in Christ Jesus you who formerly were far off have been brought near by the blood of Christ. 14 For He Himself is our peace, who <strong>made both groups into one</strong>, and broke down the barrier of the dividing wall, 15 by abolishing in His flesh the enmity, which is the Law of commandments contained in ordinances, that in Himself <strong>He might make the two into one new man,</strong> thus establishing peace, 16 and <strong>might reconcile them both in one body to God</strong> through the cross, by it having put to death the enmity. 17 And he came and preached peace to you who were far away, and peace to those who were near; 18 for through Him <strong>we both</strong> have our access in one Spirit to the Father. 

Verse six states the mystery that Paul is referring to clearly.

### 6 This mystery is that the Gentiles are fellow heirs, members of the same body, and partakers of the promise in Christ Jesus through the gospel

<strong>This mystery </strong>" -  The term "mystery" (mystērion) refers to something previously hidden but now revealed by God. The word "Mystery" is very much a key word in the book of Ephesians repeated 6 times. 3x are here in chapter 3.

<strong>is that the Gentiles</strong> - The Gentiles, (anyone who was not a Jew) who were previously excluded from the promises of God.

<strong>are fellow heirs"</strong> "Coheirs or joint heir" suggests that Gentiles are not secondary beneficiaries but have an equal share in the inheritance. This is a radical declaration in the context of Jewish-Gentile relations of the time. Fellow (joint) heirs is used 4 times in the NT.

Romans 8:16-17:

![[Rom-08#v16]]
![[Rom-08#v17]]

The Greek word "συγκληρονόμος" (transliterated as "sugkleronomos") can be translated as "co-heir," "joint-heir," or "fellow heir."

This term is used  by Paul to convey the idea that believers in Christ are joint heirs with Christ. This means they are considered to share in the inheritance promised by God to Jesus Christ, symbolizing a shared destiny in the Christian faith. It emphasizes the idea that all believers, regardless of their background, are equally entitled to the promises and blessings of God through their faith in Christ. This concept is fundamental in understanding the inclusive nature of Christian salvation and the breaking down of barriers between different groups of people in the early Christian community <strong> in Christ </strong>.

See also: Galatians 3:28-29, Heb. 11:9, 1 Peter 1:7

> <strong>[[Henry Law]] </strong> asks and answers:  " What is it to be an heir? It is to stand in a position which legally and rightly entitles us to succeed to the inheritance. But the inheritance which is here meant is no earthly property—no worldly title or distinction—no wealth to be possessed only for the short, uncertain tenure of this fleeting life. It is an inheritance incorruptible, undefiled, and that fades not away; laid up for us in heaven. It is the inheritance of eternal life in the kingdom of God. It is to sit upon the throne of God's glory; to enjoy the greatness, the pleasures, and the dominion of the King of kings and Lord of lords. Our souls are lost in wonder, when we strive a little to imagine the exalted, glorified state of the Lord Jesus. We know that "He is gone into heaven, and is on the right hand of God—angels and authorities and powers being made subject unto Him." Now, great asHis glory is, such will be the glory of His saints. His own words are, "The glory which You gave me, I have given them." And "the Spirit itself bears witness with our spirit, that we are the children of God; and if children then heirs, heirs of God, and joint-heirs with Christ." Thus the inheritance to which the Gentiles are called, is nothing less than to be co-partners for ever with Christ in the happiness and glory of heaven.
> 
> O my soul, is such your position? Are these the joys before you? Live, then, worthy of this high vocation. Trample beneath your feet the sordid pleasures and worthless vanities of time, and keep looking onward—looking upward—to the fullness of joy, the pleasures for evermore which are at God's right hand.

<strong>members of the same body</strong> - The Greek  literally means "of the same body." This suggests a profound unity among believers, irrespective of their ethnic background, in the body of Christ (the Church). We dug into this image concept earlier when we discussed Paul coining this word.

<strong>and partakers of the promise</strong> - The Greek means "partner," "participant," or "sharer." The Gentiles are sharers of the promises of Abraham. 

This highlights the idea that Gentiles share in the promise of salvation and especially the promise of the Holy Spirit. 
Galatians states <em> "Christ has redeemed us from the curse of the law, being made a curse for us—for it is written, Cursed is every one that hangs on a tree—that the blessing of Abraham might come <u>on the Gentiles </u>through Jesus Christ; that we might receive <u>the promise of the Spirit</u> through faith." </em>
<p align= "left">
> Henry Law says - "This promise God fulfils to His elect among the Gentiles; pouring into their souls this heavenly power, by which they are taught their need, filled with conviction of sin, and brought to the Cross for salvation. All these mercies are communicated through the Gospel. It is through the preaching of the Word that the Spirit descends. Wherever this Word is proclaimed, the footsteps of Deity may be traced. This thought should make us diligent to hear and to propagate the glorious Gospel."
---

<strong>in Christ Jesus</strong> - The phrase “in Christ Jesus” is central to Paul's theology. It denotes the believer's intimate and living union with Christ.

<strong>through the gospel</strong>-Finally, “through the gospel” (διὰ τοῦ εὐαγγελίου) indicates the means by which this mystery is made known and effective. The gospel is the vehicle of God's grace and the revelation of this mystery.

Being united with Christ is the only condition that is necessary and necessary to receive the rewards of redemption. The apostle says that the Gentiles are co-heirs, members of the same body, and sharers of the gift through Christ. These two groups come together because of the Gospel. We are united to Christ and made children of God not by birth, natural means, or joining with an outside body. We are united to Christ through the Gospel, which we receive and accept by faith. 
This verse teaches 3 things:
1. What kind of gifts the Gentiles have access to, namely the inheritance that God promised to his people. 
2.  The prerequisite for that involvement, which is union with Christ; and 

3. The way to achieve that union, which is the Gospel. So, the apostle goes on to talk more about how important and honorable it is to spread the Gospel. This is what follows.

 ### 7. Of this gospel I was made a minister according to the gift of God's grace, which was given me by the working of his power. 

<strong>"Of this gospel"</strong>: The word "gospel" originates from the Greek word "euangelion," which means "good news." In this context, it refers to the message of salvation through Jesus Christ.

The Anglo-Saxon word "gospel" originally meant "go

od news" or "message." Long ago, the term "spell" was used to refer to news or a message. When someone captivates an audience with their message, they may be called a "spellbinder." So, the gospel is like the ultimate "good spell" or "good message." It's God's wonderful news for lost sinners and tells us about His blessed Son. It's crucial to understand that the gospel isn't just good advice to follow; it's good news to believe in. When we believe in this message, we are saved.
<p align= "left">
<strong>Romans 1:16</strong> - For I am not ashamed of the gospel of Christ: for it is the power of God unto salvation to every one that believeth; to the Jew first, and also to the Greek."

gos·pel
/ˈɡäsp(ə)l/


[Origin](https://www.google.com/search?q=gospel+etymology&rlz=1C1ONGR_enUS1051US1051&oq=gospel+et&gs_lcrp=EgZjaHJvbWUqBwgBEAAYgAQyBggAEEUYOTIHCAEQABiABDIHCAIQABiABDIHCAMQABiABDIHCAQQABiABDIHCAUQABiABDIHCAYQABiABDIGCAcQRRg80gEINDUyMGowajSoAgCwAgA&sourceid=chrome&ie=UTF-8)
![[Pasted image 20231126215811.png|300]]

Old English gōdspel, from gōd ‘good’ + spel ‘news, a story’ (see spell2), translating ecclesiastical Latin bona annuntiatio or bonus nuntius, used to gloss ecclesiastical Latin evangelium, from Greek euangelion ‘good news’ (see evangel); after the vowel was shortened in Old English, the first syllable was mistaken for god ‘God’.

The power of God is inherit in the Gospel message itself.  It is the power for salvation.  These effects are not dependent on how clever or eloquent we are in presentation but on how faithful we are to speak forth the truth of the Gospel.

Good News!!

<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
"The Gospel tells rebellious men that God is reconciled, that justice is satisfied, that sin has been atoned for, that the judgment of the guilty may be revoked, the condemnation of the sinner cancelled, the curse of the Law blotted out, the gates of hell closed, the portals of heaven opened wide, the power of sin subdued, the guilty conscience healed, the broken heart comforted, the sorrow and misery of the Fall undone." - A.B. Simpson <!-- .element: style="font-size: 24px" align="justify" --><br>

<strong>I was made a minister/servant</strong>":  Paul was made "minister." Paul did not make himself minister. Paul is always quick to point out that he is what he is as a slave, an apostle, a minister of the gospel not by his own will, but by the will of God.  
The term "minister" comes from the Greek word "diakonos," which means "servant" or "one who serves." It signifies a role of serving and spreading the message of the gospel. It signifies one who executes the commands of another, especially of a master, a servant, attendant, minister a deacon. 

<strong>according to the gift of God's grace</strong> "Grace" is derived from the Greek word "charis," denoting unmerited favor or God's kindness. Paul's ability, his strength is all from the grace of God.  "It's a gift."  God "gifts" us with the skills and the resources we need to complete his work for his calling.  That's a great comfort when we say "We can't" Have you ever felt like God called you to something that you just couldn't do?

<strong>which was given me</strong>: This phrase underscores that the ministry is a divine gift given personally to Paul by God. It emphasizes the sovereignty of God in choosing and equipping individuals for ministry.

<strong>by the working of his power</strong>: The term "power" stems from the Greek word "dunamis," indicating God's mighty and supernatural ability. Paul acknowledges that it is God's power that empowers and enables him to fulfill his ministry. Remember Ephesians chapter 2?

### 8 To me, though I am the very least of all the saints, this grace was given, to preach to the Gentiles the unsearchable riches of Christ

<strong>To me</strong>: This phrase emphasizes the personal nature of Paul's experience. In Greek, "to me" is "emoi," indicating that this revelation and grace were uniquely given to Paul. 

<strong>though I am the very least of all the saints</strong>: The phrase "the very least" comes from the Greek word "elachistoteros," signifying the extreme sense of unworthiness. Paul humbly acknowledges his own perceived insignificance compared to other believers. Paul, who persecuted the church. Paul who was not among the twelve disciples. They would be "more deserving" would they not? But God chose and called Paul specifically for this great work, the ministry of the gospel among the Gentiles.

<strong>this grace was given</strong> "Grace" here, as in the previous verse, is from the Greek word "charis," denoting unmerited favor. It highlights that the ability to preach to the Gentiles is not due to Paul's merit but a gift from God.

<strong>to preach</strong> The Greek word for "preach" is "euaggelizesthai," derived from "euangelion" (gospel). It means to announce or proclaim the good news of Christ.

<strong>to the Gentiles</strong> In Greek, "Gentiles" is "ethne," referring to non-Jewish nations or people. Paul's ministry had a specific focus on sharing the gospel with those outside the Jewish community.

<strong>the unsearchable /unfathomable riches of Christ</strong>: The term "unsearchable" comes from the Greek word "anexichniastos," suggesting that the riches of Christ are beyond human comprehension or exploration. Paul is emphasizing the depth and abundance of blessings and knowledge found in Christ.  We saw some of these riches in Ephesians chapter 1...

