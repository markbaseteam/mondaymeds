
<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->

---
Opening Prayer
---

<center><strong><em>Review</strong></em></center>
<p align= "left"><font size="6">  
Last time we were together we finished Ephesians Chapter 1 which focused on our spiritual blessings in Christ and the great power we have available to us through Christ that Paul prayed we would know. In Ephesians Chapter two the theme transitions to look at our past, present and future condition.  Paul seeks for us to gain a deeper understanding of the depravity of the human heart and the necessity of salvation by grace alone.
<p align= "left">

---
Why is it important for us to remember our previous condition? <br>
---
<font size="6">  
<p align= "left">
The last few weeks we have talked much about "cheap grace" and how it has no requirements, no seeking to put off sin and pursue righteousness and no love for God. One of the reasons that grace is seen as "cheap" is because of a lack of understanding of the doctrine of sin. Those who are against Total Depravity would argue we have some good in us, do not have a grasp on the doctrine of sin.  Just as we spoke of in chapter one many of the complex doctrines such as predestination, total depravity are built on the foundations and pillars of other doctrines.  If you do not have a solid foundation of these doctrines, the Doctrines of Grace may be more difficult to grasp.
<p align= "left">
Charles Spurgeon once made the comment that there is a connection between soul distress and sound doctrine.
---
Costly Grace
<font size="6">  
<p align= "justify">
<strong> Dietrich Bonhoeffer, The Cost of Discipleship </strong> - "Such grace is costly because it calls us to follow, and it is grace because it calls us to follow Jesus Christ. It is costly because it costs a man his life, and it is grace because it gives a man the only true life. It is costly because it condemns sin, and grace because it justifies the sinner. Above all, it is costly because it cost God the life of his Son: "ye were bought at a price," and what has cost God much cannot be cheap for us. Above all, it is grace because God did not reckon his Son too dear a price to pay for our life, but delivered him up for us. Costly grace is the Incarnation of God.”
---
Ephesians 2:1-3 (ESV)
<font size="6">  
<p align= "justify">
1. And you were dead in the trespasses and sins 2 in which you once walked, following the course of this world, following the prince of the power of the air, the spirit that is now at work in the sons of disobedience— 3 among whom we all once lived in the passions of our flesh, carrying out the desires of the body and the mind, and were by nature children of wrath, like the rest of mankind.
---
#### And you were dead <!-- element style="background: floralwhite" -->
<font size="5">  
[Parallel Plus by TheBible.org](https://thebible.org/gt/index)
![[Pasted image 20230909185323.png]]
<p align= "left">
Note the past tense. You were dead. It is implied that you are now alive. Some versions such as KJV and ASV accent this by including "hath he quickened" or "did he make alive". Both of these are accurate as the translations seek to communicate our previous and our current state.  We were dead and are now alive with Christ. Eph. 2:5 clarifies this. Ephesians chapter 1:19-23  spoke of the resurrection power behind Christ's resurrection, this same power is now in us and raised us with Christ and now operates in us.  We saw the Christian life is one of power. <br>
<strong>1 Cor. 4:20 </strong><em>"For the kingdom of God does not consist in words but in power" . </em><br>
<strong>2 Timothy 3:5</strong><em>  having the appearance of godliness, but denying its power. Avoid such people.</em>


---
Dead - Nekros
<font size="5">  
<p align= "left">
<strong>nekros</strong><br>
Total KJV Occurrences: 132<br>
Part of Speech: adjective<br>
A Related Word by Thayer’s/Strong’s Number: from an apparently primary nekus (a corpse) <br>
Literally a dead body or a corpse <br>
<strong>Thayer Definition:</strong><br>
1) properly<br>
1a) one that has breathed his last, lifeless<br>
1b) deceased, departed, one whose soul is in heaven or hell<br>
1c) destitute of life, without life, inanimate<br>
2) metaphorically<br>
2a) spiritually dead<br>
2a1) destitute of a life that recognises and is devoted to God, because given up to trespasses and sins <br>
2a2) inactive as respects doing right <br>
2b) destitute of force or power, inactive, inoperative<br>

---
Spiritual Death
<font size="5">  
<p align= "justify">
Death is separation. 
<p align= "left">
The bible speaks of three kinds of deaths<br>
-  <strong>Spiritual death</strong> - The separation of the spirit from God.<br>
- <strong>Physical death</strong> - The separation of the soul and all life from the body.<br>
- <strong>Eternal death</strong> - The eternal separation of the soul from the body and the spirit from God.<br>
<p align= "left">
To be spiritually dead is to be separated from the Spirit of God who is life eternal, who is our power source to do good works.  It takes Christ's resurrection power to raise any of us from this death. <p align= "left">
When the law came and we all died.  Death itself came through sin. "Sin is lawlessness". Death is a sentence of the law. " The wages of sin is death."  Spiritual death came immediately when Adam sinned, Physical death followed as will Eternal death.  The last enemy to be destroyed will be death itself.

---
<font size="5">  
<p align= "justify">
<strong>Barnes Commentary</strong> A corpse is insensible. It sees not, and hears not, and feels not. The sound of music, and the voice of friendship and of alarm, do not arouse it. The rose and the lily breathe forth their fragrance around it, but the corpse perceives it not. The world is busy and active around it, but it is unconscious of it all. It sees no beauty in the landscape; hears not the voice of a friend; looks not upon the glorious sun and stars; and is unaffected by the running stream and the rolling ocean. So with the sinner in regard to the spiritual and eternal world. He sees no beauty in religion; he hears not the call of God; he is unaffected by the dying love of the Saviour; and he has no interest in eternal realities. In all these he feels no more concern, and sees no more beauty, than a dead man does in the world around him. Such is, in “fact,” the condition of a sinful world. There is, indeed, life, and energy, and motion. There are vast plans and projects, and the world is intensely active. But in regard to religion, all is dead. The sinner sees no beauty there; and no human power can arouse him to act for God, anymore than human power can rouse the sleeping dead, or open the sightless eyeballs on the light of day. The same power is needed in the conversion of a sinner which is needed in raising the dead; and one and the other alike demonstrate the omnipotence of him who can do it.
---
Romans 5:12-14 (ESV)
<font size="6">  
<p align= "justify">
12 Therefore, just as sin came into the world through one man, and death through sin, and so death spread to all men because all sinned— 13 for sin indeed was in the world before the law was given, but sin is not counted where there is no law. 14 Yet death reigned from Adam to Moses, even over those whose sinning was not like the transgression of Adam, who was a type of the one who was to come.
---
All Sinned - All Died to God
<font size="5">
<p align= "left">
Adam was created with the Spirit of God in his heart, the light of heaven, but when he sinned, that light was extinguished. Both Adam and Eve immediately died spiritually and could no longer impart to their descendants what they no longer possessed. We were born in their likeness, dead by nature and separated from God. God's spirit was no longer the power within us.  Instead, the life of the Evil One, the Prince of the Power of the Air,  came to work within us, our heart was inclined to his will to accomplish his work in the world. When we think of our spiritual death, we tend to think of a void, an empty house, a neutral position, that Christ comes into and gives us his Spirit. But the bible teaches until we experience a second birth via Christ and our spirit is reborn in him, it is the spirit of the Evil One who works within each one of us. Let that sink in. We are slaves to sin before we are redeemed by Christ. We are Satan's possession, not possessed as those who loose all control and responsibility, but we willfully submit and are inclined with an alignment issue to "follow the ways of this world" and "the prince of the power of the air". and  often with pleasure to accomplish his work.

<p align= "left">
<strong>John 1:13 </strong> - <em> who were born, not of blood nor of the will of the flesh nor of the will of man, but of God."</em>
<br>

---
Total Depravity
<font size="5">  
<p align= "left">
It is from this truth emphasized here in Ephesians 2:1-3 and in Romans and in several other places in the bible that the doctrine of "Total Depravity" rests. 
<p align= "left">
The doctrine of "Total Depravity" shows the extent of our sinful condition. It holds that every part of human nature is corrupted by sin as a result of the Fall of Adam and Eve. This doesn't mean that humans are as evil as they could be, but rather that every part of our being—mind, will, emotions, and body—is tainted by sin like a virus that has spread <u>everywhere</u> and to <u>everyone</u>. Because of this corrupting influence, we are incapable of coming to God or choosing good over evil without divine intervention. We are dead and without hope in our own power.
<p align= "left">
 A spiritually dead person can be morally upright, charitable, and even religious, but if these actions are not rooted in a regenerated heart, they are insufficient for true spiritual life and communion with God. They are not done for the glory of God but with impure motives, self-indulgence, personal gain, pride,...etc..."  We often see a push of being "good" without God but being "good" without God is always man centered and subjective.
---
The Walking Dead
<font size="5">  
<p align= "left">
Spiritual death is  seen as a condition that affects the entire human race due to original sin.  To be spiritually dead does not mean that are inactive in this world,  those who are spiritually dead are like the walking dead, zombies, they have no idea they are dead until the light of God shines in their hearts. We will see it is the Evil one who is at work in them and apart from God's grace, they have no hope of resurrection or of choosing to follow God on their own, they instead "follow the course of this world" and they "follow the Prince of the power of the air" . <br><br>
<strong>Isaiah 59:2 </strong> - <em> But your iniquities have made a separation between you and your God, And your sins have hidden His face from you so that He does not hear.</em><br>
---
The Roman Practice - Addicere Ad Ludibrium
<font size="5">  
<p align= "left">
"Dead" can also mean hyperbolically and proleptically as if already dead, sure to die, destined inevitably to die. 
<p align= "left">
The Romans had a tradition of using public punishment as a form of social control. They were masters at leveraging spectacle for both entertainment and moral instruction. Their arena games, public punishments, and even military triumphs were as much about instilling values and reinforcing social norms as they were about individual justice or entertainment.
<p align= "left">
One form of Roman punishment was known as "Damnatio ad bestias," or "condemnation to beasts." This was a form of capital punishment where criminals or prisoners of war were sentenced to fight against wild animals, often as part of a public spectacle like the games in the Colosseum. There was a specific variant of this punishment known as <em>"addicere ad ludibrium," </em> where the condemned were not given the "honor" of dying in combat but were instead used in a manner considered shameful or dishonorable.
---
<font size="5">  
<p align= "left">
In some instances, these men would be forced to carry around a dead man or animal, symbolizing their own upcoming death. This was meant to be an especially humiliating form of punishment, serving as both a deterrent to other would-be criminals and as a spectacle for the Roman populace. The image of a man dragging a corpse around would have been deeply symbolic, capturing the attention and imagination of those who witnessed it. In Roman society, where honor and the opinions of others were extremely important, this would have been a fate considered worse than death by many.

<p align= "left">
The act of carrying the corpse could have various interpretations. On one level, it could symbolize the weight of the man's crimes, serving as a physical representation of the moral or social burden he had imposed upon society. On another level, it served as a visceral reminder of the man's impending fate, essentially forcing him to confront his own mortality in a very tangible way. In either case, the message was clear: the man had transgressed so egregiously that he was no longer considered a part of Roman society. He was, in effect, a "living dead man."
<p align= "left">
It was this Roman practice that many commentators believe Paul was referring to when he cried out in Romans 7:24, <em>"Wretched man that I am! Who will deliver me from this body of death?" </em>
---
<font size="5">  
<p align= "left">
In the Roman practice, the dragging of a corpse symbolized the doomed man's inescapable fate, his moral degradation, and societal exile. Similarly, when Paul exclaims in Romans 7:24, <em>"Wretched man that I am! Who will deliver me from this body of death?" </em> he's acknowledging the sinful nature that drags him down and holds him captive. He's lamenting his inability to follow the law perfectly, thus realizing that he is spiritually dead without intervention from outside himself.
<p align= "left">
The phrase <em>"this body of death" </em>that Paul refers to many commentators believe metaphorically parallels the corpse the Roman prisoner drags around. In Paul's usage, <em>"this body of death" </em>signifies the sinful human nature, the 'old self,' that people carry around as a burden, much like the corpse. It's a vivid imagery that people in his time, particularly those aware of Roman practices, would likely have found potent. This burden of sin, is one that humans cannot shed on their own; it requires divine intervention.
<p align= "left">
Paul’s outcry for deliverance in Romans 7:24 finds its resolution in Romans 7:25 and Romans 8, where he acknowledges that it is through Jesus Christ that he finds freedom from "this body of death." In contrast the Roman condemned man finds no deliverance; instead he faces his inevitable demise alone, his corpse serving as a cruel reminder of his fate.
--
<font size="3">  
<p align= "left">

In Roman lands, where men of guilt  
Drag corpses heavy, chains they've built,  
A wretched cry ascends the air,  
A desperate plea escapes despair.

Two worlds apart, yet intertwined,  
Each man a weight he cannot find  
A way to lose—this grievous load  
That keeps him on a darkened road.

One cries in shame, for all to hear,  
A spectacle that draws a jeer.  
The other, silent in his dread,  
Both bound to their own form of dead.

Yet whispers echo through the mist,  
A tale of an untwisted wrist,  
Where chains do break, and burdens lift,  
And souls set free through love's great gift.

No earthly key, nor crafted blade  
Can sever links so strongly made.  
But in the quiet, one might find  
A love that leaves no chain behind.

The first man's fate, forever sealed,  
His cries of anguish never healed.  
The second finds his burden gone,  
As dawn dispels the blackest dawn.

Two men, two weights they could not flee,  
But one found love that set him free.  
A spectral chain no more to bind,  
A life renewed, his past behind.
.
--
<font size="5">  
<p align= "left">
The Latin word addicere is the source of the English word "addiction." Originally, addicere meant "to assign." The word "assign" solidifies and stabilizes when one reads the definition of "addiction" in the Oxford English Dictionary.
Dissecting "addicere" One definition of the prefix "ad-" is "to."  In addition, "dicere" is defined as "say." Addicere thus means "to say" or "to assign."
The word "addiction" has its origins in the Roman Empire of antiquity, notably Roman Law. In accordance with Roman Law, addiction was defined as "the formal delivery of a person or property to an individual, typically in accordance with a judicial decision." It could also refer to the act of tying someone to another as a "servant, adherent, or disciple." The word "slavery" would best describe this description of "addiction" if it were made simpler. In ancient Rome, owning slaves was commonplace. Many of the educated slaves in ancient Rome were of Greek descent. Slaves were responsible for the economic and architectural development of the empire, as well as for holding any nation's seams together. In some ways, it was cohesion—codependency, if you will. According to Roman law, the term "addiction" referred to the judicially determined binding or "assignment" of one person to another, typically for life.
---
<font size="5">  
<p align= "left">

|Criteria|Morality centered on Man|Righteousness centered on God|
|---|---|---|
|**Source of Authority**|Human reason, cultural norms, social contracts.|Divine commandments and principles, as revealed by the Bible.|
|**Motivation**|Varied: societal norms, personal benefit, emotional well-being, etc.|Love for God, desire to be in a right relationship with Him and to obey His will.|
|**Objective/Subjective**|Often subjective and can vary from person to person or culture to culture.|Objective, with an absolute standard based on the character and nature of God.|
|**Scope**|Primarily concerned with interpersonal relationships and societal cohesion.|Concerned with one's relationship with God, & interpersonal relationships, loving others.|
|**Outcome**|Physical, emotional, and societal well-being; social order.|Eternal implications, including the state of one's soul and standing before God.|
|**Temporal/Eternal**|Focuses on current, worldly matters.|Focuses on both worldly matters and eternal consequences.|
|**Inclusion of Faith**|Can exist independently of any religious or spiritual belief system.|Is inseparable from faith in Jesus Christ.|
---
Condition: "Dead in the Trespasses and Sins"
<font size="6">  
<p align= "left"><br>
One commentator described being dead in trespasses and sins using the imagery of one being buried in a very deep pit with high unsurmountable walls made up of their trespasses and sins.  This description has since haunted my imagination and made me think of the 1999 movie "Double Jeopardy" with Ashley Judd and Tommy Lee Jones. There is a scene in it where her husband who is trying to kill her knocks her out in a graveyard and she awakes in a coffin that is sealed shut laying on top of a decayed body and righty freaks out.  I later thought that our spiritual awakening as a little bit like one being buried and coming alive and aware of our trespasses and sins that surround us and our hopeless condition apart from Christ. 
--
<font size="4">
<p align= "left"><br>

In a chasm dark, so cavernous and deep,  
Lay a soul entombed, in sin's dead sleep.  
The walls around, a monument of guilt,  
Built brick by brick, of trespasses and silt.  
Unknowing lay, oblivious to plight,  
A heart encased in ever-growing night.

For what is death, if known not as decay?  
A spirit still, yet wasting far away.  
Oblivious to bonds, both iron and cold,  
Unaware of chains, its freedom had been sold.

Yet came a gasp, a shudder, and a quake,  
As if from slumber, the soul did wake.  
Awareness dawned, like searing rays of sun,  
Revealing walls that could not be undone.  
Desperation clawed, but walls too high to breach,  
A sentence clear, extending far from reach.

But lo, a Light! A glimmer far above,  
A ray of Hope, a testament of Love.  
A figure leaned, hands scarred yet strong,  
Whose gaze could penetrate the thickest wrong.  
It was the Christ, His countenance so fair,  
Descending to this foul and dank despair.
--
<font size="4">
<p align= "left"><br>

"With love and blood, I've paid your ransom cost,  
So you, dear soul, may nevermore be lost.  
My sacrifice, your penalty erased,  
In Me, your sins are fully now effaced."

He shattered walls that seemed forever fixed,  
In Him, both life and liberty were mixed.  
The soul ascended, free from sin and dread,  
Transformed from being spiritually dead.

In awe and wonder, singing praise anew,  
Now clad in robes of righteousness and hue.  
The pit, a distant, fading memory,  
For Christ had set the captive sinner free.

So ends the tale, yet now another starts,  
For saved souls bear His gospel in their hearts.  
With joy anew, the soul proclaims His Name,  
That others too, may be from pits reclaimed.  
For what is found, is too sweet not to share,  
A Savior's love, a cross none else could bear.

- Buried in Sin, Rescued - Anonymous
---
#### <font color="#4f81bd">Trespasses & Sins </font>
<font size="5">
<p align= "left">
In Ephesians 1:7 we learned about the difference between "Trespasses" and "Sins".
 There are two Greek words that very graphically reveal God’s view of sin. Both of these words, in fact, appear together in Ephesians 2:1, where Paul declares that we “were dead in trespasses and sins.”
 <p align= "left">
<strong>Sin </strong>is to "miss the mark".  Ancient Greeks used the term to describe a spearman who failed to hit the intended target with his spear. Later, it started to be used in the ethical sense of failing to meet standards or falling short of an aim or ideal. Romans 3:23, states that <em>"all have sinned and fall short of the glory of God," </em>i The glory of God is the target of our aim which we consistently fall short of every time.
<p align= "left">
<strong>Trespasses</strong> refers to willful sin, intent. In courts of criminal law, intent has to be proven. We are guilty of intent to sin.  We all have deliberately disobeyed God's commands, like Adam, Israel, Saul. We don't just fail, or make a mistake, or "miss the mark" as the word "sin" indicates.  We sin willfully because we choose to, yet God forgives us and delivers us from this body of death!
<p align= "left">
---
### <font color="#4f81bd">  trespasses</font>
<font size="5">
Offenses (NET) - Sin (KJV)<br>
<p align= "left">
Trespasses:<br>
<strong>G3900</strong> παράπτωμα<strong> paraptoma </Strong>(pa-ra'-ptō-ma) n.<br>
1. a side-slip, faltering (lapse or deviation).<br>
2. (unintentional) a mistake or fault.<br>
3. (willful) a trespass, transgression.<br>
[from G3895]<br><br>
KJV: fall, fault, offence, sin, trespass <br><br>
Paraptoma consists of para [παρα] (G3844 [παρά]), “along side of,” and piptō [πιπτω] (G4098 [πίπτω]), “to fall.”  It means a deviation to one side or the other. The ancient Greeks would use it to describe a mistake in judgement or blunder but the NT uses this word to speak of a willful deviation from God. Willful sins.

---
### <font color="#4f81bd">  Sin</font>
<font size="6">
<p align= "left">
<strong>Sin</strong> - hamartia [ἁμαρτια] (G266 [ἀμαρτία]), to miss the mark.
hamartia<br>
Thayer Definition:<br>
1) equivalent to 264<br>
1a) to be without a share in<br>
1b) to miss the mark<br>
1c) to err, be mistaken<br>
1d) to miss or wander from the path of uprightness and honour,to do or go wrong<br>
1e) to wander from the law of God, violate God’s law, sin<br>
2) that which is done wrong, sin, an offence, a violation of the divine law in thought or in act<br>
3) collectively, the complex or aggregate of sins committed either by a single person or by many<br>

---
<font size="5">
<p align= "justify">
<em>“We commonly have a wrong idea of sin. We would readily agree that the robber, murderer, the razor-slasher, the drunkard, the gangster are sinners, but, since most of us are respectable citizens, in our heart of hearts we think that sin has not very much to do with us. We would probably rather resent being called hell-deserving sinners. But hamartia [ἁμαρτια] brings us face to face with what sin is, the failure to be what we ought to be and could be.”</em> - William Barclay
<p align= "left">
Many think that sin is something we do, but sin is actually something we don't do. What is the one thing that we don't do? We are not holy enough to meet God's standards. Since God is holy, perfect, and totally clean, sin is not living up to that ideal. All of our "sins" are caused by what we don't do. How far short we are of God's glory!
<p align= "left">
God's expectations for us are based on how he created us to be before the fall. God does not expect anything from man, that He never designed man to do and that man would be totally incapable of. Man is capable of obeying God and held responsible for that capability despite man's predisposed inclination to sin.
---
Ephesians 2:2 (ESV)
<font size="5">
<p align= "left">
in which you once walked, following the course of this world, following the prince of the power of the air, the spirit that is now at work in the sons of disobedience<!-- element style="background: floralwhite" -->

[Parallel Plus by TheBible.org](https://thebible.org/gt/index)
![[Pasted image 20230911012418.png]]
---
<font size="6">


<strong>In which you once walked</strong><br>
<p align= "left">
Note the past tense. This was the pattern of their former life. How they had conducted themselves.
<p align= "left">
<strong>Walked</strong>
περιπατέω<br>
peripateō<br>
Thayer Definition:<br>
1) to walk<br>
1a) to make one’s way, progress; to make due use of opportunities<br>
1b) Hebrew for, to live<br>
1b1) to regulate one’s life<br>
1b2) to conduct one’s self<br>
1b3) to pass one’s life<br>

---
 following the ==course ==of this world, following the prince of the power of the air, the spirit that is now at work in the sons of disobedience <!-- element style="background: floralwhite" -->
<font size="6">
<p align= "left">
<p align= "left">
<Strong>Age</strong><br>
Age - αἰών<br>
aiōn<br>
Thayer Definition:<br>
1) for ever, an unbroken age, perpetuity of time, eternity<br>
2) the worlds, universe<br>
3) period of time, age<br>
Part of Speech: noun masculine<br>

---
World - Kosmos
<font size="6">
<p align= "left">
κόσμος<br>
kosmos<br>
Thayer Definition:<br>
<p align= "left">
1) an apt and harmonious arrangement or constitution, order, government<br>
2) ornament, decoration, adornment, i.e. the arrangement of the stars, ‘the heavenly hosts’, as the ornament of the heavens. 1Pe 3:3<br>
3) the world, the universe<br>
4) the circle of the earth, the earth<br>
5) the inhabitants of the earth, men, the human family<br>
6) the ungodly multitude; the whole mass of men alienated from God, and therefore hostile to the cause of Christ<br>
7) world affairs, the aggregate of things earthly<br>
---
<font size="6">
<p align= "left">
We now follow Christ, but we had turned away from following the course of "ways" of this age, this period of time of the  world, cultural trends, man morality, humanism, to centering our eyes on Christ. When we turn to Christ, we must turn away from the world. And we must turn away from <em>"following the prince of the power of the air, the spirit that is now at work in the sons of disobedience."</em>
---
Prince - archōn
<font size="6">
<p align= "left">
Prince<br>
ἄρχων<br>
archōn<br>
Thayer Definition:<br>
1) a ruler, commander, chief, leader<br>
Part of Speech: noun masculine<br>
---
Power - exousia
<font size="5">
<p align= "left">
ἐξουσία<br>
exousia<br>
Thayer Definition:<br>
1) power of choice, liberty of doing as one pleases<br>
1a) leave or permission<br>
2) physical and mental power<br>
2a) the ability or strength with which one is endued, which he either possesses or exercises<br>
3) the power of authority (influence) and of right (privilege)<br>
4) the power of rule or government (the power of him whose will and commands must be submitted to by others and obeyed)<br>
4a1) authority over mankind<br>
4b1) the power of judicial decisions<br>
4b2) of authority to manage domestic affairs<br>
4c1) a thing subject to authority or rule<br>
4c1a) jurisdiction<br>
4c2) one who possesses authority<br>
4c2a) a ruler, a human magistrate<br>
4e) the sign of regal authority, a crown<br>
---
-
Greek Words for "Power"
<font size="5">  
<p align= "left">

|Greek Word|Definition|Context and Usage|Biblical References|
|---|---|---|---|
|Dunamis|Potential, ability, strength|Often refers to inherent ability or capacity|Acts 1:8, Romans 1:16|
|Energeia|Active working, effectiveness|Focuses on manifestation or operation of power|Ephesians 3:7, Colossians 1:29|
|Kratos|Dominion, ruling power|Emphasizes authority and sovereignty|Revelation 5:13, 1 Peter 4:11|
|Exousia|Authority, permission|Highlights legitimate right to exercise control|Matthew 28:18, John 1:12|

---
Satan's Temporary Authority
<font size="5">
<p align= "left">
The term "prince" is significant. While a prince has authority, he is not the ultimate authority. God remains sovereign. Satan's reign, therefore, is both limited in scope and duration and is permitted for the purposes of God for a limited time.

| Verse Ref | Verse Text                                                      |
|-----------------------|---------------------------------------------------------------------|
| John 12:31            | "Now is the judgment of this world; now will the ruler of this world be cast out."   |
| John 14:30            | "I will no longer talk much with you, for the ruler of this world is coming. He has no claim on me."  |
| John 16:11            | "concerning judgment, because the ruler of this world is judged."      |
| 2 Corinthians 4:4     | "In their case the god of this world has blinded the minds of the unbelievers, to keep them from seeing the light of the gospel of the glory of Christ, who is the image of God."  |
| Ephesians 2:2         | "in which you once walked, following the course of this world, following the prince of the power of the air, the spirit that is now at work in the sons of disobedience—"  |

---
Realm of Reign & Influence - Air
<font size="5">
<p align= "left">
The term "air" in this context is often understood to represent the spiritual realm that is invisible but all around us. In antiquity, "air" was considered the domain of spirits. Hence, "prince of the power of the air" implies that Satan has authority over a realm that, while invisible, has an influence on the physical world.
<p align= "left">
<strong>Gill</strong> - It was a notion of the Jews, that there are noxious and accusing spirits, who fly about באויר, "in the air", and that there is no space between the earth and the firmament free, and that the whole is full of a multitude of them; but also it was the opinion of the Chaldeans {n}, and of Pythagoras {o}, and Plato {p}, that the air is full of demons: now there is a prince who is at the head of these, called Beelzebub, the prince of devils, or the lord of a fly, for the devils under him are as so many flies in the air,  Mt 12:24.
---
His work
<font size="5">
<p align= "left">
The Spirit who now ==works== in the children of disobedience.<br>
<p align= "left">
Worketh <br>
ἐνεργέω<br>
energeō<br>
Thayer Definition:<br>
1) to be operative, be at work, put forth power<br>
1a) to work for one, aid one<br>
2) to effect<br>
3) to display one’s activity, show one’s self operative<br>

Compare with Ephesians 1:19, the power at work in us through God's Spirit
---
Children
<font size="5">
<p align= "left">
![[Pasted image 20230911020412.png]]
---
Disobedience - Obstinacy
![[Pasted image 20230911020529.png|700]]
---
<font size="6">
<p align= "left">
Satan has great influence especially over the reprobate part of the disobedient and obstinate; he blinds their minds and fills their hearts, and inspires them to do the worst of crimes, he would influence the elect themselves in their unbelief to be captive to his will. Those who are unregenerate walk after him and imitate him like children, they willingly and even eagerly comply with his suggestions and temptations and lusts. 
---
<font size="4">
<p align= "left">

|Method of Influence|Bible Verse Reference|Verse Text|
|---|---|---|
|Temptation|1 Corinthians 10:13|"No temptation has overtaken you that is not common to man. God is faithful, and he will not let you be tempted beyond your ability, but with the temptation, he will also provide the way of escape, that you may be able to endure it."|
|Deception|Revelation 12:9|"And the great dragon was thrown down, that ancient serpent, who is called the devil and Satan, the deceiver of the whole world—he was thrown down to the earth, and his angels were thrown down with him."|
|Accusation|Revelation 12:10|"And I heard a loud voice in heaven, saying, 'Now the salvation and the power and the kingdom of our God and the authority of his Christ have come, for the accuser of our brothers has been thrown down, who accuses them day and night before our God.'"|
|Distraction|1 Peter 5:8|"Be sober-minded; be watchful. Your adversary, the devil, prowls around like a roaring lion, seeking someone to devour."|
|Division|John 8:44|"You are of your father the devil, and your will is to do your father's desires. He was a murderer from the beginning, and does not stand in the truth because there is no truth in him. When he lies, he speaks out of his own character, for he is a liar and the father of lies."|
Disbelief | Corinthians 4:4"| In their case the god of this world [referring to Satan] has blinded the minds of the unbelievers, to keep them from seeing the light of the gospel of the glory of Christ, who is the image of God." |
---
<font size="6">
<p align= "left">
<strong>John 12:31</strong> Now the judgment of this  world; now shall  the prince of this world be cast out.
<p align= "left">
<strong>1 John 4:4 </strong>Little children, you are from God and have overcome them, for he who is in you is greater than he who is in the world.
<p align= "left">
<strong>Ephesians 6:12 </strong> - For we do not wrestle against flesh and blood, but against the rulers, against the authorities, against the cosmic powers over this present darkness, against the spiritual forces of evil in the heavenly places.

---
Ephesians 2:3 (ESV)
among whom we all once lived in the passions of our flesh, carrying out the desires of the body and the mind, and were by nature children of wrath, like the rest of mankind.<!-- element style="background: floralwhite" -->
<font size="6">
<p align= "left">
![[Pasted image 20230911014436.png]]
---
Among whom also we all had our == "conversation"== in times past. 
<!-- element style="background: floralwhite" -->
<font size="6">
<p align= "left">
When you are trying to encourage someone to move positions or to change, it's always nice to be able to identify with them, and say "I was once like you." or "I was once were you are".  This is essentially what Paul is doing with the Ephesian Gentiles, we were all once unregenerate, children of wrath, walking according to the ways of this world, following the prince of the power of the air, we were all equally sinners but not anymore. Not since Christ made us Alive.  Thank goodness this is our past.
---
Lusts
<font size="5">
<p align= "left">
![[Pasted image 20230911181302.png]]
In the lusts of our flesh; by "flesh" is meant, the corruption of nature; so called, because it is spreading by natural generation; and is opposed to the Spirit, or principle of grace.  and has for its object fleshly things. It makes persons carnal or fleshly: and this is called "our", because it belongs to human nature, and is inherent in it, and inseparable from it in this life. 
The "lusts" of it, are the inward motions of it, in a contrariety to the law and will of God; and are various, and are sometimes called fleshly and worldly lusts, and the lust of the flesh, and the lust of the eyes, and the pride of life: and persons may be said to live in these and follow them, when these are the ground of their lives, when they are solicitous about them, and make provision for the fulfilling of them, and constantly employ themselves in obedience to them, being slaves of the flesh.
---
Mind
<p align= "left">
![[Pasted image 20230911181802.png]]
<p align= "left">
Even our minds, understanding, reasoning that we followare darkened by sin.
---
By nature children of wrath, even as others.
<font size="5">
<p align= "left">
Not only are the unregenerate wrathful persons, living in malice, hateful, and hating one another; but that they were deserving of the wrath of God, which comes upon the children of disobedience, among whom they had their conversation; and which is revealed from heaven against such sins.
<p align= "left">
![[Pasted image 20230911182419.png]]
---

<font size="5">
<p align= "left"> <strong> Dr. Macknight:</strong> -"Nature often signifies one's birth and education, Ga 2:15: We, who are Jews BY NATURE.  Also, men's natural reason and conscience, Ro 2:14: The Gentiles who have not the law, do BY NATURE the things contained in the law,  Also, the general sense and practice of mankind, Eph 2:1; Eph 11:14: Doth not even NATURE itself teach you, that if a man have long hair, Also, the original constitution of any thing, Ga 4:8: Who are not gods BY NATURE,  Also, a disposition formed by custom and habit thus Demetrius Phalereus said of the Lacedemonians: φυσειεβραχυλογουνλακωνες.  The Lacedemonians had naturally a concise mode of speaking.  Hence our word laconic a short speech, or much sense conveyed in a few words."  The words in the text have often been quoted to prove the doctrine of original sin, but, though that doctrine be an awful truth, it is not, in my opinion, intended here; it is rather found in the preceding words, the lusts of the flesh, and the desires of the flesh and of the mind. The apostle appears to speak of sinful habits; and as we say HABIT is a second nature, and as these persons acted from their originally corrupt nature-from the lusts of the flesh and of the mind, they thus became, by their vicious habits, or second nature, children of wrath-persons exposed to perdition, because of the impurity of their hearts and the wickedness of their lives.  Here we see that the fallen, apostate nature produces the fruits of unrighteousness.  The bad tree produces bad fruit.""
 
---
<!-- element style="background: floralwhite" -->
<font size="6">
<p align= "left">
---
END READING
## Ephesians 2:1-3 ESV
<p align= "Left">
<font size="6"> 
 <em> <p align="justify">1. And you were dead in the trespasses and sins 2 in which you once walked, following the course of this world, following the prince of the power of the air, the spirit that is now at work in the sons of disobedience— 3 among whom we all once lived in the passions of our flesh, carrying out the desires of the body and the mind, and were by nature children of wrath, like the rest of mankind.</em>   
---

![[Image Closing Prayer Pink.png]]

---