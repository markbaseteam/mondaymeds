
<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->
---
OPENING PRAYER
==
---
Annoucements
<font size="6">  
- No Bible Study Monday, December 25th, Christmas Day
- No Bible Study Monday, January 1st, New Year's Day

---
Ephesians 3:14-21
<font size="6">  
<p align= "Justify">
14 <font color="#c0504d">For this reason I bow my knees before the Father, 15 from whom every family  in heaven and on earth is named, 16 that according to the riches of his glory he may grant you to be strengthened with power through his Spirit in your inner being,</font> 17 so that Christ may dwell in your hearts through faith—that you, being rooted and grounded in love, 18 may have strength to comprehend with all the saints what is the breadth and length and height and depth, 19 and to know the love of Christ that surpasses knowledge, that you may be filled with all the fullness of God.
<p align= "Justify">
20 Now to him who is able to do far more abundantly than all that we ask or think, according to the power at work within us, 21 to him be glory in the church and in Christ Jesus throughout all generations, forever and ever. Amen.
---
Context - Review Last Week
<font size="6">  
<p align= "left">
Last week we studied the manifold wisdom of God and how the whole world is the theatre for God to display his wisdom to the principalities and powers through the Church! We left off with Paul encouraging the Ephesians not to lose heart because of his sufferings.
---
<font size="6">  
14 For this reason I bow my knees before the Father, <!-- element style="background: floralwhite" --></font><br>
<font size="6">  
<p align= "left">
<strong>For this Reason/Cause</strong><br>
Q. For what reason is Paul referring to?   <br>
<p align= "left">
A. "For this Reason" would first to verse 1 and 13, where Paul begins this section with the phrase "For this reason". Verse 14 is a continuation of thought. Verse 2-13 of chapter 3 were a "side-thought" as Paul paused in the middle of of his talk to speak of the ministry of the mystery of the gospel as identified in vs 6 which had been given by grace specifically to him for which he now suffered as a prisoner of Christ in Rome. He did not lose heart over his circumstances and he did not wish for the Ephesians to loose heart, to be discouraged, or faint hearted at his tribulation and afflictions. He did not want them to be spiritually weakened in their inner man by his imprisonment for the gospel which was for their benefit. He wanted them instead to be strengthened by it. This is what he is about to pray for.

    

---
Paul's Burden
<!-- element style="background: floralwhite" -->
<font size="6">  
<p align= "left">
....I kneel before the Father<p align= "left">
Paul is so desirous and personally burdened for the state of the Ephesians heart, that after he pleads with them in this letter not to be weakened on account of his circumstances and tribulations, he then goes before God to plead on their behalf, that they would not be weakened or fainthearted.  His kneeling shows his humility and his earnestness before God. 
<p align= "left">
It is very much an imitation of Jesus praying for Peter and warning Peter that Satan has asked to sift him like wheat.
<p align= "left">
<strong>Luke 22:31-32</strong> <em>“Simon, Simon, pay attention! Satan has demanded to have you all, to sift you like wheat,  but I have prayed for you, Simon, that your faith may not fail. When you have turned back, strengthen your brothers.”</em>
---
The Ephesian's Challenges
<font size="6">  
<p align= "left">
<font color="#4f81bd">Gentile vs Jew Relationship</font>
<p align= "left">
Ephesian Christians had to navigate a complex and often hostile environment, balancing their commitment to their faith with the challenges posed by a society that was largely non-Christian and frequently opposed to their beliefs and practices. You can see where Paul was at because of the Jews opposition to the Gospel.  There was a large Jewish presence in Ephesus and the relationship between the Jews and the Gentile Ephesians was quite complex and strained because of the differing beliefs about Jesus as the Messiah. Dealing with the pagans in the city, would have been one challenge but dealing with the Jews, would have been another despite their shared heritage.
---
The Ephesian's Challenges
<font size="5">  
<p align= "left">
<font color="#4f81bd">A Pagan Culture</font>
<p align= "left">
Ephesus was known for its religious and cultural diversity. The city's religious life was deeply intertwined with pagan worship and rituals, which posed a significant challenge to Christians who were taught to reject idolatry.  The Temple of Artemis, one of the Seven Wonders of the Ancient World, was located there. The city was a melting pot of pagan religions, early Christianity, and other beliefs, which often led to religious tensions and conflicts.  The city's economy was closely linked to its religious practices, particularly the cult of Artemis. Craftspeople and merchants who depended on selling religious artifacts might have seen the Christian rejection of idols as a direct threat to their livelihood. This is illustrated in Acts 19:23-41, where a riot against the Apostle Paul and his companions was incited by those whose trade was affected by his preaching.  The Ephesians would have faced a lot of economic challenges in their rejection of idolatry and paganism in their day.  They stood out. 
---
The Ephesians Challenges
<font size="6">  
<p align= "left">
<font color="#4f81bd">Time Period of Persecution under Nero</font><br>
  Ephesians is believed to have been written around 60-62AD. This was a great time of persecution for the early Christians. Historically, Emperor Nero was in power during this period. His reign (54-68 A.D.) was marked by extravagance, political plots and schemes, and increasing cruel absolute power. Nero's policies and actions had a significant impact on the entire Roman Empire, including the province of Asia. There were already growing hostilities and suspicions against Christians during the early 60s. The most severe persecutions under Nero started after the Great Fire of Rome in 64 A.D; however, Ephesian Christians might have felt this increasing tension, especially as the culture would blame them for any poor economic conditions that would have resulted in a drop of sales in idols.
---
  The Ephesians Challenges
<font size="5">  
<p align= "left">
<font color="#4f81bd">Temptation to Lose Heart </font><br>
All of these circumstances would try their faith on top of Paul's imprisonment. It's hard to see the hand and will of God operating in victory when all you see around you is against the will of God and does not appear to be his hand at all. Following Christ in this world often does not look like overcoming the world to a place of security, peace, prosperity and coasting. Instead it often much swimming upstream, our security is found in Christ-alone, much giving, generosity and denial will not lead to prosperity, our peace is in Christ-Alone and in this world we know we are at war, and experience much, heartache, suffering, fatigue in pursing God's kingdom .  
<p align= "left">
The temptation to loose heart, to "faint", to become weak,  to become discouraged is very strong for even the most mature Christian.  Paul knew that.  Paul encouraged the Thessalonians in 1 Thes. 5:11 to "encourage one another."
<p align= "left">
    <strong>1 Thess. 5: 11</strong> - <em>Therefore encourage one another and build one another up, just as you are doing. </em>
<p align= "left">
In Eph. 3:13 Paul was encouraging the Ephesians. He is still seeking to encourage and build up the Ephesians in verse 14-21 as he prays for them. 

---
the Father
<font size="5">  
<p align= "left">
Paul prays before the Father, "Our Father which art in heaven".  He comes before the Father kneeling showing earnestness, humility and an acknowledgment of the Father's work and role in His Family. 
<p align= "left">
Paul did not refer to God the Father as "our Father" in this letter, instead he refers to God as "<strong>the Father</strong>.  God is the Father of fathers as we are about to see in Eph. 3:15 . 
<p align= "left">
In Ephesians 1:3 Paul begins this letter to the Ephesians, blessing God the Father of our Lord Jesus Christ, acknowledging that God has blessed us in Christ with every spiritual blessing in the heavenly places.  God the Father is the source of every blessing and good gift from above. 
<p align= "left">
<span style="background:rgba(255, 183, 139, 0.55)">	<strong>Ephesians 1:3</strong> - <em> Blessed be the God and Father of our Lord Jesus Christ, who has blessed us in Christ with every spiritual blessing in the heavenly places,</em></span>
<p align= "left">
Now Paul kneels before God in prayer, and he prays to God the Father who is the source of every spiritual blessing who has already blessed us in Christ, to manifest these spiritual blessings on the Ephesians.  Paul is coming to the great storehouse of God's blessings and boldly accessing this storehouse to distribute its riches to God's people in their time of need and poverty. 
<p align= "left">
 <span style="background:rgba(255, 183, 139, 0.55)">	<strong>Ephesians 3:12</strong><em> in whom we have boldness and access with confidence through our faith in him. <em></span>

---
Expectation Corner
<font size="5">  
<p align= "left">
Emily Steele Elliott in 1828 wrote a short story called ["Expectation Corner"](http://hanswaldvogel.com/lib/Elliott%20-%20Expectation%20Corner.pdf)   
<p align= "left">
It’s a short story about a man named Adam, who lives in a little cottage on Redeemed Land. The reason why it was called Redeemed Land was because long ago there was a rebellion among the people whi ch devastated the land and placed all of its citizens under bondage. But the land Owner sent his son to live among the cottage people. The Son rescued and bought back the people and leased their property back to them and even gave them special rights and privileges of love and favor while they lived in the land. If they had a request or a need all they had to do was refer to their book of the Covenant and write up their need on a slip of paper and send it to the Owner of the land. Each day the Land Owner would send out his messengers to his various storehouses where each request was filled with the request or with something better and then delivered on wagons to every home.

---
<font size="6">  
<p align= "left">
Unlike his neighbors who lived richly around him, Adam lived poor in the land. His windows were dulled over and darkness filled his little house. He often complained about his own lack of fresh water. His next door neighbor would often remind him that he needed only to check his pipes to make sure they were connecting to the right place and that they were not blocked then he could enjoy the fresh water from the living fountain just over the hills like he did. But Adam never got around to checking it and he never wiped the dust from his windows that would have flooded his little house with so much sunlight. Adam never took advantage of the rights and privileges that his citizenship in the Redeemed Land afforded him.
---
<font size="6">  
<p align= "left">
Adam was old and weak. He just didn’t consider himself to be the scholarly type like his neighbors and his sight wasn’t that good to look things up in the Covenant-book. One day his good natured neighbor Widow Full-joy talks him into sending his request into the rich Father, who lived in the Great Palace and reminded Adam of how difficult it is for the rich Father to watch his children go around poorly clad and complaining of scarcity when he had provision stored for them at his Great House according to the Covenant-book that laid on Adams table.
<p align= "left">
With Widow Full-joy’s help and encouragement, Adam drafts up a petition and sends it off to the Great House. Widow Full-joy reminds Adam that in accordance to the Covenant-book in sending in his petition, he must wait by continuing in prayer and watch for the delivery to be made.
---
<font size="6">  
<p align= "left">
The very next day a messenger from the Great House arrives at Adams house in answer to his petition. The messenger cleans Adams window and cleans a bunch of rubbish out of Adam’s pipes and begins telling him of the Lord’s loving care for his tenants and the great may storehouses that the Lord has to provide for all his tenants needs.
<p align= "left">
The messenger takes Adam to the center of the Redeemed Land to see these grand storehouses for himself so that he might understand the goodness of the Lord and his great provision for his tenant. It is here that Adam sees all the attempts that were made by the Lord, to deliver daily provision, answer petitions and even send him gifts of favor, but they were all returned because Adam in his great depression, and dark windows never watched and never answered the door to receive them when they came.
---
<font size="6">  
<p align= "left">
The story continues and Adam soon comes to enjoy all the benefits of living in the Redeemed Land through learning how to watch and petition the Lord for all his daily needs. He no longer lives as a poor man in the Lord’s rich land.
<p align= "left">
It is a great story that reminds us of our great position living in the Redeemed land, and how I too often neglect to take advantage of the benefits our new land and our new position has to offer by not making requests, or by not being prepared to receive them when they do arrive. <p align= "left"> Ephesians 3:1 reminds us that "God the Father has blessed us in the spiritual realms with every blessing in Jesus Christ."  Charles Spurgeon compared this to [Faith's Checkbook](https://www.ccel.org/ccel/s/spurgeon/checkbook/cache/checkbook.pdf) another great book and popular daily devotional if you are looking for one for the New Year.  In the Preface of this Christian Classic Book, Charles Spurgeon writes:
---
<font size="5"> 
<p align= "left">
<em>A promise from God may very instructively be compared to a check payable to order. It is given to the believer with the view of bestowing upon him some good thing. It is not meant that he should read it over comfortably, and then have done with it. No, he is to treat the promise as a reality, as a man treats a check. He is to take the promise, and endorse it with his own name by personally receiving it as true. He is by faith to accept it as his own. He sets to his seal that God is true, and true as to this particular word of promise. He goes further, and believes that he has the blessing in having the sure promise of it, and therefore he puts his name to it to testify to the receipt of the blessing. This done, he must believingly present the promise to the Lord, as a man presents a check at the counter of the Bank. He must plead it by prayer, expecting to have it fulfilled. If he has come to Heaven's bank at the right date, he will receive the promised amount at once. If the date should happen to be further on, he must patiently wait till its arrival; but meanwhile he may count the promise as money, for the Bank is sure to pay when the due time arrives. Some fail to place the endorsement of faith upon the check, and so they get nothing; and others are slack in presenting it, and these also receive nothing. This is not the fault of the promise, but of those who do not act with it in a common-sense, business-like manner. God has given no pledge which He will not redeem, and encouraged no hope which He will not fulfill. To help my brethren to believe this, I have prepared this little volume. - Charles Spurgeon </em>
---
<font size="6">  
<p align= "left">
Paul is kneeling before "God and Father of our Lord Jesus Christ, who has blessed us in Christ with every spiritual blessing in the heavenly places, in bold and confident faith as he about to pray for the spiritual strengthening of the Ephesians. The strengthening of their faith. Their encouragement. That they would not loose heart but they would be firmly grounded and rooted in love.  In Ephesians 1, we talked about how spiritual blessings are the best blessings.

- Eph  1:4 Father God has chosen us 
- Eph 1:5  Father God has ordained us to sonship
- Eph 1:6  Father God has bestowed grace on us in the Beloved.
- Eph 1:7 In Christ, we have redemption, the forgiveness of our sins,  according to the riches of His grace
- Eph 1:8-10 In Christ we have knowledge of the mystery of His will
- Eph 1:11 In Christ we have obtained an inheritance
- Eph 1:13 In Christ we were sealed with the Holy Spirit
---
<font size="6">  
<p align= "left">
These blessings are distributed evenly to every saint.  No one is more loved then you. No one has a closer family tie or union. You are adopted and have full sonship, full union with Christ. No one has less forgiveness. 

- 2 Peter 1:3 - Divine Power has given to us all things that pertain to life and godliness
- Psalms 23 -  if the Lord is your shepherd, then you shall not want.
- 2 Cor 9:8 - God is able to make all grace abound to you, always having all sufficiency you may abound in every good work.
<p align= "left">
<em>"In him thou has given me so much that heaven can give no more. " </em>This line comes from my favorite Christmas Poem is [The Gift of Gifts](https://banneroftruth.org/us/devotional/the-gift-of-gifts/) in book Valley of Vision.
---
<font size="6">  
<p align= "left">
As Christmas is coming upon us and I know all of us wish we could give more then our capability and we often give things others do not really need. Let us make a point of giving this year to others what they really need by praying Ephesians 3:14-19 by coming to God in faith on their behalf in intercessory prayer and asking God to distribute to these specific individuals spiritual strength as needed and  his riches in Christ and to help them clean their windows to see and their pipes to receive.
---
<font size="6">  
from whom every family in heaven and on earth is named.
<font size="5">  
<p align= "left">
<strong>"from whom every family"</strong>: God is the ultimate source or origin of every family and the institution of the family. This does highlight the divine design and purpose of families.
<p align= "left">
The Jews would boast of having Abraham as their Father, but now both Jews and Gentiles are denominated from Christ. We are of one family unit, one household, one body, one father, one spirit. 
<p align= "left">
Ephesians 3:15 highlights the idea that every family, whether in heaven or on earth, ultimately derives its existence and identity from God the Father. 
<p align= "left">
The father figure is critical to a family unity and identity.   As children receive their name from their Father and their relationship to their Father is identified by their last name, so the apostle says, the whole family of God derive their name from him and are known and recognized as his children.
<p align= "left">
This concept can be a reminder of the divine purpose and significance of families and their role in reflecting God's design for human relationships. It also underscores the idea of God's sovereignty over all aspects of creation, including the institution of the family unit which is so much under attack today.
---
<font size="6">  
<p align= "left">
This word <strong>"family"</strong> in the Greek is "patria" and it means a group of familes or a whole race (nation). It can be used a bit broader to include all of creation and all the diverse nations, races, communities, organizations, "families of animals" and angels are in their own "families". In this broader sense of categories of creation that God has placed all into "families." 
<p align= "left">

<p align= "left">

---
<font size="6">  
<strong>"The Father… Of whom the whole family in heaven and earth is named,"</strong> 
<font size="5">  
<p align= "left">
Ironside writes: <em>The Father… Of whom the whole family in heaven and earth is named.” “The whole family” is undoubtedly a correct rendering here, and yet “every family” would be just as correct. “The whole family,” however, conveys the most precious thought. This phrase means that all saints in earth and Heaven constitute one great family of born-again ones, of whom God is the father. But I am thinking too of the great hosts of angels never redeemed by the blood of Christ because they have never fallen; even those who fell found no Savior. The angels also acknowledge the fatherhood of God, but they are servants, waiting on the family. Then there is the family of the Old Testament saints. There was the antediluvian family, the patriarchal family, the Israelites, those who were truly of Israel. All these were families through the past dispensations. Today there is the church of this age of grace, and in the future there will be the glorious kingdom family. There are dispensational distinctions, but all receive life from the same blessed Person, and all together adore and worship Him. Notice that the whole family is located in Heaven and on earth. Those who are dead to us are alive to God above.</em>
---
<font size="6">  
<p align= "left">
This passage is most often understood to be a reference to the redeemed, the family of God, who are now the children of God. God is the Father of both Jew and Gentile and those who are in heaven, the saints who have passed away and those who still live. We are one united family in the brotherhood of saints with God the Father in our midst.  As we discussed last week, we are very different from the angels in many aspects but especially in our relationship to God and our ability to call God "Father" as we do.
<p align= "left">
---
<font size="6">  
Charles Spurgeon wrote a touching sermon on this passage called "Saints in Heaven and Earth One Family." In it he writes:. 
<font size="5">  
<p align= "left">
"Let us note, first, -concerning those in heaven and earth whom the Lord loves that their names are all written in one family register. That mystical roll which eye hath not seen containeth all the names of his chosen. They are born by degrees, but they are chosen at once; by one decree set apart from the rest of mankind, by one declaration “They shall be mine,” separated for ever as hallowed things unto the Most High. “Blessed be the God and Father of our Lord Jesus Christ, who hath blessed us with all spiritual blessings in heavenly places in Christ: according as he hath chosen us in him before the foundation of the world, that we should be holy and without blame before him in love: having predestinated us unto the adoption of children by Jesus Christ to himself, according to the good pleasure of his will, to the praise of the glory of his grace, wherein he hath made us accepted in the beloved.” We like to keep our own family registers; we are pleased to look back to the place where our parents recorded our names with those of our brothers and sisters. Let us gaze by faith upon that great book of life where all the names of the redeemed stand indelibly written by the hand of everlasting love, and as we read those beloved names let us remember that they make but one record. The faithful of modern times are on the same page with the saints of the Old Testament, and the names of the feeblest among us are written by the same hand which inscribed the apostles and the martyrs. We confidently believe that Mrs. Bartlett’s name is found in the same roll which contains yours, my sister, though you may be the most obscure of the Lord’s daughters. “Even as ye are called in one hope of your calling,” so were ye all comprehended in one election of grace."
---
<font size="5">  
<p align= "left">
Paul begins his prayer for the Ephesians to be strengthened with power, where is this strength derived from? God's storehouse. Paul prays that God strengthens them according to the riches of His glory.
<p align= "left">
<strong>he may grant you to be strengthened with power through his Spirit in your inner being</strong>
They were to receive power communicated through the Holy Spirit.  He is the immediate worker of grace in the souls of God's people.
<p align= "left">
The inner man is the heart or soul. To be strengthened with might/power  (dunamis) is a reference to miraculous power, force. Our English word dynamite comes from this Latin word Dunamis.   
<p align= "left">
Paul is praying for a high degree of grace, and spiritual abilities for discharging duty, resisting temptations, enduring persecutions for the Ephesian believers. 
<p align= "left">
 <strong>Matthew Henry</strong> - That strength from the Spirit of God in the inner man is the best and most desirable strength, strength in the soul, the strength of faith and other graces, strength to serve God and to do our duty, and to persevere in our Christian course with vigour and with cheerfulness. 
---
<font size="5">  
<p align= "left">
<strong>Henry Law</strong> -<em> "The petition which presses to be foremost in the list, is for rich abundance of spiritual strength. Greatly do we need this blessing. Spiritual life may indeed have been revived in our souls— but it is a flickering spark, and we have frequent cause to tremble lest it should be extinguished. It is as the feeble lamb amid devouring wolves. It is as the timid dove beset by cruel hawks. It is as the little bark amid engulfing billows. Many indeed are our perils and our foes —and weak is our own strength to resist our adversaries. We wrestle not only against inborn corruptions, but against principalities and powers, against the rulers of the darkness of this world—against spiritual wickedness in high places. The devil as a roaring lion goes about seeking whom he may devour—as a fierce dragon he watches to destroy. How shall we resist—how shall we escape! We must look upward to Him who is mightier than the mightiest—who can give indomitable support—and make us more than conquerors over all the hosts of darkness. We must pray unto Him, who according to the riches of His glory can strengthen us with all might by His Spirit in the inner man! He is always ready to hear—always able to give needful strength. We have indeed to fight a good fight—to wrestle against mighty foes—and vain would be our efforts if left to our unaided strength.</em> 
---
<font size="5">  
<p align= "left">
<em>But He who gives the sword will give too the arm to wield it. In all our conflicts He will stand by our side—upholding when we are prone to fall—giving power to the faint, and to those who have no might increasing strength. But not only have we to fight and struggle, we are called to bear heavy burdens, and to do arduous work."<br><br>
Soon would we be crushed beneath the overwhelming load—quickly should we faint before the constant toil, if we trusted only in our own resources. But He will endue us with patience, and arm us with holy endurance. He will teach us to look upward, and to go on our way rejoicing. How arduous, too, is the work to which we are called! It must be our constant effort to adorn His doctrine—to call men to His faith—to teach the ignorant—to reclaim the backslider—to strengthen the irresolute, and in countless ways to win to the knowledge of the faith and love of Jesus. What gifts—what knowledge—what wisdom—what perseverance are here required! And in ourselves what weakness, and ignorance, and sin! How shall we succeed and prosper except strength be supplied from heaven? The lamp would soon go out except replenished with the needful oil. So we should be soon vanquished except the Lord should strengthen and uphold. But we are taught to pray that He, according to the riches of His glory, would strengthen us by His Spirit in the inner man</em>
---
<font size="6">  
<p align= "left">
<strong>That according to the riches of his glory </strong>
<p align= "left">
<strong>riches</strong> - wealth, abundance, 
<font size="5">  
<p align= "left">
How rich is the glory of God? Can it be measured? Can anyone discern the end or the limits to it? We spoke last week about the manifold wisdom of God and how there is no end to his wisdom. The wisdom of God is without beginning and without end. It's incomprehensible, multifaceted. 
<p align= "left">
The riches of God's glory is also incomprehensible, immeasurable and without limit. There is no end to the glory of God.  Paul prays that God would grant the Ephesians to be strengthened according to the riches of his glory,  Not <strong>"out of"</strong> the riches of his glory, but  <strong>"according to" to the riches of his glory.</strong>  It is an important distinction. In Ephesians 1:7 we discussed this distinction using the example of a millionaire.  If you asked a millionaire to donate to your cause, he may give you $10 <strong>"out of his riches"</strong> but it is not </strong>"according to his riches."</strong>   If the millionaire gave you a blank check book and told you to fill in what you need, that would be <strong>"according to his riches." </strong> This is what God does. God gives us according to his riches, according to the riches of his grace and according to the riches of his glory, honor. praise.  We can never overdraw God on His account. 
---
<font size="5">  
<p align= "left">
What does it mean for God to give according to the riches of his glory?
<p align= "left">
In Ephesians 1:7 it was according to the riches of his grace. What does it mean for God to give out of the riches of his glory? 
<p align= "left">
It is for his namesake.  This is another important aspect of prayer.  That God often moves and answers our prayers for his namesake, for his own honor and glory. The Old Testament Prophets would often depend on this and would call on God to hear and to move for his namesake, for his reputation.
<p align= "left">
<strong>Jeremiah's Prayer (Jeremiah 14:7-9)</strong>: In this passage, the prophet Jeremiah pleads with God to act for His name's sake and not abandon His people. He acknowledges God's reputation and asks Him to intervene. <p align= "left">
<> <strong>Jeremiah 14:7-9 (ESV):</strong> <em>"Though our iniquities testify against us, act, O Lord, for your name's sake; for our backslidings are many; we have sinned against you. O you hope of Israel, its savior in time of trouble, why should you be like a stranger in the land, like a traveler who turns aside to tarry for a night? Why should you be like a man confused, like a mighty warrior who cannot save? Yet you, O Lord, are in the midst of us, and we are called by your name; do not leave us."<em>
---
<font size="5">  
<p align= "left">
<strong>Moses' Intercession (Exodus 32:11-14):</strong> When the Israelites sinned by making a golden calf, Moses interceded for them, asking God to spare them for the sake of His name and His promises to their forefathers.<br>
<> <strong>Exodus 32:11-14 (ESV):</strong><em> "But Moses implored the Lord his God and said, 'O Lord, why does your wrath burn hot against your people, whom you have brought out of the land of Egypt with great power and with a mighty hand? Why should the Egyptians say, "With evil intent did he bring them out, to kill them in the mountains and to consume them from the face of the earth"? Turn from your burning anger and relent from this disaster against your people. Remember Abraham, Isaac, and Israel, your servants, to whom you swore by your own self, and said to them, "I will multiply your offspring as the stars of heaven, and all this land that I have promised I will give to your offspring, and they shall inherit it forever." And the Lord relented from the disaster that he had spoken of bringing on his people."</em>
---
<font size="5">  
<p align= "left">
<strong>Ezekiel's Prayer (Ezekiel 36:22-23):</strong>Ezekiel prophesies about God's restoration of Israel, and he makes it clear that it's not for their sake but for the sake of God's holy name.<br>
<><strong>Ezekiel 36:22-23 (ESV):</strong><em> "Therefore say to the house of Israel, Thus says the Lord God: It is not for your sake, O house of Israel, that I am about to act, but for the sake of my holy name, which you have profaned among the nations to which you came."</em>
<p align= "left">
Here in Ephesians 3:16, we see Paul imitating the prayers of the Old Testament prophets by calling on God with boldness to answer according to the riches of his glory.  We too can imitate this in our prayers that God would answer us according to the riches of his glory and for his own glory and namesake to act in his honor for righteousness or justice or mercy in any given situation.
---
END READING<br>
Ephesians 3:14-16
<font size="6">  
<p align= "Justify">
<font color="#4f81bd">14 For this reason I bow my knees before the Father, 15 from whom every family  in heaven and on earth is named, 16 that according to the riches of his glory he may grant you to be strengthened with power through his Spirit in your inner being,</font> 17 so that Christ may dwell in your hearts through faith—that you, being rooted and grounded in love, 18 may have strength to comprehend with all the saints what is the breadth and length and height and depth, 19 and to know the love of Christ that surpasses knowledge, that you may be filled with all the fullness of God.
<p align= "Justify">
20 Now to him who is able to do far more abundantly than all that we ask or think, according to the power at work within us, 21 to him be glory in the church and in Christ Jesus throughout all generations, forever and ever. Amen
---
CLOSING PRAYER 
==
---