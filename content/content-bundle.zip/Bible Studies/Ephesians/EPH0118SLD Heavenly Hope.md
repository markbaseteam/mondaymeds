
<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->

---

![[Pasted image 20230710165632.png]]
---
Ephesians 1:18
<p align= "Left">
<font size="6"> 
18 having the eyes of your hearts enlightened, that you may know what is the hope to which he has called you, what are the riches of his glorious inheritance in the saints, 
---

<center><strong><em>Review</strong></em></center>
<p align= "left"><font size="6">  
Last week we looked at the beginning of Paul's prayer for the Ephesian saints, that God would give them a spirit of wisdom and revelation in the knowledge of God.
<p align= "left">
Paul is praying for the Ephesian believers, asking God to grant them a deepening understanding of Himself through the Holy Spirit's work of wisdom and revelation. The ultimate goal of this prayer is for the believers to know God more intimately and to understand the spiritual truths of their faith on a deeper level...because when we understand them, we apply them, when we apply them we become more like Christ...when we become more like Christ we glorify God.


<p align= "left">
---
#### Having the eyes of your hearts enlightened,<!-- element style="background: floralwhite" -->
<font size="5">  
<p align= "left">
In this verse, Paul is building upon the foundation laid in the previous verse. He prays that the Ephesians' spiritual eyes would be opened or enlightened by the Holy Spirit. This enlightenment serves a purpose: so that they might grasp the hope to which God has called them and understand the immense spiritual riches that come with being a part of His redeemed 

There are three key word nouns in this sentence. [thebible.org](https://thebible.org/gt/index)
| Greek      | Greek Definition                                                              | Eng ESV | Eng KJV       | Eng HCSB   |
| ---------- | ---------- | ------- | ------------- | ---------- |
| ophthalmos | 1. the eye. 2.    metaphorically the eyes of the mind, the faculty of knowing | Eyes    | Eyes          | Perception |
| dianoia    | 1. the mind as a faculty of understanding, feeling, desiring 2. understanding | hearts  | understanding | mind       |
| phōtizō           | 1.  to give light, to shine 2. to enlighten, light up, illumine                                                                              |  enlighten          |         enlightened      |  enlighten          |   

---
The Eye
<font size="5">  
<p align= "left">
<Strong>Matthew 6:22</strong> - <em>The eye is the lamp of the body. So, if your eye is healthy, your whole body will be full of light,</em>
<p align= "left">
Philo - , "What the eye is to the body, that is the mind to the soul."
<p align= "left">
Our eyes allow us to see and understand the physical world around us. They enable us to respond and navigate the physical world without stumbling over objects in our path. The eyes need good lighting to see well and function well.  In the same way our understanding is how our minds, our "heart" or "inner soul", "sees", "perceives" the world around us.  Our understanding requires good light also.
---
<font size="5">  
<p align= "left">
Our eyes can see nothing apart from light shining. 
<p align= "left">
I love being out here in the country because it is what I call "country dark." It's great to see the stars at night but when it is cloudy and stars and the moon are hidden, it is extremely dark. Usually a porch light is shining not too far or I use my phone light to walk out to the back yard, usually to chase down my barking dog and bring him back in the house late at night after he has spotted a possum, raccoon or a neighborhood cat outside our chain link fence. It's very dark out. Our eyes require some measure of light to see.
<p align= "left">
Our understanding in the same way can see or discern nothing on its own, unless the light of God enlightens it by the spirit of wisdom and revelation so that we might see God.
---
The "Heart"/ "Mind"/"Understanding" dianoia 
<font size="5">  
<p align= "left">
In the ESV & ASV, the phrase is written as "the eyes of your heart," rather than "mind." The term "heart" here encompasses the entire inner self, including emotions and will. It represents the core of a person's being. We often see the mind as all reason and the heart as all emotion, but the mind is driven by the hearts desire and will. Proverbs 4:23  <em>"Keep your heart with all vigilance, for from it flow the springs of life."</em>
<p align= "left">
Unfortunately, the ability to perceive spiritual realities with the "heart" is absent in those who have not been spiritually reborn. Such individuals are incapable of grasping spiritual concepts. 
<p align= "left">
<strong>1 Cor. 2:14</strong>, <em>"But the natural man receiveth not the things of the Spirit of God; for they are foolishness unto him: neither can he know them, because they are spiritually discerned"</em>
<p align= "left">
Therefore, for a believer's understanding of spiritual truths to grow, the eyes of their heart must be consistently focused on the Lord.
---
Having Been  Enlightened
<font size="5">  
<p align= "left">
![[Pasted image 20230821165138.png]]
---
Having Been  Enlightened
<font size="5">  
<p align= "left">
While many translations interpret this as a prayer for "enlightenment," the truth lies in Paul's use of the perfect tense for the word "photizo." This tense indicates a past action with ongoing impact. A more accurate interpretation is  "the eyes of your heart are in an enlightened state, aimed at helping you comprehend the hope of His calling."

This rephrasing emphasizes the continuous nature of enlightenment as described by Paul, rather than a one-time event. We have been given light and God will continue to give us his light.
---
<font size="5">  
<p align= "left">

<strong>2 Cor. 4:6 </strong>- <em>For God, who said, “Let light shine out of darkness,” has shone in our hearts to give the light of the knowledge of the glory of God in the face of Jesus Christ.</em>
<p align= "left">
The bible speaks much about spiritual blindness of those who have not been spiritually reborn.  Our understanding is blind because of sin when we do not have the light of God shining in our hearts.  Our spiritual understanding has eyes but they can't see without God's spiritual light. Just like our physical eyes can't see without physical light. Sin makes us blind, one of the first effects of true religion is our eyes being open and seeing the truth in God's word and that we are sinners in light of it.  
<p align= "left">
The light of understanding enters our minds and our recognition and acknowledgement of truth  enables to navigate the world around us, to obtain a true knowledge of God, ourselves and gain wisdom.


---
God Gives Understanding
<font size="5">  
<p align= "left">
Paul is praying for a deeper spiritual understanding, that "Aha!" reaction we have when we begin to really understand something and exclaim "I see it! I finally see what you’re telling me, Lord!" That's what Paul is praying for here. A good definition of understanding is when the heart and the mind meet, then we not only "know" with reason, but we "understand" with our heart.

|Verse|Scripture Reference|
|---|---|
|Luke 24:45|"Then he [Jesus] opened their minds to understand the Scriptures."|
|Psalm 119:18|"Open my eyes, that I may behold wondrous things out of your law." |
|1 Cor. 2:14|"The natural person does not accept the things of the Spirit of God, for they are folly to him, and he is not able to understand them because they are spiritually discerned." |
|Proverbs 2:6|"For the Lord gives wisdom; from his mouth come knowledge and understanding." |
|Nehemiah 8:8|"They read from the book, from the Law of God, clearly, and they gave the sense, so that the people understood the reading." |
|James 1:5|"If any of you lacks wisdom, let him ask God, who gives generously to all without reproach, and it will be given him." |
---
<font size="5">  
<p align= "left">
 Most of us know that God gives us understanding, this is not exactly an "Aha!" revelation, but it is an truth that we need to be reminded of.
<p align= "left">
 Recognizing that it is God who gives us spiritual understanding <Strong> humbles</Strong>  us and reminds us of our <Strong> dependence </Strong> on Him. As Christians, we believe that our relationship with God is not based on our own merit or superior intellectual skills, but on His grace and revelation. Understanding that God is the source of spiritual insight helps us avoid arrogance and self-reliance, directing our focus and gratitude toward Him.  
<p align= "left">
This is especially true for us in the reformed church who have a healthy love for doctrine. "Knowledge puffs up", It's an open door for pride to waltz right on into our hearts and to look down on others weaker in the faith. Sin blinds us so we may not be aware of our attitude. Any knowledge or insight that God has given us, should remind us of our dependence on God, it should humble us and it should cause us a healthy dose of fear, <em>"for to whom much is given, much will be required"</em> (Luke 12:48). With knowledge comes responsibility,
---
<font size="5">  
<p align= "left">
<Strong> James 3:1 -</Strong>  Not many of you should become teachers, my brothers, for you know that we who teach will be judged with greater strictness.  For we all stumble in many ways. And if anyone does not stumble in what he says, he is a perfect man, able also to bridle his whole body.
<p align= "left">
<Strong> 1 Timothy 1:5-7 - </Strong> The aim of our charge is love that issues from a pure heart and a good conscience and a sincere faith. Certain persons, by swerving from these, have wandered away into vain discussion,  <em>desiring to be teachers of the law, without understanding</em> either what they are saying or the things about which they make confident assertions.
---
<font size="5">  
<p align= "left">
Remembering that it is God who enlightens our minds and hearts also encourages <Strong> unity</Strong>  among us as believers and <Strong> growth </Strong> .  It's not about someone's superior intellectual ability, but about our relationship with God, our dependence on him and on one another. We each can know God for ourselves and we each have a responsibility to hold one another accountable to the Word of God.  Those who would try to create an authority beyond question or special revelation are dangerous, proud, divisive and "immature" if saved at all. We all have direct access to the source of knowledge and understanding.
<p align= "left">
The spirit does distribute the gifts according to God's pleasure and some may have the gift of knowledge or of wisdom in greater degree then others, and this comes from life experience walking with God longer (sometimes), prayer and  personal bible study. God calls us to desire the greater gifts and if we truly desire a greater gift of knowledge or wisdom, all we have to do is pray and study God's word for ourselves and we should.
---
<font size="5">  
<p align= "left">
The reality of the ordinary progress of Christian understanding should not escape our notice: early believers "know no answers"; immature believers "know all the answers"; and mature believers "know the limits of our answers.  
  
Bryan Chapell, Ephesians
---
<font size="5">  
<p align= "left">

|Reference|Spiritual Blindness - Having eyes that don't "see" at all|
|---|---|
|2 Cor. 4:3-4 |"And even if our gospel is veiled, it is veiled to those who are perishing. In their case the god of this world has blinded the minds of the unbelievers, to keep them from seeing the light of the gospel of the glory of Christ, who is the image of God."|
|Matthew 15:14 |"Let them alone; they are blind guides. And if the blind lead the blind, both will fall into a pit."|
|Isaiah 6:9-10 |"And he said, 'Go, and say to this people: Keep on hearing, but do not understand; keep on seeing, but do not perceive. Make the heart of this people dull, and their ears heavy, and blind their eyes; lest they see with their eyes, and hear with their ears, and understand with their hearts, and turn and be healed.'"|
|1 John 2:11 |"But whoever hates his brother is in the darkness and walks in the darkness, and does not know where he is going, because the darkness has blinded his eyes."|
|Ephesians 4:17-18 |"Now this I say and testify in the Lord, that you must no longer walk as the Gentiles do, in the futility of their minds. They are darkened in their understanding, alienated from the life of God because of the ignorance that is in them, due to their hardness of heart."|

---
<font size="5">  
<p align= "left">
The reality of spiritual blindness can be frightening because it highlights the potential for us to be unaware of our own condition and the truths of God.  God has enlightened our eyes and is continuing to do so, but not one of us has "perfect vision" yet or "perfect understanding". This means that we each have a degree of spiritual blindness and the fear of spiritual blindness  should prompt us to pray fervently for the enlightenment of hearts,  to support one another in love in our spiritual walks, helping us see our weaknesses and holding each other accountable, and to be compassionate and patient in sharing the gospel praying that God would open the eyes of those who are spiritually blind so they can see the truth.
---
<font size="5">  
<p align= "left">

The Domino Dangers of spiritual blindness are many;
1. <strong>We don't hear the gospel. </strong>We don't know God.
2. <strong>Misguided false beliefs.</strong>  Our beliefs can be distorted about God Himself, leading to anxiety, fear, sin. Our distorted about ourselves or our life purpose leading to undue depression and grief.  Steals our level of joy and peace.
3. <strong>Lack of spiritual growth.</strong>  If we have misguided beliefs, it will result in a lack of spiritual growth and maturity.
4. <strong>Damaged relationships with others </strong> If we are not growing spiritually in obedience to God, it means we are not loving others as we should. Our love for God and our love for our brothers and sisters in Christ cannot be separated. We will be experiencing broken relationships, hurting others from our lack of showing love and be completely blind to our responsibility.
5. <strong>Limited Impact </strong> If we have misguided false believes and are not growing spiritually and are not loving others, then our impact in spreading the gospel is going to be effected. We will not be living out our faith or walking like Jesus in this world but will be walking according to the flesh. We will see no fruit. No new life. No power of God. Our life is is not aligned with God's.
6. <strong> Eternal Consequences </strong> Being separated from God eternally is the ultimate risk of someone who does not know God but is spiritually blind to it.  A believer who is spiritually blind in some areas and lacking spiritual growth and relationships and having limited impact will experience some loss of rewards. We may be saved but as one snatched from the fire.

---
<font size="5">  
<p align= "left">
It is important for us to "see" that spiritual blindness has potential consequences  and does inherently set off a chain reaction that touches various aspects of our lives now and in eternity. Each step is a progression and has a far-reaching impact beyond just our own lives.
<p align= "left">
This chain reaction emphasizes the urgency and importance of addressing spiritual blindness  in our lives and in our  interactions with others.  There are profound stakes involved in matters of faith and the gravity of sharing the Gospel message with those who are spiritually blind. We are to work with God as he works salvation in the lives of others. Yes, God can do it himself, but do you want to be that person? Would you want to be that employee, that worker...and go off and do as you please?
<p align= "left">
As Christians, we each have degrees of light and we have enough to share. God has enlightened our hearts with a knowledge of him. We may desire more light, we will always desire more light as Christians, but there are those who have no light at all. Completely spiritually blind and stumble in the darkness and are blind guides unaware.  Knowing that God enlightens our hearts reminds us of the importance of sharing the gospel and praying to God to enlighten the hearts of others.
---
<!-- slide bg="#000" -->
</center>.</center>
---
<font size="5"> 
<p align= "Left">
18 having the eyes of your hearts enlightened,<font color="#7f7f7f"> <strong>that you may know what is the hope to which he has called you, what are the riches of his glorious inheritance in the saints, </strong></font> <!-- element style="background: floralwhite" -->
<p align= "Left">
As our understanding of God deepens, we are more equipped to grasp the profound hope that is part of our calling in Christ. This hope includes the anticipation of eternal life, the fulfillment of God's promises, and the transformation of our lives according to His purposes.
<p align= "Left">
In Ephesians 1:18, Paul is praying for the Ephesian believers, asking that their hearts be enlightened to grasp the hope to which God has called them. This "hope" refers to the confident expectation of the future promises God has given to His people. Understanding this hope is crucial because it gives believers a profound sense of purpose, assurance, and motivation in our daily lives.
<p align= "Left">
 It reminds us that our lives are not aimless but are part of God's grand plan and we have work to do and a limited amount of time to do it in. This hope is grounded in the promises of God and the assurance of eternal life through Christ. It inspires us to persevere through trials, keeping our focus on eternity.
---
<font size="5"> 
<p align= "Left">
How does our hope for eternity bring joy in our present lives?
---
<!-- slide bg="#000" -->
</center>.</center>
---

<!-- slide bg="[[Candle.jpg]]" -->
---
<!-- slide bg="[[Background Image - Music.png]]" -->
Classic Hymns on Our Hope for Heaven
<font size="5"> 
<p align= "Left">
- "When We All Get to Heaven"<br>
- "In the Sweet By and By"<br>
- "I'll Fly Away" <br>
- "I'll Meet You in The Morning" - <br>
- "Swing Low, Sweet Chariot" -  <br>
- "When the Roll is Called up Yonder"<br>
- "I am a Pilgrim" <br>
- "I'm Bound for the Promised Land" <br>
- If We Never Meet Again" <br>
- "Let the Lower Lights Be Burning" <br>
- "Where the Soul of Man Never Dies" <br>
- -"Where We'll Never Grow Old"<br>
---
<!-- slide bg="[[Bookpage Background.jpg]]" data-background-opacity="0.75" -->
<font size="5"> 
<p align= "Left">

Blaise Pascal's quote below touches on the connection between hopequote for eternity and the experience of happiness in this life.<br>
<p align= "Left">
<strong> Blaise Pascal, Pensees </strong> - "Let us reflect on this, and then say whether it is not beyond doubt that there is no good in this life but in the hope of another; that we are happy only in proportion as we draw near it; and that, as there are no more woes for those who have complete assurance of eternity, so there is no more happiness for those who have no insight into it."   -
---
<font size="6"> 
<p align= "Left">
How did hope for eternity effect martyrs lives? 

---
<font size="6"> 
<p align= "Left">
Martyrs willingly endured unimaginable suffering and death for the sake of their faith because they were motivated by the hope of eternal life and the promises of God.  Like Christ, the "joy of the cross" set before them, shows the paradoxical nature of our Christian faith – finding joy and purpose even in the midst of suffering, because of the assurance of eternity.

<strong>Jim Elliot</strong> - "He is no fool who gives what he cannot keep to gain what he cannot lose."
<p align= "Left">
Jim Elliot's quote highlights the Christian perspective that earthly possessions and comforts are fleeting, while the rewards and joys of eternity are immeasurable. It's a reminder to invest in eternal treasures rather than temporary ones for <em>"...the world is passing away along with its desires, but whoever does the will of God abides forever." </em>
---
<p align= "Left">
<font size="6"> 
Consider an Atheist. Can an Atheist truly be happy in this life when they have no hope for eternity and this life is quickly coming to an end and filled with much sorrow, affliction and decay as we age?

---
Contrast an Atheist & Believer
<font size="5"> 
<p align= "Left">
Atheists often find meaning and purpose in the present moment, in human relationships, personal accomplishments, contributions to society, and the pursuit of knowledge and experiences. Their happiness is rooted in the here and now, without  eternal hope. Instead of relying on the prospect of an afterlife, atheists  focus on living their "best life now" during their limited time on Earth.
<p align= "Left">
Christians in contrast, do find much joy in this life and in our relationships and work but unlike Atheists we are looking further down the road. These are not an end to themselves or for our own pleasure, we do them for the glory of God and we look forward to our reward in heaven,  A Christian believer however, finds meaning and purpose  in the promises of God, in the hope of eternal life, in Christ himself knowing everything in this world is passing away.  A Christian is called to give his life away.  To die to self. We seek our "best life later". 
<p align= "Left">
When we live with the mindset of our "best life later" or "Better days ahead" we look forward to heaven! It's truly where our treasure is. But if we don't then we mourn and struggle more with our own death, because our treasure is here, or we just never fueled our hope because we are not "seeing" better days ahead.
---
<font size="5"> 
<p align= "Left">
<strong>1 John 2:15-17</strong> - <em>15 Do not love the world or the things in the world. If anyone loves the world, the love of the Father is not in him. 16 For all that is in the world—the desires of the flesh and the desires of the eyes and pride of life—is not from the Father but is from the world. 17 And the world is passing away along with its desires, but whoever does the will of God abides forever.</em>
<p align= "Left">
Atheists emphasize the significance of the here and now, while Christians anchor their lives in the hope of eternity. As we speak about vision, we can see how God enlightens the heart of the Christian to see further by hope. Hope gives Christians far sightedness beyond the bounds of this world.<p align= "Left">
A Christians belief in eternity and the hope of an afterlife, can be seen as "far-sighted." Our emphasis is or should be on eternal values, rewards, and the ultimate purpose  to shape our decisions in light of the bigger picture. This long-term perspective and willingness to invest in actions and choices that align with our faith, even if it means sacrificing temporary comforts or desires.
<p align= "Left">
Atheists, in contrast, might be  more generally described as "near-sighted," focusing on the immediate experiences, relationships, present pleasures and accomplishments in this lifetime. Without a belief in an afterlife, their emphasis tends to be on maximizing their current existence and making the most of their time on Earth. 
---
"The day which we fear as our last is but the birthday of eternity."
<font size="4"> 
<p align= "Left">
Lucius Annaeus Seneca 4BC AD 65, Stoic Roman Philospher, an advisor to Emperor Nero who was ordered to commit suicide after being accused of conspiring against Nero. His calm and philosophical approach to his own death is what has given him much notarity. He lived among the early Christians but there is no evidence to say he ever became one though he sought wisdom and values according to Stoicism.
---
Weary
<font size="4"> 
<p align= "Left">

I am weary of straying — oh I fain would I rest,  
In the far distant land of the pure and the blest;  
Where sin can no longer her blandishments spread,  
And tears and temptation forever have fled.  
  
I am weary of hoping — where hope is untrue:  
As fair but as fleeting as morning's bright dew;  
I long for that land whose blest promise alone  
Is changeless and sure as eternity's throne.  
  
I am weary of sighing o'er sorrows of earth,  
O'er joy's glowing visions that fade at their birth;  
O'er the pangs of the loved, that we can not assuage;  
O'er the blightings of youth, and the weakness of age.  
  
I am weary of loving what passes away —  
The sweetest, the dearest, alas I may not stay;  
I long for that land where these partings are o'er  
And death and the tomb can divide hearts no more.  
  
I am weary, my Savior, of grieving Thy love;  
Ohl when shall I rest in Thy presence above?  
I am weary — but oh I let me never repine,  
While Thy word and Thy love and Thy promise are mine.  
- SONGS IN THE NIGHT.


---
Songs in the Night - A Prayerful Meditation
<font size="5"> 
<p align= "Left">

1. **Weary of Earthly Struggles**: The repeated refrain "I am weary" emphasizes a profound fatigue with the trials and tribulations of life on Earth. The weariness extends to various aspects of human experience, including sin, false hope, sorrow, love's fleeting nature, and even the grief caused by failing to live up to divine love.
    
2. **Longing for Heaven**: The poem's longing for a "far distant land" where sin, tears, and temptation have no place reflects a deep desire for the peace and purity of heaven. This longing is not just for personal rest but for a place where love is eternal, and separation and death are no more.
    
3. **Contrast Between Earthly and Heavenly**: The imagery in the poem contrasts the impermanence and suffering of earthly life with the unchanging and eternal nature of heavenly existence. Earthly joys are compared to "morning's bright dew," beautiful but fleeting, while heavenly promises are as "changeless and sure as eternity's throne."
    
4. **Faith and Hope in Christ**: The poem concludes with a personal address to the Savior, expressing both a weariness of grieving Christ's love and a steadfast faith in His word, love, and promise. Despite the weariness, there's a resolve not to complain, grounded in the assurance of Christ's presence and promises.

---
<!-- slide bg="[[Background Image - Music.png]]" -->
Are You Weary, Are You Heavy Hearted?  
Tell It To Jesus, Tell It To Jesus.  
Are You Grieving Over Joys Departed?  
Tell It To Jesus Alone.

Tell It To Jesus, Tell It To Jesus,  
He Is A Friend That’s Well Known.  
You’ve No Other Such A Friend Or Brother,  
Tell It To Jesus Alone.
---
<!-- slide bg="#D4E4F7" -->
END READING
## Ephesians 1:18 ESV
<p align= "Left">
<font size="6"> 
 <em> <p align="justify">18 having the eyes of your hearts enlightened, that you may know what is the hope to which he has called you, what are the riches of his glorious inheritance in the saints, </em>   
---

![[Image Closing Prayer Pink.png]]

---