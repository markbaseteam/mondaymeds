5. Having predestinated us unto the adoption of children by Jesus Christ to himself, according to the good pleasure of his will,
 6. To the praise of the glory of his grace, wherein he hath made us accepted in the beloved.


### Why did God chose us as heirs of Salvation?

><span style="background:rgba(240, 200, 0, 0.2)"> "The glory of the gospel is not that Jesus comes and rescues the princess. The glory of the gospel is that Jesus comes and marries and changes the evil hag." - R.C. Sproul</span>

God's election of the saints through predestination was:
1. according to the purpose of the pleasure of his will.
2. To the praise of the glory of his grace.

Everything God does is to demonstrate His power and the magnificence of His character, or His 'glory'. Everything God does is good and and right.  [[Gen-18#v25|Gen 18:25]], [[2 Tim-04#v18|2 Tim 4:18]] 

Why studying God and Christ is important:
We tend to become like that which we admire and enjoy,  the more we love and admire God,  the more we will desire to be like him and work out that which he is working within us 


### **According to the <u>purpose </u>| of the <u>pleasure of his will</u>.**

The word rendered "good pleasure"--(ευδοκια)--means a being well pleased; 

What is the purpose of God?: the pleasure of his will. 
What pleases the will of God?: praise for how glorious his grace is. Worship

> God made man to be like Him so that man could give more pleasure to God than all the other creatures. Only in man, as created by God, can God admire Himself. Man is the mirror image in which God looks to see Himself. Man is the reflection of the glory of God, which was the purpose and intention of God originally. Man’s supreme function through all eternity is to reflect God’s highest glory, and that God might look into the mirror called man and see His own glory shining there. Through man, God could reflect His glory to all creation. - A.W. Tozer, [[The Purpose of Man]]

> God made man to reflect His glory; but unfortunately, man does not. The flowers are still as beautiful as God meant them to be. The sun still shines yonder with spacious firmament on high. Evening shadows fall and the moon takes up the wonders and tells us whether the hand that made us is divine. Bees still gather their honey from flower to flower, and the birds sing a thousand songs and the seraphim still chant “holy, holy, holy” before the throne of God. Yet man alone sulks in his cave. Man, made more like God than any creature, has become less like God than any creature. - A.W. Tozer, [[The Purpose of Man]]

We saw last week when we were studying the doctrine of adoption, that God seeks to restore his image in man, and that he has predestined us to be conformed into the image of Christ and we can be confident one day we WILL be like him.

**According to the good pleasure of his will:**
	1. This phrase communicates the Sovereignty of God behind the action. God acts according to the good pleasure of <u>His</u> will.
	
> *"Thou art worthy to receive glory and honor: for thou hast created all things, and for Your good pleasure they are and were created." The good pleasure of His will. - Revelation 4:11*

#### A Look at Man's Will
Most of our own wills are acted upon at one time or another. Our wills are easily influenced by circumstances or others influence over us. We are not always free to act according to our own will especially in our various roles in life and as we submit to one another and to various ruling authorities.
- Law of the land
- Marriage
- Parents
- Friends
- Work we operate under and for the companies will.

There is one primary ruling authority that we are called to submit to that we don't acknowledge: God. God's Will, God's Law, God's Spirit.  

Our inability to submit to God's righteous will, we show that we are slaves to sin.  

<span style="background:rgba(240, 200, 0, 0.2)">Often times we don't know we are slaves to sin until we attempt to leave sin, only then do we feel the cords of sin on us and see our captivity to sins dominion over us</span>.

> *Let not sin therefore reign in your mortal body, to make you obey its passions. Do not present your members to sin as instruments for unrighteousness, but present yourselves to God as those who have been brought from death to life, and your members to God as instruments for righteousness. For sin will have no dominion over you, since you are not under law but under grace. - Romans 6:12-14***

**We naturally serve sin.**
Before the cross, sin has dominion over us just as the country we are born in has dominion over us. We serve the country just by being in the land. Not all of us are patriotic and intentionally think about serving this country everyday, (not saying we shouldn't). As we go about our normal business, we buy, sell, tend our land this country benefits from us being in it by our taxes, by our labor, by the product that we are making benefiting the people of the country in some manner, by our land being tended, by our supporting the economic system, buying groceries, etc...  

In a similar way, man is born in sin. Sin benefits from our presence in its domain since we serve its interests as we look out for our own interests instead of God's interests and others interest by glorifying it and enabling it to spread and increase in the world through influence and imitation even though we may not be intentional in our efforts and in our worldliness.   Sin often occurs when we pursue good things in the wrong way and for the wrong ends. 

**The Nature of Evil**
C.S. Lewis in Mere Christianity aptly labeled evil a parasite: 
> *If Dualism is true, then the bad Power must be a being who likes badness for its own sake. But in reality we have no experience of anyone liking badness just because it is bad. The nearest we can get to it is in cruelty. But in real life people are cruel for one of two reasons—either because they are sadists, that is, because they have a sexual perversion which makes cruelty a cause of sensual pleasure to them, or else for the sake of something they are going to get out of it—money, or power, or safety. But pleasure, money, power, and safety are all, as far as they go, good things. The badness consists in pursuing them by the wrong method, or in the wrong way, or too much. I do not mean, of course, that people who do this are not desperately wicked. I do mean that **_wickedness, when you examine it, turns out to be the pursuit of some good in the wrong way_**.*
> 
> *You can be good for the mere sake of goodness: you cannot be bad for the mere sake of badness. You can do a kind of action when you are not feeling kind and when it gives you no pleasure, simply because kindness is right; but no one ever did a cruel action simply because cruelty is wrong—only because cruelty was pleasant or useful to him. In other words badness cannot succeed even in being bad in the same way in which goodness is good. **_Goodness is, so to speak, itself: badness is only spoiled goodness_**. And there must be something good first before it can be spoiled. We called sadism a sexual perversion; but you must first have the idea of a normal sexuality before you can talk of its being perverted; and you can see which is the perversion, because you can explain the perverted from the normal, and cannot explain the normal from the perverted…*
> 
> […]
> 
> *And do you now begin to see why Christianity has always said that the devil is a fallen angel? That is not a mere story for the children. It is a real recognition of the fact that **_evil is a parasite_**, not the original thing. (**_emphasis mine_**) - C.S. Lewis, Mere Christianity.* 

Parasite is a good description for evil. A parasite is an organism that lives in or on another organism of another species, its hosts and benefits by deriving nutrients at the other's expense and causes the host harm.

Sin lives at our expense and it only spreads as we allow it. This is what we serve when we serve sin and allow sin to reign in our mortal bodies. Hopefully this will give us a new mental image of sin and make our skin crawl every time we are tempted to gossip, to pride and bolster our image up, to lie and pretend we are good when we have done something very wrong. 

We need to despise sin so that our affections no longer are willing to support it.   

Since our adoption and our deliverance our hearts go back and forth in their new affection for God and their old affection for sin. Our spirit and flesh begin to struggle. That is a good sign of the new birth and the new transformation within us, that struggle itself.  If there is no struggle, we are dead.

The good news is that Christ:

>   He has delivered us from the domain of darkness and transferred us to the kingdom of his beloved Son, - Colossians 1:13**

**Man's will for willing good**
Man's will was created to operate in conjunction with God's will through God's Spirit in us carrying out the will and work of God in creation.  Man was created to do good works and to glorify God through our good works and through our enjoyment of his grace. 

**Man's captured will - The fall**
When man fell, through disobeying God, man submitted to sin as the ruling authority whom he obeyed instead by obeying sins desires.  Our desires became slaves.

Our will which was once centered in God's own will and designed to operate within God's will, we took into our own hands as if we could wield it ourselves.  But we could and cannot ever wield our own will though God has given us a junior size will that is designed to operate from the center of his own, never outside of it or apart from him. 

 As a slave to sin and our will is not free to serve God until Jesus sets it free. Only after the cross do we have free will and even then, it becomes captive to the will of God, or we surrender our will to the will of God, as one lays down a crown of authority before him. As we become Christians we recognize, our will belongs in the center of God's will.  For us to take our will out of God's good will, we automatically place it in sin's way, and support the demonic will of evil. As God's creation, we are and will always be subsidiary beings, we are dependent and created to serve, the Creator.  
 

 Satan became dissatisfied with this position and sought to be like God. He caused other angels to become discontent and dissatisfied with their positions and 1/3 of the angels fell and followed him. [[Isa-14#v13|Isa 14:13-14]] Satan caused man to be dissatisfied with man's position in the garden, tempting Eve to be like God, by eating the apple and deciding right and wrong for themselves. [[Gen-03#v5|Gen 3:5]] In that moment, when their eyes were opened to the evils of this world, their spirits became blind to God. Before this, only God knew evil and would have protected them from such knowledge as we would protect our own children from such knowledge if they would heed our warnings. But seeking to be our own authority, to decide right and wrong for ourselves and to rise above our humble positions, man becomes a slave to the desires of sin working in him and is blind to God. 
 
We can and never truly possess our own will for any good cause ourselves for there is no good outside of God.
 
I remember seeing movies, where there is some sacred or powerful sword or stone that is deeply desired to be possessed and great riches and power are promised to those who can obtain it. So a team goes on a hunt to find it and they find the treasured object safely encased in the back of some deep dark obscure cave and once they take it they realize the implications of having such power and evil intentions begin to manifest and someone always in the end puts it back in its place and they leave it there in order to save humanity.  They realize their are certain powers humanity in our finiteness should not possess and they are best left out of our reach or we would destroy ourselves.

Our own will is a bit like that.  

> **Jeremiah 17:9-10** "The heart is deceitful above all things, and desperately sick; who can understand it? “

We desired sinful immorality more then righteousness. Our pleasures became centered in sin, full of greed, selfishness, lust, pride, cowardice, disobedience, rebellion. We no longer mirrored the image of God, were no longer capable of good works or of bringing glory to God.

 
> "Free will I have often heard of, but I have never seen it. I have always met with will, and plenty of it, but it has either been led captive by sin or held in the blessed bonds of grace."  - C.H. Spurgeon

Our will is our ability to make choices and decisions.  Which is good.  However, Our will is driven by our affections, our pleasures, our desires. We will and base our choices off that which we desire to occur, or what we don't desire to occur (fear) what we want, and what all men want is pleasure, happiness.  

Our desires are the driving force behind our will and actions. 

Blaise Pascal wrote in Pensées: 
![[Pascal's Pensées#^820161]]

The issue with our choices and decisions and seeking pleasure is that our heart is deceitful and what we would see and call as as "good" , really is not "good" at all. We are spiritually blind to God. 

Our will was designed to operate within God's will. When

#### God's Will
Now that we have looked at our will, lets look at God's will and how his will is different then our own.

**No external factors influence God's will.** 

Unlike men and angels, who are both created beings, God is absolutely sovereign and solitary. He is perfect and himself and does not change.  God's sovereignty, solitariness and immutableness are three critical attributes to truly knowing God.

Paul prays for us to know God in Ephesians 1:17:
![[Ephes-01#v17]]

**Sovereignty** - God is the supreme ruler and authority over all things. His sovereignty extends over creation, providence, and salvation, and nothing occurs outside of His control. God is completely independent and uninfluenced by anything outside of Himself. God acts according to His own sovereign will and purposes, without being coerced or influenced by any external forces. His decisions and actions are not determined by human will or circumstances but are guided by His perfect wisdom, righteousness, and love. [[Lam-03#v37|Lam 3:37]], [[Ephes-01#v11|Eph 1:11]], [[Ps-103#v19|Psa 103:19]], [[Job-42#v2|Job 42:2]]

**Solitariness:** God is self-existent, self-sufficient and independent, existing eternally in and of Himself.  He has no needs from us. His decisions are autonomous and self-determined. He is not bound by external pressures or influences  in his choices. His counsel will stand, He does as he pleases.  Thankfully what pleases him, is righteousness. [[Isa-45#v5|Isa 45:5]], [[Isa-43#v10|Isa 43:10]], [[Ps-50#v10|Psa 50:10-]][[Ps-50#v11|11]], [[Acts-17#v24|Acts 17:24-]][[Acts-17#v25|25]], [[Rom-11#v35|Rom 11:35]]

**Immutable:** God is unchanging in His being, perfections, purposes, and promises. His decisions are not influenced by changing circumstances or human actions. God's purposes are fixed and unalterable as a result his decrees are eternal. He states the end from the beginning. His word does not change. His mind does not change. His will does not change because there is no fault in him, his understanding and wisdom are perfect, he sees the beginning and end.  Man on the other hand, we live in a constant state of flux in our decision making, this can be difficult for us to understand. [[Heb-13#v8|Heb 13:8]], [[Num-23#v19|Num 23:19]]

A.W. Pink writes in Attributes of God regarding God's Solitariness:
> *God was under no constraint, no obligation, no necessity to create. That He chose to do so was purely a sovereign act on His part, caused by nothing outside Himself, determined by nothing but His own good pleasure; for He "worketh all things after the counsel of His own will" (Eph. 1:11). That He did create was simply for His manifestative glory. Do some of our readers imagine that we have gone beyond what Scripture warrants? Then we appeal to the Law and the testimony: "Stand up and bless the LORD, your God, for ever and ever; and blessed be thy glorious name, which is exalted above all blessing and praise" (Neh. 9:5). God is no gainer even from our worship. He was in no need of that external glory of His grace which arises from His redeemed, for He is glorious enough in Himself without that. What was it that moved Him to predestinate His elect to the praise of the glory of His grace? It was "according to the good pleasure of His will" (Eph. 1:5).*

  1. **No external influences on God's will**
			1. Man did not have control over God's choosing heirs for salvation.
			2. Man was not consulted over decision God's choosing heirs for salvation.
			3. Man's works had nothing to do with God's choosing heirs for salvation.
	**2. God's will is always in complete freedom to act**
			1.  It is never hindered
			2. He never does anything that displeases himself, because he is forced to do it or obligated to do it.
				2. God is never coerced or trapped.
					1. He did not spare his son. [[Rom-08#v32|Rom 8:32]]
					2. It pleased God to crucify Christ [[Isa-53#v10|Isa 53:10]]
					3. Jesus's life was not taken, he laid down his life willingly [[John-10#v18|John 10:18]]
					4.  Jesus always did what pleased God.  [[John-08#v29|John 8:29]]

> *God does what he does not begrudgingly or under external constraint as though he were boxed in or trapped by some unforeseen or unplanned situation. On the contrary, because he is complete and exuberantly happy and overflowing with satisfaction and the fellowship of the Trinity, all he does is free and uncoerced. His deeds are the overflow of his joy.* John Piper, The Pleasures of God

**God always does what pleases himself** [[Ps-115#v3|Ps 115:3]], [[Ps-135#v6|Ps 135:6]], *[[Isa-46#v10|Isa 46:10]]
	1. Q Does God seeks his own pleasure? A. He does not have to. It's not outside of himself. 
			1.  God is complete in himself. God is never incomplete or lacking anything outside of himself. God is pleased in himself already.
			2.  God's works are always perfect. He is never dissatisfied with his own actions or works. [[Gen-01#v31|Gen 1:31]] No mistakes. As a result, God always pleases himself.
			3. God is content. God is satisfied in himself. His works overflow from his delight, satisfaction.
			4. God's joy is always full. He never changes. God is joyful in himself. He is never displeased.
			
 **God works in us so that our wills might align with his to do what pleases him**. [[Phil-02#v13|Phil 2:13]]
			1. What pleases God is good and righteous [[Ps-11#v7|Ps 11:7]]
				1. What about the death of the wicked? [[Ezek-18#v23|Ezek 18:23]] [[Ezek-18#v32|Ezekial 18:32]] [[Deut-28#v63|Deut 28:63]]
					1. "He is not malicious or bloodthirsty. Instead, when a rebellious, wicked, unbelieving person is judged, what God delights in is the vindication of truth and goodness and of his own honor and glory.' - John Piper'

The purpose of our calling, our predestination to adoption was for pleasure of God's will **and.**..

**To what end?**

###  To the praise of the glory of his grace.

This is an infinitive phrase, what does it modify in the preceding verses?  Infinitive phrases function as a direct object of the verb intended.

![[Drawing EPH0104 Diagram.excalidraw]]

The object of God's will is to stir up thanksgiving & praise for the glory of God regarding his grace. It is to give to the universe a right conception of his grace, and draw forth corresponding tributes of praise. To God be the Glory!

> God desires to draw attention, not only to this attribute, but to the boundlessness of it thus to draw the love and confidence of his creatures to himself and inspire them with the desire to imitate him. - C.H. Spurgeon

> There is no room for human boasting. Our salvation is according to the good pleasure of God’s will, to the praise of the glory of His own grace, and no man may give himself any credit whatsoever. It is to the praise of the glory of God’s grace that He has accepted us in the Beloved. I hope we are all clear about grace. We are constantly preaching about it, singing about it, and reading about it, and yet how few there are who really understand the precious fact that our salvation is altogether of grace. No matter how many times one may preach on salvation by grace, every time he rises to face an audience there are many who are still strangers to the grace of God. Let us never forget that grace is God’s free unmerited favor lavished on those who deserve nothing but His judgment. You cannot earn grace, you cannot earn His lovingkindness. - Ironside

The Saints are made use of for glorifying God by three primary means:
	1. They themselves are subjects of grace [[Ephes-01#v12|Eph 1:12]] [[1 Pet-02#v9|1 Peter 2:9]]
	2. The saints are specimens of grace [[1 Tim-01#v16|1 Tim 1:16]], [[Ephes-03#v10|Eph 3:10]]
	3.  The Saints are channels or instruments for grace that flows to mankind. [[Ps-87#v7|Ps 87:7]], [[Ephes-02#v10|Eph 2:10]]

**Eph 1:12** - So that we who were the first to hope in Christ might be to the praise of his glory.

**1 Peter 2:9**  But you are a chosen race, a royal priesthood, a holy nation, a people for his own possession, that you may proclaim the excellencies of him who called you out of darkness into his marvelous light.
> 
> *We become fruitful by grace; we persevere by grace; we mature by grace; by grace we grow to love one another the more, and by grace we cherish holiness and a deepening knowledge of God. Therefore Paul reminds his readers at teh end of his prayer in Ephesians that everything he has asked for is available only on the basis of grace. The Savior himself cannot be glorified in our lives, nor can we be finally glorified, apart from the grace that he provides. - D.A. Carson, Praying with Paul.*

**1 Tim 1:16** - But I received mercy for this reason, that in me, as the foremost, Jesus Christ might display his perfect patience as an example to those who were to believe in him for eternal life.

**Eph 3:10** - so that through the church the manifold wisdom of God might now be made known to the rulers and authorities in the heavenly places.

**Psa 87:7** - Singers and dancers alike say,  “All my springs are in you.”

**Eph 2:10** - For we are his workmanship, created in Christ Jesus for good works, which God prepared beforehand, that we should walk in them.

What is God's glory?
God's glory is the very expression of God Himself, God manifested. Jesus, the word of God manifested God to us. God, who is hidden, was revealed to us by Christ by Christ displaying his glory.

> *He is the radiance of the glory of God and the exact imprint of his nature, and he upholds the universe by the word of his power. After making purification for sins, he sat down at the right hand of the Majesty on high, - Hebrews 1:3*

We who were created to glorify God ourselves, to express his glory to creation, did not recognize his glory when He walked among us.  How far we had fallen! How blind we had become! But when Christ opens our eyes, when we behold true glory, we desire to be like Him, to display the glory of God as we were created to do.

We already saw that God does not need our glory. He does not need more glory. But he is most worthy of all glory, of all our worship and of all our praise. 

God does what he does so that his glorious grace would be praised by his people. That is why God is so good toward us. 

>  *God made man to be like Him so that man could give more pleasure to God than all the other creatures. Only in man, as created by God, can God admire Himself. Man is the mirror image in which God looks to see Himself. Man is the reflection of the glory of God, which was the purpose and intention of God originally. Man’s supreme function through all eternity is to reflect God’s highest glory, and that God might look into the mirror called man and see His own glory shining there. Through man, God could reflect His glory to all creation.* - A.W. Tozer, [[The Purpose of Man]]

God magnifies himself.

When creation magnifies itself, it's misleading, because there is something greater that it points to, the Creator Himself. It's like a piece of art work magnifying itself and disregarding the Artist. 

When God magnifies himself, there is nothing greater. He is worthy. When he magnifies himself, He magnifies his attributes, his goodness, his righteousness, his great love, his munificence which are his glory.

> So that in the coming ages he might show the immeasurable riches of his grace in kindness toward us in Christ Jesus. - Eph 2:7

**Munificent**:  The quality or action of being lavishly generous; great generosity. God is abundantly generous. [[1 John-03#v1|1 John 3:1]], [[2 Cor-09#v8|2 Cor.9:8]], [[Ephes-01#v3|Eph 1:3]], [[Ephes-01#v7|Eph 1:7]]

### wherein he hath made us accepted in the beloved.

**God graced us**, God blessed us, God freely bestowed, God made us accepted - Once again we see God acting.

**In the Beloved** - In Christ. We are accepted in Christ. We are blessed in Christ.  Our being accepted in Christ is our blessing, He is our favor. God has brought us into fellowship with Himself in Christ.

Just as our will belongs in the will of God. We ourselves belong in Christ. In the body of Christ, as members of Christ.

accepted (charito), “highly favored” or “full of grace” 

![[Pasted image 20230625235248.png]]![[Pasted image 20230625235449.png]]