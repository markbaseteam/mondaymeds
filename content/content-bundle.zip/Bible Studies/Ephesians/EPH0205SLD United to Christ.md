<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->
---
OPENING PRAYER
==
---
Ephesians 2:4-10
<font size="6">  
<p align= "Justify">
4 But God, being rich in mercy, because of the great love with which he loved us,<font color="#366092"> 5 even when we were dead in our trespasses, made us alive together with Christ—by grace you have been saved— 6 and raised us up with him and seated us with him in the heavenly places in Christ Jesus, 7 so that in the coming ages he might show the immeasurable riches of his grace in kindness toward us in Christ Jesus. </font>8 For by grace you have been saved through faith. And this is not your own doing; it is the gift of God, 9 not a result of works, so that no one may boast. 10 For we are his workmanship, created in Christ Jesus for good works, which God prepared beforehand, that we should walk in them.

---
Review Last Week
<font size="6">  
<p align= "left">
Ephesians 2:4 But God, being rich in mercy because of his great love with which He loved us,
---
<strong>Even when</strong> we were <strong>dead</strong> in our trespasses<!-- element style="background: floralwhite" -->
<font size="5">  
<p align= "left">
God's great love extended to us "Even when"...we were dead in our trespasses. <br>
<p align= "left">
<strong>1 John 4:19 </strong>- We love because he first loved us. <br>
<p align= "left">
This refers back to Ephesians 2:1-3, the condition in which God found us, when he poured out his mercy and love upon us. To be dead is to be unaware of anything, it is to be unresponsive. We were spiritually dead, unaware and unresponsive to God himself. <br>
<p align= "left">
We were, however, very much alive to sin, in the ways we once walked, as we followed the course of this world, we followed the prince of the power of the air, we followed the desires of the body and mind, we were unable to follow Christ, and as such, we were children of wrath, like the rest of mankind. <br>
<p align= "left">
There was nothing attractive about us, that drew God's mercy to us. We were repugnant, disobedient sinners and God chose of Himself according to his own will to save us and make us alive with Christ. He chose to unite us with Christ, as his beloved  bride for his one and only Son.  Most unions a Father would seek the most fitting bride, the most worthy bride, and here we are, the most unworthy bride for his son who he makes worthy. It is our union with Christ that makes us worthy. His agape love towards us.

---
Dead in our Trespasses
<font size="5">  
<p align= "left">
<strong>Steven Cole, Bible.org </strong>- There are many evangelicals today who view salvation as a joint project between God and men. God has done all that He can do, and the rest is up to the free will of the sinner. They don’t view him as dead, but rather as sick or wounded. Like a drowning man, there still is life in him. He can grab the rope if we throw it to him. But, if he refuses to cooperate, even God can’t save him. That is an unbiblical view of salvation! The biblical view is summed up in the short sentence, “Jesus saves!”  As the angel announced to Joseph concerning Jesus, “He will save His people from their sins.” He didn’t say, “He will do all that He can, but He is limited by the sinner’s stubborn will.” He didn’t say, “He will throw the rope to everyone, but they’ve got to grab on to be saved.” God isn’t frustrated in heaven, wishing that He could do more: “I’d like to save Saul of Tarsus, but the guy is so stubborn!” No, the hope of the gospel is that God saves sinners. We were dead—but God! **He made us alive**!....We need to understand that salvation is not a matter of a spiritually sick sinner deciding to take the medicine. If it were, we could perhaps talk him into making that decision. It is not a matter of a drowning man grabbing the life ring. Who wouldn’t grab it, if he knew his desperate condition? Rather, the sinner is a corpse, floating face down in the water. He’s dead. God must raise him from the dead. But the good news is, God can raise the dead! He can impart new life to dead sinners. If He can’t, then why pray for the conversion of anyone? Is God in heaven saying, “Yes, I wish I could save him, but he just won’t take the life ring”? No, God made us alive even when we were dead in our sins.
---
[But God] ...made us <strong>alive together </strong>with Christ
<!-- element style="background: floralwhite" -->
<font size="6">  
<p align= "left">

Suzoopoieo

![[Pasted image 20230921221144.png|600]]
<br>
<iframe width="260" height="115" src="https://www.youtube.com/embed/HgHYBNfJF7Q?si=3c6PpwMH64t5kS7V" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

---
suzōopoieō" 
<font size="6">  
<p align= "left">
The term "suzōopoieō" (συζωοποιέω) is a Greek word that appears in the New Testament and combines the preposition "syn" (σύν), meaning "with," and "zōopoieō" (ζωοποιέω), which means "to make alive" or "to give life to." When these two parts come together, "suzōopoieō" essentially means "to make alive together with." In the New Testament, it is used to signify the<u> joint </u>enlivening or quickening of a believer with Christ, particularly in reference to being raised from spiritual death to spiritual life.

---
Sun/Syn "with" vs Meta "with"
<font size="5">  
<p align= "left">
Each of the verbs "made alive with", "raised with", "seated with" has the identical prepositional prefix "sun/syn" which means "with" in Greek but is significantly different than the other Greek word for "with (meta)"" which conveys the "of beside", whereas sun speaks of an <em>intimate, indissoluble union.</em> 
<p align= "left">
At the crucifixion event, two criminals were punished with Jesus and both were crucified with (metá) Him, i.e., in His company, but only one was spiritually crucified with (sún/syn) Christ, i.e., bound up or in union with Him while the other thief was not. The first thief entered paradise, while the second entered hell.
<p align= "left">And*so we get a glimpse of the significance of Paul's three combination verbs used to explain our salvation. Paul is driving home not only these basic truths of our salvation but also emphasizing with the use of <strong>sun-</strong> that this salvation is irrevocable. You cannot lose your salvation. The believer who has been made alive with Christ, raised with Christ and seated with Christ is eternally secure in Christ! We are eternally identified with Him. While unconfessed sin can disrupt our communion with Him, it cannot break the infinitely omnipotent bonds of our union with Him. We are one with Christ in time and eternity and nothing, absolutely nothing can negate or reverse that glorious truth beloved! [PeceptAustin(https://www.preceptaustin.org/ephesians_26-7)
---
![[Pasted image 20230921221245.png|700]]
---
<font size="5">  
<p align= "left">
<strong>To be made alive together with Christ</strong> is a critical doctrine of our Christian faith that speaks of "regeneration" or "spiritual rebirth." Our previous position was that we were dead in sins and trespasses, Ephesians 2:1-3
<p align= "left">
<strong>John 3:3 </strong>3 Jesus answered him (Nicodemus), “Truly, truly, I say to you, unless one is born again, he cannot see the kingdom of God.”
<p align= "left">
When we are made alive in Christ, profound changes are made in a believers life, transformational changes, just as profound as in a physical birth we see profound steady progressive changes over the period of days, weeks, months and the years that make us more and more into the image of our natural parents.
<p align= "left">
When we are spiritual reborn, quickened with Christ, there <strong>will</strong> be profound changes that take place over the period of days, weeks, months and years that slowly transform us more and more into the image of Christ now that we have been made alive together with him and <u>now possess a new nature, new identity, new empowerment within</u>.
---
Illustration: Chemical Reaction vs Spiritual Reaction.
<font size="5">  
<p align= "left">
A chemical that permanently alters a substance and cannot be separated once added is typically referred to as a reactant in a chemical reaction. When a reactant is added to a substance, it undergoes a chemical change, resulting in the formation of new compounds with different properties. This change is often irreversible.
<p align= "left">
For example, if you mix hydrochloric acid (HCl) with sodium hydroxide (NaOH), they react to form water (H2O) and common table salt (NaCl). Once this reaction occurs, it is not possible to separate the original substances back into their individual components.
<p align= "left">
Not all chemical reactions are irreversible. Some reactions can be reversed under specific conditions, but others lead to permanent changes in the substances involved.
---
Chemical Reaction vs Spiritual Reaction
<font size="5">  
<p align= "left">
A natural metaphor that provides a little bit of insight and illustration.

- **Transformation**: In both cases, there is a transformation. In a chemical reaction, substances are transformed into something new. Similarly, in a spiritual reaction with Christ, a person undergoes a profound transformation, becoming a new creation in Christ (2 Corinthians 5:17).
- **Irreversibility**: Just as some chemical reactions are irreversible, a genuine spiritual transformation is considered permanent. Once a person is quickened with Christ, they are regarded as being eternally united with Him.
- **New Identity**: In a chemical reaction, the resulting compounds have distinct properties from the original substances. Likewise, in a spiritual reaction with Christ, a believer takes on a new identity, characterized by righteousness and a renewed purpose (Ephesians 4:24).
- **Purpose and Function**: Compounds formed in a chemical reaction often serve specific functions. Similarly, believers, after being quickened with Christ, are called to serve a specific purpose in accordance with God's plan (Ephesians 2:10).
- **Continual Growth**: In both scenarios, there is potential for further development. In chemistry, compounds can undergo further reactions. Spiritually, believers are encouraged to grow in their faith and understanding of God's Word.
---
<font size="6">  
<p align= "left">
The term "suzōopoieō" emphasizes the believer's  inseparable <strong>union with Christ, </strong>asserting not merely that God made us alive but that He made us alive jointly, together with Christ. This reflects the intimate relationship and union that Christians share with Christ.
<p align= "left">
Was as believers are in binding, indissoluble covenant with Christ. We are so are eternally in union with Him and identified with Him. When He died, we died. When He was buried, we were buried. When he was raised up, we were raised up. When He was seated at the right hand of His Father, we were seated at the right hand of our Father in heaven. These great truths of the believer's identification with Christ are more thoroughly expounded by Paul in Romans 6, using the figure of baptism.

---
Romans 6:3-11 United with Christ
<font size="5">  
<p align= "left">
3 Do you not know that all of us who have been baptized into Christ Jesus were baptized into his death? 4 We were buried therefore with him by baptism into death, in order that, just as Christ was raised from the dead by the glory of the Father, we too might walk in newness of life.
<p align= "left">
5 For if we have been united with him in a death like his, we shall certainly be united with him in a resurrection like his. 6 We know that our old self was crucified with him in order that the body of sin might be brought to nothing, so that we would no longer be enslaved to sin. 7 For one who has died has been set free from sin. 8 Now if we have died with Christ, we believe that we will also live with him. 9 We know that Christ, being raised from the dead, will never die again; death no longer has dominion over him. 10 For the death he died he died to sin, once for all, but the life he lives he lives to God. 11 So you also must consider yourselves dead to sin and alive to God in Christ Jesus.
---
<font size="5">  
<p align= "left">
To grow in our understanding and realization of our union with Christ is a prayer that we should pray. Jesus prayed for it:
<p align= "left">
<strong>John 17:20-23 - 20 </strong> - <em>“I do not ask for these only, but also for those who will believe in me through their word, 21 that they may all be one, just as you, Father, are in me, and I in you, that they also may be in us, so that the world may believe that you have sent me. 22 The glory that you have given me I have given to them, that they may be one even as we are one, 23 I in them and you in me, that they may become perfectly one, so that the world may know that you sent me and loved them even as you loved me.</em>
---
<font size="5">  
<p align= "left">
Paul prayed that we would know this resurrection power in Christ, it is the same power that makes us alive in Christ and raises us with him. When we are united and identified with Christ, we do know this power. If we are not united and identified with Christ we do not know this power :
<p align= "left">
<strong>Ephesians 1:19-23 </strong> - <em> and what is the immeasurable greatness of his power toward us who believe, according to the working of his great might  that he worked in Christ when he raised him from the dead and seated him at his right hand in the heavenly places, far above all rule and authority and power and dominion, and above every name that is named, not only in this age but also in the one to come.  And he put all things under his feet and gave him as head over all things to the church, which is his body, the fullness of him who fills all in all.</em>
<p align= "left">
---
 by grace you have been saved. 
<font size="5">  
<p align= "left"> 
This phrase is repeated in verse 8-9 where we will dive into deeper, but it bears a reminder now, we are saved by grace, unmerited favor from God.  The mercy and love that God has shown us in verse 5, not getting what we deserved, comes to us through grace, being given what we do not deserve instead. We were dead in sins and trespasses and being dead in sin we had no ability for any "good works"
---
6 and raised us up with him and seated us with him in the heavenly places in Christ Jesus, 
<font size="5">  
<p align= "left">
![[Pasted image 20230924202919.png]]
---
Raised us up with him
<font size="5">  
<p align= "left">
"Raised us up" is from the Greek "synegeiró" (συνεγείρω), signifying being awakened or raised together with someone.
<font size="5">  
<p align= "left">
![[Pasted image 20230924203218.png|700]]
<iframe width="260" height="115" src="https://www.youtube.com/embed/rX0Coz_u9cg?si=7mXshG3PzLWVvZbb" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
---
 "suzōopoieō" vs "synegeiró
<font size="5">  
<p align= "left">
<Strong>"being made alive with Christ" </strong> focuses on the initial regeneration and spiritual rebirth that occurs when we place our faith in Him. It's about moving from spiritual death to spiritual life. <br>
<p align= "left">
 <strong>"being raised with Christ" </strong>emphasizes our ongoing identification with Christ's resurrection, highlighting our new position in Him and the transformative power of His resurrection in our daily lives.
<p align= "left">
Both concepts are crucial to understanding the comprehensive work of salvation. They represent different aspects of our journey of faith, from the moment of conversion to the ongoing process of sanctification and growth in Christ.
---
So What?
<font size="4">  
<p align= "left">

| Raised with Christ                                  | Significance of Doctrine                                                                                                                                               |
| ---------------------- | --------------------------------------------- |
| Identification with Christ's Death and Resurrection | When we believe in Christ, we are united with Him in His death and resurrection. This means that His victory over sin and death becomes our victory as well. We die to our old sinful selves and are raised to new life in Him (Romans 6:4).                                     |
| Freedom from Sin's Power                            | Position change, once slaves of sin now slaves of righteousness. This identification with Christ's resurrection signifies our liberation from the power of sin. Just as Christ conquered sin and death, we too can live a life freed from the enslavement of sin (Romans 6:6-7). |
| Newness of Life                                     | This concept emphasizes the transformative nature of our faith. We are not merely forgiven and left in our old ways, but we are given a new life in Christ. We are empowered by the Holy Spirit to live in righteousness and holiness. New Creation.  (Ephesians 4:24).          |
| Hope of Eternal Life                                | The resurrection of Christ assures us of our own resurrection and eternal life with Him. It gives us hope beyond this earthly existence and reminds us that our ultimate destination is with the Lord (1 Corinthians 15:20-23).                                                  |
| Empowerment for Christian Living                    | Knowing that we are raised with Christ encourages us to live in a manner worthy of this calling. We are called to set our minds on things above and to seek the things that are above, not on earthly things (Colossians 3:1-2).                                                 |
| Assurance of Future Glory                           | The fact that we are raised with Christ assures us of our future glorification. We are promised to share in His glory and be transformed into His likeness (Romans 8:30, 1 John 3:2).                                                                                            |
| Participation in Christ's Glory                                                    |       Along with being raised, believers are said to be seated with Christ in heavenly places (Ephesians 2:6). This speaks to the idea that believers share in Christ's exalted position and future glory.                                                                                                                                           |

---
Raised with Christ Parallel Verses
<font size="5">  
<p align= "left">
<strong>Col 2:12</strong> -<em>having been buried with him in baptism, in which you were also raised with him through faith in the powerful working of God, who raised him from the dead.</em>
<br><p align= "left">
<strong>Col. 3:1 </strong>- <em>
If then you have been raised with Christ, seek the things that are above, where Christ is, seated at the right hand of God.</em>
<br><p align= "left">
<strong>Rom 6:4 </strong> - <em>We were buried therefore with him by baptism into death, in order that, just as Christ was raised from the dead by the glory of the Father, we too might walk in newness of life.</em>
---
and seated us with him in the heavenly places in Christ Jesus, 
<font size="5">  
<p align= "left">
This signifies our position of authority and intimacy with Christ. Being "seated" (συνεκάθισεν - synekathisen) implies a position of rest, indicating our position of security and privilege in Christ.
<p align= "left">
<strong>Hebrews 10:12-13 - </strong><em> But when this priest had offered for all time one sacrifice for sins, he sat down at the right hand of God,  and since that time he waits for his enemies to be made his footstool.  For by one sacrifice he has made perfect forever those who are being made holy.</em>
<p align= "left">
We are not with Christ, but we are in Christ, so where Christ is, there we are.  God's word is so sure that we can see ourselves in the future already seated with Christ.

---
<font size="4">  
<p align= "left">
John Piper's thoughts on what <strong>seated with Him in heavenly places</strong> means...
<p align= "left">
Now what does that mean? We are all right here in this room, aren't we. Or are we? What did Tony Bennet mean twenty years ago when he sang, "I left my heart in San Francisco"? Well, he meant that San Francisco still holds his affections. San Francisco is always pulling him back. San Francisco governs his tastes. He may look like he is in Chicago. But Chicago has no claim on his affections. It's a foreign land. He is not interested in being like the natives of the windy city. That is the way it is with us when we are converted. God takes our heart and puts it in heaven with Christ. Colossians 3:3 says, "For you have died, and your life is hid with Christ in God." So just like it is with Tony Bennet and San Francisco, so it is with us and heaven. It's heaven that holds our affections. It's heaven that's always pulling us upwards, its heaven that governs our tastes. We may look like we are in the world. But the world has no claim on our affections. It's a foreign land. We are exiles and aliens.
<p align= "left">
In a word, when we are converted God frees us from the spirit of the age and the god of the age. It's as though we had been kidnapped and brainwashed and made to think we were really citizens of the enemy territory. And then the king's intelligence finds you and shocks you out of your stupor, and you suddenly realize that what the enemy has to offer would never satisfy the deepest longings of your heart. Your heart is in the homeland. But the king says stay for now, and, though it may be dangerous, live like an alien in love with the homeland, and when you come home bring as many with you as you can. Don't you really want to be FREE from the spirit of the age. Why would anybody want to be jelly fish carried around by currents in the sea of secularism? You can be a dolphin, and swim against the currents and against the tide. Jelly fish aren't free. Dolphins are free. (Full sermon [Ephesians 2:4 But God…])
---
So What?
<font size="5">  
<p align= "left">

| Seated with Christ                   | Significant Implications            |
|--------------------------------------|--------------------------------|
| Union with Christ                     | It emphasizes our intimate spiritual connection with Christ. As Christ is seated in the heavenlies, so we are seated in the heavenlies, in Christ.                                                |
| Position of Authority                 | In the ancient world, being seated was a posture of authority and rest. So, being seated with Christ signifies that we share in His authority. This isn't about earthly power, but a spiritual authority over the forces of darkness. |
| Heavenly Perspective                  | It reminds us to view our lives from an eternal perspective. We're not merely bound by the temporal realities of this world, but we have a heavenly citizenship and are partakers in the kingdom of God.    Read: 1 John 5:4-5          |
| Rest and Assurance                   | It is finished. Just as sitting denotes rest, it assures us of the finished work of Christ. We rest in the completed work of redemption, knowing that our salvation is secure.                                                        |
| Victory over Spiritual Forces         | We know the end of our story. This imagery implies that, in Christ, we have authority over spiritual forces and powers of darkness. It encourages us as believers to stand firm against spiritual opposition.                                             |

---
<font size="5">  
<p align= "left">
<strong>A. B. Simpson</strong>
<p align= "left">
Ascension is more than resurrection. Much is said of it in the New Testament. Christ rises above all things. We see Him in the very act of ascending, as we do not in the actual resurrection. With hands and lips engaged in blessing, He gently parts from His disciples. So simply, so unostentatiously, He has brought heaven near to our common life. We, too, must ascend, even here. If ye then be risen with Christ, seek those things which are above Colossians 3:1. We must learn to live on the heavenly side and look at things from above. To contemplate all things as God sees them, as Christ beholds them, overcomes sin, defies Satan, dissolves perplexities, lifts us above trials, separates us from the world and conquers fear of death. Such a perspective enables us to view them as we shall one day look back upon them from His glory, and as if we were now really seated with Him, as indeed we are, in heavenly places Ephesians 2:6.6). Let us arise with His resurrection and, in fellowship with His glorious ascension, learn to live above.
---
<font size="6">  
 so that in the coming ages he might show the immeasurable riches of his grace in kindness toward us in Christ Jesus.
<font size="5">  
<p align= "left">

| Phrase                               | Notes                          |
| ---------------------- | ---------------------- |
| so that                              | the reason, God has made us alive with Christ, raised us up with Christ, seated us with Christ in the heavenly places and showed us great mercy and love |
| in the ages to come                  | Future eras, future periods of time beyond the current age. It implies an eternal perspective, suggesting that God's work of revealing His grace will continue throughout all of time, even beyond what we can currently conceive. Recognizing the significance of "ages to come" inspires a sense of hope and anticipation for what God has in store for us in the future. It also emphasizes the eternal nature of God's promises and the enduring impact of His grace throughout all of time.  We have no fear of God's grace towards us coming to an end.  "When we have been there a thousand years..."   |
| he might show                        | He (God), so God might show, to manifest, display, put forth, When we display something, it is to the public, to make something visible and apparent. Display what?                                                                      |


---
<font size="6">  
 so that in the coming ages he might show <strong>==the immeasurable riches of his grace </strong>== in kindness toward us in Christ Jesus.
<font size="5">  
<p align= "left">
<strong>Eph 1:12</strong> -  so that we who were the first to hope in Christ might be to the praise of his glory.
<p align= "left">
To what end have we been predestined? To the praise of his glory. The immeasurable riches of God's grace towards us, is to the praise of his Glory. This is what God wishes to display to to all mankind below, all principalities and powers, all rulers and authorities, the immeasurable riches of his grace. We are living spectacles. 
<p align= "left"><center><strong><font color="#0070c0">The chief end of man is to glorify God by enjoying him forever.</font></strong></center>
<font size="5"> 
<p align= "justify">
<strong>might be to the praise of his glory - </strong>
This is the end purpose of God's plan of predestination and our great inheritance -  <strong>the praise of the glory of God </strong>.
<p align= "left">So that His grace and goodness, as displayed in election, redemption, adoption, justification, regeneration and eternal salvation might be revealed to all mankind below, all principalities and powers, all rulers and authorities, and made known to the saints who are called to declare his excellencies.  So that we, the Saints, would give praise and honor to Him because of all these things, by attributing all to his grace, and nothing to ourselves; by expressing gratitude for all his blessings; by living our lives in accordance with the Gospel; and by doing everything with the intention of bringing glory to Him.<br>
---
<font size="5">  
<p align= "left">
<strong>==Immeasurable ==- </strong><em>Surpassing</em> ([5235] <strong> huperballo </strong>from <em>hupér</em> = above + <em>bállo</em> = cast, put) literally means to throw beyond the usual mark and was used in this way in secular Greek in a description of a spear throwing contest. All the NT uses are by Paul, and all are figurative uses expressing a degree which exceeds extraordinary. It means to attain a degree that extraordinarily exceeds a point on a scale of extent. To be surpassing, extraordinary, outstanding, exceeding, highly eminent.

Huperballo - 5x in 5v - Usage: surpasses(2), surpassing(3).
<p align= "left">
<strong>2 Corinthians 3:10 </strong>-  For indeed what had glory, in this case has no glory because of the glory that surpasses it.
<p align= "left">
<strong>2 Corinthians 9:14 </strong> while they also, by prayer on your behalf, yearn for you because of the surpassing grace of God in you.
<p align= "left">
<strong>Ephesians 1:19]  </strong> and what is the <strong>surpassing</strong> greatness of His power toward us who believe. These are in accordance with the working of the strength of His might
<p align= "left">
<strong>Ephesians 3:19</strong>and to know the love of Christ which **surpasses** knowledge, that you may be filled up to all the fullness of God.
---
Riches
<font size="5">  
<p align= "left">
In a word, God's <strong>riches</strong> are immeasurable, extraordinary, outstanding! We need to recall this great truth to our minds (and turn it into a praise in prayer) when we are tempted to think otherwise and be pulled down into the miry clay of this present world ruled by the Evil One. The Fortune 500 list of the World's Wealthiest, pales in comparison to the inestimable, inexhaustible wealth of our very own dear Heavenly Father!
<p align= "left">
<strong>Riches</strong> 4149 <strong>ploutos</strong> from pletho = fill) defines a plentiful supply, a wealth, an abundance, plentitude.
---
 WE ARE MONUMENTS OF GOD'S WEALTH 
<font size="5">  
<p align= "left">
That He could love us when we were dead like Lazarus, in trespasses and sins; that He has linked us in the bonds of indissoluble union with his Son; that He had made it possible for us to share his Resurrection, his Triumph, and his Throne; that we, the poor children of earth and sin, should be admitted into the inner circle of Deity--this will be, to all eternity, the mightiest proof of the exceeding riches of his grace.
<p align= "left">
 The word "exceeding" might be rendered "beyond throwing distance." Fling your thoughts forward as far as you can, and there will always be an immense beyond; throw them as high as you may, till they out soar the stars, and there will always be an above; let them sink for ever, and there will always be a beneath--in the exceeding riches of God's grace.
 <p align= "left">
 "The heavens declare the glory of God, and the firmament showeth his handiwork"; but the glory of the position and character of the saints, contrasted with the degradation from which they were raised, will be accounted in coming ages a more extraordinary exemplification of the riches of Divine grace than the splendour of the heavens is of the wealth of his skill. ([The Father's Wealth](http://articles.ochristian.com/article11764.shtml)) F.B. Meyer
---
<font size="6">  
 so that in the coming ages he might show the immeasurable riches of his grace  <strong>==in kindness toward us in Christ Jesus.==</strong>
<font size="5">  

<p align= "left">
  <strong>kindness </strong>Titus 3:4 - "<em>But when the goodness and loving kindness of God our Savior appeared" </em> This kindness is God's goodness towards us, his benevolence towards us. 
  <p align= "left">
  Another key word is <strong>toward us</strong>, we the saints are objects of God's affection, the whole world lies under the wrath of God, but not the saints, we lie under his kindness, his mercy and love.. Reread: 1 Peter 2:9, we are called to proclaim his excellencies.    
---
God's Kindness Towards Us
<font size="4">  
<p align= "left">
<strong>John Piper - </strong>Paul piles up words to to make a deep and lasting impression on our hearts. God's settled purpose is to be gracious to those who are in Christ Jesus. And lest we miss the sweetness and gentleness and gladness of the word "grace" he adds the words, "in kindness toward us." Now ask yourself this question: If there were one person in all the universe the benefits of whose kindness you could choose, who would it be? Would it not be God? You might be able to think of a thousand things that would be kindness to you. But then your imagination would run out. But God's imagination will never run out.
<p align= "left">
And to make this clear Paul uses the word "riches." God's purpose is to spend the "riches of his grace in kindness on us." And then to assist our faltering imagination he adds the word "immeasurable" or "surpassing" or "incomparable." How rich is God? I read in the paper recently that Queen Elizabeth is worth about four billion dollars. Now if you got a letter in the mail from Queen Elizabeth which said that she had taken an oath by the blood of her son to spend her riches to show you as much kindness as she could for the rest of your life, wouldn't you get excited. And her wealth compares to God's like a grain of sand to the Sahara Desert.
<p align= "left">
But that's not all. She could only show you kindness for a few years -- ten, thirty, sixty maybe. But look what Paul says God intends to do for you? "That in the coming ages he might show the immeasurable riches of his grace in kindness to us in Christ Jesus." How long is and age? And how many ages are coming? Well, the answer is simple: all of them that lie in the future are coming. So it doesn't matter how long one of them is.
<p align= "left">
Do you know why Paul had to say it this way? Because that's how long it will take God to run out of fresh ideas about how to show you kindness. When eternity ends, God will have run out of ways to show you kindness. Now tell me, when does eternity end? (See full sermon [Ephesians 2:4](https://www.desiringgod.org/messages/but-god) But God… ) John Piper
---
END READING<br>
Ephesians 2:4-10
<font size="6">  
<p align= "Justify">
4 But God, being rich in mercy, because of the great love with which he loved us, <font color="#366092">5 even when we were dead in our trespasses, made us alive together with Christ—by grace you have been saved— 6 and raised us up with him and seated us with him in the heavenly places in Christ Jesus, </font>7 so that in the coming ages he might show the immeasurable riches of his grace in kindness toward us in Christ Jesus. 8 For by grace you have been saved through faith. And this is not your own doing; it is the gift of God, 9 not a result of works, so that no one may boast. 10 For we are his workmanship, created in Christ Jesus for good works, which God prepared beforehand, that we should walk in them.
---
CLOSING PRAYER 
==
---