#Ephesians [[Ephes-01]] [[Ephes-01#v3|Eph 1:3]]

*"I am so blessed."*

What do we mean when we say we are so blessed?

Many times we are referring to physical positions or states of being.  Our family, Our spouse, our kids, our parents, our health, our abilities, our homes, our church, our jobs,  our vehicles, our lifestyle. We have food, we have electricity, shelter, clothes, security...our needs are met abundantly. We can't count all our blessings.

What if we did not have any of these physical blessings, would we still consider ourselves blessed? Did Job?

Consider those who are persecuted for confessing Christ in countries such as China and Iraq, would they consider themselves blessed?

I think they would, even more so then we would, for they gave up all for the sake of Christ, for the value of possessing Christ.  They gave up reputation, possessions, family, security, safety, freedom, possessions and some their own life for Christ and would still consider themselves as "blessed".

I read a story this week that in Saudi Arabi, a man while traveling on his annual annual Islamic pilgrimage to Mecca, says Jesus appeared to him in a dream. So he traveled abroad afterward and secretly read the new testament and was converted to Christianity. He could not take the bible back to Saudi Arabi for his of his life and he could not tell anyone.  

> “It is unnatural – maybe even wrong – to keep one’s love for Jesus entirely to oneself. I cannot tell my wife. Or my children. Or my parents. I found Christ in a dream, and only He knows I follow him. But I have to, or I’m dead.” – 
> “It’s too risky. If the authorities find a Christian Bible on my person, they will interrogate me, and I will not lie, so my new faith would be exposed. I do not know how long I can go without fellowship, without witness, living a lie.” - [Open Door Youth](https://opendoorsyouth.org/article/five-quotes-from-persecuted-christians/)

![[Pasted image 20230521214355.png]]


It's easy to reach such a story and automatically feel, "*I'm blessed.*" However, we it would be a worldly and a fleshly type of outward blessing. This young man lives in a very difficult situation, but he no doubt considers himself blessed for having found Jesus Christ despite his danger.  He would seek the further blessings of simple fellowship to share his joy, to share the good news, but he must proceed cautiously in his new blessed life. And it is a blessed life for a blessed life is one that has God's favor bestowed upon it.

There is a blessed state that the world does not and cannot comprehend. For the way the world defines "blessed" and the way a Christian defines 'blessed' are worlds apart. Once again it comes down to our values. Valuing Christ above all and valuing this world less.

In this next section of Ephesians that we are entering into, we are going to see some of the great blessings that belong to the "Saint" alone.  They are largely unseen by the world for they are "in Christ" and kept "in the heavenly realms" 

Verse 3-14 make up one very large sentence in the Greek language. They make up 12 verses in the English.

John McArthur says this next section is foundational to absolutely everything you ever think about in your life and to our worship.

Let's take a quick overview look at some of these blessings listed that we will be studying.

- Eph  1:4 Father God has _chosen us to holiness
- Eph 1:5  Father God has ordained us to sonship
- Eph 1:6  Father God has bestowed grace on us in the Beloved.
- Eph 1:7 In Christ, we have redemption, the forgiveness of our sins,  according to the riches of His grace
- Eph 1:8-10 In Christ we have knowledge of the mystery of His will
- Eph 1:11 In Christ we have obtained an inheritance
- Eph 1:13 In Christ we were sealed with the Holy Spirit

These are our magnificent blessings and God the Father is the source of all of them. We are going to see over and over again that God does not just meet our needs, but he meets our needs according to his infinite riches and glory.

**James 1:17**
![[James-01#v17]]

## Blessed be God the Father of Our Lord Jesus Christ
### Paul Stirs Up Worship
Is it any wonder that Paul starts off this epistle blessing and bursting with praise for  God the Father?   Paul starts off with praise and a call to worship, a doxology, an expression of praise even before he tells the Gentile readers what God is to be praised for. It's almost as if he is so overwhelmed with what he is about to share that he gets ahead of himself. 

Some have said that this passage is not meant to be read, but to sing the words instead because something extraordinary is being spoken here and shining into our lives.  God blesses us and we respond in blessing Him in return.

**Text**: [[Ephes-01#v3|Ephesians 1:3]] 
![[Ephes-01#v3]]
     
	   (Father of our Lord Jesus Christ)
God  ^ be blessed
             who has blessed us
                                    with *every* spiritual blessing
                                                     in the heavenly places
                                                     in Christ

However, almost all St. Paul’s Epistles begin with some call to praise. Titus is the only exception.  This is proper as blessing a meal before one eats.

Paul seeks to stir up his readers hearts to worship and praise God before he begins. It is almost as if Paul is saying:

[[Ps-95#v6|Psa 95:6]]
> *Oh come, let us worship and bow down; let us kneel before the Lord, our Maker!*

[[Ps-95#v2|Psa 95:2]]
> *Let us come into his presence with thanksgiving; let us make a joyful noise to him with songs of praise!*

Don't you wish you could return some portion of the blessing that God gives us back to God? How do we bless God who so richly blesses us?

Do you remember being a child and wanting to give your parent a present? So you wrap something that is theirs already and give it to them as a gift? That is the best we can do for God since he owns all. 

[[Ps-50#v10|Psa. 50:10-15]]
> *10 For every beast of the forest is mine,  
>     the cattle on a thousand hills.  
> 11 I know all the birds of the hills,  
>     and all that moves in the field is mine.
> 
> 12 “If I were hungry, I would not tell you,  
>     for the world and its fullness are mine.  
> 13 Do I eat the flesh of bulls  
>     or drink the blood of goats?  
> 14 Offer to God a sacrifice of thanksgiving,  
>     and perform your vows to the Most High,  
> 15 and call upon me in the day of trouble;  
>     I will deliver you, and you shall glorify me.”*

God does not have any needs that we can fill. What he does want is our obedience, which is better then sacrifice and thanksgiving, acknowledgement of his goodness, of his grace.  God wants to display and for us to proclaim his excellencies to the world. 

**1 Peter 2:9**
![[1 Pet-02#v9]]
Eph 2:7
![[Ephes-02#v7]]
We are objects of God's mercy instead of objects of God's wrath.

### God the Father of Our Lord Jesus Christ
Paul is very specific in how he identifies God. "God the Father of Our Lord Jesus Christ" In the Old Testament God was often identified as "the God of Abraham, the God of Isaac, the God of Jacob." or "the God of our fathers"

Exodus 3:6
![[Exod-03#v6]]

Deuteronomy 26:7
![[Deut-26#v7]]

Paul specifically refers to God as the Father of Jesus Christ. This is critical. People refer to "God" all the time and it is a different "God" then what is found in the bible. People can refer to "God" and say they believe in "God" but not believe in Jesus Christ.  This would be a different God, because the God in the bible declares that if one denies the Son then he does not have the Father.

**1 John 2:23**
![[1 John-02#v23]]

**2 John 1:9**
![[2 John-01#v9]]

John 3:35
![[John-03#v35]]


### Who has blessed us with every spiritual blessing

Come ye blessed of my Father.” Matt 25:34

**Matthew 25:34**
![[Matt-25#v34]]

#### Who
God the Father of our Lord Jesus Christ  is the source of our blessing.

#### has blessed
God ===**has blessed**===us.  Notice the tense of the verb.  Present perfect tense.   Present Perfect is used to talk about a continuing situation.  A state or event that started in the past and continues in the present and will probably continue in the future. God has blessed us in Christ, that started in the past, at the cross, and also before the cross, before the foundation of the world.  These blessings continue to present and they *will* continue to the future. 

#### us
= the saints [[EPH0102 Saints]] But before we were saints by the grace of God, let us never forget that that we were first sinners.  We have done nothing to deserve these blessings, but by our default sinful nature we have done everything to deserve his wrath. We do not deserve the least of God's mercies. We who were dead in our sins and trespasses, without hope, without God, having no love for him or his ways, he loved us first and blessed us despite our constant defiance and rebellion against him.

#### with every spiritual blessing
- God was not stingy when he poured out his blessings upon us.  He was exceedingly generous.  

Material blessings and gifts are distributed unevenly. Some have better health, bigger houses, financial resources, more vacations, more intelligence, etc...

But these spiritual blessings are distributed in full, no partials, nothing was withheld or left out. Savor this word "every", God has blessed us with *every* spiritual blessing that can be had. Every spiritual blessing according to his riches, not our poverty.

They are not  temporal blessings that decay, rust and age. These blessings are eternal, they started in the past, before the foundation of the world,  they continue in the present and will continue in the future.  God's blessings never stop flowing. They are continuous. 

"Spiritual Blessings" is going to be the key phrase of the next 3 chapters that are steep in theology and unpacking these spiritual blessings that we have been given Verses 3-14 lists them, Paul goes into more detail about them in chapters 1-3, allowing us to dig into them further.

- God has chosen us - He will never unchoose us
- God has adopted us - permanently
- God has redeemed & forgiven us - He will never be separated from us again.
-  God has lavished us with grace - We will always only know his favour
- God has united us with Christ - We will never be separated from Christ
- 
These blessings are distributed evenly to every saint.  No one is more loved then you. No one has a closer family tie or union. You are adopted and have full sonship, full union with Christ. No one has less forgiveness. 

[[2 Pet-01#v3|2 Peter 1:3]]  Divine Power has given to us all things that pertain to life and godliness
[[Ps-23#v1|Psalms 23]].  if the Lord is your shepherd, then you shall not want.
[[2 Cor-09#v8|2 Cor 9:8]] God is able to make *all* grace *abound* to you, *always* having *all* sufficiency you may *abound* in *every* good work.

#### In the heavenly places, realms
Our spiritual blessings are in the heavenly realms, where Christ is seated because as they are "in Christ"

**Col. 2:2-3**
![[Col-02#v3]]

**Eph 1:20**
![[Ephes-01#v20]]

**Eph 2:6**
![[Ephes-02#v6]]
Physically we are in the body, but in the Spirit, we are in heaven, [[Heb-06#v4|Heb 6:4]]
We should be longing for home. Home for us is where Christ is, for in him is our dwelling place. Our spirits are consistently dwelling in heaven through our mediations and constant prayers.

**Phil 3:20**
 ![[Phil-03#v20|Phil 3:20]]
In him is our treasures [[Matt-06#v20|Matt 6:20,]]  [[Matt-06#v21|21,]] and affections [[Col-03#v1|Col 3:1]] and our hope is laid up [[Col-01#v5|Col 1:5]]. our inheritance is reserved for us, [[1 Pet-01#v4|1 Pet 1:4]] 


#### in Christ 
We are "in Christ" like the Saints were "in Ephesus" . In Christ is our location.  There are no blessings outside of Christ.  Christ is our head, he is the treasurer over God's storehouse of blessings who causes God's blessings flow down to his members. 

Christ is no damn, all the blessings he receives he pours out to his members.  As the vine receives its life from abiding in the branch, we receive our life and blessings as we abide in Christ. As we remain in him, in his will, in his way.

Christ does not become wealthy himself as so many 'heads' or people in positions of authority and power do through their membership. Not at all.  Christ does no let his members languish in need; instead he gives all he has, even his own life,  that we might have life. He is not out seeking his own survival, but ours! He is life.

2 Cor. 8:9
![[2 Cor-08#v9]]

"Here are the blessings and Christ is the golden case  that holds them all. When the City of London makes a man a freeman of the city, the document giving  him his liberty is usually presented to him enclosed in a golden case. Christ is that golden case in which  we find the charter of our eternal liberty. He has blessed us with all spiritual blessings in Christ. If they  came to us any other way, we might lose them—or we might not be sure that they were genuine. But  when they come to us in Christ, they come to stay, and we know that they are real. If Christ is mine, all  blessings in heavenly places are mine " - Charles Spurgeon


### Summary

If this is true , and it is true, how do we respond?

Remember: *Man's chief end is to glorify God and enjoy him forever.*

Meditating on how God has blessed us with every spiritual blessing, should strengthen our faith in God's deep love for us. It should increase our joy. It should increase our hope that this world cannot destroy. It should increase our peace. Our contentment but most of all it should increase our love and worship for God the Father himself and Jesus Christ the Son, the source and supplier. It should increase our thanksgiving and praise. When we count our blessings, may we begin to include and list first, the fact that God chose us before the foundation of the world, that he adopted us, that he redeemed and forgave us, that he has promised us an inheritance, sealed us with the spirit. May we not forget these revealed eternal blessings that are ours.

The next time we say "I am blessed " May we truly say it with much weight, gravity and holy fear at the gianormity of our blessed state by God.  I am sooo blessed! May we never say it lightly or superficially.
