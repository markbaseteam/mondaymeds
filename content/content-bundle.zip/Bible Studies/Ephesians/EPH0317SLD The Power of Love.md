

<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->
---
OPENING PRAYER
==
---
Annoucements
<font size="6">  
- No Bible Study Monday, December 25th, Christmas Day
- No Bible Study Monday, January 1st, New Year's Day
- Officially 1/2 through Ephesians after tonight.
---
Ephesians 3:14-21
<font size="6">  
<p align= "Justify">
14 For this reason I bow my knees before the Father, 15 from whom every family  in heaven and on earth is named, 16 that according to the riches of his glory he may grant you to be strengthened with power through his Spirit in your inner being,  <font color="#c0504d">17 so that Christ may dwell in your hearts through faith—that you, being rooted and grounded in love, 18 may have strength to comprehend with all the saints what is the breadth and length and height and depth, 19 and to know the love of Christ that surpasses knowledge, that you may be filled with all the fullness of God.
<p align= "Justify">
20 Now to him who is able to do far more abundantly than all that we ask or think, according to the power at work within us, 21 to him be glory in the church and in Christ Jesus throughout all generations, forever and ever. Amen.</font>

---
Review Last Week
<font size="6">  
<p align= "left">
Last week we started dissecting Paul's prayer that begins in verse 14 and continues to 21 ending with a doxology. This week, we will meditate on the great love of God .

---
<font size="6">  
<strong><font color="#4f81bd">17. so that</font> Christ may dwell in your hearts through faith </strong> 
<font size="5">  
<p align= "left">
<em>"So that"</em> is a conjunction used to introduce a clause expressing purpose or intention. This conjunction is often used to express a cause-and-effect relationship, where the effect or intended outcome is stated after the <em>"so that." </em>
<p align= "left">
Some bible translations just use the single word <em>"that" </em>but this is still a conjunction phrase we are studying so we must look at both parts together, since the end <em>"Christ dwelling in our hearts through faith" </em>is the purpose, the effect of Paul's preceding prayer for us to be <em> "strengthened with power through His Spirit in our inner being." </em>
<p align= "left">
An observation to consider is that Christ cannot dwell in our hearts by faith if we are not strengthened with power through His Spirit in our inner being. 
<p align= "left">
We are going to see that this power from the Holy Spirit that strengthens us is love.  Christ dwells in our hearts when love dwells in our hearts. If love does not dwell in our hearts, we should question if Christ dwells in our hearts. (1 Jn 3:14, 1 Jn 4:15) Love itself is very powerful and necessary for our ability to overcome sins and temptations.
---
<font size="6">  
so that <strong><font color="#4f81bd">Christ may dwell in your hearts through faith </strong> </font>
<font size="6">  
<p align= "left">
If you are a Christian, then Christ does dwell in your heart by faith. This is a fundamental key concept taught throughout scripture.
<p align= "left">
<Strong>Dwell  - 
G2730 κατοικέω katoikeo (kat-oi-ke'-ō) </strong>v.
to house permanently, i.e. reside.
<p align= "left">
Every translation I came across, uses the word "dwell"
<p align= "left">
<strong>Spurgeon</strong> - <em> That He may dwell</em>"does not means that He may call upon you sometimes, as a casual visitor enters into a house and tarries for a night, but that He may <em>“dwell,”</em> that Jesus may become the Lord and Tenant of your heart." (C H Spurgeon, Daily Help)
<p align= "left">
<strong>In your hearts</strong> - In the innermost sanctuary Christ is to be given the place of pre-eminence, enshrined and enthroned as Lord over all. Not in our minds, or intellect but in our hearts, the very seat of our desires, our love and passions that drive us.
---
<font size = "5">
<p align= "left">
<strong>MacDonald </strong> - explains that "Actually, the Lord Jesus takes up His personal residence in a believer at the time of conversion (John 14:23; Rev. 3:20). But that is not the subject of this prayer. Here it is not a question of His being in the believer, but rather of His feeling at home there! He is a permanent Resident in every saved person, but this is a request that He might have full access to every room and closet; that He might not be grieved by sinful words, thoughts, motives, and deeds; that He might enjoy unbroken fellowship with the believer. The Christian heart thus becomes the home of Christ, the place where He loves to be—like the home of Mary, Martha, and Lazarus in Bethany. The heart, of course, means the center of the spiritual life; it controls every aspect of behavior. In effect, the apostle prays that the lordship of Christ might extend to the books we read, the work we do, the food we eat, the money we spend, the words we speak—in short, the minutest details of our lives....We enter into the enjoyment of His indwelling through faith. This involves constant dependence on Him, constant surrender to Him, and constant recognition of His “at home-ness.” It is through faith that we “practice His presence,” as Brother Lawrence quaintly put it.
--
<font size = "5">
<p align= "left">
<strong>Wayne Barber writes:
<p align= "left"><em>
"If you are not being strengthened in the inner man with power by the Spirit of God, it is very obvious that you are not making Christ at home in your hearts. Why? Because Christ is His Spirit that lives there. If you are living a lifestyle that is not pleasing to Him, if you are grieving Him, then no wonder you're discouraged, defeated and generally a "mess" spiritually speaking. No wonder your life is falling apart. There is a very basic truth in Scripture and when you come to grips with it, it becomes very understandable what victory is all about.
<p align= "left">
Victory is not me doing for Him. It is me being strengthened.
<p align= "left">
That enables the Spirit of Christ to be welcomed in my heart...
<p align= "left">
You have already received Jesus into your life. You say, "I want to walk in the fullness of what He has to offer. Where do I start?" It starts when you realize how weak you are and how desperate we all are to tap into His strength. You see, weakness is an absolutely necessity if you are going to be strengthened in the inner man by the Spirit of God. God will bring people and circumstances into your life that will cause you to get down on your face and say, "Oh, God, I can’t." He says, "That’s right. I never said you could. I can. I always said I would. Now tap into Me. Appropriate what is already yours."</em>
---
<font size = "5">
<p align= "left">
What a great truth for us to meditate on a week before Christmas!  Christmas is all about "Emmanuel" or Immanuel". <strong>God with us. </strong>
<p align= "left">
Just in case you are wondering about the difference of these two spellings...I was and had to look it up to see which one I should use. Here is what I found. They are both correct and it is just denominational preference.
<p align= "left">

1. **Immanuel**: This is a more direct transliteration from Hebrew. In Hebrew, the name is composed of two parts: "עִם" (im), meaning "with," and "אֵל" (el), meaning "God." So, "Immanuel" means "God is with us." This transliteration tries to stay close to the original Hebrew pronunciation.
    
2. **Emmanuel**: This version is influenced by the Greek spelling and pronunciation found in the New Testament, specifically in the Gospel of Matthew, where the prophecy from Isaiah is quoted in reference to the birth of Jesus. In Greek, the name is written as "Ἐμμανουήλ" (Emmanuel), which is a transliteration of the Hebrew into Greek. The English spelling "Emmanuel" is derived from this Greek transliteration.
---
<font size="6">  
<p align= "left">
In Isaiah 7:14, the prophet Isaiah delivers a prophecy where he speaks of a virgin giving birth to a child named Immanuel, which is interpreted as a sign from God. This prophecy is connected to the birth of Jesus Christ, as seen in the Gospel of Matthew 1:23 in the New Testament, where Matthew interprets the birth of Jesus as the fulfillment of this prophecy. Therefore, "Emmanuel" is often associated with Jesus, symbolizing the belief in Jesus as God incarnate, who dwelt among people. 
<p align= "left">
What a marvelous truth that we should never loose our sense of wonder over! Christ being born into this fallen and dark world, being born as a babe, among men, among us, being born in a manger.
---
![[Pasted image 20231217183257.png]]
---
<font size="5">  
<p align= "left">

| Verse Ref.      | God Seeking a Dwelling Place Among Men                                                                                                          |
|------------------------|------------------------------------------------------------------------------------------------------------------------------------|
| Exodus 25:8            | "And let them make me a sanctuary, that I may dwell in their midst."                                                               |
| Leviticus 26:11-12     | "I will make my dwelling among you, and my soul shall not abhor you. And I will walk among you and will be your God, and you shall be my people." |
| 1 Kings 8:27           | "But will God indeed dwell on the earth? Behold, heaven and the highest heaven cannot contain you; how much less this house that I have built!"    |
| John 1:14              | "And the Word became flesh and dwelt among us, and we have seen his glory, glory as of the only Son from the Father, full of grace and truth."      |
| Matthew 1:23           | "Behold, the virgin shall conceive and bear a son, and they shall call his name Immanuel" (which means, God with us).                                   |
| 2 Corinthians 6:16     | "For we are the temple of the living God; as God said, 'I will make my dwelling among them and walk among them, and I will be their God, and they shall be my people.'" |
| Revelation 21:3        | "And I heard a loud voice from the throne saying, 'Behold, the dwelling place of God is with man. He will dwell with them, and they will be his people, and God himself will be with them as their God.'" |

---
Why would God seek to dwell among us, with us?
<font size="6">  
<p align= "left">
---
Because He loves us.
---

<font size="6">  
<p align= "left">
God's love for man is as incomprehensible as He Himself is.  There is no earthly reason or explanation or cause for God to set his love upon us. There is every reason or cause for Him not to love us. At our best, we are selfish, foolish, prideful, arrogant, ungrateful, rebellious, malicious, wicked, adulterous, lawless, sinners, idolators, gluttons, drunkards, murderers..this list is not complete or exhaustive.
<p align= "left">
And yet...
<p align= "left">
<strong>Romans 5:8</strong><em> but God shows his love for us in that while we were still sinners, Christ died for us. </em>
<p align= "left">
The world is a grand stage for the manifold wisdom of God to be put on display and his great love demonstrated before the principalities and powers in the heavenly places... through the church.
--
![[Pasted image 20231217190837.png]]
--
![[Pasted image 20231217190902.png]]
--
![[Pasted image 20231217191256.png]]
--
<font size="6">  
so that <strong><font color="#4f81bd">Christ may dwell in your hearts through faith </strong> </font>
<font size="5">  
<p align= "left">
Let's go back to our text now that we have the backdrop of the great love of God for us in the background of this text.  Paul's prayer is all about our knowing the love of God and one of the fundamental ways we know the love of God is by Christ dwelling in our hearts. When Christ dwells in us, God's love dwells in us.  


<p align= "left">
<strong>Ephesians 2:22 NET  </strong>- in whom you also are being built together into a dwelling place of God in the Spirit.
<p align= "left">
<Strong>Charles Hodge -</strong> <em> The omnipresent and infinite God is said to dwell wherever he specially  and permanently manifests his presence. Thus he is said to dwell in heaven, Ps. 123:1; to dwell among the children of Israel, Numb. 35:34; in Zion, Ps. 9:11; with him that is of an humble and contrite spirit, Is. 57:11; and in his people, 2 Cor. 6:16. Sometimes it is God who is said to dwell in the hearts of his people, sometimes the Spirit of God, sometimes, as in Rom. 8:9, it is the Spirit of Christ; and
sometimes, as Rom. 8:10, and in the passage before us, it is Christ himself. These varying modes of expression find their solution in the doctrine of the Trinity. In virtue of the unity of the divine substance, he that had seen the Son, hath seen the Father also; he that hath the Son hath the Father; where the Spirit of God is, there God is; and where the Spirit of Christ is, there Christ is. ...When, therefore, the
apostle speaks of Christ dwelling in our hearts, he refers to the indwelling of the Holy Ghost, for Christ dwells in his people by his Spirit. ...This is the true and abiding source of
spiritual strength and of all other manifestations of the divine life. </em>

---
<font size="6">  
<strong><font color="#4f81bd">—that you, being rooted and grounded in love,</font></strong>
<font size="5">  
<p align= "left">
Rooted” and “established” are both terms relating to growth; the first refers to the growth of a plant and the second to the growth of a building. The greek word for "grounded" is "themelioo" which means" to lay a basis for" or literally "to erect".
<p align= "left">
Before Paul’s eyes may be the traditional image of Israel as a tree, and the glorious temple of living stones made of believers from all nations and races. 
<p align= "left">
"These Christians are to be <em>rooted and grounded</em> or to have 'deep roots and firm foundations' (NEB). Thus Paul likens them first to a well-rooted tree, and then to a well-built house. In both cases the unseen cause of their stability will be the same: love. Love is to be the foundation on which their life is built. One might say that their love is to be of both a 'radical' and a 'fundamental' nature in their experience, for these English words refer to our roots and our foundations." "- John Stott
<p align= "left">
<strong>Agape Love</strong>  This is the love in which we are to be rooted and grounded! It is that love which is unconditional, sacrificial, and giving, even to one's enemy.   
The ultimate example of this extraordinary kind of love is shown through the Father's love for sinners, as demonstrated by the Son's sacrifice on the Cross.
---
<font size="5">  
<p align= "left">
To be deeply embedded in love is akin to a flourishing tree that develops strong roots, allowing it to endure harsh weather and droughts. Just as a tree is a growing entity, the Christian life is a living relationship with God and others. The nourishment for this growth comes from God’s love, leading to an increase in our love for Him and for others. Love is the foremost attribute produced by the Holy Spirit (Galatians 5:22), and when one lives in the Spirit’s power, love naturally becomes a prominent feature in our life. On the other hand, a lack of visible love growth for God and others suggests a lack of spiritual growth. This could mean one is either a new believer not fully established in faith or, in a more concerning scenario, might not truly be a believer.
<p align= "left">
Being established in love resembles constructing a building on a solid foundation that reaches the bedrock. Such a structure can endure floods or earthquakes because it's built on a firm base. This illustrates a love for God and others that remains constant, regardless of changing emotions or situations, providing a stable support for everything else in life.
<p align= "left">
Love should be the driving force behind all our thoughts and actions. Is this loving? Is this for the others benefit?
---
<font size="5">  
<p align= "left">
<strong>Trials and Temptations show the strength of our Love</strong><br>
  Just as the true strength of a tree's roots is revealed in the midst of a fierce storm, and the reliability of a building's foundation is proven during an earthquake or flood, similarly, the genuine depth of your love is tested and made evident during times of significant trials and challenges.
  <p align= "left">
   Our love for others is being tested and our love for God.
   <p align= "left"> 
<strong>Without love, we will succumb to temptation in trial</strong><br>
Many believe they can overcome temptation through sheer determination and willpower alone. However, they don't realize the importance of praying for God to transform their hearts, to open their eyes to desire and love God more then the desire that is drawing them. The greater desire always wins.   Without this change, resisting temptation is nearly impossible. People naturally act in accordance with what they love. 
  <p align= "left"> 
  <strong>Prov. 4:23 </strong> - <em>"'Keep your heart with all doligence, for out of it are the outflowings of lie."</em> 
    <p align= "left"> 
Until our love for God's ways surpasses our love for worldly things, what we love most will always have the victory over our actions. 
  <p align= "left"> 
This is why it is so critical for us to be <em>strengthened with power through His Spirit in our inner man.</em>  Christ to dwell in our hearts permanently by faith, to unseat all other loves from the throne. Our passions are the power in our life's; and when our passions are corrupt we are slave to their corruptness until a great love comes along...
---

<font size="6">  
<p align= "left">
<strong>Brian Chapell</strong> - Worse than any of these sins, we also must face the humbling truth of failure in the context of the premise that Paul is about to put forward—namely, that sufficient love of God is the power to overcome sin. If this is true, then the presence of such sins in our life reveals that we do not love God enough. In fact, we have loved our sin more than we love him, or it
would not have a home in our hearts. This is not a truth that we want to face, or are accustomed to facing on these terms. On those occasions that we do face our sin, we most often say to ourselves, “I was weak,” or “I messed
up,” or “I failed my Savior.” But even in these expressions of guilt there is still the assumption that we love Jesus; we just messed up. Yet, if our sin is an expression of our true love, our words have the false and empty ring of a
wayward spouse who says to a husband or wife, “That other person didn’t mean anything; I still love you.” Yes, there is still love present, but in those moments of betrayal the love for another passion if not another person was
greater than the love for the one to whom the spouse is committed. When we sin, love for sin competes with and supersedes love for Christ. -
---
<font size="6">  
<p align= "left">
<strong>Brian Chapell</strong> - Confidence in the love of a heavenly Father for humbled creatures encourages our return, stimulates our repentance, and increases the love for the Father that is the power that the gospel offers. Humbled by our need
and driven to our knees, we can yet approach our God with confidence because of the sweetness and greatness of his mercy. Paul’s prayerful reiteration of these truths places him in a position to proclaim the power of the gospel. 
---
<strong><font size="6">  
<font color="#4f81bd">18 may have strength to comprehend with all the saints what is the breadth and length and height and depth, </font></strong>
<font size="6">  
<p align= "left">

<p align= "left">
In the Greek language, the terms for spatial dimensions (width, length, height, and depth) are used as nouns, not adjectives, and are connected by a single article. The Greek scripture doesn't specify what these dimensions are describing. This raises the question: Are they referring to the dimensions of God's power, His plan for salvation, His wisdom, or His love? While scholars have different views on this, including other potential interpretations, the New International Version (NIV) of the Bible accurately points to the most apparent meaning as being the "love of Christ" for us.
---
<font size="5"> 
<p align= "left">
<strong>may have strength</strong> ESV, ASV<br>
<strong>may be able to </strong> KJV, HSCB, LSB <br>
<p align= "left">
Greek: <strong>exischuo G1840 </strong>means "to be strong enough," "to prevail," or "to have power." In the New Testament, it's used to convey the idea of having sufficient strength or power, often in a spiritual or moral sense.
<p align= "left">
The use of this word in the New Testament is rare, but when it appears, it typically emphasizes the capability or sufficiency in a given situation, often relating to spiritual strength or the ability to overcome challenges or trials.
<p align= "left">
It is is one of the strongest Greek words for strength and signifies one completely capable of doing or experiencing something.
<p align= "left">
<strong>comprehend</strong> - katalambano - to take eagerly, seize, possess, etc.   (Apprehend, attain, comprehend, perceive). "Katalambano" means to grasp something in such a way as to make it your own.  It is possible to understand something but not to "own" it, not to "possess" it.  Paul does not want us to have just a mere intellectual knowledge of God's love, but he wants us to "own" it. To "know" it in our hearts in a way our minds can't comprehend, because the love of God is beyond intellectual comprehension. The breadth, length, the height, the depth can only be "revealed" to the heart.

---
 <font size="6">  
<p align= "left">
Paul expresses in Ephesians 3:18-19 the desire for us to grasp the vast dimensions of Christ's love – its breadth, length, height, and depth, a love that exceeds all understanding. This presents an intentional contradiction: we can attain a certain understanding of His immense love, which is more than mere conjecture. Yet, in a different aspect, this knowledge remains ever elusive, as His love is immeasurable. Eternally, we will continue to discover more about Christ's profound love for us, never reaching a point where we can claim to fully comprehend its entirety.
<p align= "left">
<strong>Breadth - </strong> Is a measurement of width or extent from side to side and is used figuratively to refer to great expanses. Rev. 7:9 says that the depth of Christ's love includes a very large group of people from every country, tribe, , and tongue. It also expands to cover every child of God in every age. 
---
<font size="6">  
<p align= "left">
<strong>Length</strong> - Time Dimension - Christ's love is everlasting and eternal in nature and enduring. According to Ephesians 1:4-5, "He chose us in Him before the foundation of the world, that we would be holy and blameless before Him," as we have already seen. Through Jesus Christ, He lovingly predestined us to be adopted as His sons in accordance with the good intention of His will. It is an eternal love that won't let us leave!
<p align= "left">
<strong>Height</strong>  - We are elevated to our exalted position of being seated with Him in the heavenly regions by the height of His love (Eph. 2:6). His ultimate goal for us is to be pure and holy, raised high above the temptations that so readily tempt us to sin here on Earth.
---
<font size="6">  
<p align= "left">
<strong>Depth</strong> - Because of the depth of His love, He left the glory and His position to come and be born as a baby on this earth. It drove Him to endure the intense agony of the crucifixion, where He—who was without sin—became our sin (2 Cor. 5:21). Despite the fact that we were disobedient and God's adversaries, Christ's love freed us from the slave trade of sin and made us co-heirs with Him. <br>
<br>
"Amazing love, how can it be that Thou, my God, shouldst die for me?" wrote Charles Wesley.
<p align= "left">
---
<font size="6">  
<p align= "left">
<strong>Brian Chapell </strong>- <em>"Paul says God’s love for his people is as long as eternity past, so wide as to
include all nations, so high as to ring praises from angels in heaven, and so deep as to cancel the claims of hell on our soul. Knowledge of such magnitude grants more than comfort, more than assurance, and even more than joy. Knowledge of this magnitude is power! Here in these verses of Ephesians, Paul tells us how to access the spiritual power of divine love as he completes the prayer that he began in the first verse of this chapter." </em>
---

<font size="6">  
<p align= "left">
<strong>Stott </strong> on breadth, length, height, and depth - Yet it seems to me legitimate to say that the love of Christ is ‘broad’ enough to encompass all mankind (especially Jews and Gentiles, the theme of these chapters), ‘long’ enough to last for eternity, ‘deep’ enough to reach the most degraded sinner, and ‘high’ enough to exalt him to heaven. Or, as Leslie Mitton expresses it, finding a parallel to Romans 8:37–39: ‘Whether you go forward or backward, up to the heights or down to the depths, nothing will separate us from the love of Christ.’ Ancient commentators went further. They saw these dimensions illustrated on the cross. For its upright pole reached down into the earth and pointed up to heaven, while its crossbar carried the arms of Jesus, stretched out as if to invite and welcome the whole world. Armitage Robinson calls this a ‘pretty fancy’.2 Perhaps he is right and it is fanciful, yet what it affirms about the love of Christ is true
---
<font size="6">  
<p align= "left">
<strong>Stott</strong> - has an interesting comment on <u>all the saints</u> - We shall have power to comprehend these dimensions of Christ’s love, Paul adds, only with all the saints. The isolated Christian can indeed know something of the love of Jesus. But his grasp of it is bound to be limited by his limited experience. It needs the whole people of God to understand the whole love of God, all the saints together, Jews and Gentiles, men and women, young and old, black and white, with all their varied backgrounds and experiences. Yet even then, although we may ‘comprehend’ its dimensions to some extent with our minds, we cannot ‘know’ it in our experience. It is too broad, long, deep and high even for all the saints together to grasp. It surpasses knowledge. Paul has already used this ‘surpassing’ word of God’s power and grace;  now he uses it of his love. Christ’s love is as unknowable as his riches are unsearchable .. Doubtless we shall spend eternity exploring his inexhaustible riches of grace and love.
--
<font size="6">  
<p align= "left">
<strong>A T Pierson</strong> once wrote that Paul "treats the love of God as a cube, having breadth and length, depth and height. The reason is that the cube in the Bible is treated as a perfection of form. Every side of a cube is a perfect square, and from every angle it presents the same appearance. Turn it over, and it is still a cube—just as high, deep, and broad as it was before." Someone has also noted the Holy of Holies was cube-shaped, so is the New Jerusalem, and so is the love of God!
---
<font size="6">  
<p align= "left">
<strong>D. A. Carson </strong> points out that the remarkable thing about this prayer is that Paul “assumes that his readers, Christians though they are, do not adequately appreciate the <strong> love of Christ</strong>. <u>It’s not a prayer that we might love Christ more, although we should. Rather, Paul is praying that we might better grasp Christ’s immense love for us. </u> While there is an intellectual side to this, it is not merely intellectual.  Paul is praying that we who already know Christ’s great love might come to experience it at ever-deepening levels.
---
<font size="6">  
<strong><font color="#4f81bd">19 and to know the love of Christ that surpasses knowledge, that you may be filled with all the fullness of God.</font></strong>
<font size="5">  
<p align= "left">
<strong>"and to know"</strong> - The greek <strong>ginosko </strong>means to concrete manner, to absolutely know, to know without exception. It indicates an experiential knowledge, not just an intellectual understanding. In the biblical context, "knowing" often involves a deep, personal, and relational aspect. It's about experiencing and internalizing the truth and not merely from a personal perspective or experience.
<p align= "left">    
<strong>"the love of Christ"</strong> This refers to the sacrificial, unconditional love that Jesus Christ has for humanity. <strong>"agape love" </strong> It is a central theme of Christian theology, emphasizing that Christ's love is the driving force behind His incarnation, life, crucifixion, and resurrection.
<p align= "left">    
<strong>"that surpasses knowledge"</strong>: The love of Christ is described as surpassing, mere human understanding or intellectual grasp.  KJV uses "passeth knowledge". This suggests that Christ's love is so profound and deep that it goes beyond what can be fully comprehended or explained by human reasoning.

---
<font size="5">  
<p align= "left">
Blaise Pascal, a French Christian philosopher wrote in his book "Pensées," the following quote:
<p align= "left">
<em>"The heart has its reasons of which reason knows nothing."</em>
<p align= "left">
There are aspects of human experience and understanding, particularly in matters of faith and emotion, that are beyond the reach of rational explanation and are known intuitively or emotionally by the heart. It emphasizes the idea that not all knowledge or understanding is derived from logical reasoning; some are perceived through the heart's unique insights.
<p align= "left">
Pascal is not suggesting that the heart is the ultimate guide in all matters, but rather that it has its own way of understanding things which reason cannot always comprehend. Ephesians 3:18 speaks of comprehending the vastness of Christ's love, which goes beyond mere intellectual understanding.  The "heart" in this context is about our inner being, our spiritual understanding that embraces both intellect and emotion in grasping God's love. God designed us with emotions, but they are to be subject to his Holy Spirit.
---
<font size="6">  
<p align= "left">    
<strong>"that you may be filled"</strong>: This part of the verse implies a transformative effect of understanding Christ's love. To be "filled" suggests not just a partial or temporary change but a complete and enduring infilling.
<p align= "left">    
<strong>"with all the fullness of God"</strong>: This is a profound phrase. The "fullness of God" could be understood as his nature or with all the "communicable" attributes of God. It implies that believers, through knowing Christ's love, participate in the divine nature. It is union with Christ and the transformative effect of grace in believers’ lives.
---

<font size="5">  
<p align= "left">
<strong>Wayne Barber </strong>on <u> filled with the fullness of God </u>- In other words, everything that fills God fills me and controls me and satisfies me. I am living in a realm now that I didn’t know was possible. I am loving people I didn’t think were lovable. I have put up with people who used to give me a fit. I am handling circumstances like never before. God, what is going on inside of me? God says, "You haven’t seen anything yet. Keep on trusting Me. I have other levels I want to take you to. Walk in the fullness of what I have to offer you." That is it. That is the Christian life. Paul is praying that all of God would dominate all that you are. In other words, that all of God would dominate all of you. I picked that word "dominate" very carefully because the word "filled" implies dominate. The Greek word is pleroo. It is the word that means "to be filled to the brim." If you fill a glass of water and fill it to the brim, that’s pleroo. It is filled full. There is no room for anything else. There is the implied meaning of satisfaction. You have a satisfied glass if it is full of water. What is a glass for? To be filled up. When you put the liquid to the top it must be satisfied. Nothing else is needed to satisfy the glass. So in light of Paul’s prayer, Paul is saying when we are empty of sin and we are empty of self and filled up with the fullness of God, then we begin to understand what satisfaction is all about. There is also the implicit meaning of dominance. Whatever fills a person dominates that person. What are you filled with? What is coming out of your life? Look at your life. Are you filled with fear and jealousy or are you filled with the Holy Spirit of God?
---

<font size="6">  
<strong><font color="#4f81bd">"Now to him who is able to do far more abundantly than all that we ask or think, according to the power at work within us,</font></strong>
<font size="5">  
<p align= "left">
<strong>Now to him"</strong>: The focus shifts to God  and recognizes God's sovereignty and is a preface to a doxology or expression of praise.
<p align= "left">  
<strong>"who is able"</strong>:  (dunamai) means to be capable of, to have power by virtue of inherent ability (one's own ability) and resources. God is able in Himself. Paul now emphasizes God's capability and omnipotence.
<p align= "left">    
<strong>"to do far more abundantly"</strong>: The words "far more abundantly" convey a sense of exceeding, superabundant provision. It suggests that God's actions are not just sufficient but are overwhelmingly generous and beyond our ordinary expectations. <br><br>
Huperekperissou  means “exceedingly above and beyond all measure," surpassing, superabundantly, surpassingly, beyond measure, exceedingly, quite beyond all measure, overwhelming, over and above, more than enough. This heightened form of comparative almost defies any single, simple English translation. It describes an extraordinary degree, involving a considerable excess over what would be expected.
---
<font size="5">  
<strong><font color="#4f81bd">"Now to him who is able to do far more abundantly than all that we ask or think, according to the power at work within us,</font></strong>
<p align= "left">  
<strong>"than all that we ask"</strong>: This part of the verse points to  prayer and petitions. It suggests that what God can and does do surpasses even our requests in prayer, indicating His deeper understanding and greater plans.
<p align= "left">  
<strong>"or think"</strong>: Adding to the previous phrase, this extends beyond spoken requests to unspoken thoughts and desires. It implies that God's power and generosity exceed not just our articulated prayers but also our imagination and understanding.
<p align= "left">  
<strong>"according to the power at work within us"</strong>:  "according to" means in proportion to God's infinite riches!  This is not just a portion of power but a proportion! Remember the Millionaire example. This final phrase connects the immense power of God to its work in believers.  What is the power that works within us? It is supernatural dunamis power. Works refers to the mighty power of continuous sanctification at work in the believer’s heart, and He will accomplish His work!
---
<font size="5">  
<p align= "left">  
<strong>Henry Law</strong> - For children of all ages, Christmas is the asking time of year. While we  may not be asking for “mutant turbo-blaster robo-dinosaurs” or “Diamond Dancing Barbies,” we adults still have our “asks.” The adult requests are more in the form of secure jobs, incomes adequate to pay for the turbo- blasters, good health, diplomas, peaceable families, and a world without war. There is no reproach in the apostle’s words for asking. That we would ask is, in fact, a natural outgrowth of Paul’s earlier conclusion that we have confident and free access to the Father by virtue of Christ’s work on our behalf (Eph. 2:18; 3:12). We come to a Father who is able to do what we ask, and invites us to come to him (Phil. 4:6).
But the apostle does not limit the Father’s care or ability to what we ask. There is too much of our humanity in our requests for them to govern God’s responses. Because we are human our requests are feeble and finite.
We want dessert when we need meat, success when we need humility, and safety when we need godly courage—or Christlike sacrifice. We ask within the limits of human vision, but he is able to do more. He sees into eternity
what is needful for our soul and for the souls of those whom our lives will touch across geography and across generations; and, seeing this, he is able to do more than we ask.
---
<font size="5">  
<p align= "left">  
He who loved us so much that he spared not his own Son to make us his children (Rom. 8:32) invites us to come to him freely and confidently, but he also promises to bring the full measure of the wisdom and powers of his
Godhead to answer us. How do we measure what he can do? He holds the whole earth in his hand; he created the universe but continues to control the light in your room and the decay of an atom in the most distant galaxy; he
makes the flowers grow and the snow fall; he rides on the wings of a storm and holds a butterfly in the air; and he who was before the beginning of all we know still uses time as his tool of healing, restoration, and retribution.
Our thoughts are as a window to him; generations to come from us are already known fully to him who loves our family more than we do. He looks at the length of our life as a handbreadth, and makes our soul, though sinful, his treasure forever. Such is the God who hears our prayers and is able to do immeasurably more than all we ask or can even imagine. 
---
<font size="6">  
<strong><font color="#4f81bd">21 to him be glory in the church and in Christ Jesus throughout all generations, forever and ever. Amen.</font></strong>
<font size="5">  
<p align= "left">
<strong>"to him be glory"</strong>:  This is the glory due God and is to be given Him in the church. The apostle has repeatedly insisted that the end of redemption is the glory of God . "Glory" here represents honor, majesty, and the awe-inspiring presence of God. It's a recognition that all praise and honor are due to Him.
<p align= "left">    
<strong>"in the church"</strong>: The term "church" refers to literally "called-out ones". The Greeks used <strong>ekklesia</strong>for assembly of citizens called out to transact city business.  The church is a living organism, composed of living members joined together; through which Christ works, carries out His purposes and He lives.
<p align= "left">      
<strong>"and in Christ Jesus" /"by Christ Jesus"</strong> This emphasizes that the glory of God is also seen in the person and work of Jesus Christ. It acknowledges Christ's central role in the Christian faith as the revelation of God's character and the mediator of God's purposes.
---
<font size="6">  
  <p align= "left">    
<strong>"throughout all generations"</strong>:  This  indicates the enduring and timeless nature of God's glory. It's not limited to a single era or group of people but spans all ages, underscoring the eternal relevance and unchanging nature of God's character and work.
 <p align= "left">     
<strong>"forever and ever"/"world without end -KJV"/the age of all ages "LSV</strong>: Echoing and expanding upon the previous phrase, this underscores the eternal aspect of God's glory. It's a declaration that God's majesty and honor are not temporary or fleeting but are everlasting.
  <p align= "left">    
<strong>"Amen"</strong>: This word means "so be it" and is a common conclusion to prayers and doxologies in the Christian tradition. It signifies agreement and affirmation of the truth of the words spoken.
---
The Love of God
<font size="5">  
by Frederick M. Lehman
<p align= "left">
<center>
The love of God is greater far than tongue or pen can ever tell,  <br>
It goes beyond the highest star and reaches to the lowest hell,  <br>
The guilty pair, bowed down with care, God gave His Son to win:  <br>
His erring child He reconciled and pardoned from his sin.<br>

When years of time shall pass away and earthly thrones and kingdoms fall,  
When men, who here refuse to pray, on rocks and hills and mountains call,  
God’s love so sure shall still endure, all measureless and strong:  
Redeeming grace to Adam’s race—the saints’ and angels’ song.

**Could we with ink the ocean fill and were the skies of parchment made,  
Were ev’ry stalk on earth a quill and ev’ry man a scribe by trade  
To write the love of God above would drain the ocean dry,  
Nor could the scroll contain the whole tho stretched from sky to sky.**  

O love of God, how rich and pure!  
How measureless and strong!  
It shall forevermore endure—  
the saints’ and angels’ song.</center>
--
<font size="6">  
<p align= "left>
The story behind the words in this famous hymn is as follows...
<p align= "left>
The lyrics are based on the Jewish poem Haddamut, written in Aramaic in 1050 by Meir Ben Isaac Nehorai, a cantor in Worms, Germany; they have been translated into at least 18 languages. (As the story is told) One day, during short intervals of inattention to our work, we picked up a scrap of paper and, seated upon an empty lemon box pushed against the wall, with a stub pencil, added the (first) two stanzas and chorus of the song…Since the lines (3rd stanza from the Jewish poem - beginning "Could we with ink the ocean fill...") had been found penciled on the wall of a patient’s room in an insane asylum after he had been carried to his grave, the general opinion was that this inmate had written the epic in moments of sanity.
---
END READING<br>
Ephesians 3:14-21
<font size="6">  
<p align= "Justify">
14For this reason I bow my knees before the Father, 15 from whom every family  in heaven and on earth is named, 16 that according to the riches of his glory he may grant you to be strengthened with power through his Spirit in your inner being,  <font color="#c0504d">17 so that Christ may dwell in your hearts through faith—that you, being rooted and grounded in love, 18 may have strength to comprehend with all the saints what is the breadth and length and height and depth, 19 and to know the love of Christ that surpasses knowledge, that you may be filled with all the fullness of God.
<p align= "Justify">
20 Now to him who is able to do far more abundantly than all that we ask or think, according to the power at work within us, 21 to him be glory in the church and in Christ Jesus throughout all generations, forever and ever. Amen.</font>
---
CLOSING PRAYER 
==
---