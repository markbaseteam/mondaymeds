
<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->

---
<!-- slide template="[[tpl-con-2-1-box]]" -->

::: title
#### _**Ephesians 1:7-8 The Blessing of Redemption**_
:::

::: left
![[Ephesians 1 7=8 Sentence Diagram.jpg]]
:::

<style>
.small-indent > ul { 
   padding-left: 1em;
}
</style>

::: right
****Keywords***<br>
- redemption
- forgiveness
- grace
- wisdom & insight


:::<!-- element align="left" style="font-size: 13px;" class="small-indent" -->

::: source
###### EPHESIANS 1:7-8 ESV:  In him we have redemption through his blood, the forgiveness of our trespasses, according to the riches of his grace, which he lavished upon us, in all wisdom and insight. 
:::

---
<!-- slide bg="#D4E4F7" -->

### <font color="#1f497d">Break down phrases</font>

<font size="5">  

- In him
- We 
- have
- Redemption
- Through His blood
- forgiveness 
- of our trespasses
- According to the riches
- of his grace
- which (this grace)
- he lavished
- upon us
- in all wisdom & insight


---
<!-- slide bg="#D4E4F7" -->
### Meditate on each  Word & Phrase

<font size="6">  

- Pray
- Read verse slowly
- Meditate on each word and phrase
- Look up the Strong's Concordance 
- Look Up in English Dictionary
- Find Synonyms to Word
- Look Up the Verse In Other Bible Translations
- Find Cross References
- Memorize the verse
- Sentence Diagram or Phrase the verse
- Rewrite the verse in your own words
- Turn it into a prayer (petition or praise)

---


### <font color="#4f81bd">In him</font>
<font size="5">  
<p align= "left"><u>In Christ</u>, is the place where <em>all </em>our blessings reside. <br><br>
	We are chosen in Christ,<br>
			 adopted through Christ, <br>
				 blessed in the beloved, <br>
					 redeemed through his blood.<br>

<p align= "left">Ephesians 1:3.  "In him" or "In Christ" or "In the Beloved" phrase is used 27x times in Ephesians.  Our spiritual union with Christ is a key them of the book. As a result of our union to Christ, we are blessed with every spiritual blessing in the heavenly places. He is ours and we are his. <br><br>
![[Ephes-01#v3]]
</p></font>

---


### <font color="#4f81bd">We </font>
<font size="6">  
<p align= "left">We refers to us:<br>
	- the Saints, Eph 1:1<br>
	- the faithful in Christ Jesus,Eph 1:1 <br>
	- the chosen ones, Eph 1:4<br>
	- those who are holy and blameless before him Eph 1:4<br>
	- predestined ones, Eph 1:5<br>
	- adopted, as sons/daughters Eph 1:5<br>
	- blessed in the beloved Eph 1:6<br>
	- the redeemed Eph 1:7<br>
	- the forgiven Eph 1:7<br>

<p align= "left">In these first 7 verses we are really focusing our new identity in Christ and the blessings of our new position.
</font>
---

### <font color="#4f81bd">have</font>
<font size="6">  
<p align= "left"><u>Present tense </u>verb which means: to possess, to own, to hold.

<p align= "left">We are about to see that we <em>have</em> redemption, we <em>have</em> forgiveness.  We already possess these blessings. They are already ours to enjoy in this life to the extent that we have faith in God's word to enjoy the truth.<br><br>

<em><font color="#4f81bd">the righteous shall live by his faith</font>.<br></em>
</font>
---

### <font color="#1f497d"> Redemption</font>

<font size="6">  

There are 3 distinct words for Redemption in the New Testament. 
1. <p align= "left">One word is <strong>agorazō** [αγοραζω] (G59 [ἀγοράζω])</strong>, which appears 31x and means <strong>to buy.</strong> This word is used, for example, in 1 Corinthians 6:20: <br><br>
<em>“For ye are bought with a <font color="#d83931">price</font>: therefore glorify God in your body, and in your spirit, which are God’s.” </em><br><br>
Referring to the tribulation saints, Revelation 5:9 declares: <br><br>
<em>“And they sung a new song, saying, Thou art worthy to take the book, and to open the seals thereof: for thou was slain, and hast<font color="#c00000"> redeemed</font> us to God by thy blood out of every kindred, and tongue, and people, and nation.”</em>
---
<font size="6">  
<p align= "left">
2. Another word is <strong>exagorazō [εξαγοραζω] (G1805 [ἐξαγοράζω]), </strong> which occurs only 4x, and means <font color="#4f81bd">“to buy out of the market".</font>  <br><br>
It is <em>to buy out</em> of so that what was purchased will never be put on sale again. <br><br>
In New Testament times, the slave trade market was very, very large with almost 6 million slaves. Many people had family and relatives sold into slavery or born into slavery. In the old slave market a slave was purchased and handed over to the new owner. In very rare cases, the owner gave the slave a legal paper granting him his own freedom and with this paper they never had to fear being put into slavery again.  <br><br>A slave had no hope of ever redeeming himself out of slavery. 
<p align= "left">

---
<font size="6">  
<p align= "left">
We find this word "to buy out of"  used in Galatians & 1 Peter: <br><br>
<Strong>Galatians 3:13</strong><em>“Christ hath <font color="#c00000">redeemed</font> us from the curse of the law, being made a curse for us: for it is written, Cursed is every one that hangeth on a tree.”</em><br><br>
<strong>1 Peter 1:18-19</strong><em> For you know that it was not with perishable things such as silver or gold that you were<font color="#c00000"> redeemed</font> from the empty way of life handed down to you from your ancestors, but with the precious blood of Christ, a lamb without blemish or defect.</em><br><br>
---
### <font color="#1f497d">Redemption</font>
<font size="6">  
<p align= "left"><strong><font color="#1f497d">3. Redemption</font></strong>- G629 ἀπολύτρωσις apolutrosis (a-po-lï '-trō-sis) n. from a compound of two Greek words is the third  word and the word for redemption.. It is used 10x in New Testament 3x here in Ephesians starting with Eph 1:7 :<br><br>
	<strong>G575</strong> apo (a-po') and  - in means<u> "from", </u>In composition (as a prefix) it usually denotes separation, departure, cessation, completion, reversal, etc.} It means going away from something.<br><br>
	<strong>G3083</strong> lutron (lï '-tron) - <u>something to loosen with, i.e. a redemption price, ransom, </u>(figuratively) atonement. to release on receipt of a ransom. Literally means "to be loosened away" from something. We have been loosened away from the curse of the law. <br><br>

---

Word Web Dictionary:<br>
<font size="6">  
1. (theology)the act of delivering from sin or saving from evil.  Salvation
2. (corporation )repayment of the principal amount of a debt or security at or before maturity as when a corporation repurchases its own stock. 
3. The act of purchasing back something previously sold. Buyback, Repurchase

Derived
**Verb:**  redeem
**Adjective:** redemptional, redemptive, redemptory

<p align= "left">Redemption is the act of delivering or saving from the captivity or bondage of sin by paying a ransom price. Salvation.
</font></p>
---
Slaves to Sin
<p align= "left">In the same, before our redemption, when we lived <em>"in sin" </em>before we came to be <em>"in Christ"</em>, we had no hope of ever freeing ourselves from the domain of sin.  We had no hope of ever being ransomed.

---
<font size="5">  

>  <p align= "left"><em> "Unlike today, Paul’s readers completely understood total depravity because they fully understood slavery. While some people think they have a problem with the doctrine of election, what they don’t realize is that their real problem is with the doctrine of depravity that makes election necessary. Our nature simply does not want to accept the totality of our depravity. But a slave was not “partly free.” No, he was a slave. Slavery was such a low position, that for all practical purposes, a slave was “dead.”<br><br>
That is precisely the picture of depravity that is painted in Scripture. As Paul writes in Ephesians 2:1–3, without Christ we “were dead in trespasses and sins” and lived according to “the lusts of our flesh, fulfilling the desires of the flesh and of the mind; and were by nature the children of wrath.” In our day, sin has been redefined to mean virtually anything we want it to mean, such as “not perfect but still basically good” or simply a “low self-esteem.” But the picture in Scripture is one of a spiritual corpse that God must redeem and regenerate, and that is the work of God’s grace alone. And it is from that that we have been redeemed.*</em> - Dr. J.D. Watson

---
##### Categories of Redemption
<p align= "left">
<font size="4.5">  
1. <strong>Subjects of Redemption</strong>. Those who were in bondage to a “vain manner of living” [[1 Pet-01#v18|1 Peter 1:18]]<br>
2. <strong>Source of Redemption</strong> "of God", It is said that “His grace” operates <em>“through the redemption that is in Christ Jesus,”</em> and that the redemption comes to us <em> “according to the riches of His grace”</em> [[Rom-03#v24|Romans 3:24]]; [[Ephes-01#v7|Eph.s 1:7]].<br>
3. <strong>Price of Redemption</strong> The price is “His Blood” [[Ephes-01#v7|Ephesians 1:7]]., which Christ gave as “a ransom” [[Matt-20#v28|Matthew 20:28]] and is the equivalent for all demands—[[1 Tim-02#v6|1 Tim.2:6]].<br>
4. <strong>Substance of Redemption</strong>. Christ is its Substance and Embodiment, hence, “He is made unto us Redemption”  [[1 Cor-01#v30|1 Cor. 1:30]].<br>
5. <strong>Receiver of Redemption</strong>. Faith, like Anna, who “looked for redemption” [[Luke-02#v38|Luke 2:38]], finds what it looks for in the Redeemer.<br>
6. <strong>Meaning of Redemption</strong> is “deliverance.” The Lion of the tribe of Judah breaks every chain— [[Heb-11#v35|Heb. 11:35]].<br>
7. <strong>Consummation of Redemption</strong> is when our Lord returns. Hence, we are waiting for “the redemption of our body” [[Rom-08#v23|Rom.8:23]]<br>

---
##### Redemption Demonstrated
<p align= "left">
<font size="4.5">  
1. <strong>Israel’s deliverance from Egypt </strong>is a picture of redemption’s emancipating liberty—Exodus 15:13.<br>
2. <strong>The Ransom and Redemption Money</strong>—Exodus 30:12; Numbers 3:49, are types of its protecting and bestowing grace.<br>
3. <strong>The Action of Boaz</strong> in reclaiming the lost inheritance of Naomi, and purchasing Ruth to be his wife, is an illustration of its releasing and claiming power—Ruth 4:10.<br>
4. <strong>The Year of Jubilee,</strong> with its bestowments of release to the debtor, freedom to the slave, and rest to the captive, depict the blessings of redemption—Leviticus 25.<br>
5. <strong>The Testimony of God’s Assuring Word </strong>to the believer is God’s guarantee as to his personal benefit of redemption in Christ—Eph. 1:7.<br>
6. <strong>The Song of the Redeemed in glory</strong> has its inspiration in the redemptive work of the Lord—Rev. 5:9.<br>
7. <strong>The Holiness of the Child of God</strong> has its incentive in the redeeming blood of Calvary—1 Peter 1:18-19; Titus 2:14.<br>

---
![[Divider - Scroll 1.jpg]]

<em>The cost of redemption cannot be overstated. The wonders of grace cannot be overemphasized. Christ took the hell He didn’t deserve so we could have the heaven we don’t deserve.</em><br><br> - Randy Alcorn, The Grace & Truth Paradox

---
#### <font color="#4f81bd">Through His blood</font>
<font size="5.5">  
<strong>How were we purchased? What was the ransom?</strong><br>
The price is “His Blood” [[Ephes-01#v7|Eph 1:7]]., which Christ gave as “a ransom”.<br>
<p align= "left">
<strong>1 Tim 2:6</strong> - <em>who gave himself as a ransom for all, which is the testimony given at the proper time.</em><br><br>
<strong>Matt:20:28 </strong>- <em>28 even as the Son of Man came not to be served but to serve, and to give his life as a ransom for many.”</em></br><br>
<strong>1 Corinthians 6:20 - </Strong> - <em> for you were bought with a price. So glorify God in your body.</em><br><br> 
<strong>1 Peter 1:18-19 </strong><em> knowing that you were ransomed from the futile ways inherited from your forefathers, not with perishable things such as silver or gold,  but with the precious blood of Christ, like that of a lamb without blemish or spot.</em><br>
---

<em>What can wash away my sin?  
Nothing but the blood of Jesus.  
What can make me whole again?  
Nothing but the blood of Jesus.  

O precious is the flow  
that makes me white as snow;  
no other fount I know;  
nothing but the blood of Jesus.</em>

---
#### <font color="#4f81bd">Why Blood?</font>
---
<font size="5.5">  
<strong>[[Hos-13#v14|Hosea 13:14]] </strong> - <em>  I shall ransom them from the power of Sheol; I shall redeem them from Death. O Death, where are your plagues? O Sheol, where is your sting? </em><br>
---
<p align= "left">
<font size= "5.5">
Since the Fall of Man in Genesis, a substitutionary sacrifice for the sins of man has been required.<br>
<p align= "left">
- <strong>Genesis 2:17 </strong> - <em> but of the tree of the knowledge of good and evil you shall not eat, for in the day that you eat of it you shall surely die.”</em><br><br>
- <strong>Genesis 3:21 </strong>- <em>And the Lord God made for Adam and for his wife garments of skins and clothed them.</em><br><br>
-<strong> Romans 5:12</strong><em>Therefore, just as sin came into the world through one man, and death through sin, and so death spread to all men because all sinned</em><br><br>
- <strong>Leviticus 17:11 - </strong><em> For the life of the flesh is in the blood, and I have given it for you on the altar to make atonement for your souls, for it is the blood that makes atonement by the life.</em><br><br>
- <strong>Hebrews 9:22</strong> -<em>Indeed, under the law almost everything is purified with blood, and without the shedding of blood there is no forgiveness of sins.</em><br><br>
- <strong>1 John 1:7</strong> <em>...the blood of Jesus his Son cleanses us from all sin.</em>

---
##### <font color="#4f81bd">Blood - Morrish Dictionary</font>
<p align= "left">
<font size="5.5">  
The blood of man is claimed by God; for the 'life is in the blood;'  'the blood is the life.' It therefore must not be eaten; if not offered in sacrifice it must be 'poured upon the earth as water.' "Whoso sheddeth man's blood, by man shall his blood be shed." The blood also maketh atonement for the soul: it must be poured out upon the altar. Gen. 9:4-6; Lev. 17:10-14; Deut. 12:23-25; Acts 15:29. In the O.T. dispensation everything in the tabernacle, the priests and their dresses were purged and sanctified by blood, everything being sprinkled with blood, including the book of the law and the people. Heb. 9:18, 21. This was typical of the blood of the Lord Jesus, which has accomplished everything for the Christian: with His blood He 'purchased' us, Acts 20:28; 'justified' us, Rom. 5:9; 'redeemed,' Eph. 1:7; 'sanctified,' Heb. 13:12; 'cleanseth us from all sin,' 1 John 1:7; etc. - Morrish Dictionary

---
##### <font color="#4f81bd">The ransom for our sin had to be Christ's blood.</font>
<font size="6">  
Only the blood of Christ is pure, has the power to cleanse and to take away the sin of the world. <br><br>
<strong>John 1:29 </strong>- <em>The next day he saw Jesus coming toward him, and said, “Behold, the Lamb of God, who takes away the sin of the world!</em><br><br>
<em> "No guilt so high but it can master, no stain so deep but it can purge; being the blood of the Son of God, and therefore of infinite virtue, it has as much force to demolish mountains of guilt as level mole-hills of iniquity." </em>- Steven Charnock<br>
---
#### The Blood of Christ is Precious Because:

<font size="6">  
- It belongs to Christ, the Son of God. Matt 3:17<br>
- It pays the debt of our unrighteousness. Rom 3:23<br>
- It's power to truly clean unlike blood of animals. - Heb. 10:4<br>
- It cleans, present tense, it is a perpetual pleading for us, a continual flowing, a fountain set open for sin. Zech 13:1<br>
- It cleanses from all sin ass universal remedy. 
- It demonstrates the weight of divine righteousness. - Rom 3:21-3:26<br>
- It demonstrates the love of God. John 3:16<br>
- It speaks a better word then the blood of Abel pleading Christ's merit vs vengance.  Heb 10:24<br>
- It cleanses the conscience. Heb 9:14

---
#### <font color="#4f81bd">Who was the ransom paid to?</font>

<strong>God</strong>
<font size="5.5
	  ">  
- <strong>1 John 5:19</strong> - <em>We know that we are from God, and the whole world lies in the power of the evil one.</em><br><br>
- <strong>John 3:36</strong>  - <em>Whoever believes in the Son has eternal life; whoever does not obey the Son shall not see life, but the wrath of God remains on him.</em><br><br>
- <strong>Romans 1:18</strong>  <em>For the wrath of God  is revealed from heaven against all ungodliness and unrighteousness of men, who by their unrighteousness suppress the truth.</em><br><br>
- <strong> Romans 5:9 </strong> -<em> Since, therefore, we have now been justified by his blood, much more shall we be saved by him from the wrath of God.</em><br>

==We are delivered from the wrath of God by the forgiveness of our sins. The blood Christ, satisfied the wrath of God. ==</font>
---
<p align= "left">
<font size="6">  
Jesus could not have paid a ransom to Satan because that would put Satan in a position whereby he, a creature, could demand something from the Creator, and Jesus is God incarnate - John 1:1–14<br>
Additionally, when Scripture talks about the atonement, it emphasizes God's demands: the Lord ordered the Suffering Servant to be crushed for our iniquities ([Isa. 52:13–53:12]
Moreover, Satan could not have taken us captive in the first place without God's sovereign permission; therefore, if anyone could demand a ransom for our salvation, it would be God. In Christ, God paid to Himself the ransom He justly demanded so that we could have eternal life. [-Ligonier](https://www.ligonier.org/learn/devotionals/ransom-christ-paid)
---
##### Isaiah 53:5-6
<p align= "left">
<em>He was pierced for our transgressions; he was crushed for our iniquities; upon him was the chastisement that brought us peace, and with his wounds we are healed. All we like sheep have gone astray; we have turned — every one — to his own way; and the Lord has laid on him the iniquity of us all. 
</em>
---
### <font color="#4f81bd">forgiveness </font>
<p align= "left">
<font size="5.5
	  ">  
<p align= "left">Redemption and Forgiveness are two very different words but very closely related and the way Paul uses them in this sentence, forgiveness is acting as an appositive phrase.

<p align= "left">In grammar an appositive phrase, is a noun that comes after another noun and gives more information on that noun. For instance, I could say, "*Sunny, my sister went hiking with me.* The word "sister" would be considered "appositive" since it is a noun that describes another noun in more detail.

<p align= "left">An understanding of basic grammar rules can really help in bible study as it helps you as you meditate on words and how they are used within a sentence and what they modify.
---
<p align= "left">With the word 'forgiveness' in this sentence being used as an appositive phrase, Paul is giving us more information on what it means to be redeemed. To be redeemed is to be forgiven of our sins.
---
Forgiveness Greek Aphesis
![[Pasted image 20230703000505.png]]
---
![[Pasted image 20230703000531.png]]
<p align= "left">
<font size="6">
<strong>Romans 3:25</strong>  <em> whom God put forward as a propitiation by his blood, to be received by faith. This was to show God's righteousness, because in his divine forbearance he had passed over former sins.</em>
---
#### <font color="#4f81bd">Word of the Day - Forgiveness</font>
<p align= "left">
<font size="5.5">
One of the direct results of redemption is the forgiveness of sins. The Greek is aphesis [αφεσις] (G859 [ἄφεσις]), which literally means “release, pardon, or cancellation.” In Classical Greek it means “the voluntary release of a person or thing over which one has legal or actual control.” This powerful word actually has three aspects.<br>
<strong>First</strong>, in legal terms, forgiveness is a judicial release from the guilt and punishment of sin, which is death. Primarily, forgiveness is a legal transaction. This is a vitally important point, for we who were under the legal sentence of death according to the Law, are now forgiven by legal transaction. The Law can never save; it can only reveal guilt and condemn us, “for by the law is the knowledge of sin” (Rom. 3:20), and “no man is justified by the law” (Gal. 3:11). This is, in fact, Paul’s thrust throughout the first half of the epistle to the Romans, to first show man’s guilt and then show God’s grace.
---
<p align= "left">
<font size="5.5">
<strong>Second</strong>, in ethical terms, forgiveness is a release from the terribleness of sin that affects the conscience. Salvation changes the sinner ethically. The Christian no longer desires the things he or she used to desire (2 Cor. 5:17).<br><br>
<strong>Third,</strong> in personal terms, forgiveness is a cessation of God’s intended wrath upon the sinner. A vivid illustration of this is in the OT scapegoat in Leviticus 16. On the Day of Atonement (Yom Kippur), the High Priest chose two unblemished goats, one of which he killed and sprinkled its blood on the mercy seat (see Dec. 11). Verses 21–22 go on to describe the High Priest laying his hands on the live goat, confessing the sins of the nation, and then sending it into the wilderness.
---
<p align= "left">
<font size="5.5">
That was a wonderful picture, but as beautiful as it was, it was still only a symbol. It did not take sin away. It was not a perfect sacrifice. It was merely a symbol of what only God could do through the coming Messiah. Jesus Christ would not only be the perfect sacrificial lamb, but He would also be the perfect scapegoat. He would not only redeem His people with His blood, but He would also remove their sin forever. That is forgiveness.
---
### <font color="#4f81bd"> of our trespasses</font>
<font size="6">
Offenses (NET) - Sin (KJV)<br>
<p align= "left">
Trespasses:<br>
<strong>G3900</strong> παράπτωμα<strong> paraptoma </Strong>(pa-ra'-ptō-ma) n.<br>
1. a side-slip, faltering (lapse or deviation).<br>
2. (unintentional) a mistake or fault.<br>
3. (willful) a trespass, transgression.<br>
[from G3895]<br><br>
KJV: fall, fault, offence, sin, trespass <br><br>
<strong>Sin</strong> - hamartia [ἁμαρτια] (G266 [ἀμαρτία]), to miss the mark.
---
#### <font color="#4f81bd">Word of the Day: Trespasses </font>
<p align= "left">
<font size="5.5">
There are several different approaches to the “sin question” as far as man is concerned. There are, of course, people who don’t recognize a “sin problem” at all. Such people view sin as an accident, mistake, or indiscretion. Others view it as merely an “amiable weakness” or simple “immaturity.” Liberal theology, led by men such as Robert Schuller, views “the core of sin [as] a lack of self-esteem.” In addition to those approaches, there is also a general sense of flippancy about sin nowadays. Worse is the fact that in much modern preaching, even among evangelicals, sin is not dealt with at all.
In stark contrast, there are two Greek words that very graphically reveal God’s view of sin. Both of these words, in fact, appear together in Ephesians 2:1, where Paul declares that we “were dead in trespasses and sins.”
---
<p align= "left">
<font size="5.5">
The word trespasses is paraptōma [παραπτωμα] (G3900 [παράπτωμα]), which consists of para [παρα] (G3844 [παρά]), “along side of,” and piptō [πιπτω] (G4098 [πίπτω]), “to fall.” The word, therefore, pictures a deviation to one side or the other. It was used at times by the ancient Greeks to describe an error, a mistake in judgment, or a blunder. But that idea is never even implied in the NT.1 Rather the NT usage strongly emphasizes a deliberate act with its serious consequences. In fact, the key to understanding this is to realize that trespasses speaks of a willful deviation from God’s requirement.
---
<p align= "left">
<font size="5.5">
Romans 5:15–20 uses the word offence (paraptōma [παραπτωμα]) several times to describe clearly Adam’s sin as a willful deviation from God’s command: “through the offence of one many be dead … by one man’s offence death reigned by one … by the offence of one judgment came upon all men to condemnation … Moreover the law entered, that the offence might abound. But where sin abounded, grace did much more abound.”<br>
What’s the application? Simply that we are all willful sinners. We, just as Adam, Achan, Saul, and Israel, deliberately disobey God’s commands. We don’t just make mistakes; we don’t just commit indiscretions; we don’t just “trip up.” We are willful sinners. We sin not because “the devil made us do it,” not because it’s our spouse’s fault, not because we had a bad childhood. We sin because we choose to sin; we deviate from the commands of God. Thank God for His forgiveness! 
---

### According to the riches
<font size="6"> 
<p align= "left">
G4149 πλοῦτος ploutos (plou'-tos) n.
1. wealth (as fulness).
2. (literally) money, possessions.
3. (figuratively) abundance, richness.
4. (specially) valuable bestowment.
[from the base of G4130]
KJV: riches 
Root(s): G4130 <br>
<p align= "left">
<em>"We who are saved may well rejoice, for we have been forgiven, we have been redeemed, not out of the riches of God’s grace but according to the riches of His grace. If you grasp this thought, you will never feel poor again."</em> - Ironside

---
### of his grace
χάρις charis
good will, loving-kindness, favour<br><br>
<p align= "left">
God his rich in grace, good wlll , loving-kindness and favour towards us. 

...<em>Whatsoever is pure, whatsoever is lovely, think in these things...</em>
---
### which (this grace)
Lovingkindness - good will- favour towards us
---
### he lavished
<p align= "left">
<font size="6"> 
God's munificence is once again displayed in how he pours out his grace upon us. It is not just a little bit of grace,

G4052 περισσεύω perisseuo (pe-riys-sev'-ō) v.
1. to superabound (in quantity or quality), be in excess, be superfluous.
2. (transitively) to cause to superabound or excel.
[from G4053]
KJV: (make, more) abound, (have, have more) abundance (be more) abundant, be the better, enough and to spare, exceed, excel, increase, be left, redound, remain (over and above) 
Root(s): G4053 

---
### upon us
<font size="6">  
<p align= "left">We refers to us:<br>
	- the Saints, Eph 1:1<br>
	- the faithful in Christ Jesus,Eph 1:1 <br>
	- the chosen ones, Eph 1:4<br>
	- those who are holy and blameless before him Eph 1:4<br>
	- predestined ones, Eph 1:5<br>
	- adopted, as sons/daughters Eph 1:5<br>
	- blessed in the beloved Eph 1:6<br>
	- the redeemed Eph 1:7<br>
	- the forgiven Eph 1:7<br>

---
### in all wisdom & insight (prudence)
<font size="5.5">  
<p align= "left">
G4678 σοφία sophia (so-fiy'-a) n.
wisdom (higher or lower, worldly or spiritual).
<p align= "left">
G5428 φρόνησις phronesis (fro'-nee-sis) n.
mental action or activity, i.e. intellectual or moral insight.
<p align= "left">
This superabounding grace  towards us that worked out our redemption and forgiveness of sins was not spur of the moment, unplanned action. It was pre-destined, pre-determined. It was pre-planned. That which God pre-plans, he accomplishes because it is done with ALL wisdom and ALL insight. It is a demonstration of  not only God's great love, but also, God's great wisdom, intelligence and understanding. His plans were skilly fully arranged and well formed from the beginning of time to the end of time always intending to accomplish the redemption of man.

---

## Ephesians 1:7-8 ESV

 <em>In him we have redemption through his blood, the forgiveness of our trespasses, according to the riches of his grace,  which he lavished upon us, in all wisdom and insight.</em> -  Ephesians 1:7-8 ESV
---
<em><font size="34">  <font color="#ffffff">Prayer</font><br></font></em>
<!-- slide bg="[[Pasted image 20230702190507.png]]" -->

---






