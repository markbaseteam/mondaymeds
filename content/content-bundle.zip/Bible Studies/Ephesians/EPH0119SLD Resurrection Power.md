
<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->

---

![[Pic Opening Prayer.png]]

---
This week's Passage: Ephesians 1:19-23 (ESV)
<p align= "left"><font size="6">  
19 and what is the immeasurable greatness of his power toward us who believe, according to the working of his great might 20 that he worked in Christ when he raised him from the dead and seated him at his right hand in the heavenly places, 21 far above all rule and authority and power and dominion, and above every name that is named, not only in this age but also in the one to come. 22 And he put all things under his feet and gave him as head over all things to the church, 23 which is his body, the fullness of him who fills all in all.
---
Ephesians 1:19 [Parallel Plus by TheBible.org](https://thebible.org/gt/index)
![[Pasted image 20230824202403.png]]
---
### 
And<!-- element style="background: floralwhite" -->
<font size="6">  
<p align= "left">
This links us to the previous passage in verse 18, where Paul is praying for the eyes of the Ephesians to be enlightened so that they may know the hope of their calling AND...what is the immeasurable greatness of his power toward us who believe. The rest of chapter 1 are several prepositional phrases that describe this great immeasurable resurrection power that Paul is praying the Ephesians (and us) would know. So we are going to take a close look and try to see all that God will allow us to see about this great power that is toward us who believe.
---
![[Pasted image 20230827200625.png]]
---
![[Pasted image 20230827200714.png]]
---
Christians are to Know God's Power
<font size="6">  
<p align= "left">
<strong>2 Timothy 3:5</strong> having the appearance of godliness, but denying its power. Avoid such people.
<p align= "left">
If we were to read the context surrounding 2 Timothy 3:5 we would see that Paul is talking about the last days, when there will be those who are lovers of self, lovers of money, proud, arrogant, abusive, disobedient to their parents, ungrateful, unholy,  heartless, unappeasable, slanderous, without self-control, brutal, not loving good,  treacherous, reckless, swollen with conceit, lovers of pleasure rather than lovers of God....<u>having the appearance of godliness but denying its power.</u>.. Paul warns to avoid such people and lists the dangers of the infiltrate homes and seducing vulnerable women, filled with sins and led astray by varying desires, always learning but never attaining at a knowledge of the truth.
---
<p align= "left">
<font size="6">
Paul is describing a prevalence of "cheap grace" that we referred to a couple of weeks ago when we called about Dietrich Bonhoeffer's book "The Cost of Discipleship" . In it he says: 
<p align= "left">
" <em>A grace without discipleship, grace without the cross, grace without Jesus Christ, living and incarnate".</em> vs a costly grace, "<em>a grace that costs a man his life and condemns sin, but in return gives a man the only true life and frees from sin. </em>
<p align= "left">
That is power. Imitation faith lacks power.
---
<p align= "left">
<font size="6">
In 2 Timothy 3:1-6 We see no outward working of holiness, no change of life,  in those who would profess to be believers. They have an outward appearance of godliness, in that they are not against Christianity, they would say they are for it, they may even attend church regularly, post a lot of Christian meme's,  but when you look at their life, there is no holiness. You see a "cheap grace", an imitation faith that shows very little "cost", very little self denial or overcoming sin. They are "lukewarm." Neither hot nor cold as described by the church of Laodicea in the book of Revelation.
---
### 
What is the immeasurable greatness of his power<!-- element style="background: floralwhite" -->
<font size="6">  
<p align= "left">
Immeasurable, surpassing, incomparable, exceeding  - greatness
<p align= "left">
<strong>Immeasurable </strong>- impossible to measure, beyond calculation, incomputable
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/JHnx600vMeY?si=HEKm0Ina-KmT0c05" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
---
![[Pasted image 20230824204345.png|600]]
---

![[Pasted image 20230824204853.png|600]]
---
Exceeding Greatness
<font size="5">  

huperballon megethos [ὑπερβαλλον μεγεθος]
<p align= "left">
Preachers often proclaim God's greatness, but how great is He? There are several Greek words that give us a hint. Ephesians 1:19 contains multiple similar words: "the exceeding greatness of his power to us-ward who believe, according to the working of his mighty power."
Greatness is a translation of the Greek word megethos (G3174), which means "strong" or "great." This evidently wasn't enough for Paul, so he adds huperball (exceeding, 5235), a compound term made up of huper (G5228, "over, above, or beyond") and ball (G906 , "to put or cast"). The precise meaning is "to throw beyond the usual mark," which means "to excel or surpass." 
The full meaning of the term huperballon megethos is power beyond measure, superabundant or surpassing power, power that is "more than enough."
---
<font size="5">  
<p align= "left">
The word "megethos" is found only here in the NT.  Words are nearly bulging at the seams as Paul strives to pack more meaning into them. Paul does not specify what God's strength exceeds. The apparent implication is that it is greater than everything!   
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
"There 25 compounds with hyper in the NT, 16 are found only in the Pauline Epistles and others are used mainly by Paul. They reflect the apostle's strong personality and his almost frustrated desire to seek to express in words the inexpressible greatness of God's grace.  
  <p align= "left">
This sense of the inadequacy of language to convey spiritual truths is even more prominent in the Greek text than in English translation. Paul is struggling to say what cannot be said. It is utterly impossible to put the fullness of divine reality in human language, to compress the infinite into what is finite. That is why one cannot receive the full impact of the meaning of the Word of God except as the Holy Spirit illuminates his mind to understand it. Just so, Paul struggled to express the great thoughts with the words which so weakly convey them. It is with words that we have to deal. But our goal is always to get behind those words to the meaning. Biblical interpretation is the most challenging, demanding task that anyone can undertake." - Sermon Index (_SermonIndex.net Audio Sermons - Sermon Index_, n.d.)
---
Power
<font size="5">  
<p align= "left">
δύναμις<br>
<strong>dunamis</strong><br>
Thayer Definition:<br>
1) strength power, ability<br>
	1a) inherent power, power residing in a thing by virtue of its nature,<br> or which a person or thing exerts and puts forth<br>
	1b) power for performing miracles<br>
	1c) moral power and excellence of soul<br>
	1d) the power and influence which belong to riches and wealth<br>
	1e) power and resources arising from numbers<br>
	1f) power consisting in or resting upon armies, forces, hosts<br>


---
![[Pasted image 20230828170624.png]]
---
Greek Words for "Power"
<font size="5">  
<p align= "left">

|Greek Word|Definition|Context and Usage|Biblical References|
|---|---|---|---|
|Dunamis|Potential, ability, strength|Often refers to inherent ability or capacity|Acts 1:8, Romans 1:16|
|Energeia|Active working, effectiveness|Focuses on manifestation or operation of power|Ephesians 3:7, Colossians 1:29|
|Kratos|Dominion, ruling power|Emphasizes authority and sovereignty|Revelation 5:13, 1 Peter 4:11|
|Exousia|Authority, permission|Highlights legitimate right to exercise control|Matthew 28:18, John 1:12|
---
3 Words for Power in Ephesians 1:19
<font size="5">  
<p align= "left">

1. <strong>Dunamis (δύναμις):</strong> In this verse, "dunamis" is used to describe the immeasurable greatness of God's power. It signifies inherent power, ability, and potential. In the context of believers, it emphasizes the remarkable strength and capability that God's power brings to those who believe. This power is not limited; it's boundless and extraordinary.
    
2. <strong>Energeia (ἐνέργεια):</strong> "Energeia" is used to describe the working or operation of God's power. It underscores the active and effective manifestation of God's power in the lives of believers. This term highlights the dynamic and transformative nature of God's power as it actively produces visible results and impacts their lives.
    
3. <strong>Kratos (κράτος):</strong> "Kratos" is employed to emphasize the great might and dominion of God's power. It signifies His supreme authority and rule. In the context of believers, it signifies that God's power not only possesses great strength but also exercises sovereign control over all things. This power is not just powerful in itself; it exercises authority over creation.
---
Power
<font size="5">  
<p align= "left">
<strong>dunamis [δυναμις]</strong><br>
Paul uses several words to describe God's power in Ephesians 1:19. <em> “the exceeding greatness of his power to us-ward who believe, according to the working of his mighty power.” </em> He piles word after word to try and communicate his thoughts. <br>
<p align= "left">
Our english words dynamite and dynamic come from this greek word that means  <em>"inherent or raw power, the ability to do wonders, and that which overcomes any resistance"</em>
<p align= "left">
In today's world, there are several tremendously powerful explosives, such as C-4, Petin, and many others, that can overcome practically any obstacle. Explosives specialists have a popular saying: <em>"There is no problem so insurmountable that it cannot be solved by the proper application of high explosives." </em><br><p align= "left">
While explosives did not exist in ancient times, and Paul is clearly not thinking about such things, he is telling us that we have a force at our disposal that can overcome any obstacle to our Christian walk.
<p align= "left">


---

<font size="5">  
<p align= "left">
Dunamis is the word generally used by Paul of divine energy. It is most often translated as "miracles". Miracles are defined as an extraordinary work of God, generally though transcending the ordinary powers of Nature; an extraordinary event manifesting divine intervention in human affairs; an event that is contrary to the established laws of nature and attributed to a supernatural cause. 
  <p align= "left">
Scripture uses dunamis to describe deeds that exhibit the ability to function powerfully (deeds of power, miracles, wonders).  Sometimes dunamis is used to represent an entity or being that functions with remarkable power, especially being used to describe angel as powers. (Romans 8:38)  
---
<font size="5">  
 <p align= "left"> 
There is an instructive use of dunamis later in 2 Timothy where Paul describes men...  
  <p align= "left">
holding to a form of godliness, although they have denied its power (dunamis); and avoid such men as these. (2 Timothy 3:5) The point is that the so-called godliness of these men is a sham and devoid of any real divine power to break the power of Sin. Those who practice such deception enjoy the enjoy expressions of evangelical worship but they are violently at odds with the gospel’s internal effects of subduing sin and nurturing holiness. They lack the inherent ability or capability, the dunamis, because they lack the indwelling Spirit Who strengthens with power for which Paul prays in Ephesians 3:16.  The corollary is that those who possess the indwelling Spirit and divine dunamis have the inherent ability to wage victorious battle with the believer's three mortal enemies, the world, the flesh and the devil, all seeking to turn us from God and to self -- flesh -- and its ungodly, unholy attitudes and actions. One can readily see the importance of praying for believers to be strengthened with dunamis power through the Spirit in their inner man -  SermonIndex
---
<font size="5">  
<p align= "left">
In his letter to the Ephesians Paul did not pray that believers might be given divine power but that they might be aware of the divine power <u>they already possessed</u>.
<p align= "left">
Through Christ, we have access to the supernatural power of God, the same power (dunamis) that God used to bring Jesus back to life. God doesn't give us His power so we can use it for our own ends. He gives us His power so that we can help Him reach His purposes, for his glory. When we only trust Him and want to serve Him, He is both willing and "able to do exceedingly abundantly beyond all that we ask or think, according to the power that works within us."
<p align= "left">
<strong>John MacArthur</strong> states:
"resources we have from our heavenly Father are power and love and discipline, when we are vacillating and apprehensive, we can be sure it is because our focus is on ourselves and our own human resources rather than on the Lord and His available divine resources." If God has told us to do something this verse takes away the excuse "I can't do it, it's too hard". (MacArthur, J. 2 Timothy. Chicago, Ill.: Moody Press.) (Bolding added)

---
<font size="5">  
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>"The power of the Holy Spirit was not designed solely for the first-century church. Rather, all Christians are indwelt by the Spirit and thus have His power available (1Corinthians 6:19). However, living the Christian life under the Spirit’s power must not be thought of as simply allowing the Spirit to take control while the believer does nothing. Believers still must live the Christian life, though they do it through the Spirit’s power. Romans 8:13 (note) says, “if by the Spirit you put to death the deeds of the body, you will live.” It is you who are to put to death the sinful deeds of the body, but you are to do it through the Spirit’s power. Christians who struggle in their own strength to live the Christian life will fail. They must by faith appropriate daily the power of the Holy Spirit (Ro 8:4; 8:5 -see notes Ro 8:4; 8:5). Described practically, this means that believers trust the Spirit to empower them in specific instances such as sharing their faith with others, resisting temptation, being faithful, and so on. There is no secret formula that makes the Spirit’s power available. It is simply a reliance on the Spirit to help." <strong>(The Open Bible: New King James Version. Nashville: Thomas Nelson Publishers)</strong>
---
### 
toward us who believe who believe<!-- element style="background: floralwhite" -->
<font size="5">  
<p align= "left">
The direction of this power is to those who believe.  God intends for us to have access to this strength. Paul is praying that we, ourselves would know this strength and power first hand, as he himself has. <p align= "left">
	 <strong>Philippians 3:10</strong><em> that I may know him and the power of his resurrection, and may share his sufferings, becoming like him in his death,</em>
<p align= "left">
We have no justification for accepting a life of mediocrity or failure, and we have no justification for accepting a life of constant ups and downs, because it denies the very power that has been given to us.<br><p align= "left">
The apostle Paul wrote Timothy, <em>"For God hath not given us the spirit of fear; but of power, and of love, and of a sound mind" </em>(2 Timothy 1:7). Paul assures Timothy and other Christians who are "timid" that God will give them the courage to witness despite their natural reluctance.
---
  <font size="5">  
  <p align= "left">
<strong>Acts 1:8</strong><em> But you will receive power when the Holy Spirit has come upon you, and you will be my witnesses in Jerusalem and in all Judea and Samaria, and to the end of the earth.”</em>
<p align= "left">
<Strong>(Acts 4:33)</strong> <em>And with great power the apostles were giving their testimony to the resurrection of the Lord Jesus, and great grace was upon them all.</em>
<p align= "left">
<Strong>Romans 1:16</strong><em> For I am not ashamed of the gospel, for it is the  power of God for salvation to everyone who believes, to the Jew first and also to the Greek.</em>

---
Working /Power/Exercise/Energy
<font size="5">  
<p align= "left"> ἐνέργεια<br>
<strong>energeia</strong><br>
Thayer Definition:<br>1) working, efficiency<br>
1a) in the NT used only of superhuman power, whether of God or of the Devil<br>
Part of Speech: noun feminine<br>
A Related Word by Thayer’s/Strong’s Number: from G1756<br>
Total KJV Occurrences: 10<br>
working, 6 - Eph 1:19, Eph 3:7, Eph 4:16, Phi 3:21, Col 1:29, 2Th 2:9<br>
effectual, 2 - Eph 3:7, Eph 4:16<br>
  <p align= "left">
<strong>"Energeia" </strong>is used to describe the working or operation of God's power. It underscores the active and effective manifestation of God's power in the lives of believers. This term highlights the dynamic and transformative nature of God's power as it actively produces visible results and impacts their lives.

---
#### 

according to the working "energia" of his great might "kratos" <!-- element style="background: floralwhite" -->
<font size="5">  
<p align= "left">
This great immeasurable power is  at work within us. It is the energy within us by the Holy Spirit and is an active power, transformational power, "energy." This power works according to God's energy, not ours.  Our energy is short lived. God's energy is endless. He never tires. This speaks greatly to our own preservation.
<p align= "left">
<strong>Isaiah 40:28:</strong> "Have you not known? Have you not heard? The Lord is the everlasting God, the Creator of the ends of the earth. He does not faint or grow weary; his understanding is unsearchable."
<p align= "left">
<strong>Psalm 121:3-4 </strong>: "He will not let your foot be moved; he who keeps you will not slumber. Behold, he who keeps Israel will neither slumber nor sleep."
<p align= "left">
 This "energeia" working in us, is according to the working of God's  "Mighty  <strong>kratos."</strong>

---
Mighty, Great,
<font size="5">  
<p align= "left">
ἰσχύς<br>
<strong>ischus</strong><br>
Thayer Definition:<br>
1) ability, force, strength, might<br>
Part of Speech: noun feminine<br>
A Related Word by Thayer’s/Strong’s Number: from a derivative of is (force, compare eschon, a form of G2192)<br>
Total KJV Occurrences: 11<br>
strength, 4 - Mar 12:30, Mar 12:33, Luk 10:27, Rev 5:12<br>

Eng Adjective: 1. having or about showing great strength or force or intensity.
---
Power (KJV)/ Strength/Might/Dominion 
<font size="5">  
<p align= "left">
κράτος<br>
<strong>kratos</strong>
Thayer Definition:<br>
1) force, strength<br>
2) power, might: mighty with great power<br>
2a) a mighty deed, a work of power<br>
3) dominion<br>
Part of Speech: noun neuter<br>
Total KJV Occurrences: 12<br>
power, 6 - Eph 1:19, Col 1:10-11 (2), 1Ti 6:16, Heb 2:14, Rev 5:13<br>
<p align= "left">
<strong>Kratos (κράτος): </strong> "Kratos" is employed to emphasize the great might and dominion of God's power. It signifies His supreme authority and rule. In the context of believers, it signifies that God's power not only possesses great strength but also exercises sovereign control over all things. This power is not just powerful in itself; it exercises authority over creation.
---
<font size="5">  
<p align= "left">
The term "working", "energia" implies active and intentional involvement. When we consider "his great might," it points to the unparalleled strength and potency inherent to God. This power is unmatched and not bound by earthly limitations.
<p align= "left">
The context here is important to note. It's about the resurrection of Christ, a pivotal event in Christian history. The same power that raised Jesus from the dead is the very power at play in our lives as believers. It emphasizes God's ability to accomplish His purposes, especially in matters of salvation and transformation.
<p align= "left">
By using this phrase, the Apostle Paul is reminding us of the source of this power – it's not some abstract force, but it emanates from God Himself. This understanding reinforces the sovereignty of God, His authority, and His capability to bring about transformational change in our lives.
<p align= "left">
---
Do Not Quench The Holy Spirit
<font size="5">  
<p align= "left">
<strong>Philippians 2:12</strong><em>Therefore, my beloved, as you have always obeyed, so now, not only as in my presence but much more in my absence, work out your own salvation with fear and trembling, for it is God who works in you, both to will and to work for his good pleasure.</em>
<p align= "left">
The phrase "work out your own salvation" refers to the process of living out and applying the salvation that God has graciously given us. This involves aligning our actions, attitudes, and choices with the Word of God that transforms us.
The words "with fear and trembling" highlight sobriety, seriousness and humility. It's not a casual endeavor .
<p align= "left">
<em>...for it is God who works in you, both to will and to work for his good pleasure."</em>
<p align= "left">
Their is a partnership between our efforts and God's work in us. Our desire to live according to God's will and our ability to carry out that desire come from God Himself. This is a beautiful reminder that our spiritual growth is not solely dependent on our own strength; rather, it's a collaboration between our willingness and God's empowering presence as actively engage in the process of our sanctification. God does not overpower us, but he provides the power, we must use it, accept it by faith.
---
Attributes of God's Power Toward Us
<font size="5">  
<p align= "left">
 1. that he worked in Christ when he raised him from the dead <br>
 2. and seated him at his right hand in the heavenly places, <br>
 3. far above all rule and authority and power and dominion, <br>
 4. and above every name that is named, <br>
 5. not only in this age but also in the one to come. <br>
 6. And he put all things under his feet and gave him as head over all things to the church, <br>
 7.  which is his body, the fullness of him who fills all in all.<br>
---
<font size="6">  

1. that he worked (energeo, operated) in Christ when he raised him from the dead  <!-- element style="background: floralwhite" -->

<font size="4">  
<p align= "left">
<Strong>Raising Christ from the Dead:</strong> The resurrection of Jesus showcases God's unrivaled power over death itself. By raising Christ from the dead, God demonstrated His authority over the ultimate enemy, affirming His sovereignty and offering hope in eternal life.
<font size="4">  
<p align= "left">

| Verse Ref            | Verse Text                                                                                      |
|--------------------------|-----------------------|
| Acts 2:24           | "God raised him up, loosing the pangs of death, because it was not possible for him to be held by it." |
| Romans 6:9        | "We know that Christ, being raised from the dead, will never die again; death no longer has dominion over him." |
| 1 Cor. 15:55  | "O death, where is your victory? O death, where is your sting?"                               |
| Revelation 1:18    | "and the living one. I died, and behold I am alive forevermore, and I have the keys of Death and Hades." |
| Hebrews 2:14-15    | "Since therefore the children share in flesh and blood, he himself likewise partook of the same things, that through death he might destroy the one who has the power of death, that is, the devil, and deliver all those who through fear of death were subject to lifelong slavery." |
| John 11:25-26      | "Jesus said to her, 'I am the resurrection and the life. Whoever believes in me, though he die, yet shall he live, and everyone who lives and believes in me shall never die. Do you believe this?'" |


---
<font size="6">  

2. and seated him at his right hand in the heavenly places  <!-- element style="background: floralwhite" -->


<font size="5"> 
<p align= "left">
<strong>Seating Him at His Right Hand:</strong> Placing Christ at His right hand signifies the highest position of honor and authority. This highlights God's power to exalt and establish His Son as ruler over all things, both in the heavenly realms and on earth.
<font size="/5">  
<font size="4">
<p align= "left">
<strong><u>Position of Honor</u></strong>: The right hand has historically symbolized a place of honor, trust, and authority. By seating Christ at His right hand, God magnificently exalted His Son. This reflects God's unwavering love and the affirmation of Christ's unique role in God's plan of redemption.
<p align= "left">
<strong><u>Authority and Rulership:</u></strong> The right hand signifies not only honor but also authority. Placing Christ at the right hand emphasizes His authority over all creation, both in the spiritual realm and the physical world. 
<p align= "left">
<strong><u>Unity in the Godhead: </u></strong>This imagery also underscores the profound unity within the Trinity. The Father, Son, and Holy Spirit exist in perfect harmony, and seating Christ at the right hand of the Father showcases this divine unity.  God's power at work in perfect harmony.
<p align= "left">
<strong><u>Exaltation:</u></strong> The act of seating Christ at the right hand indicates His exaltation after His sacrificial work on Earth. This exaltation demonstrates God's power to lift up the obedient and faithful, showcasing His intention to glorify Christ above all.
<p align= "left">
<strong><u>Heavenly and Earthly Dominion:</u></strong> The imagery encompasses both heavenly and earthly realms. Christ's authority extends over angels, spiritual forces, and earthly powers. This reinforces God's power to establish a kingdom that transcends all boundaries.
---
<font size="5">  
<p align= "left">

| Verse Ref          | Verse Text                                                                                   |
|-------------------------|----------------------------------------------------------------------------------------------|
| Psalm 110:1      | "The Lord says to my Lord: 'Sit at my right hand, until I make your enemies your footstool.'" |
| Acts 2:33       | "Being therefore exalted at the right hand of God, and having received from the Father the promise of the Holy Spirit, he has poured out this that you yourselves are seeing and hearing." |
| Hebrews 1:3       | "He is the radiance of the glory of God and the exact imprint of his nature, and he upholds the universe by the word of his power. After making purification for sins, he sat down at the right hand of the Majesty on high." |
| Hebrews 10:12     | "But when Christ had offered for all time a single sacrifice for sins, he sat down at the right hand of God." |
| Hebrews 12:2     | "Looking to Jesus, the founder and perfecter of our faith, who for the joy that was set before him endured the cross, despising the shame, and is seated at the right hand of the throne of God." |
| 1 Peter 3:22    | "Who has gone into heaven and is at the right hand of God, with angels, authorities, and powers having been subjected to him." |

---
<font size="6"> 

3. far above all rule and authority and power and dominion,  <!-- element style="background: floralwhite" -->

<font size="5">  
<p align= "left">
<strong>Above All Rule, Authority, Power, and Dominion:</strong> God's power surpasses every form of earthly and spiritual authority. This assertion emphasizes His supremacy over any power, whether earthly rulers, spiritual forces, or cosmic entities.
<p align= "left">
<strong><u>Earthly Authority:</u></strong> God's power extends above all human rulers and authorities. Regardless of their status or influence, no earthly ruler can compare to the ultimate authority that God holds. His supremacy over human institutions demonstrates His control over the affairs of the world.
<p align= "left">
<strong><u>Spiritual Authority:</u></strong> God's power also surpasses all spiritual forces and entities. This includes both angels and fallen spiritual beings. By asserting His dominion over the spiritual realm, God showcases His unchallenged control over the unseen.
<p align= "left">
<strong><u>Cosmic Authority:</u></strong> The mention of "power" and "dominion" also extends to cosmic entities and elements and realms. Whether it's celestial bodies, cosmic forces, or any created thing in the universe, God's power reigns supreme. This speaks to His role as the Creator and Sustainer of all things.
<p align= "left">
In a world where various powers vie for influence, this truth provides unwavering assurance that God's supremacy reigns supreme above all.
---
<font size="5"> 
<p align= "left">

| Verse Ref              | Verse Text                                                                                           |
|-----------------------------|-----------------------------|
| Ephesians 1:21         | "Far above all rule and authority and power and dominion, and above every name that is named, not only in this age but also in the one to come." |
| Colossians 2:10        | "And you have been filled in him, who is the head of all rule and authority."                         |
| Colossians 2:15       | "He disarmed the rulers and authorities and put them to open shame, by triumphing over them in him." |
| 1 Peter 3:22          | "Who has gone into heaven and is at the right hand of God, with angels, authorities, and powers having been subjected to him." |

---
<font size="6">  

4. and above every name that is named,  <!-- element style="background: floralwhite" -->

 <font size="5">  

<p align= "left">
<strong>Above Every Name:</strong> God's power is not confined to the physical or spiritual realms alone. By being above every name, God reveals His dominion over all realms of existence and His absolute authority over every created being.
<font size="5"> 
<p align= "left">
<strong><u>Supreme Name:</u></strong> Christ's name is elevated above every other name, both human and divine. This signifies His unique identity and role as the Son of God and the Savior of humanity.
<p align= "left">
<strong><u>Divine Authority:</u></strong> This statement reflects Christ's divine authority and sovereignty. His name represents His character, nature, and role as the ultimate authority in the universe.
<p align= "left">
<strong><u>Unmatched Honor:</u> </strong> No name can rival the honor and glory attributed to Christ's name. His name encapsulates His redemptive work, sacrifice, and the salvation He offers to all who believe.
<p align= "left">
<strong><u>Salvation in His Name:</u> </strong> This exalted position also emphasizes the power and significance of Christ's name in matters of salvation. His name holds the authority to forgive sins and grant eternal life to believers.
<p align= "left">

---
<font size="5">  

<p align= "left">

| Verse Ref             | Verse Text                                                                                   |
|-----------------------------|----------------------------------------------------------------------------------------------|
| Ephesians 1:21 (ESV)         | "Far above all rule and authority and power and dominion, and above every name that is named, not only in this age but also in the one to come." |
| Philippians 2:9-10 (ESV)     | "Therefore God has highly exalted him and bestowed on him the name that is above every name, so that at the name of Jesus every knee should bow, in heaven and on earth and under the earth..." |

---
<font size="6">  

5. not only in this age but also in the one to come.   <!-- element style="background: floralwhite" -->
<font size="5">  

<p align= "left">
<strong>Eternal Reign:</strong>The mention of "this age" and "the one to come" underscores the eternal nature of God's power. His authority spans beyond the limitations of time, demonstrating His unchanging reign throughout all ages.
<font size="5">  
<p align= "left">
<strong><u>Temporal and Eternal Distinction:</u> </strong> The mention of "this age" refers to the current state of the world, while "the one to come" pertains to the future state of existence. By spanning both temporal dimensions, God's authority remains unshaken and uninterrupted, reflecting His permanence.
<p align= "left">
<strong><u>Consistency Through Time:</u></strong>  God's authority and power are not subject to change or limitation by time. His reign remains consistent across all ages, ensuring that His plans and purposes unfold as intended, regardless of the chronological context.
<p align= "left">
<strong><u>Unchanging Dominion:</u></strong> The eternal nature of God's power underscores His unchanging dominion. This assures us that His authority doesn't waver with the passing of time, providing stability and confidence in an ever-changing world.
<p align= "left">
<strong><u>Complete Authority:</u></strong>  This eternal reign encompasses all aspects of existence—past, present, and future. It affirms that God's authority isn't limited to a particular era or phase but extends to every corner of creation.

---
<font size="5">  

<p align= "left">

| Verse Reference              | Verse Text                                                                                   |
|-----------------------------|----------------------------------------------------------------------------------------------|
| Ephesians 1:21         | "Far above all rule and authority and power and dominion, and above every name that is named, not only in this age but also in the one to come." |
| Hebrews 13:8         | "Jesus Christ is the same yesterday and today and forever."                                  |
| Revelation 22:13     | "I am the Alpha and the Omega, the first and the last, the beginning and the end."          |
| Revelation 11:15       | "Then the seventh angel blew his trumpet, and there were loud voices in heaven, saying, 'The kingdom of the world has become the kingdom of our Lord and of his Christ, and he shall reign forever and ever.'" |

---
<font size="6">  

6. and he put all things under his feet and gave him as head over all things to the church,    <!-- element style="background: floralwhite" -->
<font size="5">  

<p align= "left">
<strong>Head Over All Things to the Church:</strong> By making Christ the head over all things to the Church, God displays His power in orchestrating the unity and purpose of His people. This reflects His ability to align all things under Christ's leadership.
<font size="4">  
<p align= "left">
<strong><u>Divine Authority:</u> </strong>Placing Christ as the head over all things to the Church affirms His authority. Just as the head directs the body, Christ guides and directs the Church with divine wisdom and leadership.<p><p align= "left">
<strong><u>Unity and Purpose: </u></strong>The image of Christ as the head emphasizes the unity of believers as one body under His leadership. This unity transcends divisions and aligns believers toward a common purpose of glorifying God and carrying out His mission.</p><p align= "left">
<strong><u>God's Sovereign Plan:</u></strong> The placement of Christ as the head signifies God's sovereign design for His Church. It reveals God's power to orchestrate events and circumstances to fulfill His purposes through Christ's guidance.
<p><p align= "left">
<strong><u>Alignment with God's Will: </u></strong>By aligning all things under Christ's leadership, God's power is revealed in His ability to align the Church with His will. This ensures that every aspect of the Church's existence contributes to His divine plan.
<p><p align= "left">
<strong><u>Harmonious Function: </u></strong>Just as different parts of the body work harmoniously under the direction of the head, the Church functions harmoniously as Christ's body, working together for God's glory.
---
<font size="5"> 
<p align= "Left">

| Verse Ref              | Verse Text                                                                                   |
|-----------------------------|----------------------------------------------------------------------------------------------|
| Ephesians 1:22          | "And he put all things under his feet and gave him as head over all things to the church..." |
| Colossians 1:18        | "And he is the head of the body, the church. He is the beginning, the firstborn from the dead, that in everything he might be preeminent." |
| Colossians 2:10      | "And you have been filled in him, who is the head of all rule and authority."                 |
| Ephesians 4:15-16       | "Rather, speaking the truth in love, we are to grow up in every way into him who is the head, into Christ, from whom the whole body, joined and held together by every joint with which it is equipped, when each part is working properly, makes the body grow so that it builds itself up in love." |
| 1 Cor.11:3    | "But I want you to understand that the head of every man is Christ, the head of a wife is her husband, and the head of Christ is God." |

---
<font size="6">  

7. which is his body, the fullness of him who fills all in all.   <!-- element style="background: floralwhite" -->
<font size="5">  

<p align= "left">
<strong>The Church as His Body:</strong> Referring to the Church as Christ's body underscores the connection between Christ and believers. This imagery highlights God's power in uniting diverse individuals into a harmonious and purposeful entity, reflecting His wisdom and love.
<font size="4">  
<p align= "left">
<strong><u>Unity with Christ:</u></strong> Describing the Church as Christ's body signifies the deep spiritual connection between Christ and believers. Just as the head and the body are intricately connected, so are Christ and His followers. This unity is central to the Church's identity.
<p align= "left">
<strong><u>Completeness in Christ: </u></strong>The Church is referred to as "the fullness of him." This implies that the Church embodies the fulfillment of God's redemptive plan through Christ. Believers, collectively, make up the fullness of Christ's mission and purpose on Earth.
<p align= "left">
<strong><u>Divine Presence:</u> </strong>Who fills all in all" underscores Christ's omnipresence and his complete authority over all aspects of creation. It reaffirms the truth that Christ's influence extends to every corner of the universe, making His presence felt in all things.
<p align= "left">
<strong><u>Reflecting God's Glory: </u></strong>The Church, as the fullness of Christ, reflects His character, attributes, and mission to the world. It serves as a living testimony of God's redemptive work and His power to transform lives.
<p align= "left">
<strong><u>Collective Witness:</u></strong> This phrase emphasizes the vital role of the Church in manifesting Christ's glory and spreading the message of the Gospel. The Church, through its collective identity, plays a significant role in representing Christ to the world.
---
<font size="5">  
<p align= "left">

| Verse Ref.              | Verse Text                                                                                   |
|-----------------------------|----------------------------------------------------------------------------------------------|
| Ephesians 1:22-23     | "And he put all things under his feet and gave him as head over all things to the church, which is his body, the fullness of him who fills all in all." |
| Colossians 1:18-19      | "And he is the head of the body, the church. He is the beginning, the firstborn from the dead, that in everything he might be preeminent. For in him all the fullness of God was pleased to dwell..." |
| Colossians 2:9-10      | "For in him the whole fullness of deity dwells bodily, and you have been filled in him, who is the head of all rule and authority." |

---
END READING
## Ephesians 1:19-23 ESV
<font size="5"> 
<p align= "Left">
 <em> <p align="justify">19 and what is the immeasurable greatness of his power toward us who believe, according to the working of his great might 20 that he worked in Christ when he raised him from the dead and seated him at his right hand in the heavenly places, 21 far above all rule and authority and power and dominion, and above every name that is named, not only in this age but also in the one to come. 22 And he put all things under his feet and gave him as head over all things to the church, 23 which is his body, the fullness of him who fills all in all.</em>   
---

![[Image Closing Prayer Pink.png]]

---