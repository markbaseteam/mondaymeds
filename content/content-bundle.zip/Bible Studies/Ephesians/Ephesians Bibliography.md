https://gracegems.org/19/Philpot_eph02.htm

Meditations on Ephesians- Henry Law
https://gracegems.org/17/Law-eph.htm