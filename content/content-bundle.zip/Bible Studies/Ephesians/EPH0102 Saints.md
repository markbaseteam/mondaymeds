Text:  [[Ephes-01#v2|Ephesians 1:2]]

## Overview
To the Saints
			who are in Ephesus
			and who are faithful
								in Christ Jesus
   Grace to you
    Peace (to you)
	     from God our Father
	     and 
	     the Lord Jesus Christ
	 

## To the saints...who are faithful in Christ Jesus

### who are in Ephesus
-  Circular letter [[EPH0000 Ephesians Survey]]

This letter is addressed to the Saints.

"Saints" is used 42x in Paul's Epistles. It was one of Paul's favorite terms to use to address the Church. It is used 61x in New Testament in various forms.

It is important for us to understand who the Saints are because not only is this entire book is directed to them but all the promises of God. Their names are written in the Book of Life.  They are the ones who enjoy the rich blessings of this letter when Paul says "we" and "us".

One of the primary needs of churches today is understand what it means to be a "Christian".

What does it mean to be a Saint? A Christian? 
	- Does it mean that we try to live a good life?
	- That we believe doctrinal truths? All the creeds?
	- A person who believes God exists and agrees Jesus was the Son of God?
	- Is it someone that has gone through some procedural steps?
	- Is a Christian someone who has been baptized? 
	- Someone that has passed a church membership course?
	- A person with a tradition, grew up in the church, had Christian parents, born in America?
	- Anyone who is willing to identify themselves as a Christian?
	- Someone who has spent their life in the church, teaching Sunday School, active in the church?
	- A person who is heavy in community service, tithes regular?
	- Someone who has faith that they are saved?

A false view of what it means to be a Christian or a Saint could lead to a false sense of assurance, an inoculation or immunization against the gospel.  Billy Graham once stated on national television that 85% of church members were lost. I am not sure how accurate this % is or how he came to this % but I have no doubt that a great % of church membership is made up of the unsaved. My opinion is based on:
	1. Biblical illiteracy within the church,
	2. Growth of seeker sensitive churches/Open doors, unselective
	3. Believers comfortable in sin/Lack of holiness, spiritual immaturity, 
	4. Lack of value of Jesus Christ/Love for sin
	5. Lack of prayerlessness, Core function of the church, house of prayer

#### False Views:
##### To Be Saint is NOT What Roman Catholic Church Teaches - 

> *How right Warren Wiersbe is when he writes, “No word in the NT has suffered more than this word saint. Even the dictionary defines a saint as a ‘person officially recognized for holiness of life.- [[Warren Wiersbe]]
> 
> In secular Greek the word hagios [ἁγιος] (G40 [ἅγιος]) meant “to stand in awe of or be devoted to the gods.” This word came right out of pagan Greek religion, but Paul had to use it since there was no other word to use. So, the word was originally used of a person who was devoted to a god. One such as that was looked upon as a “holy one” or a “holy man.”
> 
> That view is true of Roman Catholicism, which teaches that to become a “saint,” one first has to die. The person is then nominated for the position, after which one or more “judicial inquiries” take place, where the nominating advocate pleads the virtues of the nominee and gives proof of his or her worthiness. One such proof is that the nominee had to be responsible for at least two (and, in some cases, as many as four) miracles. Then his life is examined to see if it was “holy enough to be officially recognized by canonization.” But all that flies in the face of Scripture and denies a fundamental principal of being a Christian.
> 
> Paul, by the inspiration of the Holy Spirit, lifted the word hagios [ἁγιος] to a new level of meaning: “to set apart or be separate.” The same word is also translated holy and sanctification. ===While some say a saint is dead, God says a saint is alive. Being a saint is not a matter of achievement or performance; it is a matter of position. It’s not based on what we have done, but who we are in Christ. It’s not dependent upon our works, but upon His grace===.*
 ________________________
> 1 The Bible Exposition Commentary (Wheaton: Scripture Press Publications, 1989). Electronic edition by Logos Library Systems, comment on Ephesians 1:1.

##### Worldly View
The common phrase: "That person is a saint" or "I ain't no saint"

In these cases "saint" is one who does good deeds, lots of charity work. They are considered a "good" person. They can be very caring, very kind and very generous. 
These are certainly fruits of a genuine saint, but do not necessarily a biblical saint. One primary difference is the motive, does one do it for the glory of God or glory of self? Does one do it for the love of the world or for love of God? Does one do it because of guilt, because they are passive and easily manipulated by others and used by others? They don't want to appear as a bad person or selfish or just can't say no.


### Biblical View

**Saints** - G40 ἅγιος hagios (ha'-ǰiy-os) adj.
1. holy (set apart by Yahweh God unto himself and apart from the world).
2. (of a person) a holy one.
3. (physically or ceremonially) clean.
4. (morally) blameless.

The bible uses Saints 82 times, 21 in the Old Testament and 61  in the New Testament. 

**Every Christian is a saint.** 
All who are in Christ are designated saints, his holy and set apart ones, blameless before him. You cannot be "in Christ" and not be considered a saint by the will of God.

##### Every Saint has been cleansed, sanctified.
We are cleansed from the guilt of sin.
 In the sight of God, we are holy, based on Christ's work and God's grace.
We are cleansed from the pollution of sin.
We are no longer slaves to sin.

We are saved from sin externally and internally. We are no longer a sin factory.

##### Saints are Separated, Set-Apart, Chosen Ones
God separated us from the world and put us in his family, his peculiar people, called The Church.

**1 Cor. 1:2**
![[1 Cor-01#v2]]

**Eph 4:11-12**
![[Ephes-04#v11]]
![[Ephes-04#v12]]

**A Saint is separated from the world.**
Gal  6:14
![[Gal-06#v14]]

Our relationship to God and to the world has been made forever different because of our relationship to God. Our relationship to sin is forever different.  We no longer see the world as we once did.  The world no longer knows how to relate with us. It no longer understands us or our ways.  ===Saints have a reconciled relationship with the God, fellowship with God and a new broken relationship with the world, no fellowship. ===Have you had this happen to you?

John 15:19
![[John-15#v19]]

Saints are the salt of the earth. They have a preserving influence.

##### Faithful ones -  
Faithfulness is an attribute of God's saints.  They are steadfast. They persevere. The Trustworthy Ones. Though they, the righteous fall seven times they rise again, Prov 24:!6.

1. trusty, faithful; of persons who show themselves faithful in the transaction of business, the execution of commands, or the discharge of official duties: δοῦλος, [[Matt-24#v45|Matthew 24:45]]; [[Matt-25#v21|Matthew 25:21]] [[Matt-25#v23|Matt 25:23]] 
2. trusting (as one trusting in God, that is, Yahweh or His Son Jesus), trustful. [[Ps-31#v14|Psa 31:14]]

##### In Christ - 
 The saints are located in Christ, like they are located in Ephesus.  The Saints abide in him. They abide in his word, in his will, in his way.  "In Christ" we are going to see are all the blessings and richness of God. They cannot be received apart from Christ, outside of Christ.
	
### Our Identity as Saints, The Holy Ones, Christians
In Sunday School Tim mentioned the importance of our identity as we studied [[1 Pet-02#v1|1 Peter 2:1-3 ]] ; [[Ephes-05#v1|Eph 5:1-21]]

He stressed how we should not identify our ourselves by our sinful works,  hypocrites, malice, slanderers, liars, adulterers.  Instead we need to learn to identify ourselves as imitators of God,  born again, child of God, loved among the brethren, blessed, the Elect, the chosen, saints. 

How comfortable would you be in calling yourself a Saint?

Most of us would be very uncomfortable referring to ourselves as saints. There is good reason for that since we do not take this title upon ourselves but God bestows it on us like a crown on our heads and it comes with a very high calling and responsibility that we are born into and must walk worthy of. 

**Psalms 16:3**
![[Ps-16#v3]]

**Psalms 97:10**
![[Ps-97#v10]]

Over and over again those who are faithful to God are called saints. We are a work in progress.  We do not see ourselves as saints yet, but God sees Christ. We are "in Him". We are saints, holy ones because of our relationship and union to Christ. Much like a prince or a princess is one because of their relationship to a King or Queen. We are born of God into this role and high calling.

**By the Will of God**
We do not designate ourselves as Saints, like Paul, we too are called and chosen to the position and high calling of being a "Saint"

See [[Ephes-01#v4|Eph 1:4 - "According as he has chosen us in him before the foundation of the world, that we should be holy (G40 - Hagios) and without blame before him in love."]]

In verse 4, we can see that God chose us to be saints, to be holy and blameless before him.  
![[Pasted image 20230515081413.png]]

Meditate on this truth.  It is God himself who has set us apart. Who has placed us in  Christ.   We should feel the weight of responsibility of being called a saint by God as Paul felt the weight of responsibility in being called an Apostle of Jesus Christ by the will of God.

We as baptized, faith-professing believers,  identify ourselves as "Christians".  Saints were first called "Christians" at Antioch [[Acts-11#v26|Acts 11:26]].  But I think much of the weight that should be with the title  "Christian" has been lost to us in our generation. Many who are born in the United States of America, call themselves Christians but are not faithful to Christ at all.  I know "Christians" who never attend church, never read their bible, their only prayers are self-centered prayers to fulfill worldly desires and hold no kingdom interest, they give no consideration to sin or holiness. But if you were to ask them, yes, they self-identify as Christian.

In this regard, we should see ourselves as saints that we may as [[Ephes-04#v1|Walk in a manner worthy of the calling to which you have been called]]

I am a manager at work. With my role as manager, I often feel the weight of responsibility. I can't always complain verbally. I can't show my frustration or anger. I can't speak my mind downward.  This is common with all roles of of leadership or offices. Judges, Teachers, Kings/Queens, Princesses, Pastors, Father's, Mothers.

Women & Mothers: [[The True Woman]] [[Sermon Notes Keeper of the Springs]]

Understanding what the word "saint" means enables us to pray more urgently with Paul in the last part of Ephesians chapter 1:
> ***Ephesians 1:15-20**
> 15 For this reason, because I have heard of your faith in the Lord Jesus and your love toward all the saints, 16 I do not cease to give thanks for you, remembering you in my prayers, 17 that the God of our Lord Jesus Christ, the Father of glory, may give you the Spirit of wisdom and of revelation in the knowledge of him, 18 having the eyes of your hearts enlightened, ===that you may know what is the hope to which he has called you, what are the riches of his glorious inheritance in the saints, 19 and what is the immeasurable greatness of his power toward us who believe, according to the working of his great might ===20 that he worked in Christ when he raised him from the dead and seated him at his right hand in the heavenly places,


## Grace and Peace to you from God the Father and Jesus Christ the Son

### Grace - 13x in Ephesians
It is the customary form of salutation in nearly all the apostolic epistles. However, it is important to note that that when Paul says, "Grace to you", Paul is not referring to saving grace, for these 'saints' are already saved and they already have peace and reconciliation with God the father.  There are [[9 Types of Grace| different types of grace]]This is the grace that is empowering and effectual, sufficient for all our needs as found in :

**KJV**
 to be committed or commended to the protecting and helping favor of God,[[Acts-14#v26|Acts 14:26]]; [[Acts-15#v40|Acts 15:40]]

**Webster**
> *Appropriately, the free unmerited love and favor of God, ===the spring and source of all the benefits men receive from him.===
>  And if by grace, then it is no more of works. Rom 11.
> 
> Favorable influence of God; divine influence or the influence of the spirit, in renewing the heart and restraining from sin.
>  My grace is sufficient for thee. 2 Cor 12.*

**Bible Dictionary**
> *Overwhelmingly in the letters of Paul God is the subject of grace. He gives it freely and without merit. Hence the many different phrases connected with grace: the grace of God ( [Rom 5:15](https://www.biblestudytools.com/romans/5-15.html) ), the grace of our Lord Jesus Christ ( [2 Cor 13:14](https://www.biblestudytools.com/2-corinthians/13-14.html) ), and the like. Sometimes this is explicitly stated, as in Ephesians 4:7: "to each one of us grace has been given as Christ apportioned it."
> 
> Interestingly, Paul sometimes mentions the gift of grace from God using alongside it language that speaks of human responsibility. So in Romans 15:16, Paul speaks of "the grace God gave me to be a minister of Christ Jesus to the Gentiles, with the priestly duty of proclaiming the gospel of God." ===Grace, then, is the power with which the human being then performs his or her gifted task. ===This is even more clearly seen in Paul's self-defense in Galatians. In one of the most truly dialectic passages in Scripture, Paul proclaims that he has died, yet lives, yet not he but Christ lives, yet he lives in the body by faith. He then argues that in living "by faith in the Son of God, who loved me and gave himself for me, " that he is not "setting aside the grace of God" ( [2:20-21](https://www.biblestudytools.com/passage/?q=Galatians+2:20-21) )*. . [Bible Dictionary](https://www.biblestudytools.com/dictionary/grace/)

**2 Cor. 12:9**
![[2 Cor-12#v9|2 Cor 12:9]]

**2 Cor. 9:8**
![[2 Cor-09#v8]]
**1 Cor. 15:10**
![[1 Cor-15#v10]]
**Acts 4:33**
![[Acts-04#v33]]

  ===**John 1:16** - *For from his fullness we have all received, grace upon grace.*===

If we are walk like saints, to walk in a manner worthy of the calling in which we have have been called, we are in desperate need of both grace and peace. We cannot walk the Christian life on our own. Praying for God's grace in our lives and in the lives of the saints, should be our daily prayer.

#### Grace in Ephesians
**Eph 1:6**   to the praise of his glorious grace, with which he has blessed us in the Beloved.

**Eph 1:7**    In him we have redemption through his blood, the forgiveness of our trespasses, according to the riches of his grace,

**Eph 2:5**   - even when we were dead in our trespasses, made us alive together with Christ—by grace you have been saved—

**Eph 2:7** - so that in the coming ages he might show the immeasurable riches of his grace in kindness toward us in Christ Jesus.

**Eph 2:8**  -  For by grace you have been saved through faith. And this is not your own doing; it is the gift of God,

**Eph 3:2** -   assuming that you have heard of the stewardship of God's grace that was given to me for you,

**Eph 3:7-8** - Of this gospel I was made a minister according to the gift of God's grace, which was given me by the working of his power.   To me, though I am the very least of all the saints, this grace was given, to preach to the Gentiles the unsearchable riches of Christ,

**Eph. 4:7**   -  But grace was given to each one of us according to the measure of Christ's gift.

**Eph 4:29**   - Let no corrupting talk come out of your mouths, but only such as is good for building up, as fits the occasion, that it may give grace to those who hear.

**Eph 6:24** - Grace be with all who love our Lord Jesus Christ with love incorruptible.

---

**1 Peter2:9**  But you are a chosen race, a royal priesthood, a holy nation, a people for his own possession, that you may proclaim the excellencies of him who called you out of darkness into his marvelous light.

---


### Peace  - 7x in Ephesians
To be a saint is to enjoy not only an outpouring of grace but also <u>abundant</u> peace in our lives.

There is no peace without grace first.

This is the wonderful peace of God that protects our hearts as found in [[Phil-04#v7|Phil 4:7 - And the peace of God, which surpasses all understanding, will guard your hearts and your minds in Christ Jesus.]]

**John 16:33** - I have said these things to you, that in me you may have peace. In the world you will have tribulation. But take heart; I have overcome the world.”

**Gal 5:22** But the fruit of the Spirit is love, joy, peace, patience, kindness, goodness, faithfulness,

**Eph 2:14-15** -   For he himself is our peace, who has made us both one and has broken down in his flesh the dividing wall of hostility by abolishing the law of commandments expressed in ordinances, that he might create in himself one new man in place of the two, so making peace,

**Eph 2:17** -   And he came and preached peace to you who were far off and peace to those who were near. 

Much of our inner peace comes from faith in God's future grace. 

**Future Grace - Quotes from John Piper**
> *The only life I have left is future life. The past is not in my hands to offer or alter. It is gone. Not even God will change the past. All the expectations of God are future expectations. All the possibilities of faith and love are future possibilities. And all the power that touches me with help to live in love is future power. As precious as the bygone blessings of God may be, if he leaves me only with the memory of those, and not with the promise of more, I will be undone. My hope for future goodness and future glory is future grace. pg 65* [[Future Grace - John Piper]]
> 
> *What do we learn from Paul's unbroken patter of ending his letters in this way ("Grace be to you", "Grace be with you") We learn that grace is an unmistakable priority in the Christian life. We learn that it is from God the Father and the Lord Jesus Christ, that it can come through people. We learn that grace is ready to flow to us every time we take up the inspired Scriptures to read them. We learn that grace will abide with us when we lay the Bible down and go about our daily living. pg 66* [[Future Grace - John Piper]]
> 
> *In other words, we learn that grace is not merely a past reality but a future one. Every time I reach for the Bible, God's grace is a reality that will flow to me. Every time I put the Bible down and go about my business, God's grace will go with me. This is what I mean by future grace.* [[Future Grace - John Piper]]
> 
> *The reason that future grace is so important is that everything in the Christian life depends on it. You can't be a Chritian without faith in future grace.  Jesus said "The way is narrow that leads to life, and few are those who find it" (Matthew 7:14) . Every turn in that narrow way is planned by future grace and empowered by future grace. At every point on the way, true saints sing, "Tis grace has brought me safe thus far, and grace that will lead me home" Every glance backward sparks gratitude for bygone grace, every look forward casts the soul onto faith in future grace. pg 67* [[Future Grace - John Piper]]
> 
> *Why is anxiety about the future a form of pride? God gives the answer: "I-the Lord, your Maker - I am He who comforts you, who promises to take care of you; [[Isa-51#v12|Isa 51:12-13]] and those who threaten you are mere men who will die" So your fear must mean that you do not trust Me. You must think that your protection hangs on you. And even though you are not sure that your own resources will take care of you, yet you opt for fragile self-reliance, rather than faith in future grace. So all your trembling - weak as it is - reveals pride. The remedy? Turn from self-reliance to God-reliance, and put your faith in the all sufficient power of future grace. pg 96-96* [[Future Grace - John Piper]]

Genuine peace will flow as our faith in God's future grace towards us grows.

### From God The Father

^c15ef4

===These come from God the Father and Jesus Christ the Son.=== They are not from Paul himself. Most greetings would give a blessing from it's author. But Paul is distributing blessings given from God.  ^6b463b

It's hard to imagine greater blessings then we already received in our salvation by Christ and in receiving God's grace and peace in our lives, but in the next several verses we are going to see the riches we have in Christ where we have been blessed with *every* spiritual blessing.

God the Father is  the source and Jesus is the Lord of all the father's treasuries.

**James 1:17**
![[James-01#v17]]

All the treasuries of God has been placed under Christ as mediator and as administrator and dispenser. 

Joseph was made Lord over all of Egypt to dispense the grain to the people so they might live.  How relieved were Joseph's brothers when they discovered the one who was Lord over all the granaries of Egypt was their brother. 

How can we be sure that our brother, Jesus Christ, will show us mercy? He died for us,  so that we could come to the source.  If we don't come,  if we don't avail yourself of your privileges and special rights, but instead choose to go without in poverty, how we spurn God's hand and name. 

God does not meet your need according to your need,  he meets your need according to his infinite riches and glory. 

