<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->
---
Opening Prayer
==


---
Ephesians 2:4-10
<font size="6">  
<p align= "Justify">
<font color="#366092">4 But God, being rich in mercy, because of the great love with which he loved us, </font>5 even when we were dead in our trespasses, made us alive together with Christ—by grace you have been saved— 6 and raised us up with him and seated us with him in the heavenly places in Christ Jesus, 7 so that in the coming ages he might show the immeasurable riches of his grace in kindness toward us in Christ Jesus. 8 For by grace you have been saved through faith. And this is not your own doing; it is the gift of God, 9 not a result of works, so that no one may boast. 10 For we are his workmanship, created in Christ Jesus for good works, which God prepared beforehand, that we should walk in them.
---
Review Last Week
<font size="6">  
 Man's Condition in Sin (Verses 1-3)
 
- Dead in Transgressions and Sins (Verse 1)
- Following the Ways of the World (Verse 2)
    1. Influenced by the 'Ruler of the Kingdom of the Air'
    2. Following the Spirit at Work in the Disobedient
- Nature of Wrath (Verse 3)
    1. Living in the Passions of the Flesh
    2. Objects of Divine Wrath by Nature
---
<font size="6">  
<p align= "left">
Ephesians 2:1-3 which showed our previous condition of being dead in our sins and trespasses. In our spiritually dead condition we once followed the ways of this world, we followed the prince of the power of the air, who is the spirit who is now at work in the sons of disobedience, among whom we too once lived and obeyed the passions or lusts of the flesh carried out the desires of the body and our mind and were by nature, children of wrath, like the rest of mankind.

<p align= "left">We came from the same dirt. We carried the same nature. We followed the same spirit and were once dead in our sins and trespasses. We have nothing to boast about except God <Strong>or but God... </strong>
---
But God
<font size="6">  
<p align= "left">
Not: "but we woke up and came to our senses."<br>
Not: "we made a good choice"<br>
Not: "we wised up..."<br>
<p align= "left">
"But God..."<br>
<p align= "left">
This is where our story turns on its hinges and changes direction from a hopeless situation of our being dead in our sins and trespasses, following the course of this world, following the prince of the power of the air, living in the passions of the flesh<br> to a marvelous redemption...but God... <br>
<p align= "left">
God Himself was the acting agent. God showed us great mercy we are going to see and it had nothing to do with us, <em>we contributed nothing to our salvation except the sin that made it necessary.</em>
---
But God, being rich in mercy...
<font size="6">  
<p align= "left">
God is "<em>plousios</em>", rich, wealthy, abounding in mercy "eleos", kindness, compassion, pity or good will towards the miserable and the afflicted, joined with a desire to help them. A simple definition of mercy is <em> “the withholding of deserved punishment and relieving distress."</em>
<p align= "left">
<strong>Mercy</strong> – the withholding of what is deserved (death and hell). <br>
<strong>Grace</strong> – the bestowing of what is not deserved (life and heaven). <br>
<p align= "left">
 “Mercy pities. Grace pardons.”
<p align= "left">
Mercy and grace are at the core of our Christian faith. God's <Strong>mercy </strong>means He doesn't give us the punishment we deserve for our sins, while <strong>grace </strong> means He gives us undeserved favor and blessings. Through God's mercy and grace, we find salvation in Christ. 
---
Salvation Not Performance Based - Not of Works
<font size="6">  
<p align= "left">
When we recognize God's mercy and grace, it reminds us that our relationship with Him is not based on our performance but on His love. We don't earn His favor; He freely bestows it upon us. <strong>We do not and never will deserve God's mercy</strong>, even if we were able to live a perfect life from the moment of our salvation forward, we still would not deserve God's grace and mercy, we deserve wrath.  We were dead in our sins and trespasses. (Ephesians 1:3) 
<p align= "left">God is under no requirement or obligation to extend mercy to us. Justice yes, Mercy no. Mercy is extended to us by the grace of God. Mercy is never expected or merited/deserved.
<p align= "left">

---
We will Never Deserve Mercy
<font size="6"> 
<p align= "left">
 We have to remind ourselves of this truth over and over because our fleshly nature has an alignment issue in thinking we earn God's mercy and grace.  
<p align= "left">Recognizing God's mercy and grace humbles us, as we realize our dependence on Him. It prevents self-righteousness and encourages a spirit of humility and dependence on God.
 <p align= "left">Recognizing God's mercy and grace is not earned also encourages us because God will never love us more or less then He loves us right now. He may be pleased and less pleased with our actions, but his love is constant. 
  <p align= "left">
  Meditate on this truth: <strong> You cannot increase God's love for you nor can you decrease it.</strong>
---
God's Immutability
<font size="6">  
<p align= "Left">
One of the attributes of God that we discussed earlier in Ephesians was God's immutability.  Immutability means that God's attributes, including His love, do not change or fluctuate. This concept is derived from passages like Malachi 3:6, which states, "For I the LORD do not change."
<p align= "Left">
God's love is not based on our merit or actions but is rooted in His eternal nature. It's a comforting and reassuring belief that emphasizes God's faithfulness and unconditional love for His people, regardless of our circumstances or behavior.
---
Man's Mutability
<font size="5"> 
<p align= "Left">
However, while God's love remains constant, our experience of His love and our relationship with Him can vary depending on our obedience, faith, and closeness to Him.  We are prone to change. There may be times when we are not "experiencing" the love of God as we would wish, we do not "feel like" He loves us.  
<p align= "Left">
There are many times when I may feel like my husband doesn't love me and when he feels like I don't love him. Usually it has to do with a negative experience. This is why "experiences" though they are "lovely" and though they are desired, experiences are subjective in our interpretation of them, and can be misleading or influenced by our human sinfulness. Our feelings, experiences, must be subject to the ultimate authority of scripture which is ultimate source of truth and the backbone of our reality. 
<p align= "Left">
<strong> 2 Cor 10:5 </strong>- <em>We destroy arguments and every lofty opinion raised against the knowledge of God, and take every thought captive to obey Christ.</em>
---
God is Merciful
<font size="5">  
<p align= "left">

|**Bible Verse**|**Bible Text (ESV)**|
|---|---|
|Psalm 86:15|"But you, O Lord, are a God merciful and gracious, slow to anger and abounding in steadfast love and faithfulness."|
|Lamentations 3:22-23|"The steadfast love of the Lord never ceases; his mercies never come to an end; they are new every morning; great is your faithfulness."|
|Titus 3:5|"He saved us, not because of works done by us in righteousness, but according to his own mercy, by the washing of regeneration and renewal of the Holy Spirit."|
|Hebrews 4:16|"Let us then with confidence draw near to the throne of grace, that we may receive mercy and find grace to help in time of need."|
|1 Peter 1:3|"Blessed be the God and Father of our Lord Jesus Christ! According to his great mercy, he has caused us to be born again to a living hope through the resurrection of Jesus Christ from the dead."|
|Jude 1:21|"Keep yourselves in the love of God, waiting for the mercy of our Lord Jesus Christ that leads to eternal life."|

---
The Cross Balanced Mercy & Justice Perfectly
<font size="5">  
<p align= "left">
The cross is where justice and mercy intersect. D.A. Carson stated "Do you wish to see God’s love? Look at the cross. Do you wish to see God’s wrath? Look at the cross."  "It's at this point that God's justice is satisfied and mercy displayed.  It's a beautiful harmony of God's attributes—His justice and His love.

| Justice at the Cross | Mercy at the Cross |
| -------------------- | ------------------ |
| At the cross, we see God's justice on full display. The Bible teaches that sin incurs a debt—a debt of punishment. God, being perfectly just, cannot simply overlook sin. He must address it. In the Old Testament, sacrifices were offered to temporarily cover sins, but they couldn't fully satisfy God's justice. The cross, however, is where ultimate justice is served. Jesus, the sinless Son of God, willingly took upon Himself the sins of humanity. On the cross, He bore the penalty and wrath that sin deserved. This act demonstrates that God does not compromise His justice but fully upholds it.                     |                  Simultaneously, the cross is the ultimate expression of God's mercy. Instead of demanding that we pay the price for our sins, God provided a way for us to be reconciled to Him. He offered His Son as a sacrifice to atone for our sins. This act of substitutionary atonement is an extraordinary manifestation of divine mercy. It's God's willingness to forgive and provide a path to salvation for humanity, even though we don't deserve it.  |
---
Balancing Mercy & Justice
![[Pasted image 20230917203230.png|600]]
---
What are some dangers of not balancing mercy and justice?
---
Dangers of Unbalanced mercy and Justice:
<font size="6">  
<p align= "Left">
- Legalism<br>
- Licentiousness<br>
- Spiritual Pride<br>
- Harsh Judgement<br>
- Lukewarmness/Apathy<br>
- Enablement<br>

--
Enabling
<font size="5">  
<p align= "Left">
Enabling typically refers to behavior that inadvertently supports or allows someone to continue destructive or unhealthy patterns of behavior, often without realizing the negative consequences it may have. 
<p align= "Left">
While mercy is a vital Christian principle, enabling should be approached with caution. It's essential to consider whether the help being offered truly supports the individual's well-being and recovery or if it unintentionally perpetuates harmful patterns. Striking a balance between mercy and wise discernment is crucial when dealing with enabling situations to ensure that genuine care and support are provided without enabling destructive behavior.
<font size="5">  
<p align= "Left">

- **Misguided Compassion**: Enabling often arises from a well-intentioned desire to help or show mercy to someone who is struggling. However, if this help perpetuates harmful behavior without addressing the root causes, it can be counterproductive.
    
- **Hinders Personal Responsibility**: Enabling can prevent individuals from taking responsibility for their actions and seeking the help they genuinely need. In this sense, it can hinder personal growth and accountability.
--
<font size="5">  
<p align= "Left">

- **Impedes Justice**: In some cases, enabling can be seen as an imbalance towards mercy at the expense of justice. It may allow wrongdoers to avoid facing the consequences of their actions, which is not in line with the principle of justice.

- **Creates Codependency**: Enabling can lead to codependent relationships, where one person's well-being is excessively dependent on helping or caring for another person, even to their own detriment. We should depend on God and help others to depend on God as their source of provision and supply. Sometimes this feeds our own selfish needs.
    
- **Spiritual Implications**:  Enabling can raise questions about the role of accountability and repentance. While mercy is a Christian virtue, it should not be used to excuse or enable sinful behavior. There is a point where we become culprit in their continuous sin that causes harm to themselves and others.
    
- **Balancing Mercy and Tough Love**: Finding the balance between showing mercy and practicing tough love can be challenging. Tough love may involve setting boundaries and allowing natural consequences to occur while still demonstrating love, care concern & support. 
    
- **Seek Guidance**: Pray and seek guidance from God and from trusted mentors, pastors and Christian friends, when dealing with enabling situations. They can provide valuable insights and help navigate complex situations.

---
God Calls us to be Merciful
<font size="5">  
<p align= "left">

|**Bible Verse**|**Bible Text (ESV)**|
|---|---|
|Matthew 5:7|"Blessed are the merciful, for they shall receive mercy."|
|Matthew 9:13|"Go and learn what this means: 'I desire mercy, and not sacrifice.' For I came not to call the righteous, but sinners."|
|Micah 6:8|"He has told you, O man, what is good; and what does the Lord require of you but to do justice, and to love kindness, and to walk humbly with your God?"|
|Luke 6:36|"Be merciful, even as your Father is merciful."|
|Colossians 3:12|"Put on then, as God's chosen ones, holy and beloved, compassionate hearts, kindness, humility, meekness, and patience."|
|James 2:13|"For judgment is without mercy to one who has shown no mercy. Mercy triumphs over judgment."|
---
<font size="6">  
<p align= "left">
Just  as there are those who would say "love, love, love", there are those who would say, "mercy, mercy, mercy". Usually they are one and the same and are the ones who say do not judge.
---
![[Pasted image 20230917213523.png|600]]
---
Is a Christian supposed to judge?
---
<font size="5">  
<p align= "left">
Yes, with caution. 
<p align= "left">
As  Christians are called to make judgments about actions and behaviors in accordance with biblical principles. This means discerning between right and wrong, good and evil, and making moral decisions. The Bible provides guidance on how to live a righteous and holy life, and we are encouraged to make judgments based on these teachings.
<p align= "left">
We should exercise caution when it comes to making judgments about the motives and inner lives of others. Mercy, forgiveness, and a desire for restoration should guide us, always remembering that we too are in need of God's grace and forgiveness. We too were once dead in our sins and trespasses and following the ways of this world, our flesh and the prince of the power of the air...
---
<font size="5">  
<p align= "left">
<font color="#c00000">Christians Hold Christians Accountable</font><br>
<strong>1 Corinthians 5:12-13 </strong> <em>"For what have I to do with judging outsiders? Is it not those inside the church whom you are to judge? God judges those outside."</em>
<p align= "left">
<font color="#c00000">Don't be a Hypocrite</font><br>
<p align= "left">
<strong>Matthew 7:1-2 </strong>, <em> "Judge not, that you be not judged. For with the judgment you pronounce, you will be judged, and with the measure you use, it will be measured to you." </em><br>
<p align= "left">
<font color="#c00000">God judges the unseen, thoughts, motives of the heart</font><br>
<p align= "left">
<strong>1 Cor 4:5 </strong><em>"Therefore do not pronounce judgment before the time, before the Lord comes, who will bring to light the things now hidden in darkness and will disclose the purposes of the heart. Then each one will receive his commendation from God."</em><br>
<p align= "left">
<font color="#c00000">Exercise Mercy & Forgiveness</font>
<p align= "left">
<strong> Matthew 5:7 (ESV)</strong> "Blessed are the merciful, for they shall receive mercy." 
<p align= "left">
<font color="#c00000">Seek Restoration by Spirit of Gentleness</font><br>
<p align= "left">
<strong>Galatians 6:1 </strong> <em> "Brothers, if anyone is caught in any transgression, you who are spiritual should restore him in a spirit of gentleness."</em>
---
<font size="6">  
<p align= "Center">
<strong>Application: Balancing Mercy & Justice in our Daily Life</strong><br>
<font size="5">  
<p align= "left">

1. **Turn to Scripture**:  Seek wisdom from the word of God. The Bible is our guide and it provides numerous examples and teachings that show the importance of both. Regularly reading and studying Scripture will help you gain a deeper understanding of God's perspective on these principles.  Error on side of mercy. 
    
2. **Pray for Guidance & Discernment**:  Seek God's guidance through prayer and discernment in specific situations. Ask for wisdom to know when to extend mercy and when to uphold justice. Remember that God is the ultimate source of wisdom, and He is willing to provide it to those who ask.
    
3. **Understand & Consider Context**:  Sometimes, the appropriate response may lean more towards mercy, especially in cases of repentance and forgiveness. In other situations, justice may be necessary to maintain order and protect the vulnerable. 
    
4. **Restorative Justice**:  Restorative justice seeks to address the harm caused by an offense while also focusing on the rehabilitation and restoration of the offender. This approach aligns well with Christian values of forgiveness and redemption.
    
5. **Practice Forgiveness**: Forgiveness is a fundamental aspect of Christian mercy. While justice may require consequences for wrongdoing, forgiveness allows for healing and reconciliation. Encourage forgiveness when appropriate, but also acknowledge that it doesn't always mean ignoring the need for justice.
---
<font size="5">  
<p align= "left">

6. **Advocate for the Vulnerable**: Part of Christian justice involves advocating for the marginalized and vulnerable in society. Especially widows, orphans, poor, unborn and truly helpless. Jesus emphasized caring for the "least of these" in His teachings. Engage in efforts to promote fairness and justice, especially for those who cannot advocate for themselves in whatever position and place God has called you to and burdened you with.
    
7. **Extend Grace**:  Recognize that none of us are perfect, and we all make mistakes. Extend grace to others as you would want God to extend it to you. This doesn't mean ignoring wrongdoing, but it does mean showing compassion, understanding and patience/long-suffering.
    
8. **Engage in Church Fellowship**: Engage with your church body and discuss with your pastor, elders, mature members on how to support one another in finding the right balance between mercy and justice in various life situations.
    
9. **Continual Growth**: Understand that balancing mercy and justice is a continuous life long balancing act.  You may not always get it right in every situation, but through prayer, practice and hindsight which is always 20/20,  you will grow in this aspect of our Christian walk.
    
10. **Follow Christ's Example**: Ultimately, look to Jesus as the perfect model of balancing mercy and justice to the helpless. He showed unwavering love and compassion while also upholding the righteousness of God. As Christians, we are called to imitate Him.

---
<font size="6"> 
, ==<u>because</u> of the great love with which he loved us... ==
<font size="5"> 
<p align= "left">
God's mercy toward us, is on account of his great "polus" love "agape" with which he loved us.
<p align= "left">
<strong>Agape </strong>- is a Greek word that describes a particular kind of love. <p align= "left">
There are 4 primary words for <em>love</em> in the Greek language:

- **Eros (ἔρως):** Eros represents romantic or passionate love. It's often associated with desire and physical attraction. In Greek mythology, Eros was the god of love and desire.
    
- **Philia (φιλία):** Philia refers to the love between friends and close relationships. It's a deep, platonic love based on mutual respect, shared interests, and companionship. Philadelphia, the "City of Brotherly Love," derives its name from this concept.
    
- **Storge (στοργή):** Storge is a type of love that pertains to natural affection, like the love between family members. It's the love parents have for their children or the bond between siblings. It's often described as a tender, nurturing love.
    
- **Agape (ἀγάπη):** Agape is a selfless, unconditional love. It's often considered the highest form of love in Christian theology and encompasses love for God, love for fellow humans, and even love for enemies. It's “a self-emptying self-sacrifice” type of love</p>
---
Word of the Day: Agape<br>
<font size="5.5"> 
<p align= "left">
"God’s love is often viewed today as some sort of shallow sentimentality, but God’s love is deeper than we can even begin to comprehend. When the average person today says “love,” they do not even know what they are saying because they do not mean <em>“a self-emptying self-sacrifice.” </em>Love today is more “self-gratifying” than “self-emptying.”<br>
<p align= "left">
It’s interesting to note that in secular Greek, agapē [αγαπη] was actually rather colorless. As one Greek authority explains, agapē [αγαπη] originally carried an element of sympathy and spoke of the love of a person of higher rank for one of a lower rank; it even went so far as to speak of a love that was not self-seeking. But the Lord Jesus transformed the word; it took on the much deeper meaning of being totally sacrificial. As the same authority says, “[It] thus creates a new people who will tread the way of self-sacrificing love that [Christ] took.” We, therefore, humbly offer the following definition of God’s love: “A self-emptying self-sacrifice in which God gave of Himself in the form of His only begotten Son Who gave His life for us.”<p align= "left">
---
<font size="5.5"> 
<p align= "left">
But Paul is not satisfied with using just agapē [αγαπη] in Ephesians 2:4; he speaks of God’s “great love [pollēn agapēn [πολλην αγαπην]] wherewith he loved us.” The basic meaning of the Greek <em>polus </em>[πολυς] (G4183 [πολύς], great) is <em>“much or great.”</em> But when used figuratively, as it is here, it conveys the idea of intensity. In other words, Paul is not speaking so much of the volume of God’s love as much as he is its passion. Many of us enjoy doing certain things in life; at times we all pursue a hobby or other interest “intensely.” But if we could multiply this by infinity, we would even then only scratch the surface of the great love of God.
<p align= "left">
This truth again immediately begs the question, “Why does God love us?” In all my years of ministry, the only answer I have ever come to is this: I don’t know. When we look at Ephesians 2:1–3 from the human perspective, there is no reason God should or would love us, but He does. This is not some syrupy sentimentality about “Jesus loving everybody,” but rather it is a deep, incomprehensible passion for those who are totally undeserving of love." 
---
---
<font size="6"> 
God's Great Love
<font size="5"> 
<p align= "left">

|Verse Ref|Verse Text|
|---|---|
|Romans 5:8|"But God shows his love for us in that while we were still sinners, Christ died for us."|
|John 3:16|"For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life."|
|1 John 4:9-10|"In this the love of God was made manifest among us, that God sent his only Son into the world, so that we might live through him. In this is love, not that we have loved God but that he loved us and sent his Son to be the propitiation for our sins."|
|1 John 4:16|"So we have come to know and to believe the love that God has for us. God is love, and anyone who abides in love abides in God, and God abides in them."|
|Ephesians 3:17-19|"so that Christ may dwell in your hearts through faith—that you, being rooted and grounded in love, may have strength to comprehend with all the saints what is the breadth and length and height and depth, and to know the love of Christ that surpasses knowledge, that you may be filled with all the fullness of God."|
|Romans 8:38-39|"For I am sure that neither death nor life, nor angels nor rulers, nor things present nor things to come, nor powers, nor height nor depth, nor anything else in all creation, will be able to separate us from the love of God in Christ Jesus our Lord."|

---
Book: The Difficult Doctrine of Love
<font size="6"> 
<p align= "center">
![[Pasted image 20230917235558.png]]

You would not think love would be such a difficult doctrine...

---
<font size="6"> 
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i><br>
<em>"In generations (past) when almost everyone believed in the justice of God, people sometimes found it difficult to believe in the love of God. The preaching of the love of God came as wonderful good news. Nowadays if you tell people that God loves them, they are unlikely to be surprised. <br><br><em> "Of course God loves me; he’s like that, isn’t he? Besides, why shouldn’t he love me? I’m kind of cute, or at least as nice as the next person. I’m okay, you’re okay, and God loves you and me.....</em> <Br>Today most people seem to have little difficulty believing in the love of God; they have far more difficulty believing in the justice of God, the wrath of God, and the non-contradictory truthfulness of an omniscient God. But is the biblical teaching on the love of God maintaining its shape when the meaning of “God” dissolves in mist?" - D.A. Carson</em><!-- .element: style="font-size: 24px" align="justify" --><br>
---
<font size="7"> 
<p align= "left">
"Christian faithfulness entails our responsibility to grow in our grasp of what it means to confess that God is love."
---
<font size="6"> 
Reasons why the Doctrine of Love is Difficult in our Culture Today
<font size="5"> 
<p align= "left">
1. If people believe in God at all today, they view God as a loving being. (Lack of belief in Hell or Judgement)<br>
2. Culture today disbelieves complementary truths about God: They take God's love out of context. They remove:<br>
			- Sovereignty of God<br>
			- Holiness of God<br>
			- Wrath of God<br>
			- Providence of God<br>
			- Personhood of God<br>
<strong>D.A. Carson - </strong> - <em>"The result, of course, is that the love of God in our culture has been purged of anything the culture finds uncomfortable. The love of God has been sanitized, democratized, and above all sentimentalized. This process has been going on for some time. My generation was taught to sing, <em>“What the world needs now is love, sweet love,”</em> in which we robustly instruct the Almighty that we do not need another mountain (we have enough of them), but we could do with some more love. The hubris (pride/arrogrance) is staggering. "</em>

---
<font size="5"> 
<p align= "left">
3. The Doctrine of the Love of God is difficult because "more and more people believe that the only heresy left is the view that there is such a thing as heresy. They hold that all religions are fundamentally the same and that, therefore, it is not only rude but profoundly ignorant and old-fashioned to try to win someone to your beliefs since implicitly that is announcing that theirs are inferior."<br>
4. Inside the church, "Within Christian confessions the doctrine of God poses its own difficulties... <br>
		- How does one integrate what the Bible says about the love of God with what the Bible says about God’s sovereignty, extending as it does even over the domain of evil? <br>
		- What does love mean in a Being whom at least some texts treat as impassible (incapable of suffering or feeling pain) ? <br>
		- How is God’s love tied to God’s justice?<br>
	One of the most dangerous results of the impact of contemporary sentimentalized versions of love on the church is our widespread inability to think through the fundamental questions that alone enable us to maintain a doctrine of God in biblical proportion and balance.<br>
---
<font size="5"> 
<p align= "left">
5. The doctrine of the love of God is sometimes portrayed within Christian circles as much easier and more obvious that it really is, and this is achieved by overlooking some of the distinctions the Bible itself introduces when it describes the love of God.<br><br>
	1. The peculiar love of the Father for the Son, and of the Son for the Father<br>
	2.  God’s providential love over all that he has made.<br>
	3.  God’s salvific stance toward his fallen world. John 3:16 <br>
	4. God’s particular, effective, selecting love toward his elect. <br>
	5. Finally, God’s love is sometimes said to be directed toward his own people in a provisional or conditional way—conditioned, that is, on obedience...abide in my love.<br>
---
Common Misunderstandings of Love of God
<font size="6"> 
<p align= "left">
- God loves people more than anything.<br>
- God loves all people the same, in the same way and to the same degree.<br>
- God's love is always unconditional.<br>
- God's love is indiscriminate. <br>
- God's love is sentimental.<br>
- God's love is ineffectual.  (He loves you enough to leave you as you are.)<br>
---
Is this the great love in Ephesians 2:4?
<font size="6"> 
<p align= "left">
Is God's love conditional or unconditional?<br>
Is God's love universal or is it particular?<br>
Is God's love discriminate or is it indiscriminate? <br>

God's love is not as simple as we sometimes make it out to be.
---
<font size="5"> 
<p align= "left">

|  Reference  |  Verse Text                                    |
|---------------------------------|---------------------------------------------|
| 1 John 4:8                       | God is love.                                                |
| 1 John 4:10                      | Not that we love God, but that he loved us and sent his Son as an atoning sacrifice for our sins. |
| Deuteronomy 7:7-8                | It was not because you were more in number than any other people that the LORD set his love on you and chose you, for you were the fewest of all peoples, but it is because the LORD loves you. |
| Mark 10:21                       | And Jesus, looking at him, loved him, and said to him, "You lack one thing: go, sell all that you have and give to the poor, and you will have treasure in heaven; and come, follow me." |
| John 3:16                        | For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life. |
| Romans 5:8                       | But God shows his love for us in that while we were still sinners, Christ died for us. |
| Psalm 145:9                      | The LORD is good to all, and his mercy is over all that he has made. |

---
<font size="5"> 
<p align= "left">

| Reference  | Verse Text                                    |
|--------------------------|-----------------------------------|
| John 14:21                       | Whoever has my commandments and keeps them, he it is who loves me. And he who loves me will be loved by my Father, and I will love him and manifest myself to him. |
| John 14:23                       | Jesus answered him, "If anyone loves me, he will keep my word, and my Father will love him, and we will come to him and make our home with him." |
| John 15:10                       | If you keep my commandments, you will abide in my love, just as I have kept my Father's commandments and abide in his love. |
| Jude 1:20-21                     | But you, beloved, building yourselves up in your most holy faith and praying in the Holy Spirit, keep yourselves in the love of God, waiting for the mercy of our Lord Jesus Christ that leads to eternal life. |
| Psalm 86:5                       | For you, O Lord, are good and forgiving, abounding in steadfast love to all who call upon you. |
| Psalm 103                         | Bless the Lord, O my soul, and all that is within me, bless his holy name! Bless the Lord, O my soul, and forget not all his benefits, who forgives all your iniquity, who heals all your diseases, who redeems your life from the pit, who crowns you with steadfast love and mercy. |

---
<font size="5"> 
<p align= "left">
D.A. Carson asks: <br>
So now God comes to us and says, “I love you.” What does he mean? <br>
<p align= "left">
Does he mean something like this? “You mean everything to me. I can’t live without you. Your personality, your witty conversation, your beauty, your smile—everything about you transfixes me. Heaven would be boring without you. I love you!” <br>
<p align= "left">
That, after all, is pretty close to what some therapeutic approaches to the love of God spell out. We must be pretty wonderful because God loves us. And dear old God is pretty vulnerable, finding himself in a dreadful state unless we say yes. Suddenly serious Christians unite and rightly cry, “Bring back impassibility!”
---
<font size="5"> 
<p align= "left">
When he says he loves us, does not God rather mean something like the following? <br>“Morally speaking, you are the people of the halitosis, the bulbous nose, the greasy hair, the disjointed knees, the abominable personality. Your sins have made you disgustingly ugly. But I love you anyway, not because you are attractive, but because it is my nature to love.” And in the case of the elect, God adds, “I have set my affection on you from before the foundation of the universe, not because you are wiser or better or stronger than others but because in grace I chose to love you. You are mine, and you will be transformed. Nothing in all creation can separate you from my love mediated through Jesus Christ” (Rom. 8).
<p align= "left">
Isn’t that a little closer to the love of God depicted in Scripture? Doubtless the Father finds the Son lovable; doubtless in the realm of disciplining his covenant people, there is a sense in which his love is conditioned by our moral conformity. But at the end of the day, God loves, whomever the object, because God is love. There are thus two critical points:<br>
First, God exercises this love in conjunction with all his other perfections, but his love is no less love for all that. <br>
Second, his love emanates from his own character; it is not dependent on the loveliness of the loved, external to himself.<br>
---
<font size="5"> 
<p align= "left">
John’s point in 1 John 4, “God is love,” is that those who really do know God come to love that way too. Doubtless we do not do it very well, but aren’t Christians supposed to love the unlovable—even our enemies? Because we have been transformed by the Gospel, our love is to be self-originating elicited by the loveliness of the loved. For that is the way it is with God. He loves because love is one of his perfections, in perfect harmony with all his other perfections.
<p align= "left">
At our best, we know that that is the way God’s image-bearers should love too. In one of her loveliest sonnets, never written to be published, Elizabeth Barrett Browning wrote to her husband Robert Browning in 1806-1861:
---
<font size="5"> 
<p align= "left">

If thou must love me, let it be for nought  
Except for love's sake only. Do not say,  
"I love her for her smile—her look—her way  
Of speaking gently,—for a trick of thought  
That falls in well with mine, and certes brought  
A sense of pleasant ease on such a day"—  
For these things in themselves, Belovèd, may  
Be changed, or change for thee—and love, so wrought,  
May be unwrought so. Neither love me for  
Thine own dear pity's wiping my cheeks dry:  
A creature might forget to weep, who bore  
Thy comfort long, and lose thy love thereby!  
But love me for love's sake, that evermore  
Thou mayst love on, through love's eternity.<br>
-Elizabeth Barrett Browning
---
John 3:16
<font size="6"> 
<p align= "left">
 “For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life.  For God did not send his Son into the world to condemn the world, but in order that the world might be saved through him.
---
How deep the Father's love for us,  
How vast beyond all measure,  
That He should give His only Son  
To make a wretch His treasure.  
How great the pain of searing loss -  
The Father turns His face away,  
As wounds which mar the Chosen One  
Bring many sons to glory.
---
END READING
## Ephesians 2:4-10 ESV
<font size="6"> 
<p align= "Justify">
 <em> 4 But God, being rich in mercy, because of the great love with which he loved us, 5 even when we were dead in our trespasses, made us alive together with Christ—by grace you have been saved— 6 and raised us up with him and seated us with him in the heavenly places in Christ Jesus, 7 so that in the coming ages he might show the immeasurable riches of his grace in kindness toward us in Christ Jesus. 8 For by grace you have been saved through faith. And this is not your own doing; it is the gift of God, 9 not a result of works, so that no one may boast. 10 For we are his workmanship, created in Christ Jesus for good works, which God prepared beforehand, that we should walk in them.</em>   
---
Closing Prayer
==

---