Text:  [[Ephes-01#v1|Ephesians 1:1]]

## Overview
Paul
	an apostle
	      of Christ Jesus
	      by the will of God
	 
## Greetings
Customary opening for a first century letter.
	Introduces the Author 
	Addresses the Recipients
	Gives a mixed Roman and Hebrew blessing


## Paul
Paul always introduces himself with his Greek name "Paul" vs his Hebrew name, Saul.  How Paul came by his Roman name is unknown. It was a common practice for Hebrews to give their children a Gentile name in addition to their Hebrew name. His Roman name  Paul comes from the Greek word Paulos, and means "little". His Hebrew name, "Saul" means "asked for.  

![[Paul the Apostle]]

### An apostle of Christ Jesus by the will of God

**An apostle** - ἀπόστολος apostolos -  a messenger, a delegate, one sent forth with an order, one who is commissioned by another as his representative, an ambassador

It was common for kings to have apostles as their messengers or the churches even to send "messengers". [[John-13#v16|John 13:16]]; [[2 Cor-08#v23|2Cor 8:23]]; [[Phil-02#v25|Philippians 2:25]].

Jesus Christ himself is referred to as an apostle of God in Hebrews 3:1
![[Heb-03#v1]]

Apostle with a capital "A" is more specifically applied to the 12 disciples of Christ.

Luke 6:13
![[Luke-06#v13|Luke 6:13]]

 This specific title designated Paul as a commissioned ambassador of Jesus Christ by the will of God. The 12 apostles of the early church held great authority in the church. They were eye witnesses of Christ. They heard the teachings of Christ first hand having walked with him. Their experience gave them a very unique and very critical role and responsibility in the early church of sharing what they had seen and heard and testifying about Christ.
 
-> [!Bible]- [1John 1:1-4 - ESV](https://bolls.life/ESV/62/1/)
>  1. That which was from the beginning, which we have heard, which we have seen with our eyes, which we looked upon and have touched with our hands, concerning the word of life — 2. the life was made manifest, and we have seen it, and testify to it and proclaim to you the eternal life, which was with the Father and was made manifest to us — 3. that which we have seen and heard we proclaim also to you, so that you too may have fellowship with us; and indeed our fellowship is with the Father and with his Son Jesus Christ. 4. And we are writing these things so that our  joy may be complete.

Paul's identifying himself as an apostle of Jesus Christ by the will of God is setting forth his credentials and authority. 

Paul was always defending his role as apostle. Unlike the other apostles, he did not know Jesus Christ while he was on the earth. Paul's conversion and commission came about by special revelation in Acts 9 and Paul tells about this conversion in [[Acts-26#v12|Acts 26:12-18]] to King Agrippa

-> [!Bible]- [Acts 26:12-18 - ESV](https://bolls.life/ESV/44/26/)
>  12. “In this connection I journeyed to Damascus with the authority and commission of the chief priests. 13. At midday, O king, I saw on the way a light from heaven, brighter than the sun, that shone around me and those who journeyed with me. 14. And when we had all fallen to the ground, I heard a voice saying to me in the Hebrew language,  ‘Saul, Saul, why are you persecuting me? It is hard for you to kick against the goads.’ 15. And I said, ‘Who are you, Lord?’ And the Lord said, ‘I am Jesus whom you are persecuting. 16. But rise and stand upon your feet, for I have appeared to you for this purpose, to appoint you as a servant and witness to the things in which you have seen me and to those in which I will appear to you, 17. delivering you from your people and from the Gentiles — to whom I am sending you 18. to open their eyes, so that they may turn from darkness to light and from the power of Satan to God, that they may receive forgiveness of sins and a place among those who are sanctified by faith in me.’

<span style="background:#fff88f">I</span><span style="background:#fff88f">t was not by Paul's will that he became an apostle, but by the will of God</span>. Paul is always very consistent in pointing this out that he does not take this office of Apostle on his own will. He was called by God, as God's bond servant, prisoner and Paul had such a great fear for the Lord, that he would not dare deny his duty even though it often meant great beatings for him.

The office or role of Apostle came with great respect, but it also came with great cost. All the disciples were martyred for their message, their testimony which they would not dare recant, except for the apostle John who died a normal death at old age. However, even John had his share of suffering. Tradition says that Emperor Domitian banished John to the island of Patmos because he tried to boil him in oil and he did not die.

There are no longer any "Apostles" today. Some churches use this term for their lay people and open their church up to all sorts of false doctrine by self-appointed "Apostles".  God spoke to us through his son Jesus Christ.  [[Heb-01#v1|Hebrews 1:1]]

> Long ago, at many times and in many ways, God spoke to our fathers by the prophets, 2 but in these last days he has spoken to us by his Son, whom he appointed the heir of all things, through whom also he created the world.

The Apostles capital "A", heard Jesus Christ speak. They recorded what Jesus Christ taught and most importantly were specifically called and commissioned by God. God's grace verified their message through miracles.  [[Mark-16#v20|Mark 16:20]] Since then no further revelation has been or is needed. The gospel has been recorded, the core teachings and doctrine have been preserved in the bible through the gospels and the epistles.  Nothing needs to be added to it, but our faith and obedience.

The authority we now stand on is the apolostolic authority of what is taught and recorded in the Bible and we only have authority to preach our teach as it lines up with what the Bible already says. 
