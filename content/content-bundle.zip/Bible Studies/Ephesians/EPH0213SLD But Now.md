-[<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->
---
OPENING PRAYER
==
---

Ephesians 2:13-17
<font size="5">  
<p align= "Justify">
11 Therefore remember that at one time you Gentiles in the flesh, called “the uncircumcision” by what is called the circumcision, which is made in the flesh by hands— 12 remember that you were at that time separated from Christ, alienated from the commonwealth of Israel and strangers to the covenants of promise, having no hope and without God in the world. <u>13 But now in Christ Jesus you who once were far off have been brought near by the blood of Christ. 14 For he himself is our peace, who has made us both one and has broken down in his flesh the dividing wall of hostility 15 by abolishing the law of commandments expressed in ordinances, that he might create in himself one new man in place of the two, so making peace, 16 and might reconcile us both to God in one body through the cross, thereby killing the hostility. 17 And he came and preached peace to you who were far off and peace to those who were near.</u> 18 For through him we both have access in one Spirit to the Father. 19 So then you are no longer strangers and aliens,[a] but you are fellow citizens with the saints and members of the household of God, 20 built on the foundation of the apostles and prophets, Christ Jesus himself being the cornerstone, 21 in whom the whole structure, being joined together, grows into a holy temple in the Lord. 22 In him you also are being built together into a dwelling place for God by the Spirit.
---

Separated from Christ
<font size="5">  
<p align= "left">
<em>12. remember that you were at that time separated from Christ, alienated from the commonwealth of Israel and strangers to the covenants of promise, having no hope and without God in the world.</em>
<br><p align= "center">
![[Pasted image 20231015170123.png|500]]



---
[Google Earth](https://earth.google.com/web/@0,-0.204,0a,22251752.77375655d,35y,0h,0t,0r/data=OgMKATA)

![[Pasted image 20231015170749.png|600]]
---

But Now...
---
<font size="6">  

><span style="background:rgba(240, 200, 0, 0.2)">But now in Christ Jesus </span> you who once were far off have been brought near by the blood of Christ. 
<font size="5">  
<p align= "left">
Verse 13 begins with words of contrast,<strong> "But now" </strong>, marking a turning point to the prior condition.  They are words of contrast. What was before is no more.... We are about to see a bright and unthinkable contrast. 
<p align= "left">
<strong>in Christ Jesus </strong> The most important change from their prior condition is their <em>position </em>has changed dramatically. They have a new relationship to Christ Jesus that transforms their spiritual state and destiny. They are now "in Christ Jesus". United with Christ Jesus. <strong>"In Him" </strong>
<p align= "left">
The seemingly impossible has occurred.  Those who were far off, separated from Christ, without hope and without God in the world have been brought near in Christ Jesus. Those who are of God's elect are now "in Christ" as joint-members of the body of Christy, members of the body of believers, members of the commonwealth and sharers in the promises, never to be separated again.
---
<font size="5"> 

>But now in Christ Jesus<span style="background:rgba(240, 200, 0, 0.2)"> you who once were far off have been brought near</span> by the blood of Christ. 
<font size="5">  
<p align= "left">
The Gentiles were not part of the original covenant God made with Israel. They were <strong>" once far off" </strong>in terms of the promises, being <em>"strangers to the covenants of promise"</em>, They were "aliens, foreigners" to the commonwealth of Israel and outside the immediate presence of God that Israel enjoyed as a "chosen nation"
<p align= "left">
<strong>"Have been brought near"/"are made nigh"</strong>: The passive voice indicates that the action is done to us; we don’t bring ourselves near to God. It is a divine act of grace that brings about this new proximity to God.
<br>
<p align= "left">
<strong>Near (eggus) </strong>indicates a location that is  nearby to another location. Because of their covenantal relationship with God and the existence of His Temple in Jerusalem, the Jews believed that they and their converts were brought close to God.  
<font size="4"> 
<p align= "left">
<strong>John 4:20-24 </strong> -  Our fathers worshiped on this mountain, but you say that in Jerusalem is the place where people ought to worship.” Jesus said to her, “Woman, believe me, the hour is coming when neither on this mountain nor in Jerusalem will you worship the Father. You worship what you do not know; we worship what we know, for salvation is from the Jews.  But the hour is coming, and is now here, when the true worshipers will worship the Father in spirit and truth, for the Father is seeking such people to worship him. God is spirit, and those who worship him must worship in spirit and truth. 
---
Why Was Israel Near to God?
<font size="5"> 
<p align= "left">
It was because of God's choosing, that the Jewish people had a special relationship with God. It wasn't because they were inherently more righteous than the rest of the world, but because God had chosen them. 
<font size="5"> 
<p align= "left">
- <strong>Deut 7:6 & Deut 14:2</strong> <em>"For you are a people holy to the Lord your God. The Lord your God has chosen you to be a people for his treasured possession, out of all the peoples who are on the face of the earth.</em><br>
- <strong>Psalm 135:4</strong> <em>"For the LORD has chosen Jacob for himself, Israel as his own possession."</em><br>
- <strong>2 Samual 7:23-24</strong> <em>"And who is like your people Israel, the one nation on earth whom God went to redeem to be his people, making himself a name and doing for them great and awesome things by driving out before your people, whom you redeemed for yourself from Egypt, a nation and its gods? And you established for yourself your people Israel to be your people forever. And you, O LORD, became their God."</em>
<p align= "left">
Previous to the arrival of Jesus, there was a distinction: one group appeared closer to God, while the other appeared more distant. This distinction, however, should not be taken as implying that Jews are inherently superior than Gentiles. As previously stated, the Jews were regarded a part of God's holy household solely because of God's gracious election.

---
Now the Gentiles have been made near to God.
<font size="5"> 
<p align= "left">
<strong>John 10:16</strong> <em> And I have other sheep that are not of this fold. I must bring them also, and they will listen to my voice. So there will be one flock, one shepherd.</em>
<p align= "left">
<strong>"And I have other sheep"</strong>: Jesus starts by acknowledging that His ministry extends beyond His current audience of the Jews.  There are non-Jews that belong to him, Non-Jews are "Gentiles".
<p align= "left">
<strong>"That are not of this fold"</strong>: The term "fold" generally refers to a fenced area where sheep are kept. In the immediate context, Jesus is likely referring to the Jews as "this fold," making a contrast with Gentiles who would be outside the "fold".
<p align= "left">
<strong>"I must bring them also"</strong>: The word "must" indicates a divine necessity, part of God's plan for the salvation of His people. This is not optional but a mandate.
<p align= "left">
<strong>"And they will listen to my voice"</strong>: This shows the effectual calling of Christ. Those whom Christ calls will come to Him and follow Him.
<p align= "left">   
<strong>"So there will be one flock, one shepherd"</strong>: Jesus ends by emphasizing the unity that will come from this gathering of diverse sheep. Despite their different origins, they will be united under one shepherd, Christ Himself.
---
<font size="6"> 
<p align= "left">

<strong>Acts 2:39 </strong>For the promise is for you and for your children and for all who are far off, everyone whom the Lord our God calls to himself.
<font size="5"> 
<p align= "left">
This verse occurs in the context of Peter's sermon on the Day of Pentecost. Peter is addressing a large gathering of Jews and proselytes who have come to Jerusalem to celebrate the feast. After his sermon, the hearers ask themselves, "Brothers, What shall we do?" and Peter responds they should "Repent and be baptized every one of you in the name of Jesus Christ for the forgiveness of their sins and they will then receive the gift of the Holy Spirit."
<p align= "left">
The context of Acts 2:39 shows the expansive scope of the promise of God. It includes not just their generation, but the Gospel is also for their children and those who who are far off, future generations as well as Gentiles.   It shows the Sovereignty of God, <em>everyone  whom the Lord our God calls to himself"</em>.  The proclamation of the gospel is not just general in nature, but it is effectual, it will accomplish what its purposes, drawing people to God Himself. His word does not return to him void. 
<p align= "left">
<strong>Isa. 55:11 </strong>- <em>"So shall my word be that goes out from my mouth; it shall not return to me empty, but it shall accomplish that which I purpose, and shall succeed in the thing for which I sent it." </em>
---
The Unifying Power of Christ
<font size="5">  
<p align= "left">
When we  "Gentiles" are brought near to God spiritually, we are also brought near spiritually to God's family, community, church, his body members.  Our relationship with Christ overcomes the fleshly corruptions that keep us from true community, closeness, and worship.  Our relationship with Christ, teaches us forgiveness, patience, long-suffering, perseverance, love, kindness, unconditional love, building each other up, control our tongue, giving, generosity, humility, not to think more highly of others then ourself, unity etc...etc... It is sin that always divides and separates relationships and causes cruelty. Race and nationality distinctions, pagan and religious, young and old, sinner and saint, proud and wounded, offender and offended, all collapse in him. We are all brought closer to God via Christ.
<p align= "left">
<strong>Galatians 3:26-29</strong> <em>for in Christ Jesus you are all sons of God, through faith. For as many of you as were baptized into Christ have put on Christ.  <u>There is neither Jew nor Greek, there is neither slave nor free, there is no male and female, for you are all one in Christ Jesus. </u> And if you are Christ's, then you are Abraham's offspring, heirs according to promise.</em>
<p align= "left">
<strong>Westminster Confession of Faith" </strong> states in 25.2 - The visible church which is also catholic or universal under
the gospel . . . consists of all those throughout the world that profess the true
religion, and of their children, and is the kingdom of the Lord Jesus Christ,
and the house and family of God” 
<p align= "left">
 The church is and should be the great melting pot..
---
The Implication of our Union
<font size="5">  
<p align= "left">
We are all members of the same family in Christ regardless of our pasts and ethnicity. This shared identity means that our national identity does not take precedence over our Christian identity. Racism cannot be excused. 
<p align= "left">
Our common identity unites the rich and the poor, the intelligent and the simple, the  respectable and the wretched. <em>There is no excuse for us causing a division among those whom God has united.</em> Our thoughts and attitudes should not differentiate between people deserving of grace and those who do not. We embrace Christ with equal knowledge of our need and dependency on his love and grace regardless of our pasts, positions or possessions.
<p align= "left">
Being one in Christ affects not just our connection with one another, but also our relationship with God in how we view ourselves. We can be internally divisive. We are in unity with Jesus, despite ourselves.  When we wish to refer to ourselves as a "failure, liar, hypocrite, pervert, or betrayer, an outsider" our God refers to us with love, as "my child," because we are in permanent unity with his Son. 
<p align= "left">
Through our union with Christ and position in Christ, God gives us a new identity as "His child" and relationship to himself as "Our Father" and others as "brothers and sisters". 
<p align= "left">
<Strong>Romans 12:5</strong> - <em>"So we, though many, are one body in Christ, and individually members one of another."</em>
---
<font size="6">
How? - But now in Christ Jesus you who once were far off have been brought near <span style="background:rgba(240, 200, 0, 0.2)">by the blood of Christ. </span>
<font size="5">  
<p align= "left">
<strong>Blood</strong> - (halma) is the basis of life. Halma is literally the red fluid that circulates in the heart, arteries, capillaries, and veins of a vertebrate animal carrying nourishment and oxygen to and bringing away waste products from all parts of the body and thus is essential for the preservation of life. <em>Haima</em> gives us English words like hemorrhage.
<p align= "left">
<strong>"By the blood of Christ"</strong>: The "blood" symbolizes the sacrificial death of Christ on the cross. This is the means through which reconciliation with God is made possible. It is the propitiation for our sins and serves as the basis for our peace with God. Every believing sinner owes his nearness to God, and his interest in his favor, to the blood, to the death and sacrifice of Jesus.
<p align= "left">
It is by the blood of Christ that we are brought near, not by location, bloodline, strength of our faith,  our knowledge of the bible,  our devotional efforts, or by becoming a proselyte of Judaism, but by the blood of Christ alone.  The blood of Christ drew us near to God, when nothing else could. 
<p align= "left">
<strong>Of Christ </strong>- No other blood sacrifice could satisfy the righteous demands of God's holiness and His just hatred of sin. Only the blood of the spotless, sinless Lamb of God could take away the sins of the world and bring men near. Because Jesus  is Holy, Just and Sovereign, infinite God, His sacrifice has an immeasurable atoning value that no other blood could possess.   <br><strong>Hebrews 10:4 </strong> <em>"For it is impossible for the blood of bulls and goats to take away sins"<em>
<p align= "left">


---
<font size="5">  
<p align= "left">
Ray Stedman points out "that it isn't merely the death of Christ. Paul says that it is the <strong>blood of Christ</strong> It is significant that he uses that term. Death, of course, is not always bloody. You can die without losing your blood. The Scriptures sometimes speak of the death of Christ, and more often of the cross of Christ. But still more often they speak of the <em>blood of Christ.</em>Why this emphasis? Many don't like this today. They don't like to think of the cross or of the death of Jesus as being bloody. But God emphasizes it. God wants us to think about it, because blood is always a sign of violence. You see, the death of Jesus was not just a simple passing away -- dying of old age on a comfortable bed. No, no. It was a violent death, a bloody, gory, ugly, revolting scene -- a man hanging torn and wretched upon a cross, with blood streaming down his sides and running down the cross. God wants us to remember that violent death, because violence is the ultimate result of paganism. It is the final expression of a godless society. Cruelty arises immediately when love and truth disappear from society. And God is simply reminding us that when humanity had done its worst, had sunk to its lowest, had vented its anger in the utter wretchedness and violence and blood of the cross, his love reached down to that very place and, utilizing that violent act, began to redeem, to call back those who were far off and bring them near -- in the blood of Christ. And, in the blood of Jesus, all the advantages the Jews had were conferred upon the Gentiles. Ignorant, pagan, darkened, foolish, struggling, hopeless -- nevertheless, they had just as much access to God, in the <em>blood of Christ</em>, as any Jew ever had with his temple, his Law, his priesthood, and his sacrifice. By this the apostle is trying to emphasize to us the exceedingly amazing wonder of the grace of God, which laid all these liabilities aside and reached out to us and found us just as we were, and brought us near by the blood of Jesus Christ our Lord. What a gift to give thanks for! 
---
<font size="5">  
<p align= "left">
The paradox of the cross—being both the greatest crime and the ultimate act of love—reveals the depths of both human depravity and divine grace.
---
There is a Fountain
<font size="6">  
<p align= "left">
<em>There is a fountain filled with blood drawn from Immanuel’s veins, <br>
and sinners plunged beneath that flood lose all their guilty stains.  <br>
The dying thief rejoiced to see that fountain in his day, <br>
and there may I, though vile as he, wash all my sins away.  <br>
Dear dying Lamb, Thy precious blood shall never lose its pow’r, <br>
till all the ransomed Church of God be saved to sin no more. <br> 
E’er since by faith I saw the stream Thy flowing wounds supply, <br>redeeming love has been my theme and shall be till I die. <br> 
When this poor lisping, stamm’ring tongue lies silent in the grave,<br>
then in a nobler, sweeter song, I’ll sing Thy pow’r to save.<br></em>

- William Cowper
---
<font size="6">  

><span style="background:rgba(240, 200, 0, 0.2)">For he himself is our peace</span>, who has made us both one and has broken down in his flesh the dividing wall of hostility 
<font size="5">  
<p align= "left">
The word "himself" is added in English to indicate the emphasis on the word "He" in the Greek that Paul placed on it by making it the first word in the sentence. He and no other is our peace.
<p align= "left">
<b>Our peace is a person. </b>  Christ is our peace with God and Christ is our peace with each other, Jew or Gentile.  Christ did not just make peace, or give away peace, He is our peace!  Christ is <strong>our</strong> peace. He is the peace for all believing Jews and the Gentiles. We have the Gospel of Peace. Eph 6:15
<p align= "left">
<strong>Peace </strong>1515 <strong>eirene</strong> from the verb <em>eiro</em> = to bind or join together what is broken or divided) means in essence to set at one again or join together that which is separated. In secular Greek <em>eirene</em> described the cessation or absence of war.
<p align= "left">
Peace is not something that we can obtain independently from a relationship with Christ Himself and His work on the cross which is that peace.  
---
Isaiah 9:6-7
<font size="6">  
<p align= "left">
<em>"For a child will be born to us, a son will be given to us; And the government will rest on His shoulders; And His name will be called Wonderful Counselor, Mighty God, Eternal Father, <strong>Prince of Peace</strong>. There will be no end to the increase of His government or of peace, On the throne of David and over his kingdom, To establish it and to uphold it with justice and righteousness From then on and forevermore. The zeal of the LORD of hosts will accomplish this.</em>
<p align= "left">
Christ is very first leader who will bring true peace to the world.  He both gives peace and He maintains it.  Those who are saved know his peace, and one day, the whole world will know his peace.
---
World Peace
<font size="5"> 
<p align= "left">
Today, there are many who seek "world peace" and unity with the mindset of John Lennon's song:
<p align= "left"><em>
Imagine there’s no countries; <br>
It isn’t hard to do. <br>
Nothing to kill or die for, <br>
And no religion too. <br>
Imagine all the people, <br>
Living life in peace.<br></em>
<p align= "left">
We see too often that today's culture believes if only we could end all religion or blend it together, then peace would come. Every day, it becomes evident that one of the biggest problems of our time is to address pluralism which aims at trying to get us to all "co-exist".  Cultural allegations of prejudice and intolerance, as well as personal reservations about pride and insensitivity, make us increasingly reluctant to religious assertions that divide people. We must seek to remain unwavering in our dedication to the distinctiveness of the Christian faith as God's path of salvation which alone can bring true peace in this life and in eternity, peace with God and peace between men.
<p align= "left">
The bible teaches that only the blood of Jesus Christ removes barriers between people and brings true peace to this world.
---


<font size="6">  
<p align= "left">
<strong>MacDonald</strong> after asking how Jesus, a Person, can  <strong>be</strong> Peace, answers "This is how: When a Jew believes on the Lord Jesus, he loses his national identity; from then on he is “in Christ.” Likewise, when a Gentile receives the Savior, he is no longer a Gentile; henceforth he is “in Christ.” In other words, believing Jew and believing Gentile, once divided by enmity, are now both one in Christ. Their union with Christ necessarily unites them with one another. Therefore a Man is the peace, just as Micah predicted (Mic. 5:5)
---
<font size="6">  
<p align= "left">
<strong>Ray Stedman </strong> writes that "In this very remarkable passage, the apostle gives us the way of peace. He uses as an illustration the fact that Jesus Christ bridged the widest chasm which ever has existed between men -- the gulf between the Jew and the Gentile. If you don't think that conflict can claim title to being the most difficult gulf to bridge, I suggest you consider why it is it has been so difficult to settle the Arab-Israeli problem in the Middle East. The greatest minds of our day have tried to work that out, and no one has gotten anywhere near a settlement. It is because this conflict is extremely difficult to bridge. Paul describes how Christ actually does it. And this is a wonderful picture for us of how peace can be brought in any area of conflict or hostility, whether among individuals or groups or nations. 
---
Albert Barnes
<font size="5">  
<p align= "left">
The peace here referred to is that by which a union in worship and in feeling has been produced between the Jews and the Gentiles. Formerly they were alienated and separate. They had different objects of worship; different religious rites; different views and feelings. The Jews regarded the Gentiles with hatred, and the Gentiles the Jews with scorn. Now, says the apostle, they are at peace. They worship the same God. They have the same Saviour. They depend on the same atonement. They have the same hope. They look forward to the same heaven. They belong to the same redeemed family. Reconciliation has not only taken place with God, but with each other. The best way to produce peace between alienated minds is to bring them to the same Saviour. That will do more to silence contentions, and to heal alienations, than any or all other means. Bring men around the same cross; fill them with love to the same Redeemer, and give them the same hope of heaven, and you put a period to alienation and strife. The love of Christ is so absorbing, and the dependence in his blood so entire, that they will lay aside these alienations, and cease their contentions. The work of the atonement is thus designed not only to produce peace with God, but peace between alienated and contending minds. The feeling that we are redeemed by the same blood, and that we have the same Saviour, will unite the rich and the poor, the bond and the free, the high and the low, in the ties of brotherhood, and make them feel that they are one. This great work of the atonement is thus designed to produce peace in alienated minds everywhere, and to diffuse abroad the feeling of universal brotherhood.
---
<font size="6">  

For he himself is our peace, <span style="background:rgba(240, 200, 0, 0.2)">who has made us both one</span> and has broken down in his flesh the dividing wall of hostility 
<font size="5">  
<p align= "left">
He united Jews and Gentiles into one people.  In the cultural context of the time, these groups were divided by deep-rooted hostility and religious barriers. Paul is pointing out that in Christ, those divisions are obliterated. This goes beyond mere tolerance to true unity, and the implications could extend to any divisions among human beings—be it ethnic, social, or otherwise.
<font size="4">  
<p align= "left">
<strong>John 17-21-23 </strong> -  that they may all be one, just as you, Father, are in me, and I in you, that they also may be in us, so that the world may believe that you have sent me.  The glory that you have given me I have given to them, that they may be one even as we are one,  I in them and you in me, that they may become perfectly one, so that the world may know that you sent me and loved them even as you loved me.</font>
<p align= "left">
<strong>One </strong> ([1520]) <strong>heis</strong> - is the cardinal numeral one and in this verse defines that which is united as one in contrast to being divided or consisting of separate parts. Heis speaks of oneness, unity and identity, believing Jew and Gentile united in position and privilege. They are no longer Jews or Gentiles, but Christians. And to go one step further, strictly speaking it is not accurate to speak of them as Jewish Christians or Gentile Christians because all distinctions such as nationality were nailed to the cross.
<font size="4">  
<p align= "left">
Heis in Ephesians -Eph 2:14; <strong>Eph. 2:15; Eph. 2:16; </strong> Eph. 2:18; Eph. 4:4; Eph. 4:5; Eph. 4:6; Eph. 4:7; Eph. 4:16; Eph. 5:31; Eph. 5:33</font>
---

One in Christ
<font size="4">  
<p align= "left">

| Verse Reference | Verse Text                                                                                   |
|-----------------|-----------------------------------------------------------------------------------------------|
| Eph. 2:14       | For he himself is our peace, who has made us both <strong>one</strong> and has broken down in his flesh the dividing wall of hostility, |
| Eph. 2:15       | by abolishing the law of commandments expressed in ordinances, that he might create in himself <strong>one</strong> new man in place of the two, so making peace, |
| Eph. 2:16       | and might reconcile us both to God in <strong>one</strong> body through the cross, thereby killing the hostility. |
| Eph. 2:18       | For through him we both have access in <strong>one</strong> Spirit to the Father.                               |
| Eph. 4:4        | There is one body and one Spirit—just as you were called to the <strong>one</strong> hope that belongs to your call— |
| Eph. 4:5        | <strong>one</strong> Lord, <strong>one</strong> faith, <strong>one</strong> baptism,                                                              |
| Eph. 4:6        | <strong>one</strong> God and Father of all, who is over all and through all and in all.                         |
| Eph. 4:7        | But grace was given to each <strong>one</strong> of us according to the measure of Christ's gift.               |
| Eph. 4:16       | from whom the whole body, joined and held together by every joint with which it is equipped, when each part is working properly, makes the body grow so that it builds itself up in love. |
| Eph. 5:31       | "Therefore a man shall leave his father and mother and hold fast to his wife, and the two shall become <strong>one</strong> flesh." |
| Eph. 5:33       | However, let each <strong>one</strong> of you love his wife as himself, and let the wife see that she respects her husband. |

---
<font size="6">
<p align= "left">

 For he himself is our peace, who has made us both one and <span style="background:rgba(240, 200, 0, 0.2)"> has broken down in his flesh the dividing wall of hostility, </span>
<font size="5">  
<p align= "left">
The <strong>ESV</strong> translation makes the meaning of this passage clear for it reads "he....has broken down in his flesh the dividing wall of hostility." The <strong>NET</strong> is similar and has "destroyed the middle wall of partition, the hostility."
<p align= "left">
<strong>Barrier</strong> (5418) (phragmos from phrasso = to fence or hedge in) describes a fence, or enclosing barrier. It signified originally a fence or railing erected for protection rather than separation. It could be a fence, hedge, a thorn hedge around a vineyard, beside which there was often a wall.
<p align= "left">
<strong>Dividing Wall </strong>  (3320)(mesótoichon from mésos = middle + toíchos = wall) means middle wall or partition. Metaphorically mesótoichon referred to the Mosaic Law separating Jews and Gentiles and recalled the common rabbinic idea of the law as a fence dividing the Jews by their observance of it from all other races and thus arousing hostility.
<p align= "left">
In the Jerusalem temple, a literal wall separated the court of the Gentiles from the areas where only Jews could go. Paul metaphorically expands this to include all laws and regulations that made the Jews distinct from the Gentiles, particularly the laws around circumcision and dietary restrictions. Jesus, through His death and resurrection, broke down these walls, both literal and metaphorical, that kept people from coming together and, more importantly, that kept them from God.

---
Court of Gentiles

![[Pasted image 20231008230939.png]]
---
<font size="5">  
<p align= "left">
<strong>John MacArthur </strong>writes "The barrier of the dividing wall alludes to the separation of the Court of the Gentiles from the rest of the Temple. Between that court and the Court of the Israelites was a sign that read, “No Gentile may enter within the barricade which surrounds the sanctuary and enclosure. Anyone who is caught doing so will have himself to blame for his ensuing death.” This physical barrier illustrated the barrier of hostility and hate that also separated the two groups.  As we learn from the book of Acts, even a Jew who brought a Gentile into the restricted part of the Temple risked being put to death. Although Paul had not done so, certain Jews from Asia accused him of taking Trophimus, a Gentile from Ephesus, into the Temple. They would have stoned Paul to death had he not been rescued by Roman soldiers (Acts 21:27–32). God had originally separated Jews from Gentiles (cf. Isa. 5:1–7; Matt. 21:33) for the purpose of redeeming both groups, not for saving the Jews alone. He placed the Court of the Gentiles in the Temple for the very purpose of winning Gentiles to Himself. It was meant to be a place for Jewish evangelism of Gentiles, a place for winning proselytes to Judaism and of thereby bringing them “near.” It was that court, however, that the Jewish leaders of Jesus’ day used as “a robbers’ den” (Mk 11:17) rather than as a place of witness!

---

Ephesians 2:15-16
<font size="6">  
<p align= "left">
<span style="background:rgba(240, 200, 0, 0.2)">15 by abolishing the law of commandments expressed in ordinances, </span>that he might create in himself one new man in place of the two, so making peace, 16 and might reconcile us both to God in one body through the cross, thereby killing the hostility.
---
<font size="5">  
<p align= "left">
Paul is writing to a mixed audience of Jews and Gentiles in Ephesus. The "law of commandments" he mentions specifically pertains to the Mosaic Law, which governed Jewish life and practice. These laws created a literal and figurative barrier between Jews and Gentiles, establishing an "us vs. them" scenario.  The Jewish laws is what separated them from the Romans and all other nations.  It distinguished them as God's people.
<p align= "left">
<strong>The moral aspects of the law are still very relevant:</strong>
<Br><p align= "left">
<strong>Matthew 5:17</strong>, "Do not think that I have come to abolish the Law or the Prophets; I have not come to abolish them but to fulfill them" 
<p align= "left">
<strong>Ordinances</strong> The "ordinances" likely refer to the ceremonial and civil laws that were particularly relevant for the Jewish religious system, such as dietary restrictions, festivals, and other rites that separated Jews from the rest of making, the Gentiles.  The diversity of the ordinances created an alienation and precluded all social communion. These are distinct from the moral laws (like the Ten Commandments), which are universally binding and are reiterated in the New Testament.
<p align= "left">
Remember the purpose of the Law. The law serves multiple functions, including acting as a tutor to bring us to Christ (Galatians 3:24). The ceremonial aspects were a shadow of the things to come, the substance of which is Christ (Colossians 2:17). When Christ came, He fulfilled these shadows, making them obsolete as a means of separation between Jews and Gentiles.
---
<font size="6">
<p align= "left">

 <span style="background:rgba(240, 200, 0, 0.2)"> that he might create in himself one new man in place of the two, </span>
<font size="5">  
<p align= "left">
Paul is pointing out that Jesus' work was transformative, resulting in a new entity that is neither exclusively Jew nor Gentile. This "one new man" signifies the Church, a new spiritual entity that comprises believers from all backgrounds.
<p align= "left">
This new creation is <strong> "in Himself," </strong>in Christ. This speaks to the fact that Christ is not just the agent of this new creation but also the sphere in which the new man exists.
<p align= "left">
The <strong>"one new man" </strong>represents the unified body of believers, commonly understood as the Church. Here, Paul is emphasizing that the unity is so profound it's almost as if a new "species" of humanity has been created. Early Christians actually called themselves a “third race” or a “new race.” They recognized that they were not Jews, not Gentiles, but one new man embracing all who are in Jesus.
<p align= "left">
<strong>in place of the two</strong> The "two" refers to Jews and Gentiles. Paul’s point is that these two groups, once separated by a host of religious laws and ethnic boundaries, have been made one in Christ. The "one new man" also points toward the culmination of history where all believers, from every tribe and tongue, will be united in worship before God.
<p align= "left">
The Church is not just a human institution but a divine creation, intended to transcend all earthly divisions: social, economic, and racial barriers.
---
<font size="6">
<p align= "left">
By abolishing the law of commandments expressed in ordinances, that he might create in himself one new man in place of the two <span style="background:rgba(240, 200, 0, 0.2)"> so making peace", </span>
<font size="5">  
<p align= "left">
The term "so" indicates that the making of peace is the logical outcome of what Christ has done. By abolishing the law of commandments and creating "one new man," Christ has laid the groundwork for peace. This peace is both vertical (between God and humanity) and horizontal (among human beings).
<p align= "left">
This is not just an absence of hostility but a true genuine of wellbeing and unity. The Greek word for peace, "eirene," conveys not merely the absence of conflict but the presence of justice and righteousness. The word "eirene" comes from the verb "eiro," which means to "join" or "bind together that which has been separated." In Hebrew, the equivalent term is "Shalom," which encompasses not only peace but also completeness, soundness, and wellbeing.
---
<font size="6">
<p align= "left">
 <span style="background:rgba(240, 200, 0, 0.2)"> And might reconcile us both to God in one body through the cross, </span> thereby killing the hostility"
<font size="5">  
<p align= "left">
The reconciliation is twofold—among humans and between humans and God. The term "one body" here underscores the unity that believers share because of Jesus’ sacrifice on the cross.
<p align= "left">
<strong>“Reconcile”  </strong> implies restoring a relationship that has been broken, specifically between God and humanity due to sin.
<p align= "left">
The phrase <strong> us-both</strong> is a continuation from previous verses where Paul is discussing the Jew-Gentile divide.
<p align= "left">
The<strong> 'one body'</strong> is the Church, the community of believers. This affirms the corporate nature of  our salvation, not just individualistic. 
<p align= "left">
The means of this reconciliation is explicitly stated as being <strong> “through the cross.” </strong>This points to the substitutionary atonement of Christ, Just as peace comes through the blood of Christ, reconciliation comes through the cross. They are parallel truths. 
---
<font size="6">
<p align= "left">

And might reconcile us both to God in one body through the cross,<span style="background:rgba(240, 200, 0, 0.2)"> thereby killing the hostility" </span>
<font size="5">  
<p align= "left">
Jesus’ work didn’t just paper over the hostility or set it aside temporarily; his work through the cross <strong>"killed"</strong> it. This is a forceful term, emphasizing the finality and completeness of the reconciliation.
<p align= "left">
<strong>Killing</strong>: The Greek word here is "apokteino," which means to kill or abolish. It is a strong word that denotes a definitive, irreversible action. It emphasizes the efficacy and completeness of Christ’s work.
<p align= "left">
<strong>Hostility</strong>: The Greek word for hostility is "echthra," which can refer to enmity, hatred, or hostility. The term encapsulates both vertical hostility (man against God) and horizontal hostility (man against man). It's a comprehensive term, pointing to the various ways sin creates barriers.
<p align= "left">
The cross is thus not just a place of reconciliation with God but also the killing ground for hostility between humans.
---
<font size="4">
<p align= "left">
Without input from Christians with very different backgrounds and
experiences from my own, I will not know all of what the gospel should
mean in areas of life that I have not yet explored. Thus I must examine my
heart and life to see where I may be distant from those God intends to help
me better know him. Others have described a hierarchy of hatred that I have
found useful in checking my own attitudes against the commands of
Scripture. The hierarchy moves from obvious bigotry to subtle racism to
true unity: 
 
1. We have reason to hate them, because of their race.
2. We will tolerate them, if they stay in their place.
3. We will accept them, if they become like us.
4. We will accept them, despite our differences.
5. We will love them, because God wants us to help them.
6. We will love them, because we need them to help us understand God. 
 
<p align= "left">
Unless I realize that there are treasures of God that I will not discover
until I am in union with brothers and sisters quite different than I, I will not
pursue the bonds of humanity that enable me to know the fullness of the
God who is my delight. I thought of this after reading the results of a survey
that found that most evangelicals think of their faith only in terms of “Jesus
and me.” Love for the lost, concern for the evils of society, the plight of the
poor, hunger in the world, the pervasive trap of illiteracy for two-thirds of
all peoples, the injustices of racism and materialism, too often are deemed the social causes of “bleeding heart” liberals or distracted evangelicals. Yet to
know Christ as God intends, I must realize that without concern for the
plight of all persons, my heart deadens to the Word of God for me. Jesus
said that whatever we do for the least of his people, we do for him (Matt.
25:40). I cannot dishonor him by shunning or disregarding any of his
people, and at the same time believe that my heart will still fully experience
his. - Bryan Chapell Ephesians
---
<font size="6">
<p align= "left">

<span style="background:rgba(240, 200, 0, 0.2)">And he came and preached peace to you who were far off and peace to those who were near.  </span>
<font size="5">  
<p align= "left">
<strong>And He came</strong> - Refers to Jesus Christ, who physically came into the world to accomplish God's redemptive plan. The phrase underscores the incarnation.
<p align= "left">
<strong>preached peace</strong> The term 'preached' in Greek is "euaggelizo," from which we get "evangelize." The 'peace' mentioned is "eirene," which is the same as earlier, well-being, presence of justice and righteousness.
<p align= "left">
<strong>to you who were far off</strong> Once again this would refer to the Gentiles, were outside the original covenant community of Israel and therefore remote spiritually, without Christ, without hope, without God in the world, strangers to the covenant of promise and to the commonwealth.
<p align= "left">
<strong>and peace to those who were near</strong> This would refer to the Jews who were under the Mosaic covenant and considered closer to God's promises. They were not stranger to them.
<p align= "left">
Note: It's the same gospel preached to both. The same message. Peace with God. The Good news!
---
END READING<br>
Ephesians 2:13-17
<font size="5">  
<p align= "Justify">
11 Therefore remember that at one time you Gentiles in the flesh, called “the uncircumcision” by what is called the circumcision, which is made in the flesh by hands— 12 remember that you were at that time separated from Christ, alienated from the commonwealth of Israel and strangers to the covenants of promise, having no hope and without God in the world. <u>13 But now in Christ Jesus you who once were far off have been brought near by the blood of Christ. 14 For he himself is our peace, who has made us both one and has broken down in his flesh the dividing wall of hostility  15 by abolishing the law of commandments expressed in ordinances, that he might create in himself one new man in place of the two, so making peace, 16 and might reconcile us both to God in one body through the cross, thereby killing the hostility.  17 And he came and preached peace to you who were far off and peace to those who were near. </u>18 For through him we both have access in one Spirit to the Father. 19 So then you are no longer strangers and aliens,  but you are fellow citizens with the saints and members of the household of God, 20 built on the foundation of the apostles and prophets, Christ Jesus himself being the cornerstone, 21 in whom the whole structure, being joined together, grows into a holy temple in the Lord. 22 In him you also are being built together into a dwelling place for God by the Spirit.
---
CLOSING PRAYER 
==
---