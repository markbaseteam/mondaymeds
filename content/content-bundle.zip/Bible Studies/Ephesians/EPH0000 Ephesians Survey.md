Date: [[2023-05-01]]
Book: [[Books/Ephesians]]
Verses: [[Ephes-01#v1|Eph. 1:1]] [[Ephes-01#v2|Eph.1:2]]

**Resources:**
[Timeline of the Apostle Paul](https://www.blueletterbible.org/study/paul/timeline.cfm)
[Map - Paul's Missionary Journey's](https://viz.bible/journeys/)
[Bible Atlas Pages 181-187](http://www.isdet.com/_PDF/Bible_Atlas.pdf)
[Bible places - Ephesus](https://www.bibleplaces.com/ephesus/)

> [!Bible]- [Ephesians 1:1-2 - ESV](https://bolls.life/ESV/49/1/)
>  1. Paul, an apostle of Christ Jesus by the will of God, To the saints who are in Ephesus, and are faithful  in Christ Jesus: 2. Grace to you and peace from God our Father and the Lord Jesus Christ.

**Chapters:** 6
**Verses:** 155
**Words** 3039
•Ephesians contains some of most complex sentences. 1 sentence in Greek is 244 words translated into 8 English sentences.
•The phrase “In Christ” or its equivalent is used 27x

**Author:**  [[Paul the Apostle]]
**Genre:** Letter, Epistle
**Recipients:** [[Ephesus]],
	- Some manuscripts 'saints who are also faithful' (omitting 'in Ephesus')
	-  Ephesians may have been what is called a “circular letter.” Some believe it may not have been addressed to Ephesus specifically, but rather, to several churches in the region. Reasons for this viewpoint:
		-The words “*at Ephesus*” in [Eph 1:1] are not found in the Codex Sinaiticus or Codex Vaticanus, which are two of the oldest manuscripts of the New Testament that we have today. Instead it is written in the margins of some manuscripts and there is a blank line where a church name might be filled in. The copy of letter that went to the Ephesians is the one that we have.
		- The letter itself is written very broadly
		- It tells us nothing at about the recipients
		- It addresses no particular concerns 
		- The letter does not make any personal references except for sending Tychicus [[Ephes-06#v21|Eph. 6:21]]  [[2 Tim-04#v12|2Tim 4:12]]
		- [[Ephes-03#v2|Eph 3:2]] makes it sound as though Paul did not personally know his recipients. 
	
**Place Written:**  Rome, While Paul was under house arrest in his first imprisonment.  One of four prison letters. Ephesians, Colossians, Philippians, Philemon

### **Time Written:**  60-62 AD (See Timeline)
- Paul is believed to have been released from his first Roman imprisonment in AD 62.
**Historical Setting**
- The Roman Empire surrounded much of the Mediterranean Sea a primary trade route in the middle east to Asia.  Jerusalem was a crossroads to the world. The sea connected 3 continents, Africa, Asia & Europe. Most of the western population was centered around this trade route. It allowed products of Asia to pass into Europe. (See Bible Atlas)
-  Emperor Nero ruled 54-68 AD. He started Rome when he was 16 as the youngest Emperor. This would have been about the time when Paul was living in Ephesus and wrote 1 & 2 Corinthians. 
- Nero was the fifth and last of the five Roman Emperors of the Julio-Claudian dynasty which included Augustus, Tiberius, Caligula, Claudius and Nero. They had ruled starting with Augustus in 27 BC to Nero's suicide in AD 68.  He would have been 30 years old.
-  Agrippa II of the Herodians rules the northeast of Judea
- At least 2-3 years before the Great Fire that burned down Rome in 64 AD and some of the worst persecution to Christians would begin under Nero after he blamed the fire on the Christians.
- There was already much affliction and persecution going with the early Christians in this time period, especially after the stoning after Stephen recorded in Acts 7,  [[Acts-08#v1|Acts 8:1]]  [[Acts-11#v19|Acts 11:19]]


### Ephesus the City 
#### **NT References:
Ephesus is referenced 20x in New Testament - A significant city in the early Christian Church and 1 of the 7 churches in Revelation. It was a very busy church that knew its doctrine, they could recognize and call out false doctrine, but is referred to as the "loveless church" because it had forgotten its first love

1.  [[Acts-18#v19|Acts 18:19]]  [[Acts-18#v21|Acts 18:21]] [[Acts-18#v24|Acts 18:24]]  [[Acts-18#v27|Acts 18:27]] [[Acts-19#v1|Acts 19:1]] [[Acts-19#v17|Acts 19:17]] [[Acts-19#v23|Acts 19:23]]  [[Acts-19#v26|Acts 19:26]]  [[Acts-19#v35|Acts 19:35]] [[Acts-20#v16|Acts 20:16-17]] [[Acts-21#v29|Acts 21:29]]
2.  [[1 Cor-15#v32| 1 Cor. 15:32]]  [[1 Cor-16#v8| 1 Cor. 16:8]] 
3.  [[Ephes-01#v1|Eph 1:1]]
4.  [[1 Tim-01#v3|1 Tim 1:3]]
5.  [[2 Tim-01#v8|2 Tim. 1:8]] [[2 Tim-04#v12|2 Tim 4:12]]
6.  [[Rev-01#v11|Rev 1:11]]  [[Rev-02#v1|Rev 2:1-7]] 

> [!Bible]- [Revelation 2:1-7 - ESV](https://bolls.life/ESV/66/2/)
>  1. “To the angel of the church in Ephesus write: ‘The words of him who holds the seven stars in his right hand, who walks among the seven golden lampstands. 2. “‘I know your works, your toil and your patient endurance, and how you cannot bear with those who are evil, but have tested those who call themselves apostles and are not, and found them to be false. 3. I know you are enduring patiently and bearing up for my name's sake, and you have not grown weary. 4. But I have this against you, that you have abandoned the love you had at first. 5. Remember therefore from where you have fallen; repent, and do the works you did at first. If not, I will come to you and remove your lampstand from its place, unless you repent. 6. Yet this you have: you hate the works of the Nicolaitans, which I also hate. 7. He who has an ear, let him hear what the Spirit says to the churches. To the one who conquers I will grant to eat of the tree of life, which is in the paradise of God.’


Ephesus was the commercial center of Asia Minor.  Some compare it to Hong Kong. It was a very wealthy port city.

Ephesus was highly into idolatry. The city was famous for the temple of Diana (Roman name) or Artemis (Greek name), considered to be one of the seven wonders of the ancient world. [[Acts-19#v27|Acts 19:27]]  [[Acts-19#v35|Acts 19:35]]

#### **Key Facts & Events in Ephesus:**
•Paul remained in Ephesus for nearly three years on his 3rd missionary journey. Acts 18:23 -19:41 Paul had a very strong relationship with the city of Ephesus.

•In Ephesus is where Paul leaves Aquila and Priscilla; enters into a synagogue, where he reasons with the Jews; starts on his return trip to Jerusalem;  [Acts 18:18-23]

•Paul returns to Ephesus in [Acts 19:12]; immerses in the name of the Lord Jesus, and lays his hands upon the disciples, who are baptized with the Holy Spirit; preaches in the synagogue; remains in Ephesus for two years; heals the sick people.

•Paul sends for the elders of the congregation of Ephesus; relates to them how he had preached in Asia and his temptations and afflictions, urging repentance toward God [Acts 20:17-21]

•Timothy pastored Ephesus after Paul. [1 Tim 1:3] Paul encouraged Timothy to remain at Ephesus.

•The letter to 1 Corinthians was written at Ephesus [1 Cor. 16:8]

•The church at Ephesus was one of the seven churches of Asia [Rev 1:4]

•John the Apostle is believed to have lived out the last of his days in Ephesus and possibly Mary the mother of Christ since he cared for her but there is no proof of Mary living in Ephesus with John, most scholars believed she was buried in Jerusalem.

Out of the 155 verses in Ephesians, about half are also found in Colossians in varying degrees. Compare:
	[[Ephes-01#v7|Eph. 1:7]]  to [[Col-01#v14|Col. 1:14]]  
	[[Ephes-01#v10|Eph. 1:10]] to [[Col-01#v20|Col.1:20]]
	[[Ephes-01#v16|Eph. 1:16]] to [[Col-01#v9|Col. 1:9]]
	[[Ephes-01#v21|Eph 1:21]]  to [[Col-01#v16|Col 1:16 ]]
	[[Ephes-02#v5|Eph 2:5]] to [[Col-02#v13|Col 2:13 ]]
	[[Ephes-03#v2|Eph 3:2]] to [[Col-01#v25|Col 1:25]]
	[[Ephes-04#v2|Eph 4:2-4]] to [[Col-03#v12|Col 3:12-15]] 
	[[Ephes-04#v16|Eph 4:16]] to [[Col-02#v19|Col 2:19]]
	[[Ephes-04#v22|Eph 4:22-24]] to [[Col-03#v9|Col 3:9-10]]
	[[Ephes-04#v24|Eph 4:24-25]] to [[Col-03#v9|Col 3:9]]
	[[Ephes-04#v32|Eph 4:32]] to [[Col-03#v13|Col 3:13]]
	[[Ephes-05#v6|Eph 5:6-8]] to [[Col-03#v6|Col 3:6-8 ]]
	[[Ephes-05#v15|Eph 5:15-16]] to [[Col-04#v5|Col 4:5]]  
	[[Ephes-05#v19|Eph 5:19]] to [[Col-03#v16|Col 3:16]]
	[[Ephes-05#v20|Eph 5:20-22]] to [[Col-03#v17|Col 3:17-18]]
	[[Ephes-06#v4|Eph 6:4]] to [[Col-03#21|Col 3:21]]  
	[[Ephes-06#v5|Eph 6:5-9]] to [[Col-03#v22|Col 3:22-4:1]]
	[[Ephes-06#v19|Eph 6:19-22]] to [[Col-04#v3|Col 4:3-4]]  
	[[Ephes-06#v22|Eph 6:22]] to [[Col-04#v8|Col 4:8]]

 
### Why it was written:
To help converts grow in their spiritual knowledge of Christ. Eph 1:15–18; 3:14–19
To promote unity among believes, especially between the Jew and Gentile saints Ephesians 2:11–22; 4:1–16; 5:19–6:9

### Key Theme: 
The Mystery of the Church, that the Gentiles should be fellow heirs. The Unity of the church body.

### Key Divisions: 
First 3 chapters are theological. 
Last 3 are practical.

First 3 are vertical our relationship to God   
Last 3 are horizontal , our relationship with others.

Doctrine
Duty

The Root
The Fruit

Belief
Behavior

### Key Doctrines:
**The Doctrines of Grace**
	The election and predestination of believers. [[Ephes-01#v3||Eph 1:3-6]]
	The redemption and forgiveness of sins through Christ's blood. [[Ephes-01#v7|Eph 1:7-10]]
	The sealing and guarantee of the Holy Spirit [[Ephes-01#v11|Eph. 1:11-14]]
	The power of God raising Christ from the dead and exalting him above all things, [[Ephes-01#19|Eph 1:19-23]]
	The spiritual death and depravity of all humanity apart from God's grace [[Ephes-02#v1|Eph 2:1-3]]
	The gracious work of God in raising believers from spiritual death and making them alive in Christ [[Ephes-02#v4|Eph 2:4-10]]
**The Unity of the Church**
	The reconciliation of Jews and Gentiles through Christ's sacrifice [[Ephes-02#v11|Eph 2:11-18]]
	The formation of a new humanity and household in Christ [[Ephes-02#v19|Eph 2:19-22]]
	The revelation of the mystery of Christ and the church to Paul [[Ephes-03#v1|Eph 3:1-13]]
	The prayer for believers to be strengthened by the Spirit and to comprehend love of Christ [[Ephes-03#v14|Eph 3:14-21]]
**The New Life in Christ**
	The call to walk in unity, humility, and love within the body of Christ [[Ephes-04#v1|Eph 4:1-16]]
	The exhortation to put off the old self and put on the new self. [[Ephes-04#v17|Eph 4:17-32]]
	The call to imitate God in love and submission with various relationships [[Ephes-05#v1|Eph 5:1-9]]
	The call to put on the armor of God in order to stand firm against the devil and his schemes [[Ephes-06#v10|Eph 6:10-20]]

## Paul

[[Paul the Apostle]]
[[The Acts of Paul]]
[[Timeline of the Apostle Paul]]


