[[Ephes-01#v4]]

> [!Bible]- [Eph 1:4-6 - ESV](https://bolls.life/ESV/49/1/)
>  4. even as he chose us in him before the foundation of the world, that we should be holy and blameless before him. In love 5. he predestined us  for adoption to himself as sons through Jesus Christ, according to the purpose of his will, 6. to the praise of his glorious grace, with which he has blessed us in the Beloved.


![[Drawing EPH0104 Diagram.excalidraw]]


## He Chose Us  
### The Fountainhead of All Blessings
Here in Ephesians 1:4-6 as we begin to really unpack these spiritual blessings referenced in verse three. The very first blessing is the blessing of being chosen by God. It is the blessing every other spiritual blessing flows out of and is built on.
               - salvation
               - predestination as adoption
               - redemption through Christ's blood
               - the forgiveness of our sins
               - recipients of his glorious grace
               - knowledge of the mystery of God's will
               - an inheritance
               - sealed with the holy spirit as guarantee.

He chose us, this is the fountainhead of every other spiritual blessing. Without this fountain head in place, none of the other blessings would flow to us. There would  be no redemption, no forgiveness of sins, and no adoption as children of God. It is the preeminent blessing, the very first blessing listed in Ephesians 1:4.

There are those who do not see God's divine election of us made out of his great love and grace as a spiritual blessing but instead as a violation of our free will.  

There is much debate beneath the depths of these 3 words that we are going to  touch on but not deep dive into because the disagreements have been going on for centuries and we only have less then an hour. 

Also, I do not have anything to add to that conversation which the best minds in history over the last 2000 years have thoroughly examined and written some wonderful, extensive books on this topic already. I don't have any radical new insights to add and if I did, it would probably indicate heresy. If it sounds strange, it probably is strange.

I don't want to kick off this bible study with the debate. I don't want to give it first preeminence. I want the word of God to speak for itself. I want you to see for yourself what the word of God says. Then and only then will you prepared to hear the difficulties in a text or truth as we begin to connect truths and see they don't always line up as neatly as we like.  It does not mean that any of the seemingly contradictory truths are untrue, but you have to examine them in context and sometimes do what I call "theological algebra". This is when you know the answer is absolute (ie.,God is good); but, you have to solve for "X" which seemingly contradicts the answer, (God does not save everyone, God allows evil, suffering).  You have to solve for this while not violating any revealed truths of scripture nor the fundamental attributes of God.  Namely his sovereignty, his immutability, his self-sufficiency, his justice, his holiness.  A thorough understanding of the attributes of God is in many ways a pre-requisite study before engaging in deeper studies.  You have to know God!  You can't just jam a answer into "x".  So let us acknowledge that there are many truths which are very clear cut, but there are others that are more difficult and the doctrine of election and predestination is among the more difficult.  

On top of all this, we also have to deal with those who would distort the word of God to their own destruction. [[2 Pet-03#v16|2 Ptr 3:16-]][[2 Pet-03#v17|17]], [[Ephes-04#v14|Eph 4:14]], [[2 Tim-02#v15|2 Tim 2:15]] 

Remember, God is light. He wills that you understand his word.  He has revealed great mysteries to us in the knowledge of his will and in Christ. There are no elites with him, no Gnostics or mystical elites or modern day prophets with special access to God that you do not possess; there are only those who have spent intensive hours in reading, meditating and praying to understand his word. By doing so they have become filled with the Holy Spirit, captivated by the mind of God and in love with his ways, his wisdom and his word.



#### Majestic 3 Words
He chose us. Subject, verb, direct object. A remarkably simple complete, 3-word sentence. God the Father is performing the action on the direct object, us, the Saints. God chose us. So simple and yet so majestic in nature.  These three words contain so much depth. The rest of this verse contains supporting clauses and phrases that build on and expand the idea of this one sentence. Q. When did he choose us? A. Before the foundation of the world. Q. Why did he choose us? A. 1. That we would be holy and blameless. 2. According to the pleasure of his own will and purpose. 3. To the praise of the glory of his grace. Q. How did he choose us? A. By predestining us to adoption. 

And remember, in the Greek language, this verse is a part of a much larger giant run-on sentence that runs through to verse fourteen. So, all the blessings flow from: He chose us.  This is a very God centered truth  God chose us according to the pleasure of his will, according to the glory of his grace.

### Chose  - To Select
G1586 ἐκλέγομαι eklegomai (ek-le'-ğo-mai) v.
to select.
[middle voice from G1537 and G3004 (in its primary sense)]
KJV: make choice, choose (out), chosen 

God, according to the pleasure of his will, to the praise of his glorious grace, chose us. He selected us out for himself, making us who were dead in our sins and transgressions, alive in Christ, quickening our spirits and making us heirs of salvation...before the foundation of the world. 

> "*God chose us in Christ before the foundation of the world,""*

It is a great mystery is not? It raises a lot of questions does it not? This truth has a lot of implications when you let it sink in and meditate on it.  It deals with how the saints became saints. How the elect became elect. How the chosen became chosen. It is not the gospel but it is the power behind the gospel. 

###  Doctrine of Predestination
He chose us. This truth is also known as the Doctrine of Election.  In a few more verses we are going to see the Doctrine of Predestination.  They are very closely related but they are not the same doctrine.  The Doctrine of Predestination is much broader and encompasses the Doctrine of Election, along with other doctrines dealing with God's providence and sovereignty.  The doctrine of Predestination essentially says God pre-determines what ever comes to pass. God makes a plan and he brings it to pass. God's word does not return to him void. 

[[Isa-55#v11|Isaiah 55:11]]
![[Isa-55#v11|Isaiah 55:11]]
**Luke 1:37**
![[Luke-01#v37]]
**Joshua 21:45**
![[Josh-21#v45]]

God is known for keeping his word. This should not be shocking to us. God keeps his word. God's word never fails. He always keeps his promises. He declares the end from the beginning. He does not lie, he does not fail and he does not change his mind.

**Isaiah 46:10**
![[Isa-46#v10]]

So why is the doctrine of election and the doctrine of predestination so difficult? 

It's not. Why would we think God would create the world, mankind, the plan of redemption and not ensure the outcome he intended would occur? 

When we do project planning the first thing we do is a scope a project. We determine what we want to happen, what we need to accomplish. and then we begin to determine all the steps we need to take in order to ensure our goals and plans happen according to our will. We have to think of everything that could and will go wrong and be prepared how to address those situations if and when they arise. Then we have to expect the unexpected. We cannot foresee everything despite our years of experience. 

This is man. Predestination is nothing but pre-determining the end result. Having a will and and end in mind.  Why is it hard for us to believe that God would plan the end from the very beginning? Why wouldn't He? He is the Creator. What kind of God would He be if he did not? If He just created the world and had no purpose for it or for us?

God had a plan and a purpose when he created the world, when he created man. God knew man was susceptible by nature and would sin.  Adam's sin did not catch God by surprise. It did not force God to change his plans. It did not impact the end goal. God is not in crisis management over sin.  God ultimately allowed Adam to sin. He allowed mankind to fall into sin and He continues to allow sin to occur for his own purposes.  Is it God's will for man to sin? No. But God allows mankind to sin within limits and boundaries that He has determined and limited by his grace.

### God's Greater Will & Lesser Will
There is a theological framework for this, that is debated as all things theological all. But the concept as I have always understood it,  is referred to as the two wills of God. God's greater will and God's lesser will. This framework seeks to explain the relationship between God's sovereignty and human free will. 

God's greater will refers to His overarching, sovereign will that encompasses His divine plan and purpose for the entire universe. It represents God's ultimate intentions and desires for creation. This greater will is often seen as absolute and unchangeable. It encompasses God's eternal decrees and encompasses His providential control over all things, including human actions.

According to this perspective, God's greater will cannot be thwarted or contradicted by any human choices or actions. It is seen as comprehensive and all-encompassing, unfolding according to God's perfect wisdom and sovereignty. From this viewpoint, God's greater will is often associated with His divine sovereignty and foreknowledge and is always good.

God's lesser will, also known as His permissive will or will of command, refers to His desires and instructions for human beings within the framework of their free will. 
God's lesser will allows for human freedom and choice within certain boundaries and guidelines. It presents moral laws and commandments that provide guidance for human conduct. God's lesser will reflects His desire for humanity to align with His moral standards and live in accordance with His revealed wisdom.

In this perspective, God's lesser will may not always be perfectly fulfilled due to human free will and the presence of sin and evil in the world. Humans have the ability to either align with God's desires or choose to act contrary to them.  God in his unsearchable understanding, wisdom and knowledge, knows us. He knows our nature, our inclinations and knows how we will respond in any given situation better then we do. Before a word is on our tongues, he knows what we are going to say.  God knows our strengths and he knows our weaknesses. He knows us. 

> **Acts 4:27-28**
> for truly in this city there were gathered together against your holy servant Jesus, whom you anointed, both Herod and Pontius Pilate, along with the Gentiles and the peoples of Israel,  to do whatever your hand and your plan had predestined to take place.

God knew Pharoah would harden his heart. God knew the Pharisees were looking for an opportunity to seize Jesus. God knew Pilot would cater to the people, despite his wife trying to persuade him not have anything to do with the situation. God knows us intimately. God according to his own mercy and grace, may or may not intercede to prevent us from doing something harmful that is within this lesser will. He may "goad" us in the direction we need to go in at times. He encourages us to pray and to seek his direction. But if we don't, he may to choose to let us go as prodigals and to face the consequences of our bad choices.  

God from the very beginning has made man's sin his slave, using it to accomplish his purposes. We see this in the situation with Pharoah, the Assyrian Armies that God would allow to rise up and bring against Israel to discipline them at times, the Cross. 

The fact that God in his merciful providence makes sin his slave to accomplish his good purposes should give us immense peace and comfort.   


### Total Depravity 
Within this concept of God's greater and lesser will, we can understand that God wills all men to be saved. He does not want to see any man perish. But will all men be saved? No. Why?  They do not will it. Because of their corrupt and fallen nature. Men will not and cannot come to God:

| Ref        | Man's Condition- Total Depravity                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| ---------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Gen 6:5    | he Lord saw that the wickedness of man was great in the earth, and that every intention of the thoughts of his heart was only evil continually.                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Jer 13:23  | Can the Ethiopian change his skin or the leopard his spots? Then also you can do good who are accustomed to do evil.                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| Isa 64:6   | We have all become like one who is unclean,  and all our righteous deeds are like a polluted garment. We all fade like a leaf,  and our iniquities, like the wind, take us away.                                                                                                                                                                                                                                                                                                                                                                                                                |
| Rom 5:12   | Therefore, just as sin came into the world through one man, and death through sin, and so death spread to all men because all sinned—                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Eph 2:1-5  | And you were dead in the trespasses and sins in which you once walked, following the course of this world, following the prince of the power of the air, the spirit that is now at work in the sons of disobedience— among whom we all once lived in the passions of our flesh, carrying out the desires of the body and the mind, and were by nature children of wrath, like the rest of mankind.  But God, being rich in mercy, because of the great love with which he loved us,  even when we were dead in our trespasses, made us alive together with Christ—by grace you have been saved— |
| John 14:17 | even the Spirit of truth, whom the world cannot receive, because it neither sees him nor knows him. You know him, for he dwells with you and will be in you                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| 1Cor. 2:14           | Now the natural man doesn't receive the things of God's Spirit, for they are foolishness to him, and he can't know them, because they are spiritually discerned.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |

Since sin has entered the world, man's will has been a slave to sin. Such a strong slave that we are said to be dead in our trespasses and sins, unable to receive the Spirit of truth (John 14:17) Being unable to receive the spirit of truth, we are unable to come to God on our own. God's spirit must quicken us and make us alive. The grace of God enables us to come to Jesus by drawing us .

| Ref       | God the Father Brings Us to Christ:                                                                                        |
| --------- | ----------------------------------------------------------------------------------------------------------- |
| John 6:44 | "No one can come to me unless the Father who sent me draws them, and I will raise them up at the last day." |
| John 6:37 | All that the Father gives me will come to me, and whoever comes to me I will never cast out.                |
| John 10:29          |  My Father, who has given them to me, is greater than all, and no one is able to snatch them out of the Father's hand.                                                                                                           |

### Who does God draw to Christ?
Those He has chosen.  A careful study of scriptures will show that we did not choose God but God choose us.  It was God's electing us first, to to respond to the gospel by quickening our spirits that drew us to him. 

<span style="background:rgba(240, 200, 0, 0.2)">In many cases, as in Paul's, it was an interruption in our life, it was against our initial will until He swayed us.</span> We love him because he first loved us. While we were yet sinners, Christ died for us. (Rom 5:8)

| Ref          | God Chose us                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| John 15:16   | "You did not choose me, but I chose you and appointed you so that you might go and bear fruit—fruit that will last—and so that whatever you ask in my name the Father will give you."                                                                                                                                                                                                                                                                          |
| Matt 22:14   | "Many are called, but	few	chosen"                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Matt 25:34   | Then the King will say to those on his right, 'Come, you who are blessed by my Father; take your inheritance, the kingdom prepared for you since the creation of the world.                                                                                                                                                                                                                                                                                    |
| John 6:37    | All that the Father gives me will come to me, and whoever comes to me I will never cast out.                                                                                                                                                                                                                                                                                                                                                                   |
| Acts 13:48   | And when the Gentiles heard this, they began rejoicing and glorifying the word of the Lord, and as many as were appointed to eternal life believed.                                                                                                                                                                                                                                                                                                            |
| Rom 11:5-7   | So too at the present time there is a remnant, chosen by grace.  But if it is by grace, it is no longer on the basis of works; otherwise grace would no longer be grace. What then? Israel failed to obtain what it was seeking. The elect obtained it, but the rest were hardened,                                                                                                                                                                            |
| 1 Ptr 2:9    | But you are a chosen race, a royal priesthood, a holy nation, a people for his own possession, that you may proclaim the excellencies of him who called you out of darkness into his marvelous light.                                                                                                                                                                                                                                                          |
| Rom 9:15-18  | For he says to Moses, “I will have mercy on whom I have mercy, and I will have compassion on whom I have compassion.” So then it depends not on human will or exertion, but on God, who has mercy.  For the Scripture says to Pharaoh, “For this very purpose I have raised you up, that I might show my power in you, and that my name might be proclaimed in all the earth.” 18 So then he has mercy on whomever he wills, and he hardens whomever he wills. |
| John 17:9    | I pray for them: I pray not for the world, but for them which thou hast given me; for they are thine.                                                                                                                                                                                                                                                                                                                                                          |
| John 10:16   | And I have other sheep that are not of this fold. I must bring them also, and they will listen to my voice. So there will be one flock, one shepherd.                                                                                                                                                                                                                                                                                                          |
| John 10:26   | but you do not believe because you are not among my sheep.                                                                                                                                                                                                                                                                                                                                                                                                     |
| John 8:47    | Whoever is of God hears the words of God. The reason why you do not hear them is that you are not of God.”                                                                                                                                                                                                                                                                                                                                                     |
| Rev 17:8b    | And the dwellers on earth whose names have not been written in the book of life from the foundation of the world will marvel to see the beast, because it was and is not and is to come.                                                                                                                                                                                                                                                                       |
| Jude 1:4     | For there are certain men crept in unawares, who were before of old ordained to this condemnation, ungodly men, turning the grace of our God into lasciviousness, and denying the only Lord God, and our Lord Jesus Christ.”                                                                                                                                                                                                                                   |
| 1 Tim 1:9    | who saved us and called us to a holy calling, not because of our works but because of his own purpose and grace, which he gave us in Christ Jesus before the ages began,                                                                                                                                                                                                                                                                                       |
| 2 Thess 2:13 | But we are bound to give thanks always to God for you, brethren beloved of the Lord, because God hath from the beginning chosen you to salvation through sanctification of the Spirit and belief of the truth:                                                                                                                                                                                                                                                 |
| John 15:19             |  If you were of the world, the world would love his own: but because you are not of the world, but I have chosen you out of the world, therefore the world hates you.                                                                                                                                                                                                                                                                                                                                                                                                                                                             |


#### We are the Elect

All through out scripture, the saints are called the elect of God which also means "Selected" and these words "chosen" and "elect" are almost interchangeable in meaning 

**Hebrew** - H972 בָּחִיר (bâchîyr | baw-kheer') select, choose, chosen one, elect.
**Greek** - G1588 κλεκτός (eklektós | ek-lek-tos') select; by implication, favorite, Chosen, Elect

The Saints are the 'Elect' of God, chosen by grace, favored and blessed.  In his sovereignty, God chose "the Elect" according to his own will, purposes, plan with no external influences. This truth is found all throughout scripture and not just here in Ephesians or using the word 'chosen'. Consider the additional following verses:

| Ref.      | Verses 'Elect'                                                                                                                                                                                          |
| --------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Isa 45:4  | For Jacob my servant's sake, and Israel my **elect**, I have even called you by your name: I have surnamed you, though you have not known me.                                                   |
| Isa 65:9  | And I will bring forth a seed out of Jacob, and out of Judah an inheritor of my mountains: and my **elect** shall inherit it, and my servants shall dwell there.                                |
| Mat 24:31 | And he shall send his angels with a great sound of a trumpet, and they shall gather together his **elect** from the four winds, from one end of heaven to the other.                            |
| Luk 18:7  | And shall not God avenge  his own **elect**, which cry day and night to him, though he bear long with them?                                                                                     |
| Rom 8:33  | Who shall lay any thing to the charge of God's **elect**? It is God that justifies.                                                                                                             |
| Col 3:12  | Put on therefore, as the **elect** of God, holy and beloved, bowels of mercies, kindness, humbleness of mind, meekness, long-suffering;                                                         |
| 1Ti 5:21  | I charge you before God, and the Lord Jesus Christ, and the **elect** angels, that you observe these things without preferring one before another, doing nothing by partiality.                 |
| 2Ti 2:10  | Therefore I endure all things for the **elect**'s sakes, that they may also obtain the salvation which is in Christ Jesus with eternal glory.                                                   |
| 1Pe 1:2   | Elect according to the foreknowledge of God the Father, through sanctification of the Spirit, to obedience and sprinkling of the blood of Jesus Christ: Grace to you, and peace, be multiplied. |
|           |                                                                                                                                                                                                 |

#### The Importance of the Doctrine of Election
While we may not be able to comprehensively wrap our minds around all the ins and outs of understanding the doctrine of election, it is important for us to study. It is a key aspect of understanding the sovereignty of God and his role in salvation and the depth of his blessings since it is the fountainhead. Its purpose is to humble us, to  comfort us and give us assurance, to remind us our salvation does not depend on us and we were not the source of our own salvation. God is the source. He is the source of every blessing and especially of the blessing of salvation itself.  God has started a good work in us and he will bring it to completion.  [[Phil-01#v6|Phil 1:6]]  We can't screw it up. There should be a lot of comfort in this realization.  

Romans 8:30
![[Rom-08#v30|Rom 8:30]]

This is our end. God has predestined us to adoption. He has predestined us to be conformed into the image of his son. He has predestined us to be holy and blameless before him. It will happen. His word does not fail. He will finish the good work he started in us. 

This Doctrine of Election will strengthen our faith and knowledge of God, his sovereignty, his great mercy, his grace, his love...., and increases our praise and worship of His great grace and mercy so we can join in with Paul and sing, _"Blessed be the God and Father our Lord Jesus Christ, who has blessed us with every spiritual blessing in the heavenly realms in Christ Jesus!"

Martin Bucer  (1491-1551) on Ephesians:
> *"There are some who affirm that election is not to be mentioned publicly to the people. But they judge wrongly. The blessings which God bestows on man are not to be suppressed, but insisted and enlarged upon, and, if so, surely the blessing of predestination unto life, which is the greatest blessing of all, should not be passed over … Take away the remembrance and consideration of our election, and then, good God! what weapons have we left us wherewith to resist the temptations of Satan? As often as he assaults our faith (which he is frequently doing) we must constantly and without delay have recourse to our election in Christ as to a city of refuge. Meditation upon the Father’s appointment of us to eternal life is the best antidote against the evil surmisings of doubtfulness and remaining unbelief. If we are entirely void of all hope and assurance, respecting our interest in this capital privilege, what solid and comfortable expectation can we entertain of future blessedness? How can we look upon God as our gracious Father and upon Christ as our unchangeable Redeemer? without which I see not how we can ever truly love God; and if we have no true love towards Him, how can we yield acceptable obedience to Him? Therefore, those persons are not to be heard who would have the doctrine of election laid (as it were) asleep, and seldom or never make its appearance in the congregations of the faithful.”*

Martin Luther would say that if we knew nothing on this subject, then we would be unable to worship God rightly for what he has done for us because we would not appreciate His great work.
![[Luther, Martin - Bondage of the Will#^d6c991]]

#### The Controversy
The controversy is  not over the biblical truth that God chose us, which repeated all throughout the bible; instead, the division is over the interpretation and implications of that truth, how God chose us and how much influence man had in God's choice of determining who are the chosen.

There are, broadly speaking, two positions on this issue: Calvinism and Arminianism. Unconditional Election is the Calvinistic position. Conditional Election is the Arminian position.

##### The Calvinist Position - Unconditional Election
Calvinists hold that it is God who initiates faith based on his election of a chosen people. This election is God's sovereign choice of individuals to be saved, or not and was not based on any merit of foreseen faith by the individual. Instead, their selection was solely according to God's good pleasure and eternal purposes alone. This means that God's choice is not influenced by any human effort or decision at all. It emphasizes that man being dead in sin, is unable to "choose God" unless God draws him first and that our choosing God would ultimately be a "work" when we are saved by grace alone through faith which is a gift itself from God. Those in favor of this doctrine believe it highlight's God's mercy, grace, and sovereignty, while also considering the depravity of man - man's inability to choose salvation since his condition is that of a slave to sin, spiritually dead and without hope. There are numerous key verses that support this position for unconditional election. I would say four times as many as those which would seem to support the opposite position once you begin watching for them. We find many of these key verses in Ephesians 1:4-5, Romans 8:29-9:33 and in the gospel of John.

This gives rise to many immediate cries of "Not fair" when you look at the negative impact of this doctrine, which is the fate of those whom God does not choose. Those whose God's mercy and grace passes over. Those who are left in their sins and are left to face the consequences of their sins, without Christ.  Those from the Arminian camp respond that this doctrine of God's grace not being extended to everyone makes God 'unjust' and removes "human responsibility". Both of which must be factored in to any answer.  God is just and merciful and humans are responsible for their actions as we will see. 

See also:
[[The Westminster Confession of Faith#^5e326d]]
[[1689 Baptist Confession of Faith#^e9734f]]

##### Armenian Position - Conditional Election
Armenians, support conditional election. They assert that God's election is based on his foreknowledge of those who would freely choose to follow him in response to the gospel. God, being outside of time, looked into the future and saw who would choose him and selected those individuals as his elect. Armenians would state that the doctrine of conditional election upholds the inherent value of human agency and accountability. It affirms that man's decisions have eternal consequences and that we are not mere passive recipients of predestined fates. It encourages active participation in the divine-human relationship. They would further argue that it also encourages inclusivity, that Christ died for the entire world, and everyone in the world has been given the same opportunity to be saved through making their own freewill choice to believe or not believe in Jesus Christ and are fully responsible for that decision. A couple of key passages they would refer to support their position would be [[John-01#v12|John 1:12-13]] and [[1 Pet-01#v2|1 Peter 1:2]]


#### In Context
This dispute in doctrine of how God chooses his elect has been going on for centuries between sincere and godly men on both sides. It is important to understand that the doctrine of sovereign election, is not the gospel itself. The gospel is the good news that Jesus Christ, the Son of God, came to earth as a human being, lived a sinless life, died on the cross for our sins, and rose again on the third day. Through faith in Jesus Christ, we can have forgiveness of sins and eternal life with God. This biblical message is the gospel, the foundation of Christianity. The doctrine of sovereign election is the power behind the gospel. It addresses the questions: what makes the gospel work? By whose power and will are we saved? Why does God's grace save some but not everyone in the entire world? These are the key questions at hand. 

R.C Sproul writes in Chosen By God:
![[Chosen by God#^65a975]]
R.C. Sproul does go on to say how the deck stacks in favor of the reformed on some of the greatest theologians agreeing with reformed theology.
![[Chosen by God#^35d1da]]


R. C. Sproul points out four options we are faced with when considering the Doctrine of Election that really helped me put the problem in perspective:
	1. God could decide to provide no opportunity for anyone to be saved.
	2. God could provide an opportunity for all to be saved.
	3. God could intervene directly and insure the salvation of all people.
	4. God could intervene directly and insure the salvation of some people.


Chosen by God - RC Sproul
![[Chosen by God#^fd5680]]

#### A Few Testimonies:

##### George Mueller:
> *Before this period, I had been much opposed to the doctrine of election. Particular redemption and final preserving grace. But now I was brought to examine these precious truths by. The word of God. Being made willing to have no glory of my own in the conversion of sinners, but to consider myself merely an instrument and being made willing to receive what the scripture said, I went to the word reading the New Testament from the beginning, with a particular reference to these. Truths, to my great astonishment, Mueller says. Found that the passages which speak decidedly for election and persevering grace were about four times as many as as those which speak apparently against these. Months and even those few shortly after when I examined and understood them, served to confirm me in the above doctrines. As to the effect which my belief in these doctrines had on me, I am constrained to state for God's glory that though I am still exceedingly weak and by no means so dead to the lust of the flesh and the lust of the eyes and the pride of life as I might be, and as I ought to be. That, by the grace of God, I have walked more closely with him since that period. My life has not has not been so variable, and I may say that I have lived much more for God than ever before*

##### Charles Spurgeon:
> *Charles Spurgeon himself. Spurgeon says when I was coming to Christ, I thought I was doing it. All myself, and though I and and I thought I sought the Lord earnestly, and yet I had no idea that it was the. Lord, who was seeking me. I do not think the young convert is at first aware of this. I can recall the very day an hour when I first received those truths. The doctrines of election in my own soul, when they were as John Bunyan says, burnt into my heart with with a hot iron. And I can recollect how I felt that I had grown on a sudden. From a babe into a man. And that I had made progress in scriptural knowledge through having found once for all that clue to the truth of God. Then he says this one week night when I was sitting in. The House of God. I was not thinking much about the preacher's sermon, for I did not believe it. Just like some of you right now. The thought struck me. How did you become a Christian? Well, I sought the Lord. But but how did you come to seek the Lord? The truth flashed across my mind. In a moment I should not have sought him unless there had been some previous influence on my mind to make me seek him. I prayed, thought I. But then I asked myself, how came I to pray? I was induced to pray by reading the scriptures. How came I to read the scriptures? I did read them, but what led me to do so? Then in a moment I saw that God was at the bottom of it all. That he was the author of My faith. And so the whole doctrine of Grace opened up to me. And from that doctrine, I have not departed. To this day. And desire to make this my constant confession, I ascribe my change wholly to God.*

##### R.C. Sproul
![[Chosen by God#^a3fe90]]

The doctrine of election should never be over-emphasized  in place of the gospel but it is a big part of the gospel itself, by de-emphasizing our power in salvation and amplifying God's power. It is by Christ alone, by grace alone for his glory alone. The power and work that operates in our salvation is of God and not our own. That is key and that is comforting.  It ensures victory. It ensures it's not up to us to give a perfect presentation of the gospel and be experts in apologetics to be able to reach others, although God certainly uses these as means to his end. It means we can pray for another's salvation and know that God is able to save them, they can be the most difficult case, but God can save them. It does not depend on their will or understanding.  The doctrine of election humbles us, because we contributed nothing to our salvation, except the sin that made it necessary.

### Further Reading & Study:
**Book:** [[Chosen by God| Chosen by God - R.C. Sproul]]
**Monergism Article:** [The Doctrine of Election - John G Resinger](https://www.monergism.com/doctrine-election)
Historical Quotes: [Predestination Must be Preached](https://cprc.co.uk/quotes/predestinationpreached/)
**Confession of Faith:** [1689 Baptist Confession of Faith - Chapter 3 God's Decrees](https://founders.org/library/chapter-3-gods-decree/)
**Sermon Audio:** [Praise for God's Election in Christ (Part 1 Ephesians 1:4 - Brian Borgman)](https://mp3.sermonaudio.com/filearea/129101346354/129101346354.mp3)
**Monergism E-Books:**
Pink, A. W. [The Doctrine of Election](https://www.monergism.com/doctrine-election-ebook)
Goodwin, Thomas [A Discourse of Election](https://www.monergism.com/discourse-election-ebook)
Zanchius, Jerome [The Doctrine of Absolute Predestination](https://www.monergism.com/doctrine-absolute-predestination)


