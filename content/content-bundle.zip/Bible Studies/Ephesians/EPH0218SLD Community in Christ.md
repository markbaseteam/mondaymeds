<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->
---
OPENING PRAYER
==
---
Ephesians 2:18-22
<font size="5">  
<p align= "Justify">
11 Therefore remember that at one time you Gentiles in the flesh, called “the uncircumcision” by what is called the circumcision, which is made in the flesh by hands— 12 remember that you were at that time separated from Christ, alienated from the commonwealth of Israel and strangers to the covenants of promise, having no hope and without God in the world. 13 But now in Christ Jesus you who once were far off have been brought near by the blood of Christ. 14 For he himself is our peace, who has made us both one and has broken down in his flesh the dividing wall of hostility 15 by abolishing the law of commandments expressed in ordinances, that he might create in himself one new man in place of the two, so making peace, 16 and might reconcile us both to God in one body through the cross, thereby killing the hostility. 17 And he came and preached peace to you who were far off and peace to those who were near.<u> 18 For through him we both have access in one Spirit to the Father. 19 So then you are no longer strangers and aliens, but you are fellow citizens with the saints and members of the household of God, 20 built on the foundation of the apostles and prophets, Christ Jesus himself being the cornerstone, 21 in whom the whole structure, being joined together, grows into a holy temple in the Lord. 22 In him you also are being built together into a dwelling place for God by the Spirit.</u>

---
Review Last Meeting
<font size="6">  
<p align= "left">
---
<font size="6"> 
<u>18 For through him<!-- element style="background: floralwhite" -->  we both have access in one Spirit to the Father.</u>
<font size="5">  
<p align= "left">
We (both) have access to the Father through Him (Christ) in one Spirit.<br>
Observations:<br>
	 - We have access to the Father! <br>
	 - Our access is through Jesus Christ <br>
	- "We both" includes Jews and Gentiles<br>
	- In One Spirit<br>
	- Work of the Trinity</font>
<font size="5"> 
<p align= "left">

---
<font size="6"> 
<u>For through him<!-- element style="background: floralwhite" -->  we both have access in one Spirit to the Father.</u>
<font size="6">  
<p align= "left">
<Strong>1. We have access to the Father! <br></strong>
"We have access" is the primary subject verb of this sentence. <br><p align= "left">A wonderful bright contrast to Ephesians 2:12 previous condition!
<p align= "left">
- "Jesus, when he had cried again with a loud voice, yielded up the ghost. And, behold, THE VEIL OF THE TEMPLE WAS RENT IN TWO FROM THE TOP TO THE BOTTOM" (Matt. 27:50-51).
 <p align= "left">
What a privilege it is for us to have access to God Himself and to call Him our Father! What God is like our God?

 
---
<font size="6">  
<p align= "left">
 My Father is rich in houses and lands, <br>
 He holdeth the wealth of the world in His hands! <br>
 Of rubies and diamonds, of silver and gold, <br>
 His coffers are full, He has riches untold. <br>
 <br>
 Refrain: <br>
 I'm a child of the King, A child of the King: <br>
 With Jesus my Savior, I'm a child of the King. <br>
 My Father’s own Son, the Savior of men, <br>
 Once wandered on earth as the poorest of them; <br>
 But now He is pleading our pardon on high, <br>
 That we may be His when He comes by and by. <br>
 <br>

---
<font size="5">  
<p align= "left">
This access is <strong><font color="#548dd4">Through Christ</font></strong>  and only through Christ do we have access to the Father. He is the door. He is the way. There is no other way to have access to the Father but through Jesus Christ alone. 
<p align= "left">
In the Greek, the verse begins with this prepositional phrase "Through Christ we have access..." and this is because of the emphasis on our access being "through Christ". This can <u>never ever </u> be disregarded. There are many who would say they know God and come to God apart from Christ.
<p align= "left">
<strong>John 14:6 </strong> - <em><u>"I am the way</u>, and the truth, and the life. No one comes to the Father except through me."</em>
<p align= "left">
<strong>Romans 5:2</strong> - <em>Through him we have also obtained access by faith into this grace in which we stand, and we rejoice in hope of the glory of God.</em>
<p align= "left">
<strong>Ephesians 3:12</strong> - <em> in whom we have boldness and access with confidence through our faith in him</em>
<p align= "left">
The  word rendered "access" occurs but in two other places in the New Testament, Eph 2:18; Eph 3:12. By Jesus Christ the way is opened for us to obtain the favour of God. 
<p align= "left">
A wonderful bright contrast to Ephesians 2:12 previous condition! 
---
"We both" includes Jews and Gentiles.  
<font size="5">  
<p align= "left">
This is what this whole section of Ephesians 2:11-22 have been about. At one time, the only access to God the Father was through the Jews, becoming a Jew as we saw in the past two lessons. <strong>"But now...",</strong> "you (Gentiles, Ephesians) who were far off have been brought near by the blood of Christ" Christ made both groups one and broke down the divisive middle wall of separation between them, the law.
<p align= "left">
This allows you and I as Gentiles to have access to God the Father through Jesus Christ. 
<p align= "left">
It's also a reminder that the <u>Jews access to God the Father is through Jesus Christ.</u> <em>Through Christ <u> we both</u> have access to God the Father.</em> It's not through nationality, it's not through circumcision, it's not through laws and ordinance keeping works.
<p align= "left">
This is a stumbling point for the Jews who are use to accessing God the Father through their Jewish laws and ordinances, sacrifices that is the dividing wall that fell.  It is still very difficult for an Orthodox Jew to see their own need for and accept grace for grace does away with everything they hold of value in their laws, ordinances and works and asks them to value Christ alone and his work.
---
In One Spirit
<font size="5">  
<p align= "left">
We have access to the father through Jesus by the means of the Spirit. 
<p align= "left">
The verse implicitly acknowledges the roles of all three Persons of the Trinity. Jesus is the one through whom we have this access; the Spirit is the means of this access, and the Father is the one to whom we have this access.
<p align= "left">
<em><font color="#548dd4">For through <strong>him (Christ) </strong>we both have access in one <strong>Spirit</strong> to the <strong>Father</strong>.</font></em>
<p align= "left">
<strong>One Spirit</strong>. We spoke of the frequency in which the word "one" is used in the book of Ephesians.  
<p align= "left">
<Strong>Eph 4:4-6</strong> - <em>There is <u>one</u> body and <u>one</u> Spirit—just as you were called to the<u> one</u> hope that belongs to your call—  <u>one</u> Lord, <u>one</u> faith, <u>one </u>baptism,  <u>one</u> God and Father of all, who is over all and through all and in all.</em>
<p align= "left">
 The singularity of the Spirit serves as a standard of truth and orthodoxy. Multiple "Spirits" would easily lead to divergent teachings and practices, creating confusion and, potentially, heresy. There is one Spirit uniting us all in Christ in the same body. One spirit distributing gifts. The word "one" does not just signify numerical unity but also a unity of purpose, essence, and function.  There is a perfect peace, perfect unity in the Spirit of God.

---
<font size="6">  
19. <!-- element style="background: floralwhite" -->  So then you are no longer strangers and aliens, but you are fellow citizens with the saints and members of the household of God, </font>
<font size="6">  
<p align= "left">
<strong>So then/Now therefore </strong> - We now come to Paul's concluding remarks on the above truths that Gentiles and Jews both have access to God through the Father through Jesus by the Spirit. Those who were far off and without hope have been brought near through the blood of Christ.  In these last 3 verses Paul is summarizing these truths and the implications.
<p align= "left">
<strong>you are no longer strangers/foreigners and aliens/non-citizens</strong> - These terms, "strangers" and "aliens," indicate a previous state of separation or exclusion, perhaps from the promises and covenants of God. Now, there's a change in status. They are "no longer". The Greek word "ouketi" is a negative time adverb that means a full and permanent change. The Gentiles who believe are not like they were before.

---
<font size="6">  
<p align= "left">
<strong><font color="#548dd4">Strangers/Foreigners</font></strong><br>
xenos<br>
Thayer Definition:<br>
1) A foreigner, a stranger <br>
2) Alien (from a person or a thing)<br>
3) without th eknowledge of, without a share in <br>
4) new, unheard of<br>
<p align= "left">
<strong><font color="#548dd4">Aliens/Foreigners/noncitizens</font></strong><br>
paroikos<br>
Thayer Definition<br>
1)dwelling near, neighboring<br>
2) in the NT, a stranger, a foreigner, one who lives in a place without the right of citizenship.<br>
3) without citizenship in God's kingdom
4) one who lives on earth as a stranger, a sojourner on the earth<br>
5) of Christians whose home is in heaven<br>
---
<font size="5">  
<p align= "left">
The term <strong>"Strangers" </strong>or "xenos" refers to people who are not part of a community and don't have the full rights that come with belonging. In this context, it's about being fundamentally different or out of place, like being an outsider. They would be like a foreign visitor or tourist. They are foreigners belong outside our country or on a temporary visit.  Before knowing Christ, Gentiles were like this—spiritually disconnected and not part of God's promises. They were outsiders in a spiritual sense, separated from God's kingdom. Now, through Christ, they belong and are no longer outsiders.
<p align= "left">
The term "<strong>Aliens" </strong>or "paroikos" in the Bible refers to someone living close to but not really a part of a community. It's like what we would call a "legal immigrant" today. They may have a green card and be a "visa holder" for work or education and live in our country among us for an extended stay. They have more rights and privileges then a "foreigner" but they are still a foreigner or alien or noncitizen.   Before Christ, this was how Gentiles (non-Jews) were seen in relation to God's kingdom. They were like outsiders who paid a small tax to be protected but didn't have any real rights. The term also can symbolize anyone whose true home isn't in this current world but rather with God. So, in essence, before knowing Christ, Gentiles were like nearby residents without full benefits. Now, through Christ, that status has changed, and they are considered a true part of the community.
---
<font size="6"> 
<strong>But you are fellow citizens</strong>
<font size="5">  
<p align= "left">
<Strong>Fellow citizens<br></strong>
sumpolitēs<br>
1) possessing the same citizenship with others, a fellow citizen<br>
1a) of Gentiles as received into communion of the saints<br>
1b) of the people consecrated to God<br>
<p align= "left">
<strong>This is the new status. </strong> The idea of citizenship implies privileges, responsibilities, and a sense of belonging. Before believing in Christ, <u>Gentiles were outsiders with no spiritual advantages compared to Jewish believers. </u>But now, they're on equal footing, united by their faith in Christ. Everyone, regardless of background, can now experience God's grace equally.  Gentiles have been granted "citizenship" in God's kingdom. 
<p align= "left">
<strong>New Expectations. </strong>
For those who become citizens in the USA we have certain expectations of them, do we not? We expect them to pay taxes, obey the law, be loyal to the nation, participate in civic duties of voting, serving in military, jury duty and all the responsibilities that come with citizenship.
<p align= "left">
So, the question for us is: Does our life show that we are living for our heavenly citizenship, or does it look like we're still focused on worldly things that go against God's will? Disregarding his laws, disloyal to his kingdom, not contributing financially or willing to fight for its survival? 
<p align= "left">
How do we live out our citizenship?  We are fellow citizens. As fellow citizens we are blessed with special privileges that come with citizenship. Protection. Provision. Participation.
---
<font size="5">  
<p align= "left">
<strong>With the Saints</saints></strong> Here, "saints" refers to fellow believers, emphasizing community and sanctity.
<p align= "left">
Saints<br>
hagios<br>
Thayer Definition:<br>
1) most holy thing, a saint<br>
<p align= "left">
<strong>members of the household of God</strong> This goes beyond citizenship and indicates familial intimacy and responsibility within God's family.
<p align= "left">
We are not only citizen's of God's kingdom with all its privileges which would be blessing enough it itself, but we are members of God's own household  Members of the family of God with God as the Father. Children of God. We not only have access to the presence of God, but we have access to his heart, to his love, to his concern. No matter how we might feel about "coming home" to the presence of God as if we don't belong, we are treasured by God Himself and this will never change. We are loved as one who walks into the door of their childhood "home" is and should be loved.


---
<font size="6">  
<p align= "left">
Wayne Barber writes - "The word *<u>household</u> can be translated <u>family</u>. Isn’t that wonderful? Think of our country and how the family system and structure has been totally ripped apart. A person grows up with step-parents or whatever else. Usually the people who are most effected are the children. They desperately need to hear that somebody loves them. God is screaming at them through the Scriptures and saying, "I love you. I love you. I love you. I want you to be a part of My family." As a matter of fact, He not only births us into the family, as we know from John, but He also  adopts us into His family. Both give us a picture of what He has done for us. By adoption He made us secure. Roman law says that if you adopted someone, you could never disown them. If you are worried about your eternal security, folks, you have been birthed into the family. You are eternally secure in the Lord Jesus Christ. We are a part of His family. Now, as citizens we have new responsibilities. As <u>family members</u>, we have a brand new relationship. Wherever you go, you find brothers and sisters in Christ.
---
<font size="5">  
<p align= "left">
In Morning and Evening Spurgeon writes…Fellow citizens with the saints.” — [Ephesians 2:19] What is meant by our being citizens in heaven? It means that we are under heaven’s government. Christ the king of heaven reigns in our hearts; our daily prayer is, “Thy will be done on earth as it is in heaven.” The proclamations issued from the throne of glory are freely received by us: the decrees of the Great King we cheerfully obey. Then as citizens of the New Jerusalem, we share heaven’s honours. The glory which belongs to beatified saints belongs to us, for we are already sons of God, already princes of the blood imperial; already we wear the spotless robe of Jesus’ righteousness; already we have angels for our servitors, saints for our companions, Christ for our Brother, God for our Father, and a crown of immortality for our reward. We share the honours of citizenship, for we have come to the general assembly and Church of the first-born whose names are written in heaven. As citizens, we have common rights to all the property of heaven. Ours are its gates of pearl and walls of chrysolite; ours the azure light of the city that needs no candle nor light of the sun; ours the river of the water of life, and the twelve manner of fruits which grow on the trees planted on the banks thereof; there is nought in heaven that belongeth not to us. “Things present, or things to come,” all are ours. Also as citizens of heaven we enjoy its delights. Do they there rejoice over sinners that repent—prodigals that have returned? So do we. Do they chant the glories of triumphant grace? We do the same. Do they cast their crowns at Jesus’ feet? Such honours as we have we cast there too. Are they charmed with his smile? It is not less sweet to us who dwell below. Do they look forward, waiting for his second advent? We also look and long for his appearing. If, then, we are thus citizens of heaven, let our walk and actions be consistent with our high dignity.
---
<font size="6">  
<!-- element style="background: floralwhite" --> built on the foundation of the apostles and prophets, Christ Jesus himself being the cornerstone,</font> 
<font size="6">  
<p align= "left">
<p align= "left">
<strong>Built on the foundation</strong>:  Paul switches from metaphor of a household and family to use a new metaphor to further communicate the unity and connection between believers in Christ. He really wants us to understand and get the idea across so that believers are united together as one. Paul chooses to use the metaphor of a building, indicating something structured and carefully planned that the household of God is built on. This foundation is critical for true unity and not a false inclusiveness.  The household of God is exclusive.
 <p align= "left">
<strong>Of the apostles and prophets</strong>: These are the agents through whom God's revelation came. They are foundational but not ultimate.
<p align= "left">
<strong>Christ Jesus himself being the cornerstone</strong>: Jesus is presented as the essential piece that holds everything together. The cornerstone is critical for the alignment and integrity
---
<font size="5">  
<p align= "left">
The Greek word "ἐποικοδομέω" (epoikodomeō) for <strong>building</strong> is often used in the context of the New Testament to convey the idea of "building upon" or "building up." This word is a compound of two smaller words: <strong>"epi," </strong>which means "upon," and <strong> "oikodomeō," </strong>which means "to build." In a literal sense, it refers to the act of constructing something on top of a foundation. However, it is often used metaphorically in the New Testament to describe the action of edifying, encouraging, or building up someone in a spiritual or moral sense.
<p align= "left">
For instance, in 1 Corinthians 14:26, the Apostle Paul instructs the Corinthian church on how their gatherings should be conducted for the edification of the body: "What then, brothers? When you come together, each one has a hymn, a lesson, a revelation, a tongue, or an interpretation. <u>Let all things be done for building up (ἐποικοδομή)." Here, the term is used to indicate the purpose of church activities: the edification or "building up" of the congregation in spiritual maturity and unity.</u>
<p align= "left">
Another example is Ephesians 4:29: "Let no corrupting talk come out of your mouths, but only such as is good for building up (ἐποικοδομή), as fits the occasion, that it may give grace to those who hear." Again, Paul employs "epoikodomeō" to emphasize the need for words that encourage and edify others rather than tear them down.
<p align= "left">
"Epoikodomeō" in the New Testament generally refers to the concept of spiritual or moral edification. It is used to indicate how believers should engage in practices and behaviors that contribute positively to their own spiritual growth as well as that of the community to which they belong.
---
<font size="5">  
<p align= "left">
The Greek term "θεμέλιος" (themelios) refers to a foundation or base upon which something is built. It's a term used both literally and metaphorically in the New Testament to describe foundational elements, whether they are physical foundations of buildings or conceptual foundations of faith, doctrine, or practice.
<p align= "left">
In a<u> literal architectural sense</u>, "themelios" is the groundwork or foundation upon which a structure is erected. This usage can be seen in the parable of the wise and foolish builders in Matthew 7:24-27, where the wise man is described as building his house on a solid foundation (themelios), allowing it to withstand the storms.
<p align= "left">
<u>Metaphorically, </u>"themelios" is often used to describe fundamental principles or foundational elements in theological or ethical contexts. For instance, in Ephesians 2:20, the apostles and prophets are described as the foundation (themelios) upon which the Church is built, with Jesus Christ himself being the "chief cornerstone." In this sense, "themelios" signifies the basic, essential teachings and practices that underlie and support the faith and life of the Christian community.
<p align= "left">
In 1 Corinthians 3:10-11, Paul writes, <em>"According to the grace of God given to me, like a skilled master builder I laid a foundation (themelios), and someone else is building upon it. Let each one take care how he builds upon it. For no one can lay a foundation (themelios) other than that which is laid, which is Jesus Christ."</em> Here, Paul is emphasizing the foundational role that the gospel of Jesus Christ plays in the life of the believer and the community of faith.
<p align= "left">
The idea of "themelios" underscores the importance of having a strong, biblically-based foundation in one's spiritual walk. 
---
<font size="5">  
<p align= "left">
<strong>built on the foundation of the apostles and prophets</strong> 
<p align= "left">
The apostles and prophets have laid, the foundation of this house of which the Gentiles are a part. 
<p align= "left">
The Gentiles have always been a part of God's plan from the very beginning which we reviewed last time we were together. 
<p align= "left">
Throughout Church there has only been one gospel, one saving truth and that is that Jesus is the only way to salvation.  All the prophets witness and testify of him. All the prophets proclaimed remission of sins is only through the blood of the Lamb of God and righteousness only through faith in Him. Jesus is the Lamb slain from the foundation of the world, who takes away the sins of the world. The Prophets were succeeded by the Apostles and they point to Christ also and state the same truth. The Gospel, Jesus is the foundation of the Apostles and Prophets.
<p align= "left">
Worth noting that when new Jerusalem descends from the sky it has a foundation that is built on the Apostles. The names of the twelve tribes were o the twelve gates.
<p align= "left">
<strong>Rev 21:14 </strong>And the wall of the city had twelve foundations, and on them were the twelve names of the twelve apostles of the Lamb.
---
<font size="5">  
<p align= "left">
<strong>Christ Jesus himself being the cornerstone</strong>: Jesus is presented as the essential piece that holds everything together. 
<p align= "left">
In modern construction, the cornerstone holds special significance. It is typically a brick that is carefully chosen and placed during a ceremonial event. While it may  no longer contribute to the building's structural integrity, it adds a touch of beauty and symbolism and sometimes is hallowed out to hold mementos.  In contrast, the  cornerstone that is being discussed here has its origins in ancient masonry. It was the brick by which the builder aligned the entire building. It was so critical that sometimes sacrifices were done on it to bless it.  It was the first brick to be placed as the cornerstone for the entire structure - remove this brick and the entire building collapses. The foundation was laid, built upon the chief cornerstone.
<p align= "left">
In the New Testament, this term is metaphorically applied to Jesus Christ to signify His foundational role in the Church and in the faith of individual believers. Here in Ephesians 2:20, Paul describes the Church as "built on the foundation of the apostles and prophets, Christ Jesus himself being the cornerstone (akrogōniaios)," emphasizing the preeminence and foundational nature of Christ in the church. Peter also refers to Jesus as the "cornerstone" in 1 Peter 2:6-7, drawing upon Old Testament imagery, particularly from Psalm 118:22 and Isaiah 28:16, to highlight the critical and central role that Jesus plays in the life of the believer and the Church.
<p align= "left">
	<strong>1 Peter 2:6-7</strong> - <em>For it stands in Scripture:
	“Behold, I am laying in Zion a stone, a cornerstone chosen and precious, and whoever believes in him will not be put to shame." " So the honor is for you who believe, but for those who do not believe, “The stone that the builders rejected has become the cornerstone,”[a]</em>
<p align= "left">

---
<font size="6">  
<p align= "left">
This passage gives extraordinary  significance to the prophets and the apostles. This is something to  note when today is is common for people to say they like Jesus, but don't care for the writings of Paul the Apostle or of the Old Testament Prophets. They are "red letter only" people who disregard the Apostles and the Prophets and say Jesus is their only authority. But to deny the Prophets and the Apostles is to deny Christ. They are the foundation and given great significance. 
---
<font size="6">  
<!-- element style="background: floralwhite" -->21-22 in whom the whole structure, being joined together, grows into a holy temple in the Lord.  In him you also are being built together into a dwelling place for God by the Spirit.</font>
<font size="6">  
<p align= "left">
It's important to note that Paul is not just refering to the Jews and the Gentiles but individual believers, you and me.  Each Christian is a person in whom God the Holy Spirit lives. Paul says in 2Cor 6:16 that our bodies are God's house . In the Old Testament, God lived in the temple through his Spirit. Now, he lives in us. He dwells among us in us through Christ.
That was a big deal between the Jew and the Gentile because the Jew couldn't look at the convert from the Gentile and think he was less important. The Jewish Christian looks at the Gentile believer and see the Holy Spirit living in them. A brother or sister in Christ. Fully loved by the Father in the household of God.
---
<font size="5">  
<p align= "left">
<strong>In whom  (Christ) the <font color="#548dd4">whole </font>structure</strong>: All individual "stones" or members find their proper place in relation to Christ.  We all align with Christ our cornerstone. This is our unity, which is critical to avoid those who would try to create unity today through Universalism. Universalism promotes a false sense of unity by advocating for a broad, undiscriminating acceptance of various beliefs under the guise of inclusion. True unity in Christ, however, is one that is defined by shared faith, Jesus Christ our cornerstone, upheld by the foundation of the prophets and the apostles which we stand on as doctrinal integrity, and led and filled by the Holy Spirit. 

<p align= "left">
<strong>Being joined together</strong>: This emphasizes unity and interdependence among believers.  We support one another and every brick is critical and serves a purpose that no other brick serves in its position as we encourage, rebuke, correct and serve God in our place that may seem very mediocre. We are positioned on top of so many other lives of faith and God will use our life to support the life of others to grow his building. No one is insignificant. Every brick is necessary. 
<p align= "left">
<strong>Grows into a holy temple in the Lord</strong>: This depicts the church as a living, growing entity, set apart for divine purposes. If our foundation is on Christ and we are joined to the body of believers, the church will naturally grow as a holy temple in the Lord throughout the ages rising higher and higher.
<p align= "left">

---
<font size="5">  
<!-- element style="background: floralwhite" --> 22 In him you also are being built together into a dwelling place for God by the Spirit. </font>
<font size="5">  
<p align= "left">
<strong>In him you also are being built together</strong>: This continues to emphasize the corporate aspect of Christian identity. 
<p align= "left">
	<i class="fas fa-quote-left fa-2x fa-pull-left"></i><strong>Henry Law</strong> - <em>Jesus is the foundation, immortal souls are the superstructure, God is the indweller, the Holy Spirit is the effectual agent by whom the stones are brought in 	and managed. </em>
<p align= "left">
<strong>Into a dwelling place for God</strong> The ultimate purpose of this metaphorical building is to serve as a place where God himself resides. A temple is a building in which God
dwells. The church is called the temple of God because He dwells within by the Spirit. The Spirit being a divine person, his presence is the presence of God. In a very real sense, the Kingdom of God is within us and will be revealed.
<p align= "left">
<strong>By the Spirit</strong> We are reminded that we are  built through the Spirit. The Holy Spirit as the active agent in this building process, placing brick by brick as He brings us to God in the right time, and gives us gifts and determines or places.. 
---
https://sovereigngracemusic.bandcamp.com/track/brick-after-brick
---
END READING<br>
Ephesians 2:11-22
<font size="5">  
<p align= "Justify">
11 Therefore remember that at one time you Gentiles in the flesh, called “the uncircumcision” by what is called the circumcision, which is made in the flesh by hands— 12 remember that you were at that time separated from Christ, alienated from the commonwealth of Israel and strangers to the covenants of promise, having no hope and without God in the world. 13 But now in Christ Jesus you who once were far off have been brought near by the blood of Christ. 14 For he himself is our peace, who has made us both one and has broken down in his flesh the dividing wall of hostility 15 by abolishing the law of commandments expressed in ordinances, that he might create in himself one new man in place of the two, so making peace, 16 and might reconcile us both to God in one body through the cross, thereby killing the hostility. 17 And he came and preached peace to you who were far off and peace to those who were near.<u> 18 For through him we both have access in one Spirit to the Father. 19 So then you are no longer strangers and aliens, but you are fellow citizens with the saints and members of the household of God, 20 built on the foundation of the apostles and prophets, Christ Jesus himself being the cornerstone, 21 in whom the whole structure, being joined together, grows into a holy temple in the Lord. 22 In him you also are being built together into a dwelling place for God by the Spirit.</u>
---
CLOSING PRAYER 
==
---