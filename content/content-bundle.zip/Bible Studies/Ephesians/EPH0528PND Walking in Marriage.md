Text: Ephesians 5:28-33

<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->
---
OPENING PRAYER
==
---
Ephesians Verse Reference
<font size="6">  
<p align= "Justify">
Verse Text

---
Review Last Week
<font size="6">  
<p align= "left">
---
<!-- element style="background: floralwhite" -->
<font size="6">  
<p align= "left">
---
<!-- element style="background: floralwhite" -->
<font size="6">  
<p align= "left">
---
<!-- element style="background: floralwhite" -->
<font size="6">  
<p align= "left">
---
<!-- element style="background: floralwhite" -->
<font size="6">  
<p align= "left">
---
<!-- element style="background: floralwhite" -->
<font size="6">  
<p align= "left">
---
<!-- element style="background: floralwhite" -->
<font size="6">  
<p align= "left">
---
END READING<br>
Ephesians Verse Reference
<font size="6">  
<p align= "Justify">
Verse Text
---
CLOSING PRAYER 
==
---