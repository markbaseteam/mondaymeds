
<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->

---
OPENING PRAYER
==
---
Ephesians 2:4-10
<font size="6">  
<p align= "Justify">
4 But God, being rich in mercy, because of the great love with which he loved us,5 even when we were dead in our trespasses, made us alive together with Christ—by grace you have been saved— 6 and raised us up with him and seated us with him in the heavenly places in Christ Jesus, 7 so that in the coming ages he might show the immeasurable riches of his grace in kindness toward us in Christ Jesus. <font color="#237092"><u>8 For by grace you have been saved through faith. And this is not your own doing; it is the gift of God, 9 not a result of works, so that no one may boast. 10 For we are his workmanship, created in Christ Jesus for good works, which God prepared beforehand, that we should walk in them. </u></font>

---
Review Last Week
<font size="6">  
<p align= "left">
---
For<!-- element style="background: floralwhite" -->
<font size="6">  
<p align= "left">
Tonight's text begins with a subordinating conjunction that links together two independent clauses. A subordinating clause in English serves to provide a reason or explanation for the main clause preceding or following it. In our context, the preceding sentence found in verse 7 spoke of the immeasurable riches of God's grace in kindness toward us in Jesus Christ that God intended to display. One spectacular  display of God's immeasurable riches of his grace in kindness towards us in Jesus Christ is the fact that God has saved us by grace.
---
You have been saved<!-- element style="background: floralwhite" -->
<font size="6">  
<p align= "left">
![[Pasted image 20230930212918.png]]
![[Pasted image 20230930213625.png]]
---
Have you ever saved something? <br>
What did you save and why did you save it? <br>
What are saving these from?<br>
Why do we save them? <br>
--
<font size="6">  
<p align= "left">
We save things all the time. Letters, cards, mementos, stray animals. <br>
What are saving these from? <br>
<font color="#d8d8d8">Being lost, being destroyed, thrown away, etc</font> <br>
Why do we save them?  <br>
<font color="#d8d8d8">They have some value to us, we want to keep them, they are our possessions</font>
---
You have been saved by God the Father...by grace and through faith.
---
The Lord is Our Keeper
<font size="6">  
<p align= "left">
<strong>Psalms 121:3-5 </strong>- "He will not let your foot be moved; he who keeps you will not slumber. Behold, he who keeps Israel will neither slumber nor sleep. The Lord is your keeper; the Lord is your shade on your right hand." 
<p align= "left">
<strong>2 Thess 3:3 </strong>- "But the Lord is faithful. He will establish you and guard you against the evil one."
<p align= "left">
<strong>1 Peter 1:5 </strong> - "Who by God's power are being guarded through faith for a salvation ready to be revealed in the last time."
<p align= "left">
<strong>1 John 5:18</strong> "We know that everyone who has been born of God does not keep on sinning, but he who was born of God protects him, and the evil one does not touch him."
---
We are kept in Christ
<font size="5">  
<p align= "left">
<strong>Ephesians 2:5-6</strong> 5 even when we were dead in our trespasses, made us alive together with Christ—by grace you have been saved— 6 and raised us up with him and seated us with him in the heavenly places in Christ Jesus, 
<p align= "left">
<strong>Colossians 3:3</strong> - "For you have died, and your life is hidden with Christ in God."
<p align= "left">
<strong>John 10:28-29</strong> "I give them eternal life, and they will never perish, and no one will snatch them out of my hand. My Father, who has given them to me, is greater than all, and no one is able to snatch them out of the Father's hand."
<p align= "left">
--
<!-- slide bg="[[342834_image of a treasured letter tucked away in a memen_xl-1024-v1-0.png|500]]" data-background-opacity="0.15" -->
Treasured by God

<font size="5">  
<p align= "left">
![[Treasured by God]]
---
Saved
<font size="5">  
<p align= "left">
σώζω<br>
sōzō<br>
Thayer Definition:<br>
1) to save, keep safe and sound, to rescue from danger or destruction<br>
1a) one (from injury or peril)<br>
1a1) to save a suffering one (from perishing), i.e. one suffering from disease, to make well, heal, restore to health<br>
1b1) to preserve one who is in danger of destruction, to save or rescue<br>
1b) to save in the technical biblical sense<br>
1b1) negatively<br>
1b1a) to deliver from the penalties of the Messianic judgment<br>
1b1b) to save from the evils which obstruct the reception of the Messianic deliverance<br>
Part of Speech: verb<br>
A Related Word by Thayer’s/Strong’s Number: from a primary sos (contraction for obsolete saoz, “safe”)<br>
Citing in TDNT: 7:965, 1132<br>
Total KJV Occurrences: 120<br>
---
![[Pasted image 20230930214824.png]]
---
<!-- slide bg="#D4E4F7" -->
Saved from What?
---

<split even>

![[0_A painting of a burning lake of fire full of flame_esrgan-v1-x2plus (3).png|400]]
![[Pasted image 20230930215133.png|500]]
</split>
---
<split even>
![[0_A painting of a burning lake of fire full of flame_esrgan-v1-x2plus (2).png|400]]
![[Pasted image 20230930215207.png|500]]
</split>
---
<!-- slide bg="![[0_A painting of a burning lake of fire full of flame_esrgan-v1-x2plus (1).png]]" -->

---
Saved from Wrath of God
<font size="6">  
<p align= "left">
<strong>John 3:36</strong>  Whoever believes in the Son has eternal life; whoever does not obey the Son shall not see life, but the <i>wrath of God</i> remains on him.
<p align= "left">
<strong>Ephesians 2:3 </strong> - among whom we all once lived in the passions of our flesh, carrying out the desires of the body and the mind, and <i>were by nature children of wrath, like the rest of mankind</i>
<p align= "left">
<strong>Romans 5:9</strong> -   Since, therefore, we have now been justified by his blood, much more shall we be saved by him from the <i>wrath of God</i>.
<p align= "left">  
<strong>Revelations 14:19 </strong>- So the angel swung his sickle across the earth and gathered the grape harvest of the earth and threw it into the great winepress of the wrath of God
<p align= "left">  
<strong>Revelations 15:7 </strong>And one of  the four living creatures gave to the seven angels seven golden bowls full of the  wrath of God who lives forever and ever,.
---
We are saved by God from God.
---
Romans 9:22-23
<font size="6">  
<p align= "left">
22 What if God, desiring to show his wrath and to make known his power, has endured with much patience vessels of wrath prepared for destruction, 23 in order to make known the riches of his glory for vessels of mercy, which he has prepared beforehand for glory—
---
R.C. Sproul Quotes from Saved from What?
<font size="5">  
<p align= "left">
"I would say that the greatest and most frequent error that human beings make is the assumption that they are going to survive the judgment of a holy God on the basis of their own performance"
<p align= "left">
"We  fail to understand who God is, and we fail to understand who we are. Our view of God is too low, and our view of mankind is too high. ... We are not worried about the wrath of God because we have discounted the severity of our sin. Our self-esteem is a shield protecting our eyes from God's holiness"
<p align= "left">  
"A few years ago, an international study measured the relationship between proficiency in mathematics and the students feelings about their performances, American students finished seventh - dead last - in mathematical proficiency. At the same time however, the Americans finished first in their positive feelings about their performance. It seems that our students are learning self-esteem better than they're grasping math. We are teaching people how to have a good self image while performing badly... <strong>The best self image we can ever have is one that is accurate and true."</strong>

--
In what ways have we seen our culture today maximize the love of God and deny the wrath of God altogether?
--
- Loss of Fear of God
- Influence of Secularism, Humanism
- Cheap Grace
- Rejection of "Hellfire & Brimstone" Preaching 
- Seeking Comforting & Feel Good Messages
- Shallow Meme Christianity
- Selective Emphasis in Scriptures, Lack of Reading
---
Our lack of understanding our Total Depravity is what downplays our need to be saved. 
<font size="6">  
<p align= "left">
- Minimize the severity of sin<br>
- Rely on self-effort for righteousness<br>
- Misjudge our moral standing<br>
- Downplay God's mercy and grace<br>
- Spiritual pride, lack of humility<br>
- Don't see our need for a Savior<br>
---
Total Depravity not Utter Depravity
<font size="5">  
<p align= "left">
The doctrine of "Total Depravity" shows the extent of our sinful condition. It holds that every part of human nature is corrupted by sin as a result of the Fall of Adam and Eve. This doesn't mean that humans are as evil as they could be, even Hitler could have been even worse then he was, and so can we always be worse. (Utter Depravity) but rather that every part of our being—mind, will, emotions, and body—is tainted by sin like a virus that has spread <u>everywhere</u> and to <u>everyone</u>. There is nothing we do, that is not tainted with sin to some degree. "All our righteousness is filthy rags." 
<p align= "left">
 A spiritually dead person can be morally upright, charitable, and even religious, but if these actions are not rooted in a regenerated heart, they are insufficient for true spiritual life and communion with God. They are not done for the glory of God but with impure motives, self-indulgence, personal gain, pride,...etc..."  We often see a push of being "good" without God but being "good" without God is always man centered and subjective.
---
We need to be saved and we need to see our need to be saved, we must see the sinfulness of our sin and our fullness of sin.
<font size="6">  
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>"In our natural state we are in actual rebellion against God. We are not simply neutral, not simply in neutral gear. We are not simply victims of our environment. We are rebels against the Most High." - Sinclair B. Ferguson
---
Sin is...
<font size="6">  
<p align= "left">
Saved from What? - R.C. Sproul<p align= "left">
There are three distinct ways in which human sin is described biblically:<p align= "left">
1. <strong>Debt</strong> - A failure to do what we are obligated to do.  God as Creator has given us responsibilities for which he holds us accountable. If we do not carry out those responsibilities we incur a debt.<p align= "left">
2. <strong>Expression of Enmity</strong> A violation of the personal relationship that human beings are supposed to have with their Creator. When we sin against God, we break that relationship. We communicate not love or affection or devotion to our Creator, but a kind of hostility that has to be dealt with.<p align= "left">
3. <strong>Celestial Crime </strong> - A crime against God, an offense against his holiness, a transgression of his law.
---
All Sin has Consequences
<p align= "left">
If a crime has been committed, then we must deal with penal sanctions. 
<p align= "left">
If a debt has been incurred then payment has to be made. 
<p align= "left">
If enmity has entered a personal relationship, if a relationship has been violated, that relationship must be restored.
---
Debtors before God
<font size="5">  
<p align= "left">
Have you ever had a debt you couldn't pay? <br>
How does Christ help with our Debt?
<p align= "left">
Christ is our surety. <br>
<strong>Hebrews 7:22 </strong>- This makes Jesus the guarantor of a better covenant."
<p align= "left">
Christ takes upon himself the obligation of paying what must be paid for our indebtedness to God. 
<font size="4"> 
<p align= "left">
In Luke 7:36-50, there is an account of a woman who was known as a sinner. She came to a Pharisee's house while Jesus was reclining at the table. This woman brought an alabaster flask of ointment, and she began to wash Jesus' feet with her tears, wiping them with her hair, and anointing them with the ointment.
<p align= "left">
The Pharisee was critical in his heart about her being a sinner so Jesus told the  parable of two debtors. One owed a lot of money to the lender, the other owed very little, but both were forgiven. He asked Simon which of the debtors would love the moneylender more to which Simon replied the who was forgiven the most. Which Jesus confirmed when he said "Therefore I tell you, her sins, which are many, are forgiven—for she loved much. But he who is forgiven little, loves little."
<p align= "left">
The lesson was one who recognizes the extent of their sinfulness and the magnitude of God's forgiveness will respond with great love and gratitude toward God. Conversely, someone who perceives themselves as needing little forgiveness may not exhibit as much love. We must recognize our "Total Depravity", our need for forgiveness and responding with love and gratitude towards God. We must see our debt and our inability to pay to love Christ and appreciate what he has done on our behalf.
---
Enemies of God
<font size="6">  
<p align= "left">
<strong>1 Timothy 2:5-6a </strong> - For here is one God and one Mediator, between God and men, the man Christ Jesus, who gave himself as a ransom for all.
<p align= "left">
Christ came to reconcile a broken relationship. Who is mad at who?  Who is estranged?
<p align= "left">
Does Christ side with God or with man? Does Christ seek to calm an angry God and beg God to take his wrath out on him instead of us? ... John 3:16...
<p align= "left">
<strong>Colossians  1:19-22</strong> - For in him all the fullness of God was pleased to dwell, and through him to reconcile to himself all things, whether on earth or in heaven, making peace by the blood of his cross. And you, who once were alienated and hostile in mind, doing evil deeds, he has now reconciled in his body of flesh by his death, in order to present you holy and blameless and above reproach before him.

---
Criminals before God
<font size="6">  
<p align= "left">
God the Father, does function as Governor and Judge. He is the Judge of all matters.
<p align= "left">
Example: Story of boy in ice cream parlor.
---
<font size="6">  
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>"When I sin against God, Jesus pays the price for my indebtedness. In order for that payment to be accepted, the Judge, who is at the same time the injured party, must decide and decree that He will accept that payment in my behalf. If I owed God the death penalty because I sinned against Him, and Jesus said, "I will die for him." and lad down His life for me, would God be under any obligation whatsoever to accept the payment? None whatsover.  There first must be a decision by the Governor of the univerise that He will accept a substitutionary payment in order for my crime to be covered. The decision of God the Father to do so is one of sheer <u>grace</u>" - <strong>R.C. Sproul, Saved from What?, page 53</strong>
---
<!-- slide bg="#D4E4F7" -->
Saved by What?
---
<font color="#d8d8d8">We are saved </font>by grace through faith.
![[Pasted image 20230930213625.png]]
---
<strong><i>Sola Gratia</strong></i><br>
Saved by Grace Alone
---
<strong><i>Sola Fide</i></strong><br>
Through Faith Alone
---
You have been saved <strong>by grace</strong> <font color="#d8d8d8">through faith</font>
<font size="6">  
<p align= "left">
Grace is unmerited favor of God, receiving what we do not deserve, and have not merited or earned.  This is not of works.
<p align= "left">
When the gospel reached us, we were <strong>dead</strong> in our sins and our trespasses. Ephesians 2:1, Ephesians 2:5 We were dead to God but alive to sin.
<p align= "left">
"But God", 
<p align= "left">
This is Christ stepping forward to take our death penalty and God allowing it and even orchestrating our salvation. That is grace.

---
Costly Grace - Grace Cost Christ 
<font size="5">  
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
When Jesus took the curse upon himself, he so identified with our sin that He became a curse. God cut Him off and justly so. This was an act of divine justice. At the moment when Christ took upon himself the sin of the world, He became the most grotesque , most obscene mass of sin in the history of the world. God is too holy even to look at iniquity. When Christ was hanging on the cross, the Father, as it were, turned his back on Christ. He removed his face. He turned out the lights. He cut off his Son. There was Jesus, who had been in a perfect, blessed relationship with God throughout His life. There was Jesus, the Son in whom the Father was well pleased. Now he hung in darkness, isolated from the Father, cut off from fellowship - fully receiving in Himself the curse of God - not for His own sin but for the sin He willingly bore by imputation for our sake.... Surely the physical agony of crucifixion was a ghastly thing. But there were thousands who died on crosses and may have had more painful deaths than that of Christ. But only one person has ever received the full measure of the curse of God while on a cross. I doubt that Jesus was even aware of the nails and the spear - He was so overwhelmed by the outer darkness. On the cross Jesus was in the reality of hell. He was totally bereft of the grace and the presence of God, utterly separated from all blessedness of the Father. He became a curse for us so that we someday will be able to see the face of God....  Christ was the scapegoat who carried our sins away from us (expiation) into the outer darkness. - <strong> R.C. Sproul, Saved from What? </strong>

---
No Other Way of Salvation
<font size="6">
<p align= "left">
How can an Unjust Man be Made Righteous?
<p align= "Center">
![[Pasted image 20231001210301.png|500]]
<font size="5">  
<p align= "left">
Once a person sins it is impossible to be perfect. God cannot overlook sin or else He Himself would not be just or righteous for He would not being doing what is right.  A Judge who does not punish evil is neither just nor good.
---
What did Jesus do for you?
<font size="6">  
<p align= "left">
If I ask a kid, <em>"What did Jesus do for you?" "Jesus died for my sins" </em>will be their answer.  But if that's all Jesus did, why didn't He just come down from heaven at age 30 and go straight to the cross? The idea behind atonement is that a just man, a righteous man died for the unrighteous and unjust sinner.  But Jesus had to first live a perfect life before he could be the Redeemer or the Savior.  He had to always do what he was told. <em>"He learned obedience through what he suffered" </em>(Heb 5:8) He had to get good standing with the bar of justice. In our justification, we often forget that there is a double exchange going on.
---
The Double Transfer
<font size="5">  
<p align= "left">
"If Jesus were to take on His back all the sins that I ever committed and bear the punishment for me, that would not get me into the kingdom of God. All that would do is keep me out of hell.  I would still not be just. I would be innocent but still not <i>just</i> in the positive sense.  I would have no righteousness of which to speak. Remember, it is not just innocence that gets us into the kingdom of God, it is righteousness. Unless our righteousness exceeds that of the scribes and the Pharisees, we will never get into the kingdom of God. (Matt 5:20) If the only thing that occurred in salvation was the removal of my guilt, I would still have no merit."
<p align= "left">
"So then there is a double transfer, not only is the sin of mankind imputed to Christ, but His righteousness is transferred to our account. In God's sight, our circle is now clean. When God declares me just, He is not lying. There is no more legal friction.  
Without Christ's meritorious life, the atonement would have no value. Without His obedience, His suffering on the cross would be merely a tragedy,  We must have the double transfer by which God declares us just. " - R.C. Sproul
---
<font size="6">  
<p align= "center">
![[Pasted image 20231001213327.png]]
---
<font size="6">  
<p align= "left">
The whole point of the gospel is that everything Christ has done applies to me as soon as I accept him.  Everything He is, including His righteousness, is mine. 

<p align= "left">
The Bible tells us that <strong> faith </strong>is the only way to get Christ's righteousness and credit put on our account.  We can't get it by working hard. We can't ever deserve it. We are not worthy of it. We can only believe it, trust God for it and hold onto it.
<p align= "left">
Justification by faith alone means that Christ is the only one who can make us right with God. It is because of Christ's work, righteousness, life, and death that we can stand before a holy God. Without Christ, we have no hope because all we can give God is our "unjustness."
<p align= "left">
==<strong>Hebrews 2:3</strong> - How shall we escape if we neglect so great a salvation?==

---
You have been saved <font color="#d8d8d8">by grace </font>through faith
<font size="5">  
<p align= "left">
Faith is the instrument or means by which we are saved. 
<p align= "left">
We can think of water flowing through a hose. The water is the important part, but it is communicated through the hose. The hose does not quench your thirst; the water does. But the hose brings water to the place you can benefit from it.
---
Faith

<font size="5">  
<p align= "left">
πίστιςπίστις<br>
pistis<br>
Thayer Definition:<br>
1) conviction of the truth of anything, belief; in the NT of a conviction or belief respecting man’s relationship to God and divine things, generally with the included idea of trust and holy fervour born of faith and joined with it<br>
1a) relating to God<br>
1a1) the conviction that God exists and is the creator and ruler of all things, the provider and bestower of eternal salvation through Christ<br>
1b) relating to Christ<br>
1b1) a strong and welcome conviction or belief that Jesus is the Messiah, through whom we obtain eternal salvation in the kingdom of God<br>
1c) the religious beliefs of Christians<br>
1d) belief with the predominate idea of trust (or confidence) whether in God or in Christ, springing from faith in the same<br>
2) fidelity, faithfulness<br>
2a) the character of one who can be relied on<br>
Part of Speech: noun feminine<br>
A Related Word by Thayer’s/Strong’s Number: from G3982<br>
Citing in TDNT: 6:174, 849<br>
Total KJV Occurrences: 244<br>

---
Saved through Faith
<font size="6">  
<p align= "left">

- <strong>Romans 10:9: </strong>"Because, if you confess with your mouth that Jesus is Lord and <u>believe in your heart</u> that God raised him from the dead, you will be saved."
    
- <strong>Galatians 2:16: </strong>"yet we know that a person is not justified by works of the law <u>but through faith in Jesus Christ</u>, so we also have believed in Christ Jesus, in order to be justified by faith in Christ and not by works of the law, because by works of the law no one will be justified."
    
- <strong>Romans 3:22:</strong> "the righteousness of God <u>through faith </u>in Jesus Christ for all who believe. For there is no distinction."
    
- <strong>Acts 16:31:</strong> "And they said, '<u>Believe in the Lord Jesus</u>, and you will be saved, you and your household.'"
---
And this is not your own doing; it is the gift of God,<!-- element style="background: floralwhite" -->
<font size="5">  
<p align= "left">
Our salvation is not our own doing. Paul states this very clearly. Salvation is not an achievement but a "gift" , and a gift from none other than God.  A <strong>gift</strong> is something acquired without compensation.  It is something given voluntarily to someone without payment or an expectation of anything in return. Grace is a gift by its very nature.
<p align= "left">
The <u>work of salvation</u>  itself is God’s gift to us. Paul’s grammar here indicates that this conjunction phrase connected by "and", applies to the gift of "salvation" mentioned in Eph 2:4-8, and not directly to the word "faith" mentioned in this verse.
<p align= "left">
However, our faith is a <i>gift of God</i>.  Grace comes to us through faith. No one can believe on Jesus unless God quickens their spirit and enlightens their understanding to believe the word of God when heard.  Until then, we all our are blinded by our spiritual deadness and by the God of this age. 
<p align= "left">
<strong>2 Cor. 4:4</strong> -<em>In their case the god of this world has blinded the minds of the unbelievers, to keep them from seeing the light of the gospel of the glory of Christ, who is the image of God."</em>
<p align= "left">

---
![[Pasted image 20230930224734.png|700]]
---
Faith is a Gift
<font size="5">  
<p align= "left">
Our ability to believe and trust in God  is not something that we inherently possess on our own. It's a result of God's grace, freely given to us.
    
- <Strong>Romans 12:3</Strong>: "For by the grace given to me I say to everyone among you not to think of himself more highly than he ought to think, but to think with sober judgment, each according to the <u> measure of faith that God has assigned.</u>"
    <p align= "left">
<font color="#a5a5a5">    This verse suggests that even our capacity to believe is assigned or apportioned by God. It's a part of His sovereign plan for each individual.</font>
    
- <Strong>1 Corinthians 12:9</Strong>: "<u>to another faith</u> by the same Spirit, to another gifts of healing by the one Spirit."
       <p align= "left">
    <font color="#a5a5a5">In this passage, faith is listed as one of the spiritual gifts given by the Holy Spirit. This reinforces the idea that faith is bestowed by God's grace. We can and should pray for God to increase our faith, which is of greater worth than gold.</font>
    
- <Strong>Galatians 5:22</Strong>: "But the fruit of the Spirit is love, joy, peace, patience, kindness, goodness, faithfulness..."
       <p align= "left">
    <font color="#7f7f7f">Here, faith is listed as one of the fruits of the Spirit. This indicates that genuine faith is a result of the work of the Holy Spirit within a believer.</font>
---
God's Grace Travel's Through Our Faith
<font size="5">  
<p align= "left">


|Verse Reference|Verse Text|
|---|---|
|Matthew 9:29 |"Then he touched their eyes, saying, 'According to your faith be it done to you.'"|
|Mark 11:24 |"Therefore I tell you, whatever you ask in prayer, believe that you have received it, and it will be yours."|
|Matthew 17:20 |"He said to them, 'Because of your little faith. For truly, I say to you, if you have faith like a grain of mustard seed, you will say to this mountain, ‘Move from here to there,’ and it will move, and nothing will be impossible for you.'"|
|Hebrews 11:6 |"And without faith it is impossible to please him, for whoever would draw near to God must believe that he exists and that he rewards those who seek him."|
|James 1:6 |"But let him ask in faith, with no doubting, for the one who doubts is like a wave of the sea that is driven and tossed by the wind."|
---
Parable of the Talents
<font size="5">  
<p align= "left">
In the parable of the talents <strong>(Matthew 25:14-30)</strong>, a master entrusts varying amounts of money to his servants before going on a journey. Two invest and double their amounts, pleasing the master. One, out of fear, buries his share. The master rewards the diligent servants and rebukes the fearful one for not using his talent. The parable teaches the importance of using God-given gifts and resources wisely and to develop and strength our talents.
<p align= "left">
<strong>1 Cor. 12:31 </strong>encourages us to earnestly desire the higher gifts. 
<p align= "left">
<strong>1 Peter 1:7 </strong>tells us the tested genuineness of our faith is more precious than gold that perishes though it is tested by fire.
<p align= "left">
<Strong>Faith is a gift that is given to each one of us in some measure when we are born again. It is also a gift that we should seek to develop and strengthen, and desire as one of the higher gifts being that the tested genuineness of our faith is more precious than gold that perishes though it is tested by fire.</strong>

---
 not a result of works, so that no one may boast.<!-- element style="background: floralwhite" --> 
<font size="5">  
<p align= "left">
Under God’s plan of salvation, God alone receives the glory. The Cause and effect of our salvation is made very clear.
<p align= "left">
The glory of that salvation belongs wholly to God and in no part to man. It has been so planned and so effected as to take from us all ground for boasting, is enforced on Paul’s hearers again and again, in different connections, with anxious concern and utmost plainness of expression 
<p align= "left">
<strong>1 Cor 1:4 </strong>- "I give thanks to my God always for you because of the grace of God that was given you in Christ Jesus."
<p align= "left">
<strong>1 Cor 1:26-31 </strong>- "For consider your calling, brothers: not many of you were wise according to worldly standards, not many were powerful, not many were of noble birth.  But God chose what is foolish in the world to shame the wise; God chose what is weak in the world to shame the strong; 
God chose what is low and despised in the world, even things that are not, to bring to nothing things that are, so that no human being might boast in the presence of God. And because of him you are in Christ Jesus, who became to us wisdom from God, righteousness and sanctification and redemption, so that, as it is written, “Let the one who boasts, boast in the Lord.”

---
<!-- slide bg="#D4E4F7" -->
Saved to What?
---
For we are his workmanship<!-- element style="background: floralwhite" --> 
<font size="5">  
<p align= "left">
God saves us not merely to save us from the wrath we rightly deserve, but also to make something beautiful of us. We are His workmanship, handiwork, or 'poiema'.
<p align= "left"> 
"Poiēma" is a Greek word that means "work" or "creation." It's often used in the context of artistic or creative works, and is the root of the English word "poem."  "Poiema" meant any work of art --it could mean a statue, a song, architecture, a poem or a painting. It conveys the idea of something artfully created. Here in Ephesians 2:10, it's used to refer to God's creative work. The idea is that we are His beautiful poem. The Jerusalem Bible translates  "workmanship"  as  “work of art.” 
<p align= "left"> 
This verse emphasizes that believers are God's masterpiece, created for good works in Christ. It beautifully captures the idea that our lives are a creative expression of God's design and purpose. 
---
<font size="5"> 
<p align= "left"> 
<strong>We are His workmanship</strong>- We belong to God. We are His property to do with as He chooses. But as someone has said "God don't make no junk!" As discussed more below the Master Artist has rendered each of us as His masterpiece (regardless of how we feel) if we are in Christ by grace through faith. This is amazing grace indeed! 
<p align= "left"> 
<strong>His</strong> is placed first in the Greek sentence for emphasis = "His" for we are workmanship" is the literal word order. Or "For of Him we are a product." The point is that we are not our masterpiece, not a masterpiece as a result of our making, but of His handiwork. We are a masterpiece only because we are "His" masterpiece totally unrelated to any effort or merit of our own.
<p align= "left"> 
<i class="fas fa-quote-left fa-2x fa-pull-left"></i><em>The spiritual life cannot come to us by development from our old nature. I have heard a great deal about evolution and development, but I am afraid that if any one of us were to be developed to our utmost, apart from the grace of God, we should come out worse than before the development began.” </em>- Spurgeon
---
<font size="6"> 
<p align= "left"> 
<strong>Joni Eareckson Tada</strong> who became quadriplegic after a tragic accident, alludes to herself as a "<strong>poiema</strong> in her book "A Place of Healing"(God) has a plan and purpose for my time on earth. He is the master artist or sculptor, and He is the One Who chooses the tools He will use to perfect His workmanship. What of suffering, then? What of illness? What of disability? Am I to tell Him which tools He can use and which tools He can’t use in the lifelong task of perfecting me and molding me into the beautiful image of Jesus? Do I really know better than Him, so that I can state without equivocation that it’s always His will to heal me of every physical affliction? If I am His poem, do I have the right to say, “No, Lord. You need to trim line number two and brighten up lines three and five. They’re just a little bit dark.” Do I, the poem, the thing being written, know more than the poet?" - A Place of Healing: Wrestling with the Mysteries of Suffering
---
created in Christ Jesus for good works<!-- element style="background: floralwhite" --> 
<font size="5">  
<p align= "left">
God's workmanship is making us, who were once workers of iniquity, following the ways of the world, the power of the air, our lusts, workers of evil, whose righteousness was like filthy rags,  now a new creation and  active in "good works" and bearing fruit .
<p align= "left">
Good, agathos, means means profitable, benefiting others.

<i class="fas fa-quote-left fa-2x fa-pull-left"></i><em>Works play no part at all in securing salvation. But afterwards Christians will prove their faith by their works. Here Paul shows himself at one with James.” - Wood</em><!-- .element: style="font-size: 24px" align="justify" --><br>
<p align= "left">
<strong>Philippians 1:6 </strong> - <em> "And I am sure of this, that he who began a good work in you will bring it to completion at the day of Jesus Christ."</em>
<p align= "left">
<strong> Matt. 5:16</strong> - <em>Let your light shine before men in such a way that they may see your <em>good works</em>, and glorify your Father Who is in heaven</em>


---
Illustration of Faith and Good Works
<font size="5">  
<p align= "left">
 An old Scotsman operated a little rowboat for transporting passengers. One day a passenger noticed that the good old man had carved on one oar the word “Faith,” and on the other oar the word “Works.” Curiosity led him to ask the meaning of this. The old man, being a well-balanced Christian and glad of the opportunity for testimony, said, “I will show you.” So saying, he dropped one oar and plied the other called Works, and they just went around in circles. Then he dropped that oar and began to ply the oar called Faith, and the little boat just went around in circles again—this time the other way around, but still in a circle. After this demonstration the old man picked up Faith and Works and plying both oars together, sped swiftly over the water, explaining to his inquiring passenger, “You see, that is the way it is in the Christian life. Dead works without faith are useless, and “faith without works is dead” also, getting you nowhere. But faith and works pulling together make for safety, progress, and blessing.”—Bible Friend
 <p align= "left">
<strong>William Booth</strong> founder of the Salvation Army made the interesting statement that "Faith and works should travel side by side, step answering to step, like the legs of men walking. First faith, and then works; and then faith again, and then works again -- until they can scarcely distinguish which is the one and which is the other.
---
which God prepared beforehand, that we should walk in them. <!-- element style="background: floralwhite" --> 
<font size="5">  
<p align= "left">
<strong>Prepared beforehand </strong>(4282) (proetoimazo from pró = before + hetoimazo = to make ready) means to ordain before, to make ready in advance or to be made ready beforehand. The aorist tense points to a specific action that has taken place. 
<p align= "left">
When is "beforehand?" Paul gives us a clue In chapter 1 where he says that God "chose us in Him (Christ) before the foundation of the world, that we should be holy and blameless before Him." (Eph 1:4)
<p align= "left">
Vessels of mercy prepared beforehand
for good works prepared beforehand!
<p align= "left">
<strong>Walk</strong>"peripateo" from **peri** = about, around + **pateo** = walk, tread,  means literally to go here and there or to tread all around. Most NT uses are figurative referring to the daily conduct of one's life or how they order their behavior or pass their life. The [<em>present tense</em>] "Continous action, habitual, reflects one's lifestlye, etc") indicates that this is now to be the believer's lifestyle - "</em>keep on walking</em>". To walk means to take a series of small steps in the same direction over a long period of time. Walking implies steady progress in one direction by means of deliberate choices over a long period of time. 
---
<font size="6">  
<p align= "left">
<strong>J Vernon McGee</strong>- Walking is not a balloon ascension. A great many people think the Christian life is some great, overwhelming experience and you take off like a rocket going out into space. That’s not where you live the Christian life. Rather, it is in your home, in your office, in the schoolroom, on the street. The way you get around in this life is to walk. You are to walk in Christ. God grant that you and I might be joined to Him in our daily walk.
---
The Believer’s Walk
<font size="5">  
<p align= "left">
Seven times the Apostle Paul speaks of the believer’s walk, in the book of Ephesians. This walk refers to how the Christian is to conduct himself before a holy God and a Godless world. 

1. Our previous walk: “Wherein in time past ye walked according to the course of this world, according to the prince of the power of the air” Ep 2:2 Our old walk is finished.
2. Our present walk: “For we are His workmanship, created in Christ Jesus unto good works, which God hath before ordained that we should walk in them” Ephesians 2:10 Our manner of living should be filled with good works.
3. Our privileged walk: “I beseech you that ye walk worthy of the vocation wherewith ye are called” Ep 4:1 
4.  Our guided  walk - Now this I say and testify in the Lord, that you must no longer walk as the Gentiles do, in the futility of their minds Eph 4:17
5. Our humble walk: “And walk in love, as Christ also hath loved us, and hath given Himself for us an offering and a sacrifice to God for a sweet smelling savour” Ep 5:2 . The essence of love is self-sacrifice.
6. Our changed walk: “For ye were sometimes darkness, but now are ye light in the Lord: walk as children of light” Ep 5:8
7. Our wise walk: “See then that ye walk circumspectly, not as fools, but as wise”  Ep 5:15
--
A Believers Walk
<font size="5">  
<p align= "left">

|Verse Reference|Verse Text|
|---|---|
|Eph 2:2|in which you once walked, following the course of this world, following the prince of the power of the air, the spirit that is now at work in the sons of disobedience—|
|Eph 2:10|For we are his workmanship, created in Christ Jesus for good works, which God prepared beforehand, that we should walk in them.|
|Eph 4:1|I therefore, a prisoner for the Lord, urge you to walk in a manner worthy of the calling to which you have been called,|
|Eph 4:17|Now this I say and testify in the Lord, that you must no longer walk as the Gentiles do, in the futility of their minds.|
|Eph 5:2|And walk in love, as Christ loved us and gave himself up for us, a fragrant offering and sacrifice to God.|
|Eph  5:8|for at one time you were darkness, but now you are light in the Lord. Walk as children of light|
|Eph 5:15|Look carefully then how you walk, not as unwise but as wise,|
---
END READING<br>
Ephesians 2:4-10
<font size="6">  
<p align= "Justify">
4 But God, being rich in mercy, because of the great love with which he loved us, 5 even when we were dead in our trespasses, made us alive together with Christ—by grace you have been saved— 6 and raised us up with him and seated us with him in the heavenly places in Christ Jesus, 7 so that in the coming ages he might show the immeasurable riches of his grace in kindness toward us in Christ Jesus. <font color="#366092">8 For by grace you have been saved through faith. And this is not your own doing; it is the gift of God, 9 not a result of works, so that no one may boast. 10 For we are his workmanship, created in Christ Jesus for good works, which God prepared beforehand, that we should walk in them. </font>
---
CLOSING PRAYER 
==
---