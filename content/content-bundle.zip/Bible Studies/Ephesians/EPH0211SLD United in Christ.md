-[<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->
---
OPENING PRAYER
==
---
<font size="5">  
<p align= "left">

#### P - Political Leaders and Policies
- Pray for the wisdom, discernment, and moral courage of political leaders.
- Ask God to direct policies toward peace and justice.
#### E - Emergency Personnel and Armed Forces
- Lift up those who are serving in dangerous situations like soldiers, medical teams, and first responders.
- Ask God for their protection, courage, and effectiveness in their roles.
#### A- Afflicted and Affected Civilians
- Pray for civilians caught in war zones, including children and the elderly.
- Ask God for their protection, provision, and emotional healing.
#### C - Churches and Spiritual Leaders
- Intercede for the churches within the country to be a beacon of hope and love.
- Pray for wisdom for spiritual leaders in guiding their communities during these times.
#### E - End of Conflict and Restoration
- Pray fervently for the cessation of hostilities and for peace talks to be successful.
- Ask God to bring about healing, reconciliation, and rebuilding.
---
Ephesians 2:11-22
<font size="5">  
<p align= "Justify">
<u>11 Therefore remember that at one time you Gentiles in the flesh, called “the uncircumcision” by what is called the circumcision, which is made in the flesh by hands— 12 remember that you were at that time separated from Christ, alienated from the commonwealth of Israel and strangers to the covenants of promise, having no hope and without God in the world. 13 But now in Christ Jesus you who once were far off have been brought near by the blood of Christ. 14 For he himself is our peace, who has made us both one and has broken down in his flesh the dividing wall of hostility </u>15 by abolishing the law of commandments expressed in ordinances, that he might create in himself one new man in place of the two, so making peace, 16 and might reconcile us both to God in one body through the cross, thereby killing the hostility. 17 And he came and preached peace to you who were far off and peace to those who were near. 18 For through him we both have access in one Spirit to the Father. 19 So then you are no longer strangers and aliens,[a] but you are fellow citizens with the saints and members of the household of God, 20 built on the foundation of the apostles and prophets, Christ Jesus himself being the cornerstone, 21 in whom the whole structure, being joined together, grows into a holy temple in the Lord. 22 In him you also are being built together into a dwelling place for God by the Spirit.
---

Therefore (ESV, NET, LSB) , So then (HCSV), For this reason (LSV), Wherefore 
<font size="6">  
<p align= "left">
Verse 11 starts with a conjunction indicating the upcoming paragraph and thoughts are a consequence or inference of the preceding paragraph. Ephesians 2:1-10 lays the foundation for Ephesians 2:11-22. 
<p align= "left">
<p align= "left">
<br>
What were the two main points of the proceeding paragraphs?<br>
<p align= "left">
- Ephesians 2:1
 <p align= "left">
- Ephesians 2:8



---
<font size="5">  
<p align= "left">
<strong>You were dead in your transgressions and sins, in which you once walked </strong><br>
In the first section, Paul describes the condition of humanity before we encountered Christ. He speaks of our being dead in trespasses and sins, walking according to the course of this world, and being children of wrath. <br><br>
<strong>For by grace you have been saved</strong><br>
Then, he portrays the grace of God in verses 4-10, where He makes us alive in Christ, raises us up, and seats us in heavenly places.
<p align= "left">
<strong>Unity comes through faith</strong><br>
In Ephesians 2:11-22 Paul will build on this foundation, showing that unity comes through Christ. The same grace that saved individuals also forms a new community, breaking down barriers and reconciling diverse groups into one body. This reflects the overarching theme in Ephesians of the mystery of God's will to unite all things in Christ (Ephesians 1:9-10). <u>Not only uniting man to God, but man to man. Sin not only separated man from God, but sin also separated man from man</u>. 
<p align= "left">
Paul focuses specifically on the Gentiles, their relationship to God and their relationship to the Jews. Paul reminds them of their past exclusion from the commonwealth of Israel. They were once strangers to the covenants of promise. However, because of Christ's work on the cross, the dividing wall of hostility has been broken down. Jew & Gentile are reconciled into one new man.
---
...<strong>remember</strong> that formerly you - the Gentiles in the flesh.....v12 <em>remember</em> that you were at that time without Christ...
<font size="6">  
<p align= "left">
Paul is exhorting the Ephesians and us to "remember" something. What is it that Paul is calling us to remember?
---
<font size="6">  
<p align= "left">
<strong>Their past condition</strong><br>
Paul calls them to remember their past condition before coming to faith in Christ.  They were <em>formerly, at one time</em>:<br><br>
- Gentiles in the flesh <br>
- Without Christ<br>
- Alienated from the citizenship of Israel<br>
- Strangers to the covenants of promise<br>
- Having no hope<br>
- Without God in the world<br>


---
<font size="6">  
<p align= "left">
Ephesians 2:11-12 closely parallels Ephesians 2:1-3 when Paul describes our past condition as: <br>
- those who were dead in their trespasses and sins<br>
- those who formerly walked according to the course of this world<br>
- those who formerly walked according to the ruler of the power of the air<br>
- those who formerly named among the children of disobedience<br>
- those who formerly conducted themselves in the lusts of the flesh<br>
- those who formerly followed the desires of the flesh and of the mind<br>
- those who were by nature children of wrath as the rest of the world
---
<font size="6">  
<p align= "left">
Ephesians 2:1-3 describes our past condition separation from God.<br>
Ephesians 2:11-12 describes our past condition of separation from the people of God.<br><br>
Ephesians 2:1
Ephesians 2:4 then turned on the hinge: <strong>"But God"</strong> and we saw grace <br>
Ephesians 2:13 also turns on a hing: <strong>"But now"</strong>and we will see unity, Christ is our peace.<br><br>
---
<p align= "left">
Paul calls us to <strong>remember</strong>. Don't forget.

<p align= "left">
<strong>Remember</strong> [3421] [<strong>mnemoneuo</strong> ]from <strong>[mnaomai]</strong>*= remember, call to mind, recall information) means to use the faculty of memory given by God and keep in one’s mind people, things, and circumstances because memory is basis of learning and of motivation for future action. This is the only use of this verb in Ephesians.

---
<font size="5">  
<p align= "left">
It is important for us to remember our former condition, the grace of God, the great truths of God and to keep remembering because we are prone to forget. <br><br>
Revelation 2:5, just 30 years later and the state of the church of Ephesus, where Christ in his letter to the churches rebukes the church of Ephesus for leaving their first love and exhorts them to <strong>remember </strong>from where they had fallen and to repent and to do the deeds they did at first.<br>
The Ephesian church had forgotten and lost their focus off Christ and left him as they focused more on their own works, and less on the works of God. "Remember we are his <strong>workmanship.</strong> We have to be careful about not getting caught up in our own works and losing focus. Remembering the works of God, Remembering our past condition, helps us to refocus. 
<p align= "left">
Remembering is an intentional discipline. Paul calls us to intentionally remember our past condition so that we can appreciate our present condition 
---
Importance of Taking Time to Remember
<font size="5">  
<p align= "left">
 <strong>Fosters Gratitude and Humility</strong> Remembering our past, especially moments of deliverance, helps cultivate a heart of gratitude and humility. It reminds us of our dependence on God's grace and mercy.<br>
<strong>Strengthens Our Faith</strong>: When we recall how God intervened in our lives or in history, it bolsters our trust in His providence and care.<br>
<strong>Helps us Learn from Mistakes</strong>:  It helps us acknowledge our shortcomings, seek forgiveness, and strive to live in accordance with God's will.<br>
<strong>Preserves God's Promises</strong>: Helps us hide God's word in our hearts and to remember his promises for prayer, teaching, comfort and to pass down to other generations. <br>
<strong>Keeps us from Idolatry</strong>: Remembering God's faithfulness guards against spiritual straying to idols and false gods in times of temptation.<br>
<strong>Builds Unity</strong>: It strengthens the bond among us as believers as we share stories and remember the good things God has done for us as we  experience God's work together builds community.<br>
<strong>Cultivates Thankfulness</strong>: It shifts our focus from potential hardships to the blessings and provisions God has provided.<br>
<strong>Fuels Worship</strong>:  It leads to praise and adoration, acknowledging His greatness and majesty
---
Therefore remember that at one time you <strong>Gentiles </strong> in the flesh, 
<font size="5">  
<p align= "left">
<strong>Gentiles</strong> [1484] <strong> [ethnos]</strong> - English "ethnic" defines a body of persons united by kinship, culture, language or common traditions. It is often rendered nation or people. <br>
<br>In this verse <strong>Gentiles</strong> is preceded by the definite article ("the") in the Greek text, marking Gentiles out as a distinct class. 
<p align= "left">
Basically all of mankind can be divided into <strong>Jew</strong> and <strong>Gentile</strong> and thus <strong>Gentile</strong> is a synonym for anyone who is non-Jew, who is not a member of the "chosen people". The Hebrew word corresponding to Gentile is <em>goyim</em>. This description arises from a Jewish standpoint since neither Romans nor Greeks would call themselves <em>Gentiles</em>.
<p align= "left">
Ephesians definition of a Gentile:<br>
          1,      They Were Uncircumcised.  <br>
          2.      They Were Without Christ.  <br>
          3.    They Were Aliens from the Commonwealth of Israel.  <br>
          4.      They Were Strangers to the Covenant of Promise.  <br>
          5.      They Were Without Hope.  <br>
          6.      They Were Without God in the World.<br>
---
Therefore remember that at one time you <span style="background:rgba(240, 200, 0, 0.2)">Gentiles in the flesh</span>, called “the uncircumcision” by what is called the circumcision, which is made in the flesh by hands 
<font size="5">  
<p align= "left">
Paul is addressing a primarily non-Jewish audience in Ephesus. The phrase "Gentiles in the flesh" distinguishes this audience from the Jews, who were historically the chosen people of God. God created the nation Israel from one man, Abraham.
<p align= "left">
Abraham was called by God to leave his home in Ur of the Chaldeans (located in modern-day Iraq) and go to a land that God would show him. God made a covenant with Abraham, promising to make him the father of a great nation. This nation is  Israel and has a very rich biblical history. They are a peculiar nation. They were give peculiar laws through Moses that they were required to keep. They alone were truly separated by God to Himself from the rest of the world as his chosen people for his special purpose. God maintained a very unique direct relationship with Israel through His covenant promise and through specific laws God gave Israel to approach Him.<br><br>
The term "Gentiles" refers to any nation or people group that is not Jewish, and "in the flesh" emphasizes their physical, ethnic identity as opposed to a spiritual identity in Christ. This distinction is important because it sets the stage for what Paul is about to say about unity in Christ, which overcomes these historical divisions.
---
Therefore remember that at one time you Gentiles in the flesh, <span style="background:rgba(240, 200, 0, 0.2)">called “the uncircumcision” by what is called the circumcision, which is made in the flesh by hands</span>
<font size="5">  
<p align= "left">
The Jews would traditionally refer to the Gentiles as  <em>"the uncircumcision." </em>Circumcision was an outward physical sign of the covenant between God and Abraham, and by extension, the Jewish people. Therefore, "uncircumcised" Gentiles were often viewed as outside the covenant community of God's chosen people. If you wanted to become a Jew, then you had to be circumcised. It was an outward sign, <em>made in the flesh by hands </em>. 
<p align= "left">
Observant Jews would often avoid social interactions with Gentiles to maintain ritual purity. For example, they would not eat with Gentiles or enter a Gentile home. This kind of separation was not just religious but also had social and even economic implications.
<p align= "left">
The Pharisees, observed even stricter laws concerning ritual purity, dietary restrictions, and religious practices. Gentiles, not adhering to these laws, were often viewed as impure or unclean.
<p align= "left">
The Samaritans, who were a mixed-race people with both Israelite and Gentile ancestry, were particularly despised by many Jews for their merged form of worship, further illustrating the general sentiment towards non-Jews.
---
Treatment of Gentiles by Jews
<font size="5">  
<p align= "left">
In the Jerusalem Temple, there was a partition known as the "Court of the Gentiles" beyond which non-Jews were not allowed to go. The message was clear: Gentiles could approach, but only so far.
<p align= "left">
While Jews generally did not interact socially with Gentiles, there was a subset of Gentiles known as "God-fearers" who were sympathetic to Jewish teachings. Some of these eventually converted to Judaism but had to commit to following Jewish laws, including circumcision for males—a significant barrier to conversion.
<p align= "left">
Under Roman law, Jews had some privileges, including the right to practice their religion freely. Gentiles who converted to Judaism could potentially lose their Roman citizenship, which was a serious deterrent.
<p align= "left">
From the Roman standpoint, Jews were often considered a troublesome and peculiar people because they refused to participate in the imperial cult or worship the emperor. However, Gentiles (Romans and otherwise) were typically more accommodating of the Roman religious syncretism or mixing the religions.
---
New Testament Tension Examples
<font size="5">  
<p align= "left">
 <Strong>Peter and Cornelius (Acts 10)</strong>: In the account of Peter and Cornelius, a Roman centurion. Peter has a vision indicating that he should no longer consider non-Jewish people or their dietary habits "unclean." Subsequently, he goes to Cornelius's house, a significant act given that Jews generally avoided entering the homes of Gentiles. This episode marks a significant turning point in the early Christian community's understanding of who could be included in the faith.
 <p align= "left"> 
<strong>Paul and the Judaizers (Acts, Galatians)</strong>: Paul himself was specially set apart by God to send the gospel to the Gentiles. Paul's letters often addressed the tension between Gentile Christians and those who believed that converts to Christianity should first become Jews (often termed "Judaizers"). The entire epistle to the Galatians can be seen as Paul's response to this tension.
<p align= "left">
<strong>The Council of Jerusalem (Acts 15)</strong>: Here, the apostles convened to discuss whether Gentiles who converted to Christianity needed to be circumcised and adhere to Jewish laws. The council's decision to not impose these restrictions on Gentile believers was groundbreaking.
---
<font size="5">  
<p align= "left">

<Strong>John MacArthur</strong> - A rabbinic writer tells of an incident that explains the common Jewish attitude toward Gentiles. A certain Gentile woman came to Rabbi Eleazar, confessed that she was sinful, and told him that she wanted to become righteous. She wanted to be accepted into the Jewish faith because she had heard that the Jews were near to God. The rabbi is said to have responded, “No. You cannot come near,” and then shut the door in her face**… God made Israel distinct for two reasons. First**, He wanted the world to see and notice them, to realize that they did not live and act like other men. **Second**, He wanted them to be so distinct that they would never be amalgamated with other peoples. He gave them such strict dietary, clothing, marriage, ceremonial, and other laws that they could never fit easily into another society. **Those distinctions, like the special blessings God gave them, were intended to be a tool for witness.** **But Israel continually perverted them into a source for pride, isolation, and self–glory…When a Jew entered Palestine he would often shake the dust off his sandals and clothing in order not to contaminate the Holy Land with Gentile dust. Because Samaritans were partly Gentile, most Jews would go far out of their way to avoid traveling through Samaria. If a young Jewish man or woman married a Gentile, their families would have a funeral service, symbolizing the death of their child as far as religion, race, and family were concerned. For fear of contamination, many Jews would not enter a Gentile home or allow a Gentile to enter theirs. For many hundreds of years the animosity between Jew and Gentile had festered and grown. Although they were not always in open conflict, their mutual contempt continued to widen the gulf between them. - See Ephesians MacArthur New Testament Commentary
---
<font size="6">  
<em>remember </em><span style="background:rgba(240, 200, 0, 0.2)">that you were at that time separated from Christ, alienated from the commonwealth of Israel and strangers to the covenants of promise, having no hope and without God in the world.</span>
<font size="5">  
<p align= "left">
Gentiles, all those who did not convert to Judaism, were separated from Christ.
<p align= "left">
<strong>Separated from Christ/Without Christ/Apart from Christ</strong>: The Gentiles were not part of the lineage of Abraham, to whom the promise of the Messiah was first given. They were therefore distanced from the redemptive work of Christ initially, lacking the Messianic hope that the Jews held.<br>
	<strong>J.C. Ryle</strong> - "A more miserable state cannot be conceived! It is bad enough to be without money, or without health, or without home, or without friends. But it is far worse to be “without Christ.”  [Sermon You were without Christ - Ephesians 2:12 J.C. Ryle]<br>
We meditated last Monday of how awful it was for Christ, who had lived a perfect life and who had never been separated from his Father, to have been separated from his Father on the cross. For us to be separated from Christ, thank God it is not possible, but if it were, we would be tasting that wrath of God.
	
<p align= "left">
<strong>Alienated from the Commonwealth of Israel</strong>: The Gentiles were not a part of the nation of Israel, the people whom God had chosen to reveal Himself to in a special way. They were outsiders, aliens, both in a national and religious sense. 
---
<font size="5">  
<p align= "left"> 
<strong>Strangers to the Covenants of Promise</strong> The covenants that God made were predominantly with the Israelites—from Noah to Abraham, and then Moses and David. The Gentiles were not privy to these covenants and, therefore, the promises, including the promise of the Messiah, and that through Abraham "ALL the nations shall be blessed in you"  a promise that would include the Gentiles. (Gal. 2:8-9,16) Jesus Himself mentioned he had sheep not of this fold. The salvation of the Gentiles too were always part of God's plan but they were strangers to the promise and separate from the people of God. Strangers to the hope of heaven, strangers to an inheritance, strangers to the promise of eternal life, all God's promises they would have been strangers too.
<p align= "left">
<strong>Having No Hope</strong>: Without the covenants and the promise of a Savior, the Gentiles were in a state of hopelessness. They had various gods and religious systems, but none offered the assurance and hope of salvation. They had no true knowledge of God. <strong> Heb 11:1 </strong> <em>  Now faith is the assurance of what we hope for and the certainty of what we do not see. </em>
<p align= "left">
<strong>Without God in the World</strong> Despite having many gods, the Gentiles were without the true God. Their gods were idols, unable to save or offer eternal life. In a very real sense, they were "atheists" concerning the true God. They would be without confidence in God's grace, sovereignty, promises, interventions, providence, guidance, comfort...

---
<font size="6">  
<p align= "left">
"I saw on a board this morning words announcing that an asylum was to be built on a plot of ground for a class of persons who are described in three terrible words—"HELPLESS, HOMELESS, HOPELESS." These are the kind of people whom God receives; to them he gives His mercy. Are you helpless? He will help you. Are you homeless? He will house you. Are you hopeless? He is the hope of those who have no other confidence. Come then to Him at once!" - Spurgeon"
---
Saddest Words
<font size="5">  
<p align= "left">
Several famous people were asked what they felt was the saddest word in the English language. Here’s what some of them said. Poet T.S. Eliot: “The saddest word in the English language is, of course, ‘saddest.’” Lyricist Oscar Hammerstein II: “But.” Writer John Dos Passos quoted John Keats: “Forlorn! the very word is like a bell.” Psychiatrist Karl Menninger: “Unloved.” Statesman Bernard M. Baruch: “Hopeless.” President Harry Truman quoted John Greenleaf Whittier: “For of all sad words of tongue or pen, the saddest are these: ‘It might have been!’” Alexandra Tolstoi: “The saddest word in all languages, which has brought the world to its present condition, is ‘atheism.’”
<p align= "left">
Put all of these answers together and you have a faint picture of a soul without Christ. I think of that word which Keats used so dramatically—“forlorn.” It is the English form of the Dutch word verloren, which means “lost.” But the Word of God, through the apostle Paul, gives the ultimate description, “without Christ, being aliens from the commonwealth of Israel, and strangers from the covenants of promise, having no hope, and without God in the world” Eph. 2:12
<p align= "left">
Source unknown  Bible.org
---
END READING<br>
Ephesians 2:11-22
<font size="5">  
<p align= "Justify">
<u>11 Therefore remember that at one time you Gentiles in the flesh, called “the uncircumcision” by what is called the circumcision, which is made in the flesh by hands— 12 remember that you were at that time separated from Christ, alienated from the commonwealth of Israel and strangers to the covenants of promise, having no hope and without God in the world. 13 But now in Christ Jesus you who once were far off have been brought near by the blood of Christ. 14 For he himself is our peace, who has made us both one and has broken down in his flesh the dividing wall of hostility </u> 15 by abolishing the law of commandments expressed in ordinances, that he might create in himself one new man in place of the two, so making peace, 16 and might reconcile us both to God in one body through the cross, thereby killing the hostility. 17 And he came and preached peace to you who were far off and peace to those who were near. 18 For through him we both have access in one Spirit to the Father. 19 So then you are no longer strangers and aliens,  but you are fellow citizens with the saints and members of the household of God, 20 built on the foundation of the apostles and prophets, Christ Jesus himself being the cornerstone, 21 in whom the whole structure, being joined together, grows into a holy temple in the Lord. 22 In him you also are being built together into a dwelling place for God by the Spirit.
---
CLOSING PRAYER 
==
---