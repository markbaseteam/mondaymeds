
<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->

---
![[Pasted image 20230710165632.png]]
---
Verse Text
<font size="6">  
<p align= "justify">
<strong>Ephesians 1:11-12 ESV</strong></br>
In him we have obtained an inheritance, having been predestined according to the purpose of him who works all things according to the counsel of his will, so that we who were the first to hope in Christ might be to the praise of his glory

---
<!-- slide template="[[tpl-con-2-1-box]]" -->

::: title
#### _**Ephesians 1:11-12 ESV An Inheritance**_
:::

::: left
![[EPH0111 Sentence Diagram.jpg]]

:::

<style>
.small-indent > ul { 
   padding-left: 1em;
}
</style>

::: right
****Slide Verse Text***<br>

In him we have obtained an inheritance, having been predestined according to the purpose of him who works all things according to the counsel of his will, so that we who were the first to hope in Christ might be to the praise of his glory



:::<!-- element align="left" style="font-size: 13px;" class="small-indent" -->

::: source

:::
---

<center><strong><em>Review</strong></em></center>
<p align= "left"><font size="6">  
Last week we looked at Ephesians 9 & 10 that gives us an over arching view of Christian History and God's plan as God works every thing out in the fullness of time to the purpose and pleasure of his will, the subjection of all things to Jesus Christ.
<p align= "left">

---
### In Him
<font size="6">  
<p align= "left">
Verse 10 in the NKJV ended with the phrase "- in Him"
<p align= "left">
Many bible translations, such as the ESV, ASV, NET start the beginning of verse 11 with the phrase "in him" or the comparable "in whom". 
<p align= "left">
There are no chapter or verse divisions in the original letter. So translators have to use their best judgement to stop and start sentences in places that will maintain the flow and thought. Remember verses 3-14 is one l-o-n-g glorious sentence in the greek language full of modifier clauses so they certainly had their work cut out for them.
<p align= "left">
This is also a continuous reminder that all our spiritual blessings are <strong>in Christ</strong>.
---
### We have obtained an Inheritance
<font size="6">  
<p align= "left">
This phrase is a bit more complicated to dig into because if you compared different bible translations the majority speak of us, the saints, having obtained an inheritance, but other translations such as the NET, took a different direction and translated the text as we are an inheritance.

Then there is further questions of who is included in the pronoun "we"?
---
Translation Comparison Ephesians 1:11
<font size="5"> 
| Version | Ephesians 1:11           |     |                |
| ------- | --------- | --- | ---- |
| NIV     | In him we were <font color="#ff0000">also chosen,</font> having been predestined according to the plan of him who works out everything in conformity with the purpose of his will,       |     |               |
| ESV     | In him we <font color="#ff0000">have obtained an inheritance</font>, having been predestined according to the purpose of him who works all things according to the counsel of his will,          |     |                         |
| KJV     | In whom also <font color="#ff0000">we have obtained an inheritance</font>, being predestinated according to the purpose of him who worketh all things after the counsel of his own will:          |     |                |
| NET     | In Christ we too <font color="#ff0000">have been claimed as God's own possession</font>, since we were predestined according to the one purpose of him who accomplishes all things according to the counsel of his will | LSB | In Him, we also <font color="#ff0000">have been made an inheritance</font>, having been predestined according to the purpose of Him who works all things according to the counsel of His will, |
|         |            |     |      |
---
Inheritance<br>
![[Pasted image 20230715175415.png|700]]
---
<grid drag="60 55" drop="5 10" bg="W">
<font size="5"> 
<p align= "left">
Learn a Biblical Greek WORD Everyday.
<p align= "left">
The purpose of a Word of the Day is to share the richness of the Greek language used in the New Testament and help make these words practical in the reader's Christian living. Because words do matter, the words of the New Testament matter most.  And in a day when words don't  seem to mean much, the need for precision in Christian doctrine and practice has never been more critical.
<p align= "left">
For each day of the year, Watson presents a brief word study and then offers an application to make that particular Greek word become real for practical living. To aid reinforcement, related verses are listed for the reader's personal study.
</grid>

<grid drag="25 55" drop="-5 10" style=bg="white">
<a href="https://www.amazon.com/Word-Day-Key-Words-Testament/dp/0899576869?&linkCode=li2&tag=inhispresen06-20&linkId=91af7072f18f8844dc047461f4c7c580&language=en_US&ref_=as_li_ss_il" target="_blank"><img border="0" src="//ws-na.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=0899576869&Format=_SL160_&ID=AsinImage&MarketPlace=US&ServiceVersion=20070822&WS=1&tag=inhispresen06-20&language=en_US" ></a><img src="https://ir-na.amazon-adsystem.com/e/ir?t=inhispresen06-20&language=en_US&l=li2&o=1&a=0899576869" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
</grid>

<grid drag="90 20" drop="5 -10" bg="white">
#### A Word for the Day: Key Words from the New Testament - J.D. Watson
</grid>
```

---
<font size="5"> 
<p align= "justify">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>Another direct result of redemption is inheritance, as in Ephesians 1:11.   The words we find there— <em>“we have obtained an inheritance”—</em>translate a single word in the Greek, eklērōthēmen [εκληρωθημεν] (aorist passive indicative of klēroō [κληροω], G2820 [κληρόω]) This unique word appears only here in the NT.<p>
<p align= "justify">
In Classical Greek, from the time of Homer, the noun root klēros [κληρος] (G2819 [κλῆρος]) referred to “the fragment of stone or piece of wood which was used as a lot.” Lots were drawn to discover the will of the gods. Since land was divided by lot, probably in the framework of common use of the fields, klēros [κληρος] came to mean a share, land received by lot, plot of land, and finally inheritance.1 Similarly, in the OT, the same basic concept of casting lots (the Urim and Thummin) was used to discover God’s will (Num. 27:21, 1 Chron. 24:5ff., etc.) and to divide land (1 Chron. 6:54–81). <p>
---
<font size="5"> 
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
So the idea Paul conveys here is that the lot of inheritance has fallen upon us, not by chance, but by the sovereign will of God.<p>
<p align= "justify">
Also, because eklērōthēmen [εκληρωθημεν] is in the passive voice (the subject being acted upon), it can also be translated <em> “we were made a heritage”</em> (as it is in the Revised Version and the American Standard Version). So, instead of saying that we obtained an inheritance, this says that we were made Christ’s heritage. Now, while that does fit grammatically, and even theologically, it does not fit contextually. And may we interject, the NIV misses the point by a mile with the mistranslation, “in Him we were also chosen,” for that is not what the text says.<p>
<p align= "justify">
---
<font size="5"> 
<p align= "justify">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
Our AV is correct here. Verse 14 explicitly speaks of our inheritance, which the Holy Spirit guarantees. Paul’s point in the entire passage (vv. 3–14) is to outline our riches in Christ. Specifically, the idea of inheritance really carries us back to being predestined to adoption in verse 5; the believer cannot be predestined to sonship without being predestined to inheritance. <u>Inheritance was, in fact, a primary reason for sonship.</u> Paul also says in Romans 8:17, we are “joint-heirs with Christ.” As theologian and commentator Charles Hodge put it: <em>“We have not only been made sharers of the knowledge of redemption, but are actually heirs of its blessings.”</em>
---
<font size="5"> 
<p align= "justify">
John MacArthur also explains:<br>
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
The passive form of the verb (kleroo) in Eph 1:11a allows for two possible renderings, both of which are consistent with other Scripture. It can be translated “<strong>were made an inheritance</strong>” or, as here, <strong>have obtained an inheritance</strong>. The first rendering would indicate that we, that is, believers, are Christ’s inheritance. Jesus repeatedly spoke of believers as gifts that the Father had given Him (John 6:37, 39, 10:29, 17:2,24, etc..)<br> <br>
Jesus won us at Calvary—as the spoils of His victory over Satan, sin, and death—and we now belong to Him. <em> ‘And they will be Mine,’ says the Lord of hosts, ‘on the day that I prepare My own possession’ ” (Mal. 3:17)</em>. From eternity past the Father planned and determined that every person who would trust in His Son for salvation would be given to His Son as a possession, a glorious inheritance.
---
<font size="5"> 
<p align= "justify">
Translated the other way, however, this word means just the opposite: it is believers who receive the inheritance...
<p align= "justify">
Both of the translations are therefore grammatically and theologically legitimate. Throughout Scripture believers are spoken of as belonging to God, and He is spoken of as belonging to them. The New Testament speaks of our being in Christ and of His being in us, of our being in the Spirit and of His being in us. “The one who joins himself to the Lord is one spirit with Him” ([Cor. 6:17).
<p align= "justify">
The practical side of that truth is that, because we are identified with Christ, our lives should be identified with His life (cf. 1Jn 2:6). We are to love as He loved, help as He helped, care as He cared, share as He shared, and sacrifice our own interests and welfare for the sake of others just as He did. Like our Lord, we are in the world to lose our lives for others.
<p align= "justify">
Although either rendering of eklērōthēmen can be supported, Paul’s emphasis in Ephesians 1:3-14. makes the second translation more appropriate here."
---
Are We God’s Inheritance, Or Is He Ours? Ephesians 1:17–19, Part 6 <br>
<font size="6">
Length 14:15 mins
<iframe width="560" height="315" src="https://www.youtube.com/embed/71VCHTXykiw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
---
### The Church/Saints are a Gift to Christ from God the Father
<font size="6"> 

| Ref       | Verse Text            |
| --------- | ----- |
| John 6:37 | All that the Father <font color="#ff0000">gives</font> me will come to me, and whoever comes to me I will never cast out                                                                                       |
| John 17:6 | I have manifested your name to the people whom you <font color="#d83931">gave</font> me out of the world. Yours they were, and you <font color="#d83931">gave</font> them to me, and they have kept your word. |
| Deut 32:9 | But the Lord's portion is his people,  Jacob his allotted heritage.            |
| Deut 4:20          |But the Lord has taken you and brought you out of the iron furnace, out of Egypt, to be a people of his own inheritance, as you are this day.      |
---
<font size="6"> 
<p align= "justify">
 We may not spend as much time meditating on that we, the church, are a gift given to Jesus Christ by God the Father.  Christ considers us a gift.
<p align= "justify">
This is important, because Christ loves us, as a groom loves the bride given to Him by his father as a gift.  He relates to us with love. <br><center>
<strong>We are his and he is ours.</center></strong>
<p align= "justify">
We spoke earlier this month on the richness of God's great gifts to us which he has richly  lavished upon us. Jesus Christ is our greatest possession. As Christians, we value him above all our possessions, it is what makes us distinct in this world which sees no value in the person of Jesus Christ. We see the Gift of gifts. <br>

<em>In him thou hast given me so much  
    that heaven can give no more.</em>
 <p align= "justify">

---
<font size="6"> 
<p align= "justify">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
The Son loved them as the Father's choice, He loved them as the Father's gift to Him. These are some of the bonds of the everlasting covenant which binds His people around the heart of His Son. They were beloved of His Father with an everlasting love. His Father chose them and set His heart upon them. He gave them to the Son as a gift of His love. Therefore the Son loved them. There are other, and strong, cords that bind Christ and His people together, but these are good and strong. How we love, how highly we prize a Father's gift!  - (T. Alexander, M. A.)
---
Blessed Assurance
<font size="6"> 
<p align= "justify">
This is important for us to understand because our being given to the Son by the Father emphasizes that we cannot loose our salvation. <br><br>
1. Would the Father give the Son a temporary or corruptible gift? <br>
2. Is the Son unable to keep his gift from the Father? Will he not take care of it? Will he loose it?

This should strengthen our assurance.
<p align= "justify">
<strong>John 6:37</strong> - <em> "All that the Father gives me will come to me, and whoever comes to me I will never cast out </em> "

---

<!-- slide bg="[[Background Image - Music.png]]" -->
<em>Blessed assurance, Jesus is mine!  
Oh, what a foretaste of glory divine!  
Heir of salvation, purchase of God  
Born of his Spirit, washed in His blood

This is my story, this is my song  
Praising my Savior all the day long  
This is my story, this is my song  
Praising my Savior all the day long</em>
---
<font size="5"> 
<p align= "justify">
Notice the verb tense in this first phrase: <br>
<center>"In him, we <em>have obtained</em> an inheritance....</center>

<p align= "justify">
<font size="5"> 
Paul refers to a specific previous deed by using what is called the <Strong>aorist tense</strong>. Greeks frequently spoke as if something had already happened when it was so definite that it could not possibly not happen, as in this instance. That is truly the power of God's word when He predestines something to occur. It will happen.  In a sense, by faith, we can speak of God's future promises as past tense. <p>
<p align= "justify">
There still remains a  future inheritance awaiting every believer as Peter  reminds his readers who were facing various trials.
<p align= "left"">
<Strong>1 Peter 1:3-5  </strong>- <em>Blessed be the God and Father of our Lord Jesus Christ! According to his great mercy, he has caused us to be born again to a living hope through the resurrection of Jesus Christ from the dead, to an inheritance that is imperishable, undefiled, and unfading, kept in heaven for you,  who by God's power are being guarded through faith for a salvation ready to be revealed in the last time."</em>
---
Having been predestined according to his purpose
![[EPH0111b Sentence Diagram.jpg]]
---
Predestined<br>
![[Pasted image 20230715200025.png|700]]
---
Proorizō [Προοριζω] (G4309 [προορίζω])
Word for the Day
<p align= "justify">
<font size="5"> 
Proorizō [Προοριζω] (G4309 [προορίζω]) is a fascinating word. Its simple meaning is “to designate before,” but we see the real depth of it in the fact that it’s a compound word. Pro [Προ] (G4253 [πρό]), of course, means “beforehand,” but horizō [ὁριζω] (G3724 [ὁρίζω]) speaks of a “boundary or limit,” and is actually where our English word horizon comes from. So, just as the horizon marks a limit between what we can and can’t see, God has placed us within a certain limit, a certain “horizon.” He has put us in a place where we can see and comprehend many things but where many other things are hidden from our sight and understanding, many things that are beyond our horizon. Further, even if we walk closer to the horizon, and understand things we never understood before, a new horizon appears. We will never understand it all this side of heaven.
---
<p align= "justify">
<font size="5"> 
This word graphically demonstrates that God has marked out something for each of His elect; He has marked out a destiny. Much of that destiny is hidden from us; it is beyond the horizon. But, praise be to God, he reveals more of it with each new step we take toward it.
What is that destiny? What is that purpose? While we don’t know it all, we do know some of it. The primary purpose in God’s predestination is “that [Christ] might be the firstborn among many brethren” (Rom. 8:29), that is, that Christ might be made preeminent. Scripture reveals that the firstborn always had preeminence. God’s ultimate object, therefore, is to glorify His Son. Further, Ephesians 1:5 likewise tells us that God predestined us to adoption (see Jan. 2), making us Christ’s brethren. Think of it! Each of us is either a brother or sister to our dear Savior. Then in Ephesians 1:11 we read that we are predestined to an inheritance, that is, spiritual riches, in Christ. That is our destiny.
So, we would submit that no controversy is warranted. Predestination is simply God’s marking out a destiny befitting His foreknown people. - Word for the Day
---
![[Pasted image 20230715200246.png]]
---
Habbakuk 2:2-3
![[Pasted image 20230715201749.png]]
---
### Pre-Determine
<p align= "justify">
<font size="5"> 
Compound Word - proorizo** from **pró** = before + **horízo** = to determine
<p align= "justify">
<Strong>Acts 4:28 </Strong><em>to do whatever your hand and your plan had <font color="#d83931">predestined</font> to take place.</em><br>
<Strong>Rom 8:29-30 </Strong><em>For those whom he foreknew he also <font color="#d83931">predestined</font> to be conformed to the image of his Son, in order that he might be the firstborn among many brothers. And those whom he <font color="#d83931">predestined</font> he also called, and those whom he called he also justified, and those whom he justified he also glorified.</em><br>
<Strong>1 Cor 2:7</Strong> - <em>But we impart a secret and hidden wisdom of God, which God <font color="#d83931">decreed before the ages</font> for our glory.</em>
---
Just Consider...
<font size="6"> 
<p align= "left">
What kind of God would God be if God created the world and mankind... <br>
<p align= "left">
- without having any plan in place to deal with man's fall, (having known the weakness of man's nature)<br>
- without having any end goal for creation,  no desired outcome?<br>
- without having any concern for his own glory,<br>
- not being able to accomplish his will and purposes according to his good pleasure because of some other greater force at play? Would he not be frustrated? <p>
<p align= "left">
Would God ever allow evil to override his ultimate good will, pleasure and purposes as a permanent end?
---
A Gentile's Inheritance
<font size="5"> 
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
The original reference is still kept up here in the word προορισθεντες, being predestinated, as in the word προορισας Eph 1:5. And as the apostle speaks of obtaining the inheritance, he most evidently refers to that of which the promised land was the type and pledge.  And as that land was assigned to the Israelites by limit and lot, both of which were appointed by God so the salvation now sent to the Gentiles was as expressly their lot or portion, as the promised land was that of the people of Israel. All this shows that the Israelites were a typical people; their land, the manner of possessing it, their civil and religious code, c., c., all typical and that in, by, and through them, God had fore-determined, fore-described, and fore-ascertained a greater and more glorious people, among whom the deepest counsels of his wisdom should be manifested, and the most powerful works of his eternal mercy, grace, holiness, goodness, and truth, be fully exhibited.  Thus there was nothing fortuitous in the Christian scheme all was the result of infinite counsel and design.  - Clark
---
##### According to the purpose of him who works all things after the counsel of his will.<br>
![[EPH0111c Sentence Diagram.jpg|700]]
---
<font size="6"> 
<p align= "left">
<font color="#d83931">According to</font> the purpose of him who works all things after the counsel of his will
<p align= "left">
<font size="5"> 
This "according to" echoes v7 when we read we have redemption <em>"according to the riches of his grace"</em>
<p align= "left">
<em>According to</em> implies proportionate to, not just simply a part of. God gives proportionately according to his riches. 
<p align= "left">
A Millionaire's gift of ten dollars  would be considered a "portion" of their wealth, while a gift of one million dollars would be considered a gift in proportion to their wealth. God gives us the riches of his grace and an inheritance in proportion to His own wealth, in Christ.
---
According to the <font color="#d83931">purpose </font>of him who works all things after the counsel of his will

![[Pasted image 20230715204530.png]]
---
<font size="6"> 
<p align= "left">
The shewbread  or Showbread were the 12 loaves of arranged bread that were placed before God in the Holy Place as the consecrated bread is referred to in Greek as <strong>prothesis</strong>.
<p align= "left">
The other primary definition of prothesis in the New Testament is purpose, which refers to something that is established as a goal or objective to be achieved, the making  plan in advance, or of something purposed with resolute determination for it to be accomplished.
<p align= "left">
It outlines what one aims at. It is comparable to a "blueprint" or design of God's calling of men generally, including both Gentiles and Jews.

---
<font size="5"> 
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
 predestination is not only to sonship, but to an inheritance; it not only secures the grace of adoption, but prepares and provides an heavenly portion: and this act of predestination proceeds according to a purpose; according to a purpose of God, which can never be frustrated; and according to the purpose of "that God", as one of Stephens's copies reads, that is the author of all things but sin; of the works of creation and of providence, and of grace and salvation; and who works all these according to his will, just as he pleases, and according to the counsel of it, in a wise and prudent manner, in the best way that can be devised; for he is wonderful in counsel, and excellent in working; wherefore his counsel always stands, and he does all his pleasure: and hence the inheritance which the saints obtain in Christ, and are predestinated to, is sure and certain. - Gill
---
Who <font color="#d83931">works</font> all things according to the counsel of His will


![[Pasted image 20230715223705.png|700]]


---

Our God is a God who Works.
<font size="6"> 
<p align= "left">
The verb "works" is in the present tense showing that our God is a God of continuous action and activity. He is always in motion.  The verb "works" is also in the active voice showing God as the source of action.  He is the universal agent always at work around us and within us to accomplish his will

<Strong>Phil 2:13</strong> - <em>for it is God who works in you, both to will and to work for his good pleasure.</em>
<p align= "left">
Every object and event is under our God's control. He is always at work around us as the main operating force, the main energy to ensure  His will is worked out in creation. We may not see it, like we do not see the electricity at work around us running through the circuits and through its courses before returning back again in a constant motion, or like the wind, but we can see the effects . 
---
<grid drag="90 20" drop="5 5" bg="white">
Who works all things <font color="#d83931">according to the counsel of His will</font>
</grid>
<grid drag="60 55" drop="5 30" bg="white">
![[Pasted image 20230715232647.png]]
</grid>
<grid drag="30 55" drop="-5 30" style=bg="white">
<font size="5"> 
<strong>Counsel, boule</strong> when used of man expresses a decision, a purpose or a plan which is the result of inner deliberation. <strong>Boule</strong> is that which has been purposed and planned. <strong>Boule</strong> has in it the ideas of intelligence and deliberation. In other words <strong>boule</Strong> describes the result of deliberate determination which in the present context reflects the product of not just a "mastermind" but God's heart of infinite love.
</grid>

---
<font size="5"> 
<p align= "let">
*Barnes comments:<br>
<p align= "justify">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
His agency in the work of creation was absolute and entire; for there was nothing to act on, and no established laws to be observed. Over the mineral kingdom his control must also be entire, yet in accordance with the laws which he has impressed on matter. The crystal and the snow are formed by his agency; but it is in accordance with the laws which he has been pleased to appoint. So in the vegetable world his agency is everywhere seen; but the lily and the rose blossom in accordance with uniform laws, and not in an arbitrary manner. So in the animal kingdom. God gives sensibility to the nerve, and excitability and power to the muscle. He causes the lungs to heave, and the arteries and veins to bear the blood along the channels of life; but it is not in an arbitrary manner. It is in accordance with the laws which he has ordained and he never disregards in his agency over these kingdoms. 
---
<font size="5"> 
<p align= "justify">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
So in his government of mind. He works everywhere. But he does it in accordance with the laws of mind. His agency is not exactly of the same kind on the rose-bud that it is on the diamond nor on the nerve that it is on the rose-bud, nor on the heart and will that it is on the nerve. In all these things he consults the laws which he has impressed on them; and as he chooses that the nerve should be affected in accordance with its laws and properties, so it is with mind. God does not violate its laws. Mind is free. It is influenced by truth and motives. It has a sense of right and wrong. And there is no more reason to suppose that God disregards these laws of mind in controlling the intellect and the heart, than there is that he disregards the laws of crystalization in the formation of the ice, or of gravitation in the movements of the heavenly bodies. The general doctrine is, that God works in all things, and controls all; but that “his agency everywhere is in accordance with the laws and nature of that part of his kingdom where it is exerted.” By this simple principle we may secure the two great points which it is desirable to secure on this subject:<br>
(1) the doctrine of the universal agency of God; and,<br>
(2) the doctrine of the freedom and responsibility of man<br>
---

#### So that, we (who were the first to hope/trust in Christ) might be to the praise of his glory.
![[EPH0112 Sentence Diagram.jpg|700]]
---
<font size="6"> 
<p align= "left">
<Strong>we, who first trusted in Christ</strong>; the Jews, the apostle, and others of the Jewish nation; The people of Israel, who hoped for Christ before he came, were the ones who first believed in him and trusted in him. 

<font color="#245bdb">Hope</font><br>
elpis [ελπις]<br>
<font size="5"> 
(Word of The Day)
<p align= "left">
Consider a moment the concept of hope as it’s viewed in the world today. Hope expresses a wish or a want, such as, “I sure do hope I get that promotion,” or “I sure hope I get that raise,” or “I hope we can get that new house we want.” There’s no certainty in the word as we use it today. The exact opposite, however, is true in Scripture. The Greek elpis [ελπις] (G1680 [ἐλπίς]) speaks of a “desire of some good with expectation of obtaining it.” Likewise, the verb elpizō [ελπιζω] (G1679 [ἐλπίζω]) means “to expect with desire.” <strong> So hope always means certainty; it expresses an attitude of absolute assurance and rest in that assurance.</strong><br>
---
<font size="5"> 
<p align= "left">
It’s amazing that Greek philosophy is glorified in the minds of many people when in truth it displays the depths of despair.....Why such despair? Because without Christ, there is no hope (Eph. 2:12). First Corinthians 15:19 is wonderfully significant. Paul says, “If in this life only we have hope in Christ, we are of all men most miserable.” Truly our hope (certainty) of resurrection and eternal life are only in Christ. First Thessalonians 5:8 also speaks of “the hope of salvation,” which declares our salvation to be absolutely certain. Without that, men are miserable indeed. As the old hymn declares:<br>
<center><em>
My hope is built on nothing less</br>
   Than Jesus’ blood and righteousness; </br>
I dare not trust the sweetest frame,</br>
    But wholly lean on Jesus’ Name.</br>
       On Christ the Solid Rock, I stand;</br>
       All other ground is sinking sand.</br></em>
---
#### <center><strong><font color="#0070c0">The chief end of man is to glorify God by enjoying him forever.</font></strong></center>
<font size="5"> 
<p align= "justify">
<strong>might be to the praise of his glory - </strong>
This is the end purpose of God's plan of predestination and our great inheritance -  <strong>the praise of the glory of God </strong>. So that His grace and goodness, as displayed in election, redemption, adoption, justification, regeneration and eternal salvation might be revealed to all mankind below, all principalities and powers, all rulers and authorities, and made known to the saints who are called to declare his excellencies.  So that we, the Saints, would give praise and honor to Him because of all these things, by attributing all to his grace, and nothing to ourselves; by expressing gratitude for all his blessings; by living our lives in accordance with the Gospel; and by doing everything with the intention of bringing glory to Him.<br>
<br>


---

END READING
## Ephesians 1:11-12 ESV
<p align= "Left">
<font size="6"> 
 <em> <p align="justify">11 In him we have obtained an inheritance, having been predestined according to the purpose of him who works all things according to the counsel of his will, 12 so that we who were the first to hope in Christ might be to the praise of his glory.</em>   
---

![[Image Closing Prayer Pink.png]]

---
