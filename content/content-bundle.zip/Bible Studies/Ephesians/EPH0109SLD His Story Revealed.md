
<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->

---
<font size="6">  
<p align= "left">
<strong>Ephesians 1:9-10 NKJV</strong></br>
 having made known to us the mystery of His will, according to His good pleasure which He purposed in Himself,  that in the dispensation of the fullness of the times He might gather together in one all things in Christ, both which are in heaven and which are on earth—in Him. 
---
![[Pasted image 20230710165632.png]]

---
<!-- slide template="[[tpl-con-2-1-box]]" -->

::: title
#### _**Ephesians 1:9-10 His Story Revealed**_
:::

::: left

![[EPH0109 Sentence Diagram.jpg]]
:::

<style>
.small-indent > ul { 
   padding-left: 1em;
}
</style>

::: right
****Verse Text***<br>

 9.  having made known to us the mystery of His will, according to His good pleasure which He purposed in Himself, 10 that in the dispensation of the fullness of the times He might gather together in one all things in Christ, both which are in heaven and which are on earth—in Him. NKJV



:::<!-- element align="left" style="font-size: 13px;" class="small-indent" -->

::: source

:::
---

<center><strong><em>Review</strong></em></center>
<p align= "left"><font size="6">  
Tonight's lesson starts off with a participle phrase dependent on the word "lavished" from last week's lesson.  We may have stopped, but Paul's thoughts have certainly not stopped. They continue on.
<p align= "left">
In order to understand verses 9 & 10 we must put them in context of verse 7 & 8 .

---
<p align= "left">
<font size="6">  
<em>v8. which he lavished upon us, in all wisdom and insight"</em> <!-- element class="with-border" -->
<font size="6">  
<p align= "left">
God's plan for the redemption of mankind was completed with all wisdom and insight.  Tonight we are going to see that God's Word, his divine wisdom, insights, and purposes have been more revealed or dispersed in our current dispensation then they ever had been in the past. This allows us to possess greater insight in divine things than those of former dispensations because of the revealing of the mystery of the gospel to us.
<p align= "left">
<font size="5">
<strong>1 Peter 1:12: - </strong><em>  
It was revealed to them that they were serving not themselves but you, in the things that have now been announced to you through those who preached the good news to you by the Holy Spirit sent from heaven, things into which angels long to look.</em>
---
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
<font size="6">  
Even the angels never had the knowledge of His wonderful plan that the weakest Christian may now have if he will. We are told that angels are learning the wisdom of God in us. He never gave to them a complete revelation of what was coming; but they are learning the wisdom, the counsels, the purpose of God, as they see His grace displayed in us. The church then is an object lesson to angels. It was given to us to understand these things, and not merely for intellectual gratification but in order that the truth might build us up in Christ, might form us morally and make us what God would have us be. “And every man that hath this hope in him purifieth himself even as he is pure” (1Jn 3:3) - Ironside <!-- .element: style="font-size: 24px" align="justify" -->
<br><br>
---
God's Story is Bigger then Man's Story
<p align= "left">
<font size="6">  
<strong>Ephesians 3:10- 11 </strong><em> so that through the church the manifold wisdom of God might now be made known to the rulers and authorities in the heavenly places. This was according to the eternal purpose that he has realized in Christ Jesus our Lord, </em><br><br>
<Strong>1 Cor. 11:10 </strong>- <em> That is why a wife ought to have a symbol of authority on her head, because of the angels.</em>
<font size="6">  
See also:  [[Heb-13#v2|Heb 13:2]], [[1 Tim-05#v21|1 Tim 5:21]], 
---
<p align= "left">
<font size="6">  
Even with all the divine wisdom and insight God has revealed to our dispensational age, there remains a lot of mystery still.<br>
<p align= "left">
	- Trinity & Godhead <br>
	- Christ's Incarnation<br>
	- Our Union with Christ<br>
	- Work of the Holy Spirit<br>
	- Resurrection of the dead<br>
	- Calling of the Jews<br>
	- Election & Predestination <br>
<p align= "left">
There is much we ourselves still long to look into! <br>But there is a lot of mystery that God has made known to us.
---
### History is His Story
<font size="6">  
<p align= "left">
In Ephesians 1:9-10 We can focus on the blessing of the mysteries of God that HAS been made known to us, the Saints. God reveals to us His calling of the Gentiles, and His purpose for human history. His end plan to unite all things in Christ, to bring all things to submission to Christ,  are summarized in these two verses. </br></br>
<strong>Key Points:</strong></br>
1. God makes Himself known.</br>
2. God reveals mysteries.</br>
3. God's Divine Timeline</br>
4. The end event is to bring all things together in Christ.
<font size="5">  
<p align= "left">
<strong>Deut 29:29</strong> - <em>“The secret things belong to the Lord our God, but the things that are revealed belong to us and to our children forever, that we may do all the words of this law.</em>
---

###### <font color="#4f81bd">According to His Good Pleasure which He Purposed in Himself </font>
<p align= "left">
<font size="5">  
<em><strong>v9. having made known to us the mystery of His will, <font color="#ff0000">according to His good pleasure which He purposed in Himself</font>,  </strong></em><br>
<strong><font color="#366092">Keypoint 1</font>:</strong>
God made known to us they mystery of his will. 
<p align= "left">
<strong><font color="#366092">Keypoint 2</font>: </strong>
God did this according to His good pleasure which he purposed in Himself. <br>
	- We spent a lot of time a couple weeks ago digging into the truth that God's good pleasure is his will and his will is his good pleasure. They are one and the same because God always does what pleases himself. <br>
	- We also spent time in discussing the key attributes of God and how God's will is not influenced by any external factors or pressures.  God's good pleasure is purposed in Himself. His purpose is his own, it is in Himself and we know that to be "<em>v5. to the praise of his glorious grace"</em>
---
"Known"
![[Pasted image 20230707230952.png]]
---
KP1: God Makes Himself Known to Us
<font size="5"> 
| Reference      | Verse Text                                                                                                                                                                                                                                |
| -------------- | ------------------ |
| Acts 2:28      | You have made known to me the paths of life; you will make me full of gladness with your presence.                                                                                                                                         |
| John 17:26     | I made known to them your name, and I will continue to make it known, that the love with which you have loved me may be in them, and I in them.”                                                                                          |
| Romans 9:22-23 | What if God, desiring to show his wrath and to make known his power, has endured with much patience vessels of wrath prepared for destruction, in order to make known the riches of his glory for vessels of mercy, which he has prepared |
| Luke 2:15      | When the angels went away from them into heaven, the shepherds said to one another, “Let us go over to Bethlehem and see this thing that has happened, which the Lord has made known to us.”                                              |
| John 15:15               |    No longer do I call you servants, for the servant does not know what his master is doing; but I have called you friends, for all that I have heard from my Father I have made known to you.      |
---
Throughout His Story - God has gone to great lengths to make Himself, His glorious nature and ways known to man.</br>
<font size="5">  <p align= "left">
<strong>Romans 1:19-20  - </strong><em>"For what can be  known about God is plain to them, because God has shown it to them. For his invisible attributes, namely, his eternal power and divine nature,  have been clearly perceived, ever since the creation of the world,  in the things that have been made. So they are without excuse."</em></br>
<strong>Hebrews 1:1-3-  </strong><em>Long ago, at many times and in many ways, God spoke to our fathers by the prophets, but in these last days  he has spoken to us by his Son, whom he appointed  the heir of all things,  through whom also he created  the world. He is the radiance of the glory of God and the exact imprint of his nature, and he upholds the universe by the word of his power.</em>
---
We would not and could not know anything about God Himself unless God reveals it to us.<br><br>
---
 <p align= "Left">
Question: <br>
<em>If there were no bibles in the world, no Christian books, could & would God be known?</em>
---
<p align="left">
Reminder of the Absolute Critical & Necessary Nature of Prayer <br>
-[[Ephes-01#v17|Eph 1:17]]<br>
-2 Tim 3:1-7</p>
--
The Last Days
<font size="6">  <p align= "justify">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
<em>But understand this, that in the last days there will come times of difficulty. For people will be lovers of self, lovers of  money, proud, arrogant, abusive, disobedient to their parents, ungrateful, unholy, heartless, unappeasable, slanderous, without self-control, brutal, not loving good, treacherous, reckless, swollen with conceit, lovers of pleasure rather than lovers of God,  having the appearance of godliness, but denying its power. Avoid such people.  For among them are those who creep into households and capture weak women, burdened with sins and led astray by various passions,  ==always learning and never able to arrive at a knowledge of the truth==. </em>- 2 Timothy 3:1-7
<!-- .element: style="font-size: 24px" align="justify" -->
--

<i class="fas fa-quote-left fa-2x fa-pull-left"> </i>  **Fighting for Holiness by JC Ryle:**
<font size="6">  <p align= "Left">
![[Fighting for Holiness by J. C. Ryle#^741a77]]

---
We must never forget that authentic Christianity is a living relationship with God the Father through Jesus Christ by the power of the Holy Spirit.
<p align= "left">
<font size="4">  
The Life of God in the Soul of Man by Henry Scougal:<br>

![[The Life of God in the Soul of Man#^9c3b26]]
---
**Having made known to us the <font color="#ff0000">mystery</font> of His will.**
<font size="6">  
<p align= "left">

 <center>![[Pasted image 20230707233800.png|600]]</center>
<br>
<font size="5">  
- a hidden or secret thing, not obvious to the understanding: 1 Corinthians 13:2; 1 Corinthians 14:2;<br>
- the secret counsels which govern God in dealing with the righteous, which are hidden from ungodly and wicked men but plain to the godly,
<p align= "left">
<strong>==If God had never revealed it, man never could have found it out.== </strong>
---
Ex: God Reveals Nebuchadnezzar's Dream to Daniel
<font size="5">  
| Ref         | Verse Text                                                                                                                                                                                                                                                                              |
| ----------- | ------------------- |
| Daniel 2:18 | and told them to seek mercy from the God of heaven concerning this mystery, so that Daniel and his companions might not be destroyed with the rest of the wise men of Babylon. Then the mystery was revealed to Daniel in a vision of the night. Then Daniel blessed the God of heaven. |
| Daniel 2:27 | Daniel answered the king and said, “No wise men, enchanters, magicians, or astrologers can show to the king the mystery that the king has asked,                                                                                                                                        |
| Daniel 2:47 | The king answered and said to Daniel, “Truly, your God is God of gods and Lord of kings, and a revealer of mysteries, for you have been able to reveal this mystery.”                                                                                                                   |

---
##### God's Special Dispensation of Wisdom & Insight to His Own
<font size="5"> 
<p align= "left">
 <strong>Amos 3:6-7</strong> -  If a trumpet is blown in a city will not the people tremble? If a calamity occurs in a city has not the Lord done it? Surely the Lord God does nothing unless He reveals His secret counsel to His servants the prophets.” <p>
<strong> 1 Cor. 2:7-12</strong> - But we impart a secret and hidden wisdom of God, which God decreed before the ages for our glory.  None of the rulers of this age understood this, for if they had, they would not have crucified the Lord of glory.  But, as it is written, 

“What no eye has seen, nor ear heard,  
    nor the heart of man imagined,  
what God has prepared for those who love him”—
<p align= "left">
these things God has revealed to us through the Spirit. For the Spirit searches everything, even the depths of God. For who knows a person's thoughts except the spirit of that person, which is in him? So also no one comprehends the thoughts of God except the Spirit of God. Now we have received not the spirit of the world, but the Spirit who is from God, that we might understand the things freely given us by God.   <p>
<p align= "left">
<strong>Matt. 13:11</strong> -  And he answered them, “To you it has been given to know the secrets of the kingdom of heaven, but to them it has not been given.
---
<font size="5">  <p align= "Left">
The mystery of the Gospel made known to us that Paul is referring to is that the Gentiles should be included in the call to the knowledge and faith of Jesus Christ, a truth that was plainly announced in the Scriptures but not understood by the Jews. They believed that God had placed an eternal barrier of separation between themselves and the heathen Gentiles, whom they reviled as dogs. When Paul declared his mission to the Gentiles, he was met with indignation and accusations of insanity. Even Festus, met Paul's declaration of truth with ridicule and rejection.
<p align= "Left">
<!-- element style="background:lightyellow" -->
<Strong>Isa. 49:6 </strong><em> And he said, It is a light thing that thou shouldest be my servant to raise up the tribes of Jacob, and to restore the preserved of Israel: I will also give thee for a light to the Gentiles, that thou mayest be my salvation unto the end of the earth.</em>
---
The Mystery Now Revealed
<font size="5">
| Ref             | Verse Text         |
| --------------- | ------ |
| Ephesians 3:1-6 | For this reason I, Paul, a prisoner of Christ Jesus  on behalf of you Gentiles— assuming that you have heard of  the stewardship of God's grace that was given to me for you, how the mystery was made known to me by revelation,  as I have written briefly. When you read this, you can perceive my insight into  the mystery of Christ, which was not made known to the sons of men in other generations as it has now been revealed to his holy apostles and prophets by the Spirit. ==This mystery is  that the Gentiles are  fellow heirs,  members of the same body, and  partakers of the promise in Christ Jesus through the gospel.==  |
| Romans 16:25-26 | Now to him who is able to strengthen you according to my gospel and the preaching of Jesus Christ, according to the revelation of the mystery that was kept secret for long ages but has now been disclosed and through the prophetic writings has been made known to all nations, according to the command of the eternal God, to bring about the obedience of faith                |
| Colossians 1:26-27                | the mystery hidden for ages and generations but now revealed to his saints. To them God chose to make known how great among the Gentiles are the riches of the glory of this mystery, which is Christ in you, the hope of glory.      |
---
Ephesians 1:10
<font size="5">
| Ref | Verse Text                                                                                              |
| --- | ------------ |
| ESV | as a **plan** for the fullness of time, to <font color="#366092">unite </font>all things in him, things in heaven and things on earth.       |
| KJV | that in the **dispensation** of the fullness of the times He might <font color="#366092">gather together in one</font> all things in Christ, both which are in heaven and which are on earth—in Him.  |
| NET | toward the **administration** of the fullness of the times, to <font color="#366092">head up</font> all things in Christ—the things in heaven and the things on earth.

---
**Dispensation , Administration, Plan,   Stewardship** 
Used 7x<br>
<font size="5"> 
<p align= "Left">
 [G3622]  Original: **οἰκονομία**<br>
Transliteration: **oikonomia**<br>
Phonetic: **oy-kon-om-ee'-ah**<br>
**Thayer Definition**:<br>
1. the management/administration of a household or of household affairs<br>
2. (specially) a (religious) “economy.”

<p align= "Left">
ii. The idea behind the word **dispensation** also reflects a plan or a strategy. "The plan which the master of a family, or his steward, has established for the management of the family . . . it signifies, also, a plan for the management of any sort of business." (Clarke)
---
<font size="5"> 
<p align= "Left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
What is meant by a “dispensation”? The word dispensation is used a number of times in the New Testament, and other words are also used to translate the same Greek word: stewardship, order, administration. We find that the original word has been brought right over into English; it is our word economy. In other words, “That in the economy of the fullness of times He might head up everything in Christ.” What is an economy? An economy is an ordering of a house. But the economy of one house is not necessarily the economy of every other house. If Christians would only bear that in mind, it would save a great deal of confusion. Then there is political economy-the ordering of the affairs of a nation. One nation does not order its affairs in the same way as another. The economy of Russia is not that of the United States of America; the economy of Italy is not the economy of England. These nations have their own ways of ordering their affairs, and if one came from Russia to the United States and attempted to order his conduct according to the economy of Russia, it would not be tolerated here. It might be lawful and right there, but not here. And so there are these various economies running through the Word of God. A dispensation or economy, then, is that particular order or condition of things prevailing in one special age which does not necessarily prevail in another. - Ironside
---
#### The Difference Between Dispensation & Age
<font size="5"> 
<p align= "Left">
While both dispensation and age refer to periods of time,  a dispensation is not the same as an age. 
<p align= "Left">
A dispensation refers to a period or era in which a specific set of rules, laws, or principles is applied. An age is a period of time, an era, epoch pr phase in a broader historical context in which a particular dispensation or economy prevails. 
<p align= "Left">
The dispensation  before the flood dealt with men according to conscience. After the flood, civil government was instituted by God for the restraint of human conduct. God then called Abraham to begin a new race of people with a promise of a coming Seed. At mount Sinai, the law was given to the people of Israel, which was in force until Christ’s sacrifice on Calvary. In the present age of the grace of God, we have the wonderful dispensation of the Holy Spirit, in which the gospel is being sent out into all the world. We are saved and kept by Christ, called to walk in Him to the praise of His grace. In the future, there will be “The dispensation of the fulness of times,” or “the millennium,” the last glorious age, also known as “the reign of righteousness.”
---
![[Pasted image 20230710180108.png]]
---
##### In the Fullness of Time
<font size="5"> 
<p align= "Left">
<strong><em>NKJV v10. </strong>that in the dispensation of the fullness of the times..</em><br>
<strong><em>AMP V10 </strong>with regard to the fulfillment of the times [that is, the end of history, the climax of the ages]</em>
![[Pasted image 20230710180909.png]]
<p align= "Left">
<!-- element style="background:lightyellow" -->
<strong>Galatians 4:4-5   </strong><em>
But when the fullness of time had come, God sent forth his Son, born of woman, born under the law,</em><br>
<strong>Genesis 15:16 -  </strong><em>But in the fourth generation they shall come hither again: for the iniquity of the Amorites is not yet full.,</em>
---
#### Gather together to One, Unite, Summarize, 
<font size="6"> 
Used only 2x
<p align= "Left">
<strong>Romans 13:9 </strong>-<em>For the commandments, “You shall not commit adultery, You shall not murder, You shall not steal, You shall not covet,” and any other commandment, are <font color="#ff0000">summed</font> up in this word: “You shall love your neighbor as yourself.”</em>
![[Pasted image 20230710015637.png]]
---
Root Word G2775 - Summarize
<p align= "Left">
<font size="5"> 
The term "gather together" means "to unite" or "to sum up." It was used in the past for adding up a column of figures and putting the total at the top. Paul believes that at the end, God will make all things "add up," and right now God is working towards that final result.
![[Pasted image 20230710015521.png|800]]
---
<font size="6"> 
<p align= "Left">
 In Ephesians 1:10 God is said to bring together again for himself all things and beings previously disunited by sin) into one combined state of fellowship in Christ, the universal bond; - Thayer

---
<p align= "Left">
<font size="6"> 
Last week in Ephesians 1:7-8 we talked about the fall of man, our need for redemption, to be ransomed from the slavery of sin.  Since the fall, the entire world, man and creation, the heavens and the earth, have fallen into disorder and cosmic chaos because of sin which goes beyond just total depravity of mankind. We talked about the necessity of Christ's blood atonement.  Here we see a glimpse of the future, the great reconciliation, summing up, when all knees will bow before Jesus Christ. 
---
Romans 8:18-22
<p align= "Left">
<font size="6">
For I consider that the sufferings of this present time are not worth comparing with the glory that is to be revealed to us.  For the creation waits with eager longing for the revealing of the sons of God.  For the creation was subjected to futility, not willingly, but because of him who subjected it, in hope that the creation itself will be set free from its bondage to corruption and obtain the freedom of the glory of the children of God. For we know that the whole creation has been groaning together in the pains of childbirth until now. 
---
#### Order Restored
<p align= "Left">
<font size="5"> 
Through Christ, all things are being restored to order and will be restored to order. Praise God that the fall of man and the curse is reversible!<br>Creation will be restored in ways we can't imagine.  Perfect Government. Perfect unity & peace can only be achieved through Christ alone and His righteous rule. In Christ, God has formed us into one body, bringing us into relationship with Himself, His Holy Spirit, Christ and to one another. Apart from Christ and outside the will of God there is only confusion, chaos, death & division. 
<p align= "Left">
<strong> Ephesians 4:4-6 </strong> <em>There is one body and one Spirit—just as you were called to the one hope that belongs to your call— one Lord, one faith, one baptism,  one God and Father of all, who is over all and through all and in all.</em>

---
<font size="6"> 
v 10.  He might gather together in one <font color="#ff0000"> in all things in Christ, both which are in heaven and which are on earth—in Him. </font>
<p align= "Left">
This is our prayer:<br>
"They Kingdom Come, Thy Will Be Done on earth as in Heaven.""

---
 
### The Preeminence of Christ
<p align= "Left">
<font size="6"> 
<Strong>Colossians 1:15-20 </strong> - <em>He is the image of the invisible God, the firstborn of all creation.  For by him all things were created, in heaven and on earth, visible and invisible, whether thrones or dominions or rulers or authorities—all things were created through him and for him. And he is before all things, and <span style="background:rgba(240, 200, 0, 0.2)">in him all things hold together</span>. And he is the head of the body, the church. He is the beginning, the firstborn from the dead, that in everything he might be preeminent. For in him all the fullness of God was pleased to dwell, <span style="background:rgba(240, 200, 0, 0.2)"> and through him to reconcile to himself all things, whether on earth or in heaven,</span> making peace by the blood of his cross  through him. </em>
---
The Subjugation of All Things to Christ,
<p align= "Left">
<font size="5"> 
<strong>Phil 2:10</strong> - <em>so that at the name of Jesus every knee should bow, in heaven and on earth and under the earth,</em><br>
Hebrews 2:5-8
![[Pasted image 20230710182126.png]]

---
All crowns will lay before Him.
<p align= "Left">
<font size="5"> 
<strong>Revelations 4:10-11 </strong> - <em>the twenty-four elders   fall down before him who is seated on the throne and worship him who lives forever and ever. They cast  d their crowns before the throne, saying,<br>
   "Worthy are you, our Lord and God,<br>
  to receive glory and honor and power,<br>
  for  you created all things,<br>
  and   by your will they existed and were created.”</em>

---

END
## Ephesians 1:9-10 ESV
<p align= "Left">
<font size="6"> 
 <em> <p align="justify">9. having made known to us the mystery of His will, according to His good pleasure which He purposed in Himself, 10 that in the dispensation of the fullness of the times He might gather together in one all things in Christ, both which are in heaven and which are on earth—in Him. - NKJV.</em>   
---
<em><font size="34">  <font color="#ffffff">Prayer</font><br></font></em>
<!-- slide bg="[[Pasted image 20230702190507.png]]" -->

---