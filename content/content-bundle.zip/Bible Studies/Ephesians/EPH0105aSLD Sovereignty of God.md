
As we begin to open and unpack our first blessings found in [[Ephes-01#v4|Eph 1:4]], [[Ephes-01#v5|5]] we are going to find that these blessings are pretty heavy in weight and there are many who are unable to spiritually lift them because of their weight.  So to ensure that we can receive these blessings and enjoy the lifetime supply of grace, peace, comfort and joy they contain, we are going to do have to do some spiritual muscle work by strengthening our faith with biblical doctrine regarding the nature of God.

This is akin to if someone told you that you had somehow found out that you were next of kin in relationship to inherit a great estate and position, perhaps one of a prince or a princess, next in line for the throne, or even that of a business owner from a deceived relative, but before you could receive or enter into that great privilege, you had to go through some intense training to prepare you for it.  Would you not go through the training so you could accept the role and walk worthy of the position to which you were called?  

One could say the promises of God are ours regardless of whither we fully understand or comprehend them or not. But how can we enjoy that which we cannot comprehend? How can we put into practice into our lives that which we cannot understand? How can we love, Him who we do not know? Many of us Christians have indeed received such great news of a celestial inheritance, that includes much that we can enjoy now but we are ignorant of our rights, privileges and possessions and instead live as poor beggars, fearful and anxious, shabbily clothed and feeding ourselves out of the dumpsters of what we find in the Facebook newsfeed memes, popular books or bible studies in bookstores that marginalize doctrine, watering it down so much and attempting to sweeten the gospel to the extend that all the nutrients for spiritual growth have been removed and left the pre-packaged, ready to go, bible study for the busy woman. Instead of enjoying the rich well-balanced feast that God has prepared for us that would nourish and strengthen our spiritual lives and effect knowledge of Him, spiritual growth and sanctification.

Some would question if we are even Christians as we walk in such mal-nourished,  sad and poorly clad state. But by God's power we are.  For a saint is never one who is a partial saint or partially called and elected.  Those who God calls and elects have truly been blessed with [[Ephes-01#v3| Eph 1:3 every spiritual blessing in Christ in the heavenly realms]]. We have received our notice in the gospel, but it is up to us to work out what God is working within us. 


  

As British theologians John Swinton and Harriet Mowat note “we don’t find truth, truth finds us!”Let it find you

Why it is important for a Christian to understand doctrine regarding free will.
![[Luther, Martin - Bondage of the Will#^d6c991]]