
<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->

---

![[Pasted image 20230710165632.png]]
---

<center><strong><em>Review</strong></em></center>
<font size="5">  <p align= "left">
Last week we finished verses 3-14 which make a beautiful doxology that is one long sentence in the Greek. This week we begin Paul's prayer which immediately follows in verse 15-23 which is also another long single sentence in the Greek and continues to the end of chapter 1. Ephesians is full of long sentences, below are 8 of the longest sentences in Ephesians we will encounter: <br><br>
1. Ephesians 1:3–14<br>
2. Ephesians 15–23;<br>
3. Ephesians 2:1–7<br>
4. Ephesians 3:1–13<br>
5. Ephesians 3:14–19<br>
6. Ephesians 4:1–7<br>
7. Ephesians 4:11–16<br>
8. Ephesians 6:14–20<br>

<p align= "justify">
We are going to break it down and meditate on it over the next few weeks.

---
<font size="6">  
<p align= "justify">
What made Paul so effective in his ministry? Was it his education? His upbringing? His heritage... 
<p align= "justify">
Paul had every reason brag, however he considered himself to be the least of all the apostles and acknowledged it was the grace of God which worked powerfully in him.
<p align= "justify">
" <em>For I am the least of the apostles, unworthy to be called an apostle, because I persecuted the church of God. But by the grace of God I am what I am, and his grace toward me was not in vain. On the contrary, I worked harder than any of them, though it was not I, but the grace of God that is with me." - </em>1 Cor. 15: 9-10
---
<font size="5">  
<p align= "justify">
<Strong>Believers Pray for Boldness - Acts 4:24-31:</strong><br>
24 And when they heard it, they lifted their voices together to God and said, “Sovereign Lord, who made the heaven and the earth and the sea and everything in them, 25 who through the mouth of our father David, your servant, said by the Holy Spirit,

“‘Why did the Gentiles rage,  
    and the peoples plot in vain?  
26 The kings of the earth set themselves,  
    and the rulers were gathered together,  
    against the Lord and against his Anointed’—
<p align= "justify">
27 for truly in this city there were gathered together against your holy servant Jesus, whom you anointed, both Herod and Pontius Pilate, along with the Gentiles and the peoples of Israel, 28 to do whatever your hand and your plan had predestined to take place. 29 And now, Lord, look upon their threats and grant to your servants to continue to speak your word with all boldness, 30 while you stretch out your hand to heal, and signs and wonders are performed through the name of your holy servant Jesus.” 31 And when they had prayed, the place in which they were gathered together was shaken, and they were all filled with the Holy Spirit and continued to speak the word of God with boldness.<br>

<strong>Great Grace Results:</strong>
<p align= "justify">
 33 And with great power the apostles were giving their testimony to the resurrection of the Lord Jesus, and great grace was upon them all. - Acts 4:33
---
<font size="6">  
<p align= "justify">
Paul was the 13th Apostle. He obtained "great grace" in the same manner a the 12 apostles. Through being called & prayer. Paul was a man of great prayer. His prayers alone are worthy to be studied in the bible.
---
Paul's Prayer List
<font size="6">  
<p align= "left">

- Ephesians 1:15-23 <br>
- Ephesians 3:14-21 <br>
- Philippians 1:9-11 <br>
- Philippians 4:6-7 <br>
- Colossians 1:9-14 <br>
- 1 Thessalonians 3:9-13 <br>
- 2 Thessalonians 1:11-12 <br>
- 2 Thessalonians 2:16-17 <br>
- 2 Timothy 1:3-7 <br>
- Philemon 1:4-7<br>
---
Pray!
<font size="5">  
<p align= "left">

1. <strong>Colossians 4:2</strong>: "Continue steadfastly in prayer, being watchful in it with thanksgiving."
    
2. <strong>1 Thessalonians 5:17</strong>: "Pray without ceasing."
    
3. <strong>Ephesians 6:18</strong>: "Praying at all times in the Spirit, with all prayer and supplication. To that end, keep alert with all perseverance, making supplication for all the saints."
    
4. <strong>Luke 18:1</strong> "And he told them a parable to the effect that they ought always to pray and not lose heart."
    
5. <strong>Romans 12:12</strong>: "Rejoice in hope, be patient in tribulation, be constant in prayer."
    
6. <strong>James 5:16</strong>: "Therefore, confess your sins to one another and pray for one another, that you may be healed. The prayer of a righteous person has great power as it is working."
    
7. <strong>Matthew 26:41</strong>: "Watch and pray that you may not enter into temptation. The spirit indeed is willing, but the flesh is weak."
---
Paul's Persistent Prayers
<font size="6">  

<em>...because I have heard of your faith in the Lord Jesus and your love, I do not cease to give thanks for you, remembering you in my prayers...</em>
<p align= "justify">
Paul's effectiveness can largely attributed to his prayer life. Two prayers of Paul are recorded in Ephesians, one here and another in 3:14-19. Paul's high regard among godly leaders in Church history is due to his practice of praying for others, intercessory prayer. Unfortunately, most of our prayers focus on ourselves and those closest to us, giving little attention to the needs of other members of the church, the saints at large, all who are in authority, Israel, and the persecuted church and missionaries. The Holy Spirit includes Paul's prayers as an important part of the epistle and an example of how we should pray.
---

Ephesians 1:15-23 ESV
<font size="6">  
<p align= "justify">
"For this reason, because I have heard of your faith in the Lord Jesus and your love toward all the saints, I do not cease to give thanks for you, remembering you in my prayers, that the God of our Lord Jesus Christ, the Father of glory, may give you the Spirit of wisdom and of revelation in the knowledge of him, having the eyes of your hearts enlightened, that you may know what is the hope to which he has called you, what are the riches of his glorious inheritance in the saints, and what is the immeasurable greatness of his power toward us who believe, according to the working of his great might that he worked in Christ when he raised him from the dead and seated him at his right hand in the heavenly places, far above all rule and authority and power and dominion, and above every name that is named, not only in this age but also in the one to come. And he put all things under his feet and gave him as head over all things to the church, which is his body, the fullness of him who fills all in all."
---
**Ephesians 3:14-21 ESV**
<font size="6">  
<p align= "justify">
 "For this reason, I bow my knees before the Father, from whom every family in heaven and on earth is named, that according to the riches of his glory he may grant you to be strengthened with power through his Spirit in your inner being, so that Christ may dwell in your hearts through faith—that you, being rooted and grounded in love, may have strength to comprehend with all the saints what is the breadth and length and height and depth, and to know the love of Christ that surpasses knowledge, that you may be filled with all the fullness of God. Now to him who is able to do far more abundantly than all that we ask or think, according to the power at work within us, to him be glory in the church and in Christ Jesus throughout all generations, forever and ever. Amen."
---
**Colossians 1:9-14 ESV**
<font size="6">  
<p align= "justify">
"And so, from the day we heard, we have not ceased to pray for you, asking that you may be filled with the knowledge of his will in all spiritual wisdom and understanding, so as to walk in a manner worthy of the Lord, fully pleasing to him: bearing fruit in every good work and increasing in the knowledge of God; being strengthened with all power, according to his glorious might, for all endurance and patience with joy; giving thanks to the Father, who has qualified you to share in the inheritance of the saints in light. He has delivered us from the domain of darkness and transferred us to the kingdom of his beloved Son, in whom we have redemption, the forgiveness of sins.""

---
Paul's Common Prayer Theme's
<font size="6">  
<p align= "left">

1. <strong>Spiritual Wisdom and Knowledge: </strong>Paul often prays for believers to grow in spiritual wisdom and knowledge, understanding God's will and His ways (Ephesians 1:15-23, Colossians 1:9-14).
    
2. <strong>Love and Discernment:</strong> Paul frequently prays for the recipients of his letters to abound in love for one another and to have discernment in their actions and decisions (Philippians 1:9-11).
    
3. <strong>Thankfulness:</strong> Many of Paul's prayers express gratitude to God for grace displayed in believers lives, their degree of faith, love, and perseverance. (Philippians 1:3-7, Colossians 1:3-8, Philemon 1:4-7).
---
    <font size="6">  

4. <strong>Spiritual Growth and Transformation:</strong> Paul prays for the spiritual growth and maturity of the believers, desiring that they become more Christ-like in their character and actions (Ephesians 3:14-21, Philippians 1:9-11).
    
5. <strong>Protection and Strength: </strong>Paul often intercedes for the believers' protection from evil, temptation, and the schemes of the enemy, asking God to grant them strength in their inner being (Ephesians 3:14-21).
    
6. <strong>Boldness in Witness:</strong> In some prayers, Paul asks God to grant the believers boldness in proclaiming the Gospel and fearlessly sharing their faith (Ephesians 6:18-20).
    
7. <strong>Unity and Reconciliation: </strong>Paul prays for unity among believers and for reconciliation between individuals or groups (Philemon 1:4-7).
---
<font size="6"> 

8. <strong>Hope and Encouragement:</strong> Some of Paul's prayers offer hope and encouragement to the recipients, reminding them of God's faithfulness and promises (2 Thessalonians 2:16-17).
    
9. <strong>Thanksgiving for Others' Faith:</strong> In his prayers, Paul gives thanks to God for the faith of fellow believers and their positive impact on others (1 Thessalonians 3:9-13).
10.  <strong>Knowledge of God the Father:</strong> Paul prayed believers would be given all spiritual wisdom and understanding so they might know him, know his will and his great, great love. (Ephesians 1:17)


---
Ephesians 1:15-16 ESV
<font size="6">  
<p align= "justify">
15 For this reason, because I have heard of your faith in the Lord Jesus and your love 16 I do not cease to give thanks for you, remembering you in my prayers, 
---
### For this reason,
<font size="6">  
<p align= "left">

| Version            | Translation         |
| ------------------ | ------------------- |
| ESV, NET, LSB, NIV | For this reason.... |
| HCB                | This is why...      |
| KJV                | Wherefore...        |
| LSV                   | Because of this...                    |
<p align= "justify">
A statement of causation. With such an opening statement,  we have to ask for what reason does Paul continually give thanks and pray for the Ephesian Gentile believers? What has Paul so joyful and full of gratitude? 


---
<font size="6">  
<p align= "left">
The for this reason, points back to verses 3-14, which were one large doxology of praise and blessing to God for every spiritual gift that he has bestowed on the saints in the heavenly realms in Christ. Paul's praise immediately leads him into humble prayer that these believes would know God and possess their possessions in Christ.
<p align= "left">
<strong>Obadiah 1:17 ESV:</strong><em> But in Mount Zion there shall be those who escape,  and it shall be holy,  and the house of Jacob shall possess their own possessions.</em>
---
RE-READ: Ephesians 1:15-23 ESV
<font size="6">  
<p align= "justify">
"<strong>For this reason, </strong><em>because I have heard of your faith in the Lord Jesus and your love toward all the saints, I do not cease to give thanks for you, remembering you in my prayers,</em>==that the God of our Lord Jesus Christ, the Father of glory, may give you the Spirit of wisdom and of revelation in the knowledge of him, having the eyes of your hearts enlightened, that you may know what is the hope to which he has called you, what are the riches of his glorious inheritance in the saints, and what is the immeasurable greatness of his power toward us who believe, according to the working of his great might that he worked in Christ when he raised him from the dead and seated him at his right hand in the heavenly places, far above all rule and authority and power and dominion, and above every name that is named, not only in this age but also in the one to come. And he put all things under his feet and gave him as head over all things to the church, which is his body, the fullness of him who fills all in all."==
---
<font size="6">  
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
Because of (For this reason) the believers’ acquisition of every spiritual blessing—including election, predestination, adoption, grace, redemption, forgiveness, wisdom, understanding, knowledge of the mystery of His will, the sealing of the Holy Spirit, and inheritance—Paul now prayed that his readers might know God personally and intimately. <br>
God had already given Israel the land (that's in part why it's called "the promised land"), but it was still their responsibility to put one foot in front of the other and begin to possess their possessions, stepping out in faith, trusting God's enablement and laying hold of what was theirs by divine decree. There is an important lesson for us today in all of this. God has given us "every spiritual blessing" in Christ, and yet we must step out by faith (which equates with obedience) and lay hold of God's precious and magnificent promises. And part of the secret of this process of laying hold is the prayers of the saints, interceding that they be enabled to do so.
---
<font size="6">  
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
A <Strong>LAND</strong> was given to the people of Israel, just as <strong>LIFE</strong> in Christ is made available to believers, not based on any merit of our own but solely on God's sovereign pleasure. Note that just as the land that had been given needed to be possessed, so too, believers today must lay hold of God's precious & magnificent promises by faith. Title to it is the gift of God; possession of it is the result of an obedient walk. The idea is, you can have all that you will take. You can have every bit of the spiritual life that you want. You will never get any more. God will never give you more than you are ready to take. So if you are not satisfied with the degree of your real experience of victory, it is because you haven't really wanted any more. You can have all that you want. "Every place where the sole of your foot will tread upon I have given to you." - Hoehner
---
Every Spiritual Blessing 
<font size="6">  <p align= "left">
Eph 1:4 He chose us in Christ<br>
Eph 1:5 He predestined us to adoption as sons<br>
Eph 1:6 He richly bestowed His grace on us<br>
Eph 1:7 He redeemed us through Christ's blood<br>
Eph 1:9 He has made known to us the mystery of his will<br>
Eph 1:11 He has  made us an inheritance<br>
Eph 1:12 He has sealed us with His Spirit<br>
<p align= "left">
How do these spiritual blessings effect our life today? In what ways would God have us possess and enjoy them  today? Are they just for heaven, the ages to come?
---
<font size="6"> 
Answer is in Paul's prayer:
<p align= "justify">
<u>Ephesians 1:15-23: </u>"<strong>For this reason, </strong><em>because I have heard of your faith in the Lord Jesus and your love toward all the saints, I do not cease to give thanks for you, remembering you in my prayers,</em>==that the God of our Lord Jesus Christ, the Father of glory, may give you the Spirit of wisdom and of revelation in the knowledge of him, having the eyes of your hearts enlightened, that you may know what is the hope to which he has called you, what are the riches of his glorious inheritance in the saints, and what is the immeasurable greatness of his power toward us who believe, according to the working of his great might that he worked in Christ when he raised him from the dead and seated him at his right hand in the heavenly places, far above all rule and authority and power and dominion, and above every name that is named, not only in this age but also in the one to come. And he put all things under his feet and gave him as head over all things to the church, which is his body, the fullness of him who fills all in all."==
---

### What is Paul is asking God to give the Ephesian believers?

---

#### What is it that Paul is asking God to give the Ephesian believers?<br>
<br>
![[Pasted image 20230730161154.png]]<br>
Possess Knowledge
<font size="6"> 
<p align= "justify">
- To know God the Father<br>
- To know the hope to which they are called,<br>
- To know God's power toward us who believe.<br>
---
<font size="5"> 
<p align= "justify">
Paul prays very specifically. He prays for what God has already decreed from eternity be accomplished to be made actual in the believers lifes. <br><br>
- It has been granted to believers to know God. [[John-17#v3|John 17:3]]<br>
- It has been revealed to believers the hope to which we are called.<br>
- It has been revealed to believers the power of God at work in us, through the resurrection of Christ and our salvation.<br>
<p align= "justify">
Yet often we don't realize these truths. We don't possess them as God would have us possess them. The only way we can possess them is through faith and prayer.<br><br>
Paul prays for the eternal decrees of God to be made actual. That is what prayer does. Much like the hearing the gospel is the means by which Holy Spirit brings about regeneration, prayer is the means God chooses to use to carry out his will through man.  God is his sovereignty does not have to, but He works through his creation. Some things God has decreed will only occur by prayer and fasting.
---
<font size="5"> 
<p align= "justify">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
"And if the Church be determined to-day to lift up her heart in prayer for the conversion of men, it is because God determined from before all worlds that men should be converted; your feeble prayer to-day, believer, can fly to heaven, and awake the echoes of the slumbering decrees of God. Every time you speak to God, your voice resounds beyond the limits of time, the decrees of God speak to your prayer, and cry, “All hail! Brother, all hail! Thou, too, art a decree!”

Prayer is a decree escaped out of the prison of obscurity, and come to life and liberty among men. Pray, brother, pray, for when God inspires you, your prayer is as potent as the decrees of God. As his decrees bind the universe with spell and make the suns obedient to him – as every letter of his decree is as a nail, pinning together the pillars of the universe, so are your prayers, they are pivots on which earth rests; they are the wheels on which providence resolves; your prayer are like God’s decrees, struggling to be born, and to become incarnate like their Lord.

God will, God must answer the prayers of his Church. Methinks I can see in vision in the clouds, God’s register, his file on which he puts the prayers of his Church. One after another they have been deposited; he has cast none of them away, and consumed none of them in the fire but he has put them on his file, and smiled as the heap accumulated; and when it shall reach a certain mark which he has set and appointed in his good pleasure, and the last number of the prayer shall be completed, and the blood of Christ shall have bedewed the whole, then will Eternal speak, and it shall be done; he shall command and it shall stand fast." -  <strong>Charles Spurgeon</strong>
---
<font size="6">  
<p align= "left">
Prayer is the greatest force that we can wield. It is the greatest talent which God has granted us. He has given it to every Christian. There is a democracy in this matter. We may differ among ourselves as to wealth, social position, educational equipment, natural ability, inherited characteristics; but in this matter of exercising the greatest force that is at work in the world today, we are on the same footing. It is possible for the most obscure person in a church, with a heart right toward God, to exercise as much power for the evangelization of the world, as it is for those who stand in the most prominent positions.” -<strong>John R. Mott</strong>
---
Invocation is the First Duty for Every Christian Person
<font size="5">  
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>The first general duty is the invocation of the name of God in Christ. When Saul got letters from the high Priests to persecute the Church, it is said by Luke that he received authority to bind all that call upon the name of God (Act 9.14). Paul, writing to the Church of Corinth, calls the members of it saints, and those who call on the name of the Lord Jesus (1Cor 1:2). By both of these places, the Holy Spirit would give us to understand that invocation is a main duty which every Christian man is to perform continually; and it contains both prayer and thanksgiving in the name and mediation of Jesus Christ. And indeed, by this action a Christian is distinguished and severed from all other sorts of men in the world who pretend devotion or religion. By this it appears that, however all men may desire to bear this name and take to themselves this general calling, very few are indeed true and sound Christians; for not one of a hundred can rightly invocate the name of God. Though they can indeed repeat the words of prayer, they lack the spirit of grace and supplication whereby they should ask for grace in Christ’s name, and give thanks for benefits received. Many who bear the name of Christ only for show, lack the power of that name. No, what is more, not to call on the name of God is made by the Prophet David, the note and mark of an Atheist, who says in his heart there is no God (Psa 14.1). -<strong> Perkins, Williams, A Treatise on Vocations</strong>
---
God's People Are Those Who Call on His Name
<font size="6">  
<p align= "left">

| Ref        | Verse Text       |
| ---------- | ------------------- |
| 1Cor. 1:2  | To the church of God that is in Corinth, to those sanctified in Christ Jesus, called to be saints together with all those who in every place call upon the name of our Lord Jesus Christ, both their Lord and ours: |
| Acts 9:14  | And here he (Saul/Paul) has authority from the chief priests to bind all who call on your name.”        |
| Roms 10:13 | For “everyone who calls on the name of the Lord will be saved.”     |
| Zeph 3:9           |“For at that time I will change the speech of the peoples to a pure speech, that all of them may call upon the name of the Lord and serve him with one accord.              |
---
Not Calling on the Name of the Lord
<font size="5">  
<p align= "left">

| Ref         | Verse Text                  |
| ----------- | -------- |
| Psa. 14:2-4 | "The Lord looks down from heaven on the children of man, to see if there are any who understand, who seek after God. They have all turned aside; together they have become corrupt; there is none who does good, not even one. Have they no knowledge, all the evildoers who eat up my people as they eat bread and do not call upon the Lord?" |
| Psa. 79:6   | "Pour out your anger on the nations that do not know you, and on the kingdoms that do not call upon your name!"         |
| Psa. 64:7   | "There is no one who calls upon your name, who rouses himself to take hold of you; for you have hidden your face from us, and have made us melt in the hand of our iniquities."      |
| Jer. 10:25            | "Pour out your wrath on the nations that know you not, and on the peoples that call not on your name, for they have devoured Jacob; they have devoured him and consumed him, and have laid waste his habitation."
   |
---
<font size="5">  
<p align= "left">
One of the key identifying marks of a Christian and a general calling required of every Christian, is to call on the name of the Lord. <br><br>

<strong>Martin Luther</strong>: <em>"To be a Christian without prayer is no more possible than to be alive without breathing."</em>
<p align= "left">

<p align= "left">
<strong>Dr. Thomas Guthrie </strong> - <em>The first true sign of spiritual life, prayer, is also the means of maintaining it. Man can as well live physically without breathing, as spiritually without praying. There is a class of animals—the cetaceous, neither fish nor sea fowl—that inhabit the deep. It is their home, they never leave it for the shore; yet, though swimming beneath its waves, and sounding its darkest depths, they have ever and anon to rise to the surface that they may breathe the air. Without that, these monarchs of the deep could not exist. And something like what is imposed on them by a physical necessity, the Christian has to do by a spiritual one. It is by ever and anon ascending up to God, by rising through prayer into a loftier, purer region for supplies of vine grace, that he maintains his spiritual life. Prevent those animals from rising to the surface,  and they die for want of breath; prevent the Christian from rising to God, and he dies for want of prayer. </em>

---
Cetaceous
<font size="5">  
<p align= "left">
Cetaceous refers to any marine mammal of the order Cetacea, which includes whales, dolphins, and porpoises.  They are known for their fully aquatic lifestyle, streamlined body shape, large size, and exclusively carnivorous diet. - Wikipedia
![[Pasted image 20230731005900.png|650]]
---
![[Pasted image 20230731005935.png]]
---
Behold He Prays
<font size="6">
<p align= "left">
Ironside notes that a primary sign of someone newly born into faith is their increased reliance on the Lord. They start by praying for their needs and soon extend their prayers for others as well.
<p align= "left">
When Ananias was fearful of approaching Saul after Saul's conversion on Damascus road, The Lord responded, "Behold, he prays." This showed a genuine spiritual transformation in Saul, who once persecuted God's church. Ananias then approached Saul with confidence and blessed him.
---
Prayer is Work
<font size="5">  
<p align= "left">
As we mature in the flesh it is expected that we get a job and work, develop and employ our gifts and talents for the common good and benefit of the estate of mankind and so that we can provide for our our needs and have left over to be generous and meet the needs of others also, especially the poor. A person who does not work, is viewed as lazy, slothful, idle, slack and careless. 2 Thess 3:10 even says, "<em> if you don't work, you don't eat. </em><br>
<p align= "left">
Just as we are expected to work on earth, we are also expected to work spiritually as we mature for the kingdom of God and to service God's kingdom and citizens. One way we do this is through prayer.
<p align= "left">
<strong>Colossians 4:12-13 </strong> - “Epaphras, who is one of you and a servant of Christ Jesus, sends greetings. He is always wrestling in prayer for you, that you may stand firm in all the will of God, mature and fully assured. I vouch for him that he is working hard for you and for those at Laodicea and Hierapolis.” <br><br>
 <center>If you struggle with prayer, that is normal! You are in good company!</center>
---
Why is prayer such hard work sometimes?
<font size="6">  
<p align= "left">
There are times when prayer is sweet and comes with ease, but often times, prayer and intercessory prayer especially is work. It takes really effort and energy from us to pray. Why is this? <br><br>
One of the primary reasons that prayer is work, is because it causes us to exercise the most spiritual muscles at one time. That is also  one of the primary reasons why, we ourselves grow stronger through the regular exercise of prayer.
---
Prayer Requires:
<font size="5">  
<p align= "left">

| Disciplines    | Exercise             |
| -------------- | --- |
| Faith          | It takes faith to know our prayers are heard and that we have what we ask for and to trust God when we do not receive what we ask for.  Mark 11:24     |
| Self-Control   | Pray requires discipline, to be consistent and to set aside dedicated time to plan to pray.    |
| Selflessness   | Intercessory prayer requires us to focus on the needs of others, and to care enough to feel a burden to able to pray        |
| Humility       | Prayer reminds us that are dependent on God for all our needs , It also requires vulnerability as we open our hearts up before God and others if public prayer     |
| Perseverance   | Prayer requires us that we pray continually and do not give up.     |
| Patience       | Prayer requires that we wait on God and hope in Him to answer in his timing, which can be years or even in the ages to come.   |
| Knowledge      | Prayer requires a knowledge of God's will and word as we claim promises, power    |
| Self-awareness    | Prayer requires confession, self-examination and confession of sin for God to hear us.      | 


---
<font size="5">  
<p align= "left">

| Disciplines    | Exercise             |
| -------------- | --- |
|  Reconciliation | Prayer requires us to have right relationships with others so our prayers are not hindered,  it teaches us conflict resolution. 1 Peter 3:7, Matt 5:24,      |
| Sincerity      | As John Bunyan once said, "<em> It is better to have a heart to pray then words without a heart, </em>   God looks at our heart when we pray to see if we sincerely desire what we ask for, so that we are free from deceit, pretense or hypocrisy. |
| Confidentiality         | Prayer requires that we do so in secret, in our closets, without worldly recognition.          |
| Love           | Prayer requires genuine love, for God and his kingdom and his will to come to pass, and love for the good of others, and for our enemies who we are to pray for     |
| Confidence     | We gain confidence through answered prayer. We exercise boldness in coming before the throne of grace to find help in time of need. It requires confidence to trust God.   |
| Unity               | The gospel enables us to participate in the life of the Trinity through our union with Christ. In prayer, we make our requests to God the Father through our relationship with Jesus Christ in adoption and his work that gave us righteousness and access, by the power of the Spirit who prays within us.    |
---
<p align= "left">
Prayer causes great grace. As we exercise each of these areas each time we pray, we grow in them. We grow in faith, self-control, selflessness, humility, perseverance, patience, knowledge, self-awareness, reconciliation....etc...
---
<font size="6">  
<p align= "left">
It's not easy unless we are in trouble. It's not natural to the flesh and there is nothing Satan hates more then prayer since it is the communication line between us and God where we do receive great grace, and accomplish God's will and purposes through prayer.<br><br>
In any war, communication lines are knocked out first. Satan knows if we can't/ don't communicate, we don't get help, nor do our loved ones, nor our children, nor our neighbors, nor our coworkers, nor our church, nor our country, nor our leaders, president. The church is losing the battle in this world because of a lack of prayer.  The church in the NT had a lot less going for it then we do, but they prayed! Paul prayed!  They devoted themselves to prayer and great grace was upon them all.
---
<p align= "left">
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
"Those who left the deepest impression on this sin-cursed earth have been men and women of prayer. You will find that prayer has been the might power that has moved not only God, but man." - D.L. Moody
---

![[Praying With Paul1.png]]
---
- What are some methods you use to be faithful in prayer?<br>
- Have you had a good prayer example in your life?<br>
- How can we be one for others?<br>
- What are some of the most beneficial books or other resources that influenced your prayer life?

---
Lessons from the School of Prayer by  D.A  Carson. 

<font size="6">  
<p align= "left">
1. Much praying is not done  because we do not plan to pray. <br>
2. Adopt practical ways to impede mental drift.<br>
3. At various periods in your life develop, if possible,  a prayer- partner relationship. <br>
4. Choose models - but choose them well.<br>
5. Develop a system for your prayer lists. <br>
6. Mingle praise, confession and intercession, but when you intercede,  try to tie as many requests as possible to Scripture. <br>
7. If you are in any form of spiritual leadership,  work at your public prayers. <br>
8. Pray until you pray. <br>
---
##### 1. Much praying is not done  because we do not plan to pray
<font size="6">  
<p align= "left">
The truth is we always find time to do what we want to do.  What we actually do always reflects what our highest priorities are at any given time.
<p align= "left">
<strong>D.A. Carson </strong>- <em>"Wise planning will ensure that we devote ourselves to prayer often, even if for brief periods: it is better to pray often with brevity than rarely but at length. But the worst option is simply not to pray - and that will be the controlling pattern unless we plan to pray."</em> <br>
<font size="5"> 
![[Pasted image 20230731163743.png|70]]  
<p align= "left">
- Set your phone alarm for a specific time, (morning, lunchtime or evening.) <br>
- Create a re-occurring calendar event on your schedule <br>
---
##### 2. Adopt practical ways to impede mental drift.
<font size="6">  
<p align= "left">
- Create a Prayer List <br>
- Vocalize Prayers <br>
- Pray over Scriptures <br>
- Pray using a hymnal lyrics <br>
- Pray using soft instrumental music for background or white noise. <br>
- Pace as you pray or walk <br>
- Journal your prayers <br>
- User a Pomodoro timer or app.<br>
- <iframe sandbox="allow-popups allow-scripts allow-modals allow-forms allow-same-origin" style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=US&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=inhispresen06-20&language=en_US&marketplace=amazon&region=US&placement=B089CHXTZF&asins=B089CHXTZF&linkId=3efc89c483048cd178f4442d3b7be773&show_border=true&link_opens_in_new_window=true"></iframe>
---
##### 3. At various periods in your life develop, if possible,  a prayer- partner relationship.
<font size="6">  

<p align= "left">
<strong>Ecclesiastes 4:9-10</strong> - <em>"Two are better than one because they have a good return for their labor. For if either of them falls, the one will lift up his companion."</em>
<p align= "left">
Prayer Partner can encourage, provide an example and offer accountability. 
<p align= "left">
<font size="5">  
- Schedule to meet once a week for a set period, 3 months, 6 months,<br>
- Commit to one another, no cancellations barring unforeseen circumstances.<br>
- Must not be gossips<br>
- Must be commitment to the pursuit of holiness, and spiritual growth. <br>
- Must be same sex.<br>
- Join a Prayer Groups <br>
- Journals - Accountability or Sharing <br>
- Use an Accountability App:  StickK, HabitShare, SnapHabit,
---
##### 4. Choose models - but choose them well
<font size="6">  
<p align= "left">
Listen to others pray. When you find a good model, study their content, passion, organization, burdens, but "do not ape their idiom" or do not imitate or mimic their way of speaking or expressing themselves, especially when it doesn't come naturally to you or is not authentic to your own personality.<br><br>
Models:<br>
<font size="5">  
- Study the Apostle Paul's prayers from above list or read <a href="https://amzn.to/3DCuql6">Praying with Paul by D.A.Carson</a><br> 
- <a href= "https://amzn.to/3OCZDLl">Andrew Murray, The Ministry of Intercession</a><br>
-<a href= "https://amzn.to/3DCFGxP">E.M. Bounds - The Complete Works</a><br>
- <a href= "https://amzn.to/3QkRjkB">Henry Thornton, Family Prayers</a><br>
-<a href= "https://amzn.to/3YnhU2v">J.R. Miller, Family Prayers for Thirteen Weeks</a> <br>
- YouDevotion  Daily Devotionals (Beta) App by Tap Tap Studio (Android, Apple?)
---
##### 5. Develop a system for your prayer lists
<font size="6">  
<p align= "left">
Online Prayer Guides
<font size="5">  
<p align= "left">
<a href= "https://operationworld.org/">Operation World</a><br>
<a href= "https://www.presidentialprayerteam.org/">Presidential Prayer Team</a><br>
<a href= "https://www.persecution.com/globalprayerguide/">Voice of the Martyrs Global Prayer Guide</a><br>
- <a href= "https://www.opendoors.org.au/get-involved/prayer/">Open Doors Persecuted Christians</a><br>
<font size="6">  
<p align= "left">
Organization Methods<br>
 <font size="5">  
- Binder with Tabs for days of the week<br>
- Manila File Folders - D.A. Carson <br>
- Index Cards - Paul Miller <br>
- Journal with a topic for each page or month and year <br>
- Mnemoric Techniques - Concentric Circles - John Piper Prayers for self, family, extended family, church, friends, coworkers, city, country, world, universal church, all saints...<br>
- Create a Prayer Photo Album, Scrapbook<br>
- PrayerMate App (Android & Apple) Tim Challies<br>
--
![[Pic Journal Stack1.png]]

--
<font size="6">  
![[Pic INHPD Prayer Page Tim1.png]]
--
<font size="6">  
<p align= "left">
![[Pic INHPD Prayer Page Marriage1.png]]
--
<font size="6">  
<p align= "left">
![[Pic INHPD Prayer Page Children1.png]]

--
<font size="6">  
<p align= "left">
![[Pic INPD Prayer Page Israel1.png]]
--
![[Pic Self Examination Nightly1.png]]

--
![[Pic In His Presence Daily Cover1.png]]

--
<a href= "https://www.prayermate.net/app">PrayerMate</a><br>

![[Pasted image 20230731174740.png|300]]
---
<i class="fas fa-quote-left fa-2x fa-pull-left"></i>
"All of  us would be wiser if we would resolve never to put people down, except on our prayer lists." - <strong>D.A. Carson, Praying with Paul</strong>
---
##### 6. Mingle praise, confession and intercession, but when you intercede,  try to tie as many requests as possible to Scripture
<font size="6">  
<p align= "left">
- Pray the promises <br>
- Remember the Sovereignty of God.<br>

<em>"The Bible simultaneously pictures God as utterly sovereign, and as a prayer-answering God. Unless we perceive this and learn hot to act on these simultaneous truths, not only will our views of God be distorted, but our praying is likely to wobble back and forth between a resigned fatalism that asks for nothing and badgering desperation that exhibits little real trust" </em>- D.A. Carson
---
##### 7. If you are in any form of spiritual leadership,  work at your public prayers. 
<font size="5">  
<p align= "left">

John 11:41-42 - "Father, I thank you that you have heard me. I knew that you always hear me, but I said this for the benefit of the people standing here, that they may believe that you sent me"

- Public prayers should edify those who listen, encourage and set an example.
- Public prayers ought to be the overflow of one's private praying. 
- Public prayers are more intercessory in nature. As there are different styles in communication in public and private conversations, there are different styles of prayer.
- Public prayers should be more thought out, prepared, organized and intentional then our private prayers and shorter.<br>
> <strong>D.L. Moody</strong> -<em> "My experience is that those who pray most in their closets generally make short prayers in public. Long prayers are too often not prayers at all, and they weary the people.</em>"
---
##### 8. Pray until you pray
<font size="5">  
<p align= "left">
<strong>Robert McCheyne</strong> - <em>"A great part of my time is spent in gettnig my heart in tune for prayer. It is the link that connects earth with heaven."</em>
<p align= "left">
God wants sincerity in our prayers, not just routine, going through a list or reading through someone else's prayers. Prayer Guides are great but they are only to be used to help stabilize our prayers and give them energy until our own spirit takes flight to heaven.  Pray sincerely and when you don't know what to say, remember the Spirit himself is able to groan

<strong>Romans 8:26-27 </strong> - <em>In the same way, the Spirit helps us in our weakness. We do not know what we ought to pray for, but the Spirit himself intercedes for us through wordless groans. 27 And he who searches our hearts knows the mind of the Spirit, because the Spirit intercedes for God’s people in accordance with the will of God.""=</em>

<strong>John Bunyan</strong> - <em>"In prayer, it is better to have a heart without words than words without a heart."</em>
---
##### No Set Rules
<font size="5">  
<p align= "left">
<strong>J.I. Packer </strong>- "I start with the truism that each Christian’s prayer life, like every good marriage, has in it common factors about which one can generalize and also uniquenesses which no other Christian’s prayer life will quite match. You are you, and I am I, and we must each find our own way with God, and there is no recipe for prayer that can work for us like a handyman’s do-it-yourself manual or a cookery book, where the claim is that if you follow the instructions you can’t go wrong. Praying is not like carpentry or cookery; it is the active exercise of a personal relationship, a kind of friendship, with the living God and his Son Jesus Christ, and the way it goes is more under divine control than under ours. Books on praying, like marriage manuals, are not to be treated with slavish superstition, as if perfection of technique is the answer to all difficulties; their purpose, rather, is to suggest things to try. But as in other close relationships, so in prayer: you have to find out by trial and error what is right for you, and you learn to pray by praying. Some of us talk more, others less; some are constantly vocal,  others cultivate silence before God as their way of adoration; some slip into glossolalia, others make a point in not slipping into it; yet we all may be praying as God means us to do. The only rules are,  stay within biblical guidelines and within those guidelines,  as John Chapman puts it,  "pray as you can and don't try to pray as you can't. "
---

END READING
## Ephesians 1:15-17 ESV
<p align= "Left">
<font size="6"> 
 <em> <p align="justify">15 For this reason, because I have heard of your faith in the Lord Jesus and your love 16 I do not cease to give thanks for you, remembering you in my prayers, .</em>   
---

![[Image Closing Prayer Pink.png]]

---