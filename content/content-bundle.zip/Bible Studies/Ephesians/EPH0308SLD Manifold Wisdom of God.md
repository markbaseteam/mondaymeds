<!-- slide bg="![[Ephesians Bible Study.jpg]]" -->
---
OPENING PRAYER
==
---
Annoucements
<font size="6">  
- No Bible Study Monday, December 25th, Christmas Day
- No Bible Study Monday, January 1st, New Year's Day
---
<font size="6">  
Ephesians 3:8-13
<font size="5">  
<p align= "Justify">
3 For this reason  I, Paul, a prisoner of Christ Jesus on behalf of you Gentiles— 2 assuming that you have heard of the stewardship of God's grace that was given to me for you, 3 how the mystery was made known to me by revelation, as I have written briefly.  4 When you read this, you can perceive my insight into the mystery of Christ, 5 which was not made known to the sons of men in other generations as it has now been revealed to his holy apostles and prophets by the Spirit. 6 This mystery is that the Gentiles are fellow heirs, members of the same body, and partakers of the promise in Christ Jesus through the gospel.
<p align= "Justify">
7 Of this gospel I was made a minister according to the gift of God's grace, which was given me by the working of his power. <p align= "Justify"><font color="#548dd4">8 To me, though I am the very least of all the saints, this grace was given, to preach to the Gentiles the unsearchable riches of Christ, 9 and to bring to light for everyone what is the plan of the mystery hidden for ages in God, who created all things, 10 so that through the church the manifold wisdom of God might now be made known to the rulers and authorities in the heavenly places. 11 This was according to the eternal purpose that he has realized in Christ Jesus our Lord, 12 in whom we have boldness and access with confidence through our faith in him. 13 So I ask you not to lose heart over what I am suffering for you, which is your glory. </font>
<p align= "Justify">


---
<font size="6">  
8 To me, though I am the very least of all the saints, this grace was given, to preach to the Gentiles the unsearchable riches of Christ, <!-- element style="background: floralwhite" --></font>
<font size="5">  
<p align= "left">
<strong>To me</strong>: This phrase emphasizes the personal nature of Paul's experi9962ence. In Greek, "to me" is "emoi," indicating that this revelation and grace were uniquely given to Paul. 
<p align= "left">
<strong>though I am the very least of all the saints( less than the least of all the holy ones -LSB)</strong>: The phrase "the very least" signifies the extreme sense of unworthiness. Paul humbly acknowledges his own perceived insignificance compared to other believers. Paul, who persecuted the church. Paul who was not among the twelve disciples. They would be "more deserving" would they not? But God chose and called Paul specifically for this great work, the ministry of the gospel among the Gentiles.  This displays the humility of Paul as he sees his own unworthiness and inability. The greatest of all the saints have always been humble men, Abraham, Jacob, Moses, David. All suffered greatly and in their suffering displayed their sure faith in God.
<p align= "left">
<strong>this grace was given</strong> "Grace" denotes unmerited favor. It highlights that the ability to preach to the Gentiles is not due to Paul's merit but a gift from God. God's favor is the greatest gift in life that one can possess. Possessing God's favor, we experience God's kindness, privilege benevolence, consideration and mercy. We are subjects of his affection. Paul was a subject of God's affection. You look at his life and you may wonder how that can be. Paul suffered a great deal but Paul truly did count it all joy and an opportunity to know Christ more.
<p align= "left">
---
<font size="6">  
8 To me, though I am the very least of all the saints, this grace was given, to preach to the Gentiles the unsearchable riches of Christ, <!-- element style="background: floralwhite" --></font>
<font size="5">  
<p align= "left">
<strong>to preach</strong> The Greek word for "preach" is derived from "euangelion" (gospel). It means to announce or proclaim the good news of Christ.
<p align= "left">
<strong>to the Gentiles</strong> In Greek, "Gentiles" is "ethne," referring to non-Jewish nations or people. Paul's ministry had a specific focus on sharing the gospel with those outside the Jewish community.
<p align= "left">
<strong>the unsearchable /unfathomable riches of Christ</strong>: The term "unsearchable" suggests that the riches of Christ are beyond human comprehension or exploration. Paul is emphasizing the depth and abundance of blessings and knowledge found in Christ.  We saw some of these riches in Ephesians chapter 1...
<p align= "left">
The riches of Christ, as God, are in the perfections of his nature, the works of his hands, in his empire and dominion over all, and in his glory. They are immeasurable, boundless, having no limitation, no end, no beginning.

---
<font size="6"> 
9 and to bring to light for everyone what is the plan of the mystery hidden for ages in God, who created all things, <!-- element style="background: floralwhite" --></font>
<font size="5
	  ">  
<p align= "left">
<strong>And to bring to light / to cause all to see</strong>::  "to enlighten" or "to make known."  God is making something previously hidden known to all. He is doing it through the preaching of the gospel.
     <p align= "left">
<font color="#548dd4">     <strong>Romans 10:14</strong> <em>How then will they call on him in whom they have not believed? And how are they to believe in him of whom they have never heard? And how are they to hear without someone preaching?</em></font>
<p align= "left">
<strong>for everyone</strong>: The Greek phrase is "πᾶσιν" (pasin), which means "to all" or "for everyone." It emphasizes the universal nature of what God is revealing to both Jews and Gentiles.
---
<font size="6"> 
9 and to bring to light for everyone what is the plan of the mystery hidden for ages in God, who created all things, <!-- element style="background: floralwhite" --></font>
<font size="5
	  ">  
<p align= "left">
<strong>what is the "plan" of the mystery</strong>: <br>
<Strong> Mystery </strong>(mystērion) denotes a hidden or secret thing. In the New Testament, it often refers to God's plan of salvation, which was concealed but is now being revealed through Christ.
 <p align= "left">
 <strong>Plan vs Fellowship</strong><br>
- <u>"Plan" οἰκονομία (oikonomia)</u> generally means "administration," "stewardship," or "economy." It refers to the management or dispensation of a household or affairs, especially regarding God's plan of salvation.<br>
- <u> "Fellowship" - κοινωνία (koinonia) </u>means "fellowship," "communion," "participation," or "sharing." It relates to the idea of fellowship or sharing within a community.
"Administration," "stewardship," or "plan." Some bible versions have "administrate". It is how God has chosen to "administrate" the working out and revealing the "mystery" of his will.
    <p align= "left">
   -  Fellowship of the mystery - KJV, <br>
   - administration of the mystery - HCSB<br>
    - fellowship of the secret - LSB<br>
    - God's secret plan - the mystery that has been hidden     - NET<br>
       <p align= "left">
---
    <font size="5"> 
    <p align= "left">
Some manuscripts of Ephesians 3:9 use the word οἰκονομία "plan", while others use κοινωνία "fellowship". This leads to differences in translation based on which manuscript is being used as the source. The choice between these readings has been a subject of debate among scholars. The majority text (Textus Receptus), which was the basis for many traditional translations like the King James Version, generally follows the reading οἰκονομία "plan" or "administration".  

1. **Manuscripts Using οἰκονομία (oikonomia)**:
    - This reading is found in the majority of Greek manuscripts.
    - Significant manuscripts that support οἰκονομία include Codex Sinaiticus (א), Codex Alexandrinus (A), Codex Vaticanus (B), and many others. These are some of the oldest and most respected manuscripts in biblical scholarship.
2. **Manuscripts Using κοινωνία (koinonia)**:
    
    - This variant is less common and is supported by fewer manuscripts.
    - The key manuscript that supports κοινωνία is Codex Bezae (D). Codex Bezae is known for having numerous unique readings, and it often stands alone or with a small minority of manuscripts in these variations.
<p align= "left">
<strong>Contextual Implications</strong><br>
- Using οἰκονομία "plan" emphasizes God's management or dispensation of the mysteries of Christ, highlighting the idea that God has an orderly plan for revealing His purposes in Christ.<br><br>
- Using κοινωνία, "fellowship" on the other hand, might emphasize the shared participation or fellowship in the mystery of Christ, focusing more on the communal aspect of God's revelation and the shared nature of the Christian faith.
---
    <font size="6"> 
    <p align= "left">
    <font size="6"> 
    9 and to bring to light for everyone what is the plan  of the mystery hidden for ages in God, who created all things, <!-- element style="background: floralwhite" --></font>
     <font size="5"> 
<p align= "left">
<strong>hidden for ages</strong>: The Greek means "throughout the ages" or "in past generations." It underscores that this mystery had been concealed for a long time.
    <p align= "left">
<font color="#7f7f7f">    <strong>Romans 16:25</strong>   <em>Now to him who is able to strengthen you according to my gospel and the preaching of Jesus Christ, according to the revelation of the mystery that was kept secret for long ages</em></font>
        <p align= "left">
The mystery that was kept hidden and then revealed in Christ. This mystery is God's plan of salvation, particularly how it extends to both Jews and Gentiles. Why does God hide it through the ages? Four reasons to consider:

1. **Fulfillment of Prophecy**: The Old Testament contains many prophecies about the coming Messiah and the salvation of the nations. However, the full understanding of these prophecies was not clear until the coming of Christ. The life, death, and resurrection of Jesus Christ revealed the fullness of these prophecies.
    
2. **God’s Sovereign Plan**: God, in His sovereignty, chose the appropriate time to reveal this mystery. God unfolds His plans at the perfect time. The "fullness of time" mentioned in Galatians 4:4 speaks to this concept.
    
3. **Progressive Revelation**: The Bible shows a pattern of progressive revelation, where God reveals His will and purposes gradually over time. The revelation of the mystery of Christ can be seen as the climax of this revelation.
    
4. **Teaching and Learning**: The unfolding nature of God's revelation is also educational. It teaches faith and trust in God’s promises and plans, even when they are not fully understood.
---
<font size="5"> 
<p align= "left">
<strong>in God</strong>: This phrase emphasizes that the mystery was hidden within God's divine purpose and wisdom. In God.
<p align= "left">
<strong>who created all things</strong>  God created all things. The same God who has hidden this mystery throughout the ages according to his divine plan and timing, is the same God who created all things.  
<p align= "left">
Just take a minute and meditate on how the world operates. All the details that depend on perfect timing. <br>
- The universe, our rotation, sun rising. comets path,<br>
- The human body, an embroyo forming. the body comes together in a very precise order  and timing of development.
There is a pattern and rhythm that operates all around us and we constantly seek to grasp those patterns and paths in science, in math, relationships.  The world seems like a chaotic and wild place but in truth it operates like clock work that even sin becomes a slave to serve God's greater purposes.  <br>
- Historical events, all historical events timing. Our life events. God's timing.
    <p align= "left">
We are reminded that God as the Creator of ALL things. This emphasizes His sovereignty and creative power.  By linking the mystery of salvation to the Creator of all things, Paul emphasizes the sovereignty and wisdom of God. It underscores that the same God who meticulously designed and created the universe had a plan for redemption from the beginning. This connection between creation and redemption highlights God's power and wisdom in orchestrating a cohesive and purposeful plan that spans all of history.
    <p align= "left">
There is an amazing consistency in the purposes of God. This reminder serves to affirm the consistency of God’s purpose throughout the entirety of Scripture. From creation through to the revelation of the mystery in Christ, there is a continuous thread of God's redemptive work. It reminds believers that the Gospel is not an afterthought or a plan B, but was always part of God's eternal purpose.
---
<font size="6"> 
<p align= "left">
10 so that through the church the manifold wisdom of God might now be made known to the rulers and authorities in the heavenly places. <!-- element style="background: floralwhite" --></font>
<font size="6">  
<p align= "left">
<strong>so that through the church</strong>: This part of the verse emphasizes that God's purpose (as revealed in the previous verse) is accomplished through the Church. The church is the body of Christ, through which he works in this world collectively through its members. The church is the theatre for the display of the manifold wisdom and glory of God. <br><br>Watch out for negative attutides and critical spirit about the church! The church is the display case for the glory of God. The church is the beloved work of God. 
---
<font size="6"> 
10 so that through the church the manifold wisdom of God might now be made known to the rulers and authorities in the heavenly places. <!-- element style="background: floralwhite" --></font>
<font size="5">  
<p align= "left">
<strong>the manifold wisdom of God</strong>: " The ancient Greek word polupoikilos, has the ideas of intricacy, complexity, and great beauty. It signifies that God's wisdom is rich, diverse, and multi-dimensional. This is the grand purpose of Paul's Ministry, to make known the manifold, multi-dimensional wisdom of God.
    <p align= "left">
    John Piper - Wisdom," in the Bible, "is knowing the greatest goal in any situation, and the best way to achieve that goal." 
<p align= "left">
The wisdom of God is so deep and wide that He does not and cannot grow wiser. The only way for God to become wiser is for something to enter His mind that hasn't been there before. Romans 11:36
<p align= "left">
Lindskey - "God's wisdom is one and yet can be termed multifarious because it weaves a thousand apparantly tangled threads into one glorious pattern."
<p align= "left">
<strong>might now be made known</strong>: Or "might be revealed."   It refers to God's divine plan or arrangement for the universe. Paul highlights the purpose of the Church in revealing God's wisdom. 

---
<font size="5">  
<p align= "left">

<strong>to the rulers and authorities in the heavenly places</strong>:  Here we get a glimpse into the plan of God that He is displaying his wisdom to the rules and authorities in the heavenly places, through the church. God has a particular audience in mind and it's not just us. 
    <p align= "left">
	<strong>1 Peter 1:12 </strong>"It was revealed to them that they were serving not themselves but you, in the things that have now been announced to you through those who preached the good news to you by the Holy Spirit sent from heaven, things into which angels long to look.""
    <p align= "left">
Angels have a keen interest in the gospel and the salvation of humanity. It implies that they are learning about God's plan of salvation through the proclamation of the gospel by humans. Angels may marvel at the depth of God's wisdom and love revealed in the redemption of humanity.
    <p align= "left">
	<strong>1 Cor. 11:10</strong>"That is why a wife ought to have a symbol of authority on her head, because of the angels."
	    <p align= "left">
	<strong>1 Corinthians 4:9 :</strong> "For I think that God has exhibited us apostles as last of all, like men sentenced to death, because we have become a spectacle to the world, to angels, and to men."
    <p align= "left">
<strong>1Ti 5:21</strong>I charge you before God and the Lord Jesus Christ and the elect angels that you observe these things without prejudice, doing nothing with partiality. 
---
<font size="5">  
<p align= "left">
Paul speaks of how apostles and believers are a spectacle to both the world and angels. The passage suggests that angels are observing the unfolding of God's plan in the lives of believers. BUT...
<p align= "left">
These are then likely demonic powers, demonic rules and authorities in the heavenly realms (whom God has allowed to go their own way for his own purposes) but he is displaying his manifold wisdom, a portion of his mystery to them.
<p align= "left">
Made a spectical of them triumphing over them by the cross. 
<p align= "left">
Go back to the first verse, they would not have crucified Christ had they known.
<p align= "left">
God is teaching (if they could be taught) God is making a spectecle of them. Remeber Psalms 23, in the presence of my enemies, my cup runs over. We are to declare the excellencies of God. 
<p align= "left">
The Ephesian believers lived in a superstitious culture that feared the dark principlalities and powers and had all these rites and sacrifices to ward off evil spirits. 
---

<font size="5">  
<p align= "left">
"Of course, God also wants to reveal this wisdom to the church. But in the big picture, God doesn’t use the angels to reveal His wisdom to the saints, but He does use the saints to reveal His wisdom to the angelic beings, both faithful and fallen angels. This reminds us that we are called for something far greater than our own individual salvation and sanctification. We are called to be the means by which God teaches the universe a lesson, and a beautiful lesson."" - Guzik
<p align= "left">
“What then have they to learn from us? Ah, they have to learn something which makes them watch us with wonder and with awe. They see in us indeed all our weakness, and all our sin. But they see a nature which, wrecked by itself, was yet made in the image of their God and ours. And they see this God at work upon that wreck to produce results not only wonderful in themselves but doubly wonderful because of the conditions.” (Moule)
<p align= "left">
Sometimes Christians get the crazy idea that God saved them and works in their life because they are somehow such great people. The angels see right through this. We might believe that it is because of us; the angels know better. We may think our lives are small and insignificant; the angels know better. We may doubt our high standing, seating in heavenly places; the angels see this spiritual reality with eyes wide open.
<p align= "left">
 “It is as if a great drama is being enacted. History is the theatre, the world is the stage, and the church members in every land are the actors. God himself has written the play, and he directs and produces it. Act by act, scene by scene, the story continues to unfold. But who are the audience? They are the cosmic intelligences, the principalities and powers in the heavenly places.” (Stott)

---
 11 This was according to the eternal purpose that he has realized in Christ Jesus our Lord, <!-- element style="background: floralwhite" --></font>
<font size="5">  
<p align= "left">
<strong>This was according to the eternal purpose</strong>:  This is an "eternal" or "age-lasting purpose or intention. It is not temporary but everlasting and divine.  Once again, this reminds us of the consistency of God's purposes.  The Gospel is not an afterthought or a plan B, but was always part of God's eternal purpose.
    <p align= "left">
<strong>that he has realized/accomplished/carried out</strong>:  God has accomplished or enacted this purpose. It is finished.  Jesus sat down at the right hand of God. It may still be playing out to us, but God has accomplished what He intended to accomplish from the very foundation of the world. Everything has been set in motion and released. Wait for it like a bowling ball that has been released and is headed down the alley to make it's strike.  God's word has gone out.
    <p align= "left">
    <p align= "left">
<strong>in Christ Jesus our Lord</strong>: This eternal purpose has been accomplished/carried out through Christ Jesus, who is  Lord.  In the work of Christ, the Word of God.
---
<font size="6"> 
12 in whom we have boldness and access with confidence through our faith in him. <!-- element style="background: floralwhite" --></font>
<font size="5">  
<p align= "left">
<strong>in whom</strong>: This phrase refers to Christ Jesus, as mentioned in the previous verse (Ephesians 3:11). Everything discussed in this verse is connected to our relationship with Christ.
    <p align= "left">
<strong>we have boldness</strong>  "Boldness" means confidence, openness, frankness or freedom of speech. In our relationship with Christ, we have the confidence to approach God. 
  <p align= "left">
"<em>The word for boldness has the idea of “freedom of speech.” We have the freedom to express ourselves before God, without fear or shame. “The Greek word ‘parresia’ translated by ‘boldness’ means really ‘free speech’ - that is, the speaking of all. It is the blessed privilege of prayer.” (Gaebelein)</em>
  <p align= "left">
Boldness in prayer also comes from understanding God's nature as loving, merciful, and gracious. Knowing that God is willing to listen and respond to prayers encourages believers to approach Him openly and honestly.Boldness in prayer implies freedom from fear and uncertainty. It's not about demanding or commanding God, but rather about having the assurance that God is sovereign and good, and that He cares for His children.
      <p align= "left">
<strong>and access</strong>: "approach" or "admission." Through Christ, we have the privilege of approaching God.  The right to enter. The right to obtain or make use of or take advantage of his promises. But like all rights, they can be forfeited if we do not avail ourselves of them.
    <p align= "left">
<strong>with confidence</strong>: This phrase emphasizes that we can come before God with assurance and trust with certainty. To be confident means to be full of hopefulness that events will be favorable. It is with boldness and confidence that we come before God with our prayers certain of his wisdom and kindness towards us.
   <p align= "left"> 
<strong>through our faith in him</strong> :The basis of our boldness and access—it is through faith, our faith in Christ. Faith is the means by which we approach God with confidence.  <br>
Faith is never the basis or the reason for justification, but only the channel through which God works His redeeming grace. 
---
<font size="5">
<p align= "left">   
<strong>MacArthur</strong>sums up the significance of<u> access</u>  ([prosagoge] writing that "Those who once were socially and spiritually alienated are in Christ united with God and with each other. Because they have Christ they have both peace and access in one Spirit to the Father. They have an Introducer who presents them at the heavenly throne of God, before whom they can come at any time. They can now come to God as their own Father, knowing that He no longer judges or condemns but only forgives and blesses. Even His discipline is an act of love, given to cleanse and restore His precious children to purity and spiritual richness.
<p align= "left">
<font color="#7f7f7f"><strong>Hebrews 10:19-22</strong> - <em>Since therefore, brethren, we have confidence to enter the holy place by the blood of Jesus, by a new and living way which He inaugurated for us through the veil, that is, His flesh, and since we have a great priest over the house of God, let us draw near with a sincere heart in full assurance of faith, having our hearts sprinkled clean from an evil conscience and our bodies washed with pure water.</em></font>
<font color="#7f7f7f"><p align= "left"></font>
<font color="#7f7f7f"><strong>Hebrews 4:15-16</strong>-<em>For we do not have a high priest who cannot sympathize with our weaknesses, but One who has been tempted in all things as we are, yet without sin. Let us therefore draw near with confidence to the throne of grace, that we may receive mercy and may find grace to help in time of need.</em></font>
---
<font size="6"> 13 So I ask you not to lose heart over what I am suffering for you, which is your glory.<!-- element style="background: floralwhite" --></font>
<font size="5">  
<p align= "left">
<strong>So I ask you</strong>: Paul, is addressing the Ephesian believers, making a request or appeal to them.
<p align= "left">    
<strong>not to lose heart</strong>: The phrase "lose heart" conveys the idea of becoming discouraged or disheartened.
    <p align= "left">
<strong>over what I am suffering for you</strong>: Paul is referring to the hardships and sufferings he is enduring for the sake of the Ephesian believers and the spread of the Gospel. He is writing from his first Roman imprisonment for the sake of the Gospel. 
    <p align= "left">
<strong>which is your glory</strong> This part of the verse suggests that Paul's suffering is connected to the believers' glory. It may seem paradoxical, but it emphasizes the redemptive nature of suffering in Christ.
---
<font size="5">
<p align= "left">  
<strong>F F Bruce</strong> - Gentile Christians, who recognized him as their apostle, the champion of their liberty, might well be dismayed at the thought of his being in chains, deprived of his freedom to move around for the advancement of the gospel and the strengthening of the churches. But let them not lose heart: he was as completely engaged in their interests under his present restraint as he had been when he was at liberty. Indeed, if they could only see the significance of his arrest and imprisonment, they would understand that, in the providence of God, their interests were promoted and not endangered thereby. Instead of being bewildered and discouraged, they would rejoice. If it was an honor for Paul to be Christ’s prisoner on the Gentiles’ behalf, it was an honor for the Gentiles themselves. 
<p align= "left">  
<strong>Thielman</strong> "" During this period more than a few Christians in Ephesus must have wondered from time to time whether their commitment to the God of the gospel was a mistake. With their refusal to participate in the imperial cult or to sacrifice to the local deities, had they only succeeded in angering the gods who had placed Rome in power? Were Paul’s troubles—and their own—a result of Christianity’s demand for exclusive loyalty to the God of the Jews and his Messiah? A large part of the purpose of Ephesians may well be to urge such discouraged Christians to remember who the God they worship is and what he is doing through his Messiah and the Messiah’s people, the church. They worship the Creator of the universe who is now, through Christ and the church, putting the universe back together after the ravages of sin."
<p align= "left">  
<strong>Wayne Barber</strong> explains "It means "to grow weary, to be discouraged, to be faint hearted." It also carries another idea. It means "to turn cowardly and to give into the influences of evil that are around you." It is almost as if Paul is saying,"Listen, I am in prison, yes, and my imprisonment is on your behalf. Now don’t you go and lose heart. I certainly haven’t lost heart. Look at the marvel of our salvation. Don’t you grow weary. Don’t become faint hearted. Don’t give in to the consequences and the temptations of evil that are all around you." (**Ed note**: this would be a reasonable interpretation in view of the fact that he is about to begin his discourse charging them to walk worthy of their calling, and not like they used to walk as godless heathens).
---
END READING<br>
<font size="6">  
Ephesians 3:8-13
<font size="5">  
<p align= "Justify">
3 For this reason  I, Paul, a prisoner of Christ Jesus on behalf of you Gentiles— 2 assuming that you have heard of the stewardship of God's grace that was given to me for you, 3 how the mystery was made known to me by revelation, as I have written briefly.  4 When you read this, you can perceive my insight into the mystery of Christ, 5 which was not made known to the sons of men in other generations as it has now been revealed to his holy apostles and prophets by the Spirit. 6 This mystery is that the Gentiles are fellow heirs, members of the same body, and partakers of the promise in Christ Jesus through the gospel.
<p align= "Justify">
7 Of this gospel I was made a minister according to the gift of God's grace, which was given me by the working of his power. <font color="#548dd4">8 To me, though I am the very least of all the saints, this grace was given, to preach to the Gentiles the unsearchable riches of Christ, 9 and to bring to light for everyone what is the plan of the mystery hidden for ages in God, who created all things, 10 so that through the church the manifold wisdom of God might now be made known to the rulers and authorities in the heavenly places. 11 This was according to the eternal purpose that he has realized in Christ Jesus our Lord, 12 in whom we have boldness and access with confidence through our faith in him. 13 So I ask you not to lose heart over what I am suffering for you, which is your glory.</font><p align= "Justify">

---
CLOSING PRAYER 
==
---